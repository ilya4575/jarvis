# Jarvis Android Assistant — Документация проекта

**Версия:** 3.2.0 (versionCode 10)  
**Коммит:** `279a147`  
**APK:** `jarvis 3.2.apk` (arm64-v8a, debug-подпись, 32 MB)  
**Язык:** Kotlin / Android (minSdk 29, targetSdk 34)

---

## 1. О проекте

Jarvis — это Android-ассистент с голосовым вводом,支持кой нескольких LLM-провайдеров (Gemini, Groq, OpenRouter, Custom, Puter, Perchance), локальной моделью (llama.cpp), Dynamic Island (всплывающий островок), автономным агентом управления телефоном, генерацией изображений и Function Calling.

Приложение состоит из слоёв:

| Слой | Назначение | Ключевые файлы |
|------|-----------|----------------|
| **UI** | Экраны чата, настроек, голосового ввода, Dynamic Island | `ui/chat/`, `ui/cloud/`, `ui/voice/`, `ui/island/` |
| **Координация** | Управление чатами, режимами, агентным циклом, генерацией | `feature/chat/ChatCoordinator.kt` |
| **Инференс** | Вызов LLM (локальный + облачный), сбор системного промпта | `core/inference/`, `core/cloud/` |
| **Агент** | Управление Android-устройством (открытие приложений, тапы, ввод) | `feature/agent/`, `core/agent/` |
| **Голос (STT/TTS)** | Распознавание речи и озвучка ответов | `feature/voice/`, `ui/voice/` |
| **Данные** | База сообщений, настройки, зашифрованное хранение ключей | `data/db/`, `core/prefs/` |

---

## 2. Архитектура по модулям

### 2.1. ChatMode — поведенческие режимы чата

Файл: `core/inference/ChatMode.kt`

Перечисление режимов, которые пользователь выбирает рядом с кнопкой "+" в чате:

- **NORMAL** ("Обычный помощник") — универсальный режим, температура по умолчанию.
- **CODER** ("Кодер") — для программирования, температура 0.25, промпт требует чистый рабочий код в блоках ```язык.
- **ADULT_ROLEPLAY** ("18+ флирт") — романтический/откровенный режим, температура 0.85.

Каждый новый чат всегда начинается в режиме NORMAL (без возрастных gate-диалогов). Режим сохраняется за чатом в базе.

### 2.2. ChatCoordinator — мозг чата

Файл: `feature/chat/ChatCoordinator.kt`

Координирует:
- Мультичат (список чатов, переключение, удаление, очистка).
- 20–50 сообщений в контексте + rolling summary старых частей (сжатие памяти).
- Пер-чат режим (ChatMode) с разной температурой и системным промптом.
- Живой «Думает…» трейс с этапами рассуждения модели.
- Генерацию изображений (`/фото` или естественный запрос "сделай фото…") через api-gen → Perchance → Pollinations.
- Автономный агент (5–50 шагов) с возможностью паузы и продолжения пользователем.
- MathEvaluator — локальный точный расчёт математических выражений без LLM.

### 2.3. InferenceEngine / GenerationConfig

Файл: `core/inference/InferenceEngine.kt`

Абстракция над движком генерации:
- `HybridInferenceEngine` выбирает между локальной моделью (llama.cpp) и облачным провайдером.
- `GenerationConfig` содержит все параметры: температура, maxTokens, длина ответа, тон, системный промпт, режим чата, размер контекста, инструменты агента, Function Calling tools, image generation.

### 2.4. CloudLlmClient — облачные провайдеры

Файл: `core/cloud/CloudLlmClient.kt`

Поддерживает 4 провайдера через потоковый SSE:
- **Gemini** (AI Studio + Vertex Express с авто-фейловером)
- **Groq** (Llama + Vision, TPM-aware)
- **OpenRouter** (ретрат cascade на бесплатные модели, извлечение reasoning_content)
- **Custom** (до 10 пользовательских OpenAI-/Anthropic-совместимых endpoints)

Каждый провайдер имеет метод `test*Key()` для проверки подключения на экране настроек.

### 2.5. LlamaInferenceEngine — локальная модель

Файл: `core/inference/LlamaInferenceEngine.kt`

Обёртка над нативной библиотекой `libjarvis_llama.so` (llama.cpp, arm64-v8a). Собирается через CMake/Ninja. Поддерживает:
- Загрузку профиля модели (GGUF).
- Генерацию с потоковыми токенами (`onToken`).
- Vision (мультимодальные модели с mmproj).
- Построение системного промпта и шаблонов промптов (Gemma3, Qwen3, Qwen3.5 Thinking).

### 2.6. AgentTools — автономный агент Android

Файлы: `core/agent/AgentTools.kt`, `feature/agent/AndroidAgentToolExecutor.kt`

Позволяет модели управлять телефоном через команды:
- `open_app`, `list_apps`, `open_url`, `open_search`, `open_settings`
- `set_timer`, `set_alarm`
- `get_device_info`, `get_screen` (чтение элементов экрана)
- `tap_text`, `tap_xy`, `type_text`, `scroll`, `press_key`, `wait`

Требуются Спецвозможности Android (Accessibility) для нажатий внутри чужих приложений. Агент работает до 50 шагов с возможностью паузы и продолжения.

### 2.7. RichTextFormatter — рендеринг сообщений

Файл: `ui/common/RichTextFormatter.kt`

Рендерит markdown в чат-пузыри:
- `**bold**`, `*italic*`, `` `inline code` ``, `###` заголовки, списки.
- Структурированные маркеры `[[ACTION]]`, `[[WARN]]`, `[[OK]]` с векторными иконками (нулевые эмодзи в интерфейсе).
- Фenced-блоки кода ```язык с тёмным фоном, моношириной и языком (режим Кодер).
- В 18+ режиме скобочные действия `(обнимает)` рендерятся курсивом.

### 2.8. OfflineVoiceEngine — голосовой ввод (STT)

Файл: `feature/voice/OfflineVoiceEngine.kt`

Использует Android `SpeechRecognizer` с `RecognizerIntent.EXTRA_PREFER_OFFLINE` (предпочитает офлайн-распознавание). Поддерживает:
- Android нативное распознавание.
- Groq Whisper (через облако).
- Vosk (локальная модель `libvosk.so`).

⚠️ **Важно:** runtime-проверка микрофона и распознавания на реальном устройстве не проводилась. Жалобы на STT можно подтвердить только после установки APK на телефон.

### 2.9. GrokTtsClient — xAI Grok TTS

Файл: `feature/voice/GrokTtsClient.kt`

Клиент xAI Text-to-Speech (`POST https://api.x.ai/v1/tts`, Bearer API key, параметры `text`, `voice_id`, `language`). Требует собственного API key пользователя. Настройки (ключ, voice_id, переключатель Android/Grok TTS) находятся на странице API (CloudApiSettingsFragment).

### 2.10. Dynamic Island (overlay)

Файлы: `feature/overlay/IslandForegroundService.kt`, `res/layout/overlay_dynamic_island.xml`

Всплывающий островок (как на iPhone) с ответом ассистента, аватаром и анимацией мышления. Исправлена ошибка инфлейта (テーマ-зависимые атрибуты заменены на безопасные), сервис защищён от падения всего приложения при ошибке overlay.

### 2.11. Данные и настройки

- `core/prefs/JarvisPreferences.kt` — SharedPreferences с ключами API, профилями моделей, настройками агента, изображения, голосового ввода.
- `data/db/ChatDatabase.kt` — SQLite (Room-подобная обёртка) для сообщений, сессий, резюме, путей к изображениям.
- Ключи API хранятся с AES-256-GCM шифрованием.

---

## 3. Ключевые исправления v3.2.0

1. **Исправлен crash при запуске overlay** — `InflateException` в `IslandForegroundService` из-за неразрешимых theme-атрибутов `?attr/selectableItemBackgroundBorderless`. Заменены на безопасные фоновые ресурсы. Ошибка инфлейта теперь логируется и останавливает только сервис, не падая приложение.
2. **Добавлен переключатель локального TTS / xAI Grok TTS** на странице API с полями xAI API key и `voice_id` (дефолт `eve`).
3. **Улучшен голосовой ввод (STT)** — включен `EXTRA_PREFER_OFFLINE`, уточнены подписи режимов Android/Groq Whisper/Vosk.
4. **Версия:** `versionCode 10`, `versionName 3.2.0`.

---

## 4. Как собирать APK

### Требования
- **JDK 17** (проект собирается на `JavaVersion.VERSION_17`)
- **Android SDK**: platform-tools, build-tools 34.0.0, platform android-34, CMake 3.22.1, NDK 27
- **Gradle** 8.7 (wrapper уже в репозитории)

### Шаги
```bash
cd /home/user/jarvis

# Настройка окружения (пример)
export JAVA_HOME=/путь/к/jdk-17
export ANDROID_SDK_ROOT=/путь/к/android-sdk
export ANDROID_HOME=$ANDROID_SDK_ROOT
export GRADLE_USER_HOME=/путь/к/gradle-home

# Создать local.properties
echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties

# Собрать APK
./gradlew assembleDebug --no-daemon --max-workers=1 --console=plain
```

Готовый APK появится в: `app/build/outputs/apk/debug/app-debug.apk`

### Установка на устройство
```bash
adb install -r "jarvis 3.2.apk"
```

⚠️ APK подписан Android Debug-сертификатом. Если на устройстве уже установлена другая версия Jarvis с другой подписью, необходимо сначала удалить старую версию (`adb uninstall ru.jarvis.assistant`).

---

## 5. Структура репозитория (рабочая версия v3.2.0)

```
/home/user/jarvis/
├── app/
│   ├── build.gradle.kts          # версия 10 / 3.2.0, minSdk 29, targetSdk 34
│   └── src/main/
│       ├── java/ru/jarvis/assistant/
│       │   ├── JarvisApplication.kt        # точка входа, инициализация всех компонентов
│       │   ├── core/
│       │   │   ├── inference/
│       │   │   │   ├── InferenceEngine.kt      # конфиг генерации, состояния движка
│       │   │   │   ├── ChatMode.kt             # режимы чата (Обычный/Кодер/18+)
│       │   │   │   ├── GenerationConfig.kt     # параметры генерации
│       │   │   │   ├── LlamaInferenceEngine.kt # локальная llama.cpp
│       │   │   │   └── NativeLlamaBridge.kt    # JNI к нативной библиотеке
│       │   │   ├── cloud/
│       │   │   │   ├── CloudLlmClient.kt       # Gemini/Groq/OpenRouter/Custom
│       │   │   │   ├── HybridInferenceEngine.kt# выбор движка (локальный/облачный)
│       │   │   │   ├── PuterApiClient.kt       # Puter AI
│       │   │   │   └── PerchanceWebViewBridge.kt# генерация картинок Perchance
│       │   │   ├── agent/
│       │   │   │   └── AgentTools.kt           # парсер инструментов агента
│       │   │   ├── chat/
│       │   │   │   ├── ChatContextManager.kt   # контекст + резюме
│       │   │   │   └── ImageIntentDetector.kt  # детекция запросов фото
│       │   │   ├── math/
│       │   │   │   └── MathEvaluator.kt        # локальный калькулятор
│       │   │   ├── models/
│       │   │   │   └── ModelProfile.kt         # профили моделей
│       │   │   └── prefs/
│       │   │       └── JarvisPreferences.kt    # настройки + шифрование ключей
│       │   ├── data/
│       │   │   └── db/
│       │   │       └── ChatDatabase.kt         # SQLite для сообщений/сессий
│       │   ├── feature/
│       │   │   ├── chat/
│       │   │   │   └── ChatCoordinator.kt      # координатор чата + агентный цикл
│       │   │   ├── overlay/
│       │   │   │   └── IslandForegroundService.kt
│       │   │   ├── voice/
│       │   │   │   ├── OfflineVoiceEngine.kt   # STT (Android SpeechRecognizer)
│       │   │   │   ├── GrokTtsClient.kt        # xAI TTS
│       │   │   │   └── LocalTtsSpeaker.kt      # локальный TTS
│       │   │   └── agent/
│       │   │       └── AndroidAgentToolExecutor.kt
│       │   └── ui/
│       │       ├── chat/
│       │       │   ├── ChatFragment.kt         # экран чата
│       │       │   └── ChatAdapter.kt          # адаптер сообщений
│       │       ├── cloud/
│       │       │   └── CloudApiSettingsFragment.kt  # настройки API / TTS
│       │       └── common/
│       │           └── RichTextFormatter.kt    # рендеринг markdown в UI
│       └── res/
│           ├── layout/
│           │   ├── overlay_dynamic_island.xml  # островок
│           │   ├── fragment_chat.xml
│           │   └── item_chat_message.xml
│           └── values/
├── build.gradle.kts              # корневой Gradle
├── gradlew                       # Gradle wrapper
└── local.properties              # создаётся вручную (sdk.dir)
```

---

## 6. Ограничения и известные нюансы

| Пункт | Детали |
|-------|--------|
| **STT на устройстве** | Исправления внесены, но runtime-проверка микрофона и распознавания не проводилась. Подтвердить устранение жалобы можно только после установки APK на телефон. |
| **xAI Grok TTS** | Требует собственного API key от пользователя. Без ключа функция недоступна. |
| **Подпись APK** | Android Debug. При установке поверх версии с другой подписью — удалить старую версию сначала. |
| **Сборка** | Требует JDK 17 и Android SDK. На машинах с Java 11 сборка не пройдёт. |

---

## 7. Файлы в архиве

| Файл | Описание |
|------|----------|
| `jarvis 3.2.apk` | Готовый APK v3.2.0 (arm64-v8a, debug) |
| `DOCUMENTATION.md` | Эта документация |
| `app/src/main/java/...` | Полный исходный код рабочей версии v3.2.0 |
| `app/build.gradle.kts` | Конфигурация сборки (версия 10 / 3.2.0) |
