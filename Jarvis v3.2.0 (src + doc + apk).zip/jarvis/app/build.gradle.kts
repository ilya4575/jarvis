import java.io.File
import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val llamaCppCommit = "b1b770d90d94cad9e9ea5b993bdbc383a522fb28"
val llamaCppTarballSha256 = "ae8556670b17c25931cd39eb7c95617650eaf6091bbcff206750583ddde1acb4"
val llamaCppDirProp = (project.findProperty("jarvisLlamaCppDir") as String?)
    ?: System.getenv("JARVIS_LLAMA_CPP_DIR")
val resolvedLlamaCppDir: File = if (!llamaCppDirProp.isNullOrBlank()) {
    File(llamaCppDirProp)
} else {
    layout.buildDirectory.dir("third_party/llama.cpp-$llamaCppCommit").get().asFile
}

val prepareLlamaCpp by tasks.registering {
    description = "Downloads and verifies pinned llama.cpp v1.0.0 source if JARVIS_LLAMA_CPP_DIR is not set."
    outputs.dir(resolvedLlamaCppDir)
    doLast {
        val cmakeFile = File(resolvedLlamaCppDir, "CMakeLists.txt")
        if (cmakeFile.exists()) {
            logger.lifecycle("Using llama.cpp source at ${resolvedLlamaCppDir.absolutePath}")
            return@doLast
        }
        val parentDir = resolvedLlamaCppDir.parentFile
        parentDir.mkdirs()
        val archiveFile = File(parentDir, "llama.cpp-$llamaCppCommit.tar.gz")
        val downloadUrl = "https://github.com/ggml-org/llama.cpp/archive/$llamaCppCommit.tar.gz"
        if (!archiveFile.exists()) {
            logger.lifecycle("Downloading pinned llama.cpp ($llamaCppCommit) from $downloadUrl ...")
            URL(downloadUrl).openStream().use { input ->
                archiveFile.outputStream().use { output -> input.copyTo(output) }
            }
        }
        val digest = MessageDigest.getInstance("SHA-256")
        archiveFile.inputStream().use { input ->
            val buf = ByteArray(65536)
            while (true) {
                val r = input.read(buf)
                if (r <= 0) break
                digest.update(buf, 0, r)
            }
        }
        val actualSha = digest.digest().joinToString("") { "%02x".format(it) }
        if (!actualSha.equals(llamaCppTarballSha256, ignoreCase = true)) {
            archiveFile.delete()
            throw GradleException(
                "SHA-256 mismatch for llama.cpp archive! Expected $llamaCppTarballSha256, got $actualSha"
            )
        }
        resolvedLlamaCppDir.mkdirs()
        project.exec {
            commandLine("tar", "-xzf", archiveFile.absolutePath, "--strip-components=1", "-C", resolvedLlamaCppDir.absolutePath)
        }
        logger.lifecycle("Verified & extracted llama.cpp v1.0.0 to ${resolvedLlamaCppDir.absolutePath}")
    }
}

android {
    namespace = "ru.jarvis.assistant"
    compileSdk = 34
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "ru.jarvis.assistant"
        minSdk = 29
        targetSdk = 34
        versionCode = 10
        versionName = "3.2.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DANDROID_STL=c++_shared",
                    "-DANDROID_PLATFORM=android-29",
                    "-DJARVIS_LLAMA_CPP_DIR=${resolvedLlamaCppDir.absolutePath}",
                    "-DCMAKE_BUILD_TYPE=Release"
                )
                cppFlags += listOf("-std=c++17", "-O2", "-fexceptions", "-frtti")
            }
        }

        buildConfigField("String", "ABI_LABEL", "\"ARM64 (arm64-v8a)\"")
        buildConfigField("String", "LLAMA_CPP_VERSION", "\"v1.0.0 ($llamaCppCommit)\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    packaging {
        jniLibs {
            useLegacyPackaging = false
            excludes += listOf(
                "lib/armeabi-v7a/**",
                "lib/x86/**",
                "lib/x86_64/**",
                "lib/mips/**"
            )
        }
    }

    testOptions {
        unitTests {
            isReturnDefaultValues = true
        }
    }
}

tasks.configureEach {
    if (name.startsWith("configureCMake") || name.startsWith("buildCMake")) {
        dependsOn(prepareLlamaCpp)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.drawerlayout:drawerlayout:1.2.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.6")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // HTTP client ONLY for explicit user-triggered model downloads & optional update HEAD checks
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Offline Russian Speech Recognition (Apache-2.0)
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.18.1@aar")

    // Unit tests
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
    testImplementation("org.json:json:20240303")
}
