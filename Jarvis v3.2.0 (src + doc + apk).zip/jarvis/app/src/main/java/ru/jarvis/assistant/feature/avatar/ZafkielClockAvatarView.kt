package ru.jarvis.assistant.feature.avatar

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import ru.jarvis.assistant.R
import java.io.File
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Circular character avatar with:
 *  - Built-in Kurumi Tokisaki artwork (or user photo),
 *  - Native animated GIF / WebP playback while thinking (Android 9+ AnimatedImageDrawable),
 *  - 60-FPS golden Zafkiel clockwork ring, rotating hands, crimson-gold aura & time embers while thinking!
 * Zero battery usage when idle (animator + GIF stop immediately when `setThinking(false)`).
 */
class ZafkielClockAvatarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val imageView: ImageView
    private var staticBitmap: Bitmap? = null
    private var loadedStaticPath: String? = null
    private var loadedGifPath: String? = null
    private var thinkingGifDrawable: Drawable? = null

    private var kurumiTheme: Boolean = false
    private var isThinking: Boolean = false
    private var animPhase: Float = 0f // 0..1 continuous cycle
    private var animator: ValueAnimator? = null

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val handPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val gearPath = Path()
    private val arcRect = RectF()
    private var sweepPaint: Paint? = null
    private var lastSweepRadius: Float = -1f

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false

        imageView = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER)
        addView(imageView, lp)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val pad = (min(w, h) * 0.10f).toInt().coerceAtLeast(2)
        val lp = (imageView.layoutParams as? LayoutParams) ?: LayoutParams(w, h, Gravity.CENTER)
        lp.setMargins(pad, pad, pad, pad)
        imageView.layoutParams = lp
        lastSweepRadius = -1f
    }

    /**
     * Loads avatar media cleanly from current preferences & AvatarManager.
     */
    fun bindMedia(
        staticImageFile: File?,
        thinkingGifFile: File?,
        kurumiThemeEnabled: Boolean
    ) {
        this.kurumiTheme = kurumiThemeEnabled

        // 1. Static portrait
        val staticPath = staticImageFile?.takeIf { it.exists() && it.length() > 0L }?.absolutePath
        if (staticPath != loadedStaticPath) {
            loadedStaticPath = staticPath
            staticBitmap = if (staticPath != null) {
                runCatching { BitmapFactory.decodeFile(staticPath) }.getOrNull()
            } else null
        }

        // 2. Thinking GIF / WebP
        val gifPath = thinkingGifFile?.takeIf { it.exists() && it.length() > 0L }?.absolutePath
        if (gifPath != loadedGifPath) {
            stopGifIfRunning()
            loadedGifPath = gifPath
            thinkingGifDrawable = if (gifPath != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                runCatching {
                    val src = ImageDecoder.createSource(File(gifPath))
                    ImageDecoder.decodeDrawable(src)
                }.getOrNull()
            } else null
        }

        applyCurrentDrawable()
        invalidate()
    }

    fun setThinking(thinking: Boolean) {
        if (isThinking == thinking) return
        isThinking = thinking
        applyCurrentDrawable()

        if (thinking) {
            startThinkingAnimator()
        } else {
            stopThinkingAnimator()
            imageView.scaleX = 1f
            imageView.scaleY = 1f
            invalidate()
        }
    }

    private fun applyCurrentDrawable() {
        val gif = thinkingGifDrawable
        if (isThinking && gif != null) {
            imageView.setImageDrawable(gif)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && gif is AnimatedImageDrawable) {
                gif.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                gif.start()
            }
            return
        }
        stopGifIfRunning()
        val bmp = staticBitmap
        when {
            bmp != null -> imageView.setImageBitmap(bmp)
            kurumiTheme -> imageView.setImageResource(R.drawable.kurumi_avatar_default)
            else -> imageView.setImageResource(R.drawable.ic_jarvis_avatar_default)
        }
    }

    private fun stopGifIfRunning() {
        val gif = thinkingGifDrawable ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && gif is AnimatedImageDrawable) {
            if (gif.isRunning) gif.stop()
        }
    }

    private fun startThinkingAnimator() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3600L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                animPhase = anim.animatedValue as Float
                val breath = 1f + 0.042f * sin(animPhase * Math.PI * 4.0).toFloat()
                imageView.scaleX = breath
                imageView.scaleY = breath
                invalidate()
            }
            start()
        }
    }

    private fun stopThinkingAnimator() {
        animator?.cancel()
        animator = null
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopThinkingAnimator()
        stopGifIfRunning()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            super.dispatchDraw(canvas)
            return
        }
        val cx = w / 2f
        val cy = h / 2f
        val outerR = min(w, h) / 2f
        val innerR = outerR * 0.80f

        // 1. Soft glow behind avatar when thinking (or subtle golden rim in Kurumi idle mode)
        if (isThinking) {
            val pulse = 0.55f + 0.45f * sin(animPhase * Math.PI * 4.0).toFloat()
            haloPaint.strokeWidth = outerR * 0.14f
            haloPaint.color = if (kurumiTheme) {
                Color.argb((75 + 95 * pulse).toInt(), 225, 29, 72) // Crimson aura
            } else {
                Color.argb((65 + 80 * pulse).toInt(), 96, 165, 250) // Cobalt aura
            }
            canvas.drawCircle(cx, cy, outerR * 0.88f, haloPaint)
        } else if (kurumiTheme) {
            ringPaint.strokeWidth = (outerR * 0.055f).coerceAtLeast(1.6f)
            ringPaint.color = Color.argb(170, 245, 190, 70) // Subtle antique gold rim
            canvas.drawCircle(cx, cy, outerR * 0.85f, ringPaint)
        }

        // 2. Draw the circular portrait / GIF inside
        super.dispatchDraw(canvas)

        if (!isThinking) return

        if (kurumiTheme) {
            drawZafkielClockOverlay(canvas, cx, cy, outerR, innerR)
        } else {
            drawStandardThinkingRing(canvas, cx, cy, outerR)
        }
    }

    private fun drawZafkielClockOverlay(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        outerR: Float,
        innerR: Float
    ) {
        val angleDeg = animPhase * 360f
        val clockR = outerR * 0.91f

        // A. Subtle dark-gold vignette rim so ticks stand out sharply over any portrait/GIF
        ringPaint.strokeWidth = (outerR * 0.075f).coerceAtLeast(2.0f)
        ringPaint.color = Color.argb(145, 20, 6, 12)
        canvas.drawCircle(cx, cy, clockR, ringPaint)

        // B. Rotating golden Zafkiel gear ring (16 ornate teeth)
        canvas.save()
        canvas.rotate(angleDeg, cx, cy)
        ringPaint.strokeWidth = (outerR * 0.048f).coerceAtLeast(1.5f)
        ringPaint.color = Color.parseColor("#FFD54F")
        canvas.drawCircle(cx, cy, clockR, ringPaint)

        val teeth = 16
        tickPaint.strokeWidth = (outerR * 0.045f).coerceAtLeast(1.4f)
        tickPaint.color = Color.parseColor("#F59E0B")
        for (i in 0 until teeth) {
            val rad = Math.toRadians((i * 360.0) / teeth)
            val cosA = cos(rad).toFloat()
            val sinA = sin(rad).toFloat()
            val r0 = clockR - outerR * 0.01f
            val r1 = outerR * 0.99f
            canvas.drawLine(cx + cosA * r0, cy + sinA * r0, cx + cosA * r1, cy + sinA * r1, tickPaint)
        }
        canvas.restore()

        // C. 12 Antique Roman-style hour ticks around dial (counter-rotating slowly for mystical time feel)
        canvas.save()
        canvas.rotate(-angleDeg * 0.5f, cx, cy)
        for (i in 0 until 12) {
            val rad = Math.toRadians(i * 30.0)
            val cosA = cos(rad).toFloat()
            val sinA = sin(rad).toFloat()
            val isCardinal = (i % 3 == 0)
            tickPaint.strokeWidth = if (isCardinal) (outerR * 0.06f).coerceAtLeast(1.8f) else (outerR * 0.032f).coerceAtLeast(1.1f)
            tickPaint.color = if (isCardinal) Color.parseColor("#FFF3B0") else Color.argb(215, 250, 204, 21)
            val rOuter = clockR - outerR * 0.04f
            val rInner = if (isCardinal) clockR - outerR * 0.18f else clockR - outerR * 0.12f
            canvas.drawLine(
                cx + cosA * rInner,
                cy + sinA * rInner,
                cx + cosA * rOuter,
                cy + sinA * rOuter,
                tickPaint
            )
            if (isCardinal) {
                particlePaint.color = Color.parseColor("#FF2E63")
                canvas.drawCircle(cx + cosA * clockR, cy + sinA * clockR, (outerR * 0.048f).coerceAtLeast(1.5f), particlePaint)
            }
        }
        canvas.restore()

        // D. Delicate translucent golden Zafkiel hands sweeping around the clock face
        // Minute hand (fast clockwise) & Hour hand (slower counter-clockwise — Kurumi's time manipulation!)
        val minRad = Math.toRadians((angleDeg * 2.0 - 90.0))
        val hourRad = Math.toRadians((-angleDeg + 30.0))

        handPaint.strokeWidth = (outerR * 0.042f).coerceAtLeast(1.3f)
        handPaint.color = Color.argb(215, 255, 224, 102)
        canvas.drawLine(
            cx + cos(minRad).toFloat() * (innerR * 0.58f),
            cy + sin(minRad).toFloat() * (innerR * 0.58f),
            cx + cos(minRad).toFloat() * (clockR * 0.96f),
            cy + sin(minRad).toFloat() * (clockR * 0.96f),
            handPaint
        )

        handPaint.strokeWidth = (outerR * 0.052f).coerceAtLeast(1.5f)
        handPaint.color = Color.argb(220, 244, 63, 94) // Crimson hour hand accent
        canvas.drawLine(
            cx + cos(hourRad).toFloat() * (innerR * 0.62f),
            cy + sin(hourRad).toFloat() * (innerR * 0.62f),
            cx + cos(hourRad).toFloat() * (clockR * 0.92f),
            cy + sin(hourRad).toFloat() * (clockR * 0.92f),
            handPaint
        )

        // E. 3 orbiting crimson-gold time embers
        for (p in 0 until 3) {
            val orbitRad = Math.toRadians(angleDeg * (1.5 + p * 0.5) + p * 120.0)
            val px = cx + cos(orbitRad).toFloat() * (outerR * 0.94f)
            val py = cy + sin(orbitRad).toFloat() * (outerR * 0.94f)
            particlePaint.color = if (p % 2 == 0) Color.parseColor("#FFD54F") else Color.parseColor("#FF2E63")
            canvas.drawCircle(px, py, (outerR * 0.055f).coerceAtLeast(1.8f), particlePaint)
        }
    }

    private fun drawStandardThinkingRing(canvas: Canvas, cx: Float, cy: Float, outerR: Float) {
        val r = outerR * 0.90f
        if (sweepPaint == null || lastSweepRadius != r) {
            lastSweepRadius = r
            sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = (outerR * 0.07f).coerceAtLeast(2.2f)
                strokeCap = Paint.Cap.ROUND
                shader = SweepGradient(
                    cx, cy,
                    intArrayOf(
                        Color.parseColor("#38BDF8"),
                        Color.parseColor("#A855F7"),
                        Color.parseColor("#F43F5E"),
                        Color.parseColor("#38BDF8")
                    ),
                    null
                )
            }
        }
        canvas.save()
        canvas.rotate(animPhase * 360f * 2f, cx, cy)
        arcRect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(arcRect, 0f, 300f, false, sweepPaint!!)
        canvas.restore()
    }
}
