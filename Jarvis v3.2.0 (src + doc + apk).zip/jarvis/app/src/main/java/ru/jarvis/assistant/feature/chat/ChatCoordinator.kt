package ru.jarvis.assistant.feature.chat

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ru.jarvis.assistant.core.agent.AgentToolExecutor
import ru.jarvis.assistant.core.agent.AgentToolParser
import ru.jarvis.assistant.core.chat.ChatContextManager
import ru.jarvis.assistant.core.chat.ImageIntentDetector
import ru.jarvis.assistant.core.chat.ImageSceneMemory
import ru.jarvis.assistant.core.chat.NaturalPhotoIntent
import ru.jarvis.assistant.core.chat.StoredMessageForContext
import ru.jarvis.assistant.core.cloud.ApiGenStyles
import ru.jarvis.assistant.core.cloud.ImageGenRequest
import ru.jarvis.assistant.core.cloud.ImageQualityMode
import ru.jarvis.assistant.core.cloud.PerchanceImageResult
import ru.jarvis.assistant.core.cloud.PerchanceWebViewBridge
import ru.jarvis.assistant.core.inference.ChatMode
import ru.jarvis.assistant.core.inference.ChatTurn
import ru.jarvis.assistant.core.inference.EngineState
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.GenerationResult
import ru.jarvis.assistant.core.inference.InferenceEngine
import ru.jarvis.assistant.core.inference.LlamaInferenceEngine
import ru.jarvis.assistant.core.math.MathEvaluator
import ru.jarvis.assistant.data.db.ChatHistoryStore
import ru.jarvis.assistant.data.db.ChatMessageEntity
import ru.jarvis.assistant.data.db.ChatSessionEntity
import java.util.concurrent.atomic.AtomicBoolean

data class AgentLimitPromptState(
    val sessionId: Long,
    val messageId: Long,
    val stepsExecuted: Int,
    val currentLimit: Int,
    val goalSummaryRu: String,
    val completedActions: List<String>,
    val workingHistory: List<ChatTurn>,
    val nextPrompt: String,
    val effectiveConfig: GenerationConfig,
    val thinkingTraceLines: List<String>
)

data class ChatUiState(
    val activeSessionId: Long = 1L,
    val activeSessionTitle: String = "Новый чат",
    val activeMode: ChatMode = ChatMode.NORMAL,
    val sessions: List<ChatSessionEntity> = emptyList(),
    val messages: List<ChatMessageEntity> = emptyList(),
    val isGenerating: Boolean = false,
    val liveStreamingText: String = "",
    val statusBannerRu: String? = null,
    val agentActionCounterRu: String? = null,
    val agentLimitPrompt: AgentLimitPromptState? = null,
    val perchanceVerifyPromptTick: Long = 0L
)

data class ImageGenDefaults(
    val qualityMode: ImageQualityMode = ImageQualityMode.FAST,
    val style: String? = null,
    val resolution: String = "768x768"
)

/**
 * Coordinates multi-chat local history, per-chat ChatMode (A5), 20..50 message memory + rolling
 * summary (A6/C2), persisted live «Думает…» trace for every assistant reply (C1), natural + `/фото`
 * image generation with per-chat scene memory (Phase 9), deterministic math, and the 5..50-step
 * autonomous Android agent loop (A8).
 */
class ChatCoordinator(
    private val store: ChatHistoryStore,
    private val engine: InferenceEngine,
    private val toolExecutor: AgentToolExecutor? = null,
    private val agentMaxStepsProvider: () -> Int = { DEFAULT_AGENT_STEP_LIMIT },
    private val contextWindowProvider: () -> Int = { ChatContextManager.DEFAULT_CONTEXT_MESSAGES },
    private val perchanceImageGenerator: (suspend (prompt: String, resolution: String) -> PerchanceImageResult)? = null,
    private val imageOrchestrator: (suspend (request: ImageGenRequest, onStatus: (String) -> Unit) -> PerchanceImageResult)? = null,
    private val imageDefaultsProvider: () -> ImageGenDefaults = { ImageGenDefaults() }
) {
    private val _uiState: MutableStateFlow<ChatUiState>
    val uiState: StateFlow<ChatUiState>

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val cancelRequested = AtomicBoolean(false)

    var onReplySettled: ((String) -> Unit)? = null

    /**
     * A8: Called when an autonomous agent task fails unrecoverably after opening an external app,
     * so MainActivity can return to foreground and show the user what went wrong (never silent!).
     */
    var onAgentNeedsReturnToApp: ((errorSummaryRu: String) -> Unit)? = null

    /**
     * A2: Called when the user attempts to use unverified Perchance so UI opens the verification dialog.
     */
    var onPerchanceVerifyRequired: (() -> Unit)? = null

    init {
        val sessions = ensureSessions()
        val first = sessions.first()
        _uiState = MutableStateFlow(
            ChatUiState(
                activeSessionId = first.id,
                activeSessionTitle = first.title,
                activeMode = first.mode,
                sessions = sessions,
                messages = store.getMessages(first.id)
            )
        )
        uiState = _uiState.asStateFlow()
    }

    private fun ensureSessions(): List<ChatSessionEntity> {
        val existing = store.listSessions()
        if (existing.isNotEmpty()) return existing
        store.createSession("Новый чат", ChatMode.NORMAL)
        return store.listSessions()
    }

    fun refreshHistory() {
        val sessions = ensureSessions()
        val currentId = _uiState.value.activeSessionId
        val active = sessions.firstOrNull { it.id == currentId } ?: sessions.first()
        _uiState.value = _uiState.value.copy(
            activeSessionId = active.id,
            activeSessionTitle = active.title,
            activeMode = active.mode,
            sessions = sessions,
            messages = store.getMessages(active.id)
        )
    }

    /** A5: Every new chat ALWAYS begins in ChatMode.NORMAL («Обычный помощник») with clean context. */
    fun createNewChat(): ChatSessionEntity {
        cancelGeneration()
        _isGenerating.value = false
        val current = _uiState.value
        if (current.messages.isEmpty()) {
            val existing = current.sessions.firstOrNull { it.id == current.activeSessionId }
            if (existing != null) {
                if (existing.mode != ChatMode.NORMAL) {
                    setActiveSessionMode(ChatMode.NORMAL)
                }
                return existing.copy(mode = ChatMode.NORMAL)
            }
        }
        val session = store.createSession("Новый чат", ChatMode.NORMAL)
        val sessions = store.listSessions()
        _uiState.value = ChatUiState(
            activeSessionId = session.id,
            activeSessionTitle = session.title,
            activeMode = ChatMode.NORMAL,
            sessions = sessions,
            messages = emptyList(),
            isGenerating = false
        )
        return session
    }

    /** A5: Changes and persists the behavioral mode for the active chat only. */
    fun setActiveSessionMode(mode: ChatMode) {
        val sid = _uiState.value.activeSessionId
        store.updateSessionMode(sid, mode)
        val sessions = store.listSessions()
        _uiState.value = _uiState.value.copy(
            activeMode = mode,
            sessions = sessions
        )
    }

    fun selectChat(sessionId: Long) {
        cancelGeneration()
        _isGenerating.value = false
        val sessions = store.listSessions()
        val target = sessions.firstOrNull { it.id == sessionId } ?: sessions.first()
        _uiState.value = ChatUiState(
            activeSessionId = target.id,
            activeSessionTitle = target.title,
            activeMode = target.mode,
            sessions = sessions,
            messages = store.getMessages(target.id),
            isGenerating = false
        )
    }

    fun deleteChat(sessionId: Long) {
        cancelGeneration()
        _isGenerating.value = false
        store.deleteSession(sessionId)
        val sessions = store.listSessions()
        val next = sessions.first()
        _uiState.value = ChatUiState(
            activeSessionId = next.id,
            activeSessionTitle = next.title,
            activeMode = next.mode,
            sessions = sessions,
            messages = store.getMessages(next.id),
            isGenerating = false
        )
    }

    fun clearActiveChat() {
        cancelGeneration()
        val sid = _uiState.value.activeSessionId
        store.clearSession(sid)
        store.renameSession(sid, "Новый чат")
        store.updateSessionMode(sid, ChatMode.NORMAL)
        _isGenerating.value = false
        val sessions = store.listSessions()
        _uiState.value = ChatUiState(
            activeSessionId = sid,
            activeSessionTitle = "Новый чат",
            activeMode = ChatMode.NORMAL,
            sessions = sessions,
            messages = emptyList(),
            isGenerating = false
        )
    }

    fun clearHistory() {
        cancelGeneration()
        store.clearHistory()
        _isGenerating.value = false
        val sessions = store.listSessions()
        val first = sessions.first()
        _uiState.value = ChatUiState(
            activeSessionId = first.id,
            activeSessionTitle = first.title,
            activeMode = first.mode,
            sessions = sessions,
            messages = emptyList(),
            isGenerating = false
        )
    }

    fun cancelGeneration() {
        cancelRequested.set(true)
        engine.cancelGeneration()
        _uiState.value = _uiState.value.copy(agentLimitPrompt = null)
    }

    fun dismissAgentLimitPrompt() {
        _uiState.value = _uiState.value.copy(agentLimitPrompt = null)
    }

    /** Edits a user message, removes subsequent messages in that chat, and resends. */
    suspend fun editAndResend(
        userMessageId: Long,
        newText: String,
        config: GenerationConfig
    ): ChatMessageEntity {
        val sid = _uiState.value.activeSessionId
        val existing = store.getMessages(sid).firstOrNull { it.id == userMessageId }
        val photo = existing?.imagePath
        store.deleteMessagesFrom(sid, userMessageId)
        refreshHistory()
        return sendMessage(rawUserText = newText, imagePath = photo, config = config)
    }

    /** Regenerates an assistant reply by re-running the immediately preceding user message. */
    suspend fun regenerateResponse(
        assistantMessageId: Long,
        config: GenerationConfig
    ): ChatMessageEntity? {
        val sid = _uiState.value.activeSessionId
        val msgs = store.getMessages(sid)
        val idx = msgs.indexOfFirst { it.id == assistantMessageId }
        if (idx <= 0) return null
        val target = msgs[idx]
        if (!target.imagePrompt.isNullOrBlank()) {
            return generateImageInChat(target.imagePrompt, retryMessageId = target.id)
        }
        val prevUser = msgs.subList(0, idx).lastOrNull { it.role == "user" } ?: return null
        store.deleteMessagesFrom(sid, prevUser.id)
        refreshHistory()
        return sendMessage(rawUserText = prevUser.text, imagePath = prevUser.imagePath, config = config)
    }

    fun getActiveImageSceneMemory(): ImageSceneMemory {
        val sid = _uiState.value.activeSessionId
        val session = store.listSessions().firstOrNull { it.id == sid }
        return ImageSceneMemory.fromJson(session?.imageSceneMemory)
    }

    fun resetActiveImageSceneMemory() {
        val sid = _uiState.value.activeSessionId
        store.updateSessionImageSceneMemory(sid, "")
        refreshHistory()
    }

    private fun hasImageGenerator(): Boolean =
        imageOrchestrator != null || perchanceImageGenerator != null

    private suspend fun executeImageRequest(
        req: ImageGenRequest,
        onStatus: (String) -> Unit
    ): PerchanceImageResult {
        val orch = imageOrchestrator
        if (orch != null) return orch(req, onStatus)
        val legacy = perchanceImageGenerator
        if (legacy != null) return legacy(req.prompt, req.resolution)
        return PerchanceImageResult(
            ok = false,
            errorRu = "Генератор изображений не настроен."
        )
    }

    /**
     * Generates an image directly in the active chat (used by `/фото ...`, retry button, or
     * natural photo requests when no text LLM is connected).
     * Automatically enriches the prompt with the chat's ImageSceneMemory and persists the new frame.
     */
    suspend fun generateImageInChat(
        prompt: String,
        resolution: String? = null,
        qualityMode: ImageQualityMode? = null,
        style: String? = null,
        useSceneMemory: Boolean = true,
        retryMessageId: Long? = null,
        displayUserMessage: String? = null
    ): ChatMessageEntity {
        val cleanPrompt = prompt.trim()
        require(cleanPrompt.isNotBlank()) { "Укажите описание изображения" }

        val defaults = imageDefaultsProvider()
        val resolvedRes = resolution?.takeIf { it.isNotBlank() } ?: defaults.resolution
        val resolvedQuality = qualityMode ?: defaults.qualityMode
        val resolvedStyle = style ?: defaults.style

        val sid = _uiState.value.activeSessionId
        val existing = store.getMessages(sid)
        val session = store.listSessions().firstOrNull { it.id == sid }
        val sceneMem = ImageSceneMemory.fromJson(session?.imageSceneMemory)
        val recentChatTexts = existing
            .filter { it.role == "user" || it.role == "assistant" }
            .takeLast(4)
            .map { it.text }

        val effectivePrompt = ImageSceneMemory.buildEnrichedPrompt(
            userRequest = cleanPrompt,
            memory = sceneMem,
            recentChatTexts = recentChatTexts,
            useSceneMemory = useSceneMemory
        ).ifBlank { cleanPrompt }

        if (existing.isEmpty()) {
            store.renameSession(sid, "Фото: ${cleanPrompt.take(30)}")
        }

        val traceLines = mutableListOf(
            "• Режим фото: ${resolvedQuality.labelRu} ($resolvedRes)",
            "• Стиль: ${ApiGenStyles.labelFor(resolvedStyle)}",
            "• Промпт: «$cleanPrompt»"
        )
        if (useSceneMemory && !sceneMem.isEmpty()) {
            traceLines.add("• Память сцены чата: учтено ${sceneMem.frameCount} пред. кадр(ов)")
        }

        val targetMsg: ChatMessageEntity = if (retryMessageId != null) {
            store.updateMessageText(retryMessageId, "Генерирую фото…")
            store.updateMessageThinking(retryMessageId, traceLines.joinToString("\n"))
            store.updateMessageImagePrompt(retryMessageId, cleanPrompt)
            store.getMessages(sid).first { it.id == retryMessageId }
        } else {
            store.insertMessage(
                role = "user",
                text = displayUserMessage?.takeIf { it.isNotBlank() } ?: "/фото $cleanPrompt",
                sessionId = sid
            )
            store.insertMessage(
                role = "assistant",
                text = "Генерирую фото…",
                sessionId = sid,
                thinkingLog = traceLines.joinToString("\n"),
                imagePrompt = cleanPrompt
            )
        }

        if (!hasImageGenerator()) {
            val err = "Генератор изображений сейчас недоступен."
            store.updateMessageText(targetMsg.id, err)
            store.updateMessageThinking(targetMsg.id, "• Ошибка: генератор не инициализирован.")
            emitSettledState(sid)
            return store.getMessages(sid).last { it.id == targetMsg.id }
        }

        return runImageGenerationIntoMessage(
            sessionId = sid,
            messageId = targetMsg.id,
            rawPrompt = cleanPrompt,
            effectivePrompt = effectivePrompt,
            resolution = resolvedRes,
            qualityMode = resolvedQuality,
            style = resolvedStyle,
            sceneMemory = sceneMem,
            useSceneMemory = useSceneMemory,
            prefixAssistantReply = null,
            traceLines = traceLines
        )
    }

    /**
     * Generates an image via the 3-stage orchestrator and attaches it directly to [messageId],
     * keeping [prefixAssistantReply] (if an LLM responded naturally) alongside the generated photo.
     */
    private suspend fun runImageGenerationIntoMessage(
        sessionId: Long,
        messageId: Long,
        rawPrompt: String,
        effectivePrompt: String,
        resolution: String,
        qualityMode: ImageQualityMode,
        style: String?,
        sceneMemory: ImageSceneMemory,
        useSceneMemory: Boolean,
        prefixAssistantReply: String?,
        traceLines: MutableList<String>
    ): ChatMessageEntity {
        _isGenerating.value = true
        val sessions = store.listSessions()
        val withPlaceholder = store.getMessages(sessionId).map { m ->
            if (m.id == messageId) m.copy(
                text = prefixAssistantReply?.takeIf { it.isNotBlank() } ?: "Генерирую фото…",
                isImageGenerating = true,
                thinkingLog = traceLines.joinToString("\n")
            ) else m
        }
        _uiState.value = _uiState.value.copy(
            activeSessionId = sessionId,
            sessions = sessions,
            messages = withPlaceholder,
            isGenerating = true,
            statusBannerRu = "Генерация фото…"
        )

        val startMs = System.currentTimeMillis()
        val req = ImageGenRequest(
            prompt = effectivePrompt,
            resolution = resolution,
            qualityMode = qualityMode,
            style = style
        )

        val res = try {
            executeImageRequest(req) { statusText ->
                if (traceLines.lastOrNull() != "• $statusText") {
                    traceLines.add("• $statusText")
                }
                val current = _uiState.value
                val updatedMsgs = current.messages.map { m ->
                    if (m.id == messageId) m.copy(
                        isImageGenerating = true,
                        thinkingLog = traceLines.joinToString("\n")
                    ) else m
                }
                _uiState.value = current.copy(
                    messages = updatedMsgs,
                    statusBannerRu = statusText
                )
            }
        } finally {
            _isGenerating.value = false
        }
        val elapsedSec = ((System.currentTimeMillis() - startMs) / 1000.0)

        if (res.ok && !res.localFilePath.isNullOrBlank()) {
            var newFrameCount = sceneMemory.frameCount
            if (useSceneMemory) {
                val updatedMem = ImageSceneMemory.recordGeneratedFrame(
                    previous = sceneMemory,
                    userRequest = rawPrompt,
                    style = style ?: res.styleUsed,
                    seed = res.seed
                )
                newFrameCount = updatedMem.frameCount
                store.updateSessionImageSceneMemory(sessionId, ImageSceneMemory.toJson(updatedMem))
            }

            val metaLine = buildString {
                append(res.engineUsed.ifBlank { "api-gen" })
                append(" • ")
                append(resolution)
                if (!res.styleUsed.isNullOrBlank()) append(" • ").append(res.styleUsed)
                if (useSceneMemory) append(" • сцена #$newFrameCount")
            }
            val finalCaption = if (!prefixAssistantReply.isNullOrBlank()) {
                prefixAssistantReply.trim()
            } else {
                "Готово ($metaLine)"
            }
            traceLines.add(
                String.format(
                    "• Готово за %.1f сек (%s%s)",
                    elapsedSec,
                    metaLine,
                    res.seed?.let { ", seed: $it" } ?: ""
                )
            )
            if (res.fallbackNotes.isNotEmpty()) {
                traceLines.add("• Переключения: ${res.fallbackNotes.joinToString("; ")}")
            }
            store.updateMessageImagePrompt(messageId, rawPrompt)
            store.updateMessageGeneratedImage(messageId, res.localFilePath, finalCaption)
            store.updateMessageThinking(messageId, traceLines.joinToString("\n"))
            emitSettledState(sessionId, lastReply = finalCaption)
        } else {
            if (res.needsVerification) {
                triggerPerchanceVerifyDialog()
            }
            val errMsg = res.errorRu ?: "Не удалось сгенерировать изображение."
            traceLines.add("• Ошибка генерации: $errMsg")
            if (res.fallbackNotes.isNotEmpty()) {
                traceLines.add("• Детали fallback: ${res.fallbackNotes.joinToString("; ")}")
            }
            val finalErrText = if (!prefixAssistantReply.isNullOrBlank()) {
                "${prefixAssistantReply.trim()}\n\n(Не удалось создать фото: $errMsg)"
            } else {
                "Ошибка генерации: $errMsg"
            }
            store.updateMessageImagePrompt(messageId, rawPrompt)
            store.updateMessageText(messageId, finalErrText)
            store.updateMessageThinking(messageId, traceLines.joinToString("\n"))
            emitSettledState(sessionId, lastReply = finalErrText)
        }

        return store.getMessages(sessionId).last { it.id == messageId }
    }

    suspend fun sendMessage(
        rawUserText: String,
        imagePath: String? = null,
        config: GenerationConfig = GenerationConfig()
    ): ChatMessageEntity {
        val userText = rawUserText.trim().ifEmpty {
            if (imagePath != null) "Опиши это изображение и, если на нём есть текст или задача, аккуратно перепиши и разбери." else ""
        }
        require(userText.isNotBlank()) { "Пустое сообщение" }

        // Phase 9: Explicit slash photo command (`/фото ...`, `/photo ...`, `/картинка ...`, `/нарисуй ...`, `/img ...`)
        val slashPhoto = if (imagePath == null) ImageIntentDetector.parseSlashPhotoCommand(userText) else null
        if (slashPhoto != null) {
            val sid = _uiState.value.activeSessionId
            val existingMsgs = store.getMessages(sid)
            val session = store.listSessions().firstOrNull { it.id == sid }
            val sceneMem = ImageSceneMemory.fromJson(session?.imageSceneMemory)
            val promptToUse = if (slashPhoto.useChatContextIfBlank) {
                ImageIntentDetector.buildFallbackPrompt(
                    userText = userText,
                    intent = NaturalPhotoIntent(isPhotoRequest = true, isSelfieOrSelf = false),
                    recentMessages = existingMsgs.takeLast(4).map { it.text },
                    sceneMemory = sceneMem,
                    assistantName = config.assistantName
                )
            } else {
                slashPhoto.prompt
            }
            return generateImageInChat(
                prompt = promptToUse,
                resolution = slashPhoto.resolutionOverride,
                qualityMode = slashPhoto.qualityOverride,
                displayUserMessage = userText
            )
        }

        val naturalPhotoIntent = ImageIntentDetector.detectNaturalPhotoRequest(
            rawText = userText,
            hasAttachedUserImage = imagePath != null
        )

        cancelRequested.set(false)
        _uiState.value = _uiState.value.copy(agentLimitPrompt = null)

        val sid = _uiState.value.activeSessionId
        val session = store.listSessions().firstOrNull { it.id == sid }
            ?: ChatSessionEntity(sid, "Новый чат")
        val activeMode = session.mode
        val existingMessages = store.getMessages(sid)
        val activeSceneMemory = ImageSceneMemory.fromJson(session.imageSceneMemory)

        // If user asked naturally for a photo ("сделай фотку кота") even when no LLM is loaded,
        // still generate the photo right away instead of showing a "no provider" error!
        if (naturalPhotoIntent.isPhotoRequest &&
            engine.state.value !is EngineState.Ready &&
            hasImageGenerator()
        ) {
            val directPrompt = ImageIntentDetector.buildFallbackPrompt(
                userText = userText,
                intent = naturalPhotoIntent,
                recentMessages = existingMessages.takeLast(4).map { it.text },
                sceneMemory = activeSceneMemory,
                assistantName = config.assistantName
            )
            return generateImageInChat(
                prompt = directPrompt,
                displayUserMessage = userText
            )
        }

        if (existingMessages.isEmpty()) {
            val autoTitle = userText.replace('\n', ' ').trim().take(36)
            store.renameSession(sid, autoTitle)
        }

        // A6 + C2: Assemble 20..50 recent messages + rolling summary of older turns
        val windowSize = ChatContextManager.clampWindowSize(contextWindowProvider())
        val contextAssembly = ChatContextManager.assembleContext(
            allMessages = existingMessages.map { StoredMessageForContext(it.id, it.role, it.text) },
            existingSummary = session.contextSummary,
            existingSummaryUpToId = session.summaryUpToMsgId,
            windowSize = windowSize
        )

        val mathEval = if (imagePath == null) MathEvaluator.tryEvaluateFromMessage(userText) else null
        val mathNote = mathEval?.let { "Точный расчёт: ${it.formattedAnswer}" }

        store.insertMessage(
            role = "user",
            text = userText,
            imagePath = imagePath,
            mathVerifiedNote = null,
            sessionId = sid
        )

        // Pure offline math works even before any LLM is loaded
        if (mathEval != null && engine.state.value !is EngineState.Ready) {
            val replyText = buildString {
                append(mathEval.formattedAnswer)
                if (mathEval.stepsRu.isNotEmpty()) {
                    append("\n\n")
                    mathEval.stepsRu.forEachIndexed { idx, step ->
                        append("${idx + 1}. $step\n")
                    }
                }
            }.trim()
            val saved = store.insertMessage(
                role = "assistant",
                text = replyText,
                mathVerifiedNote = mathNote,
                sessionId = sid,
                thinkingLog = "• Локальный точный математический движок\n• Выражение: ${mathEval.expression} = ${mathEval.formattedAnswer}"
            )
            emitSettledState(sid)
            return saved
        }

        if (engine.state.value !is EngineState.Ready) {
            val saved = store.insertMessage(
                role = "assistant",
                text = "Провайдер пока не подключён. Открой меню → «Провайдеры и API-ключи» и настрой Gemini, Groq, OpenRouter, Custom или Perchance. Для генерации фото напиши /фото описание.",
                sessionId = sid,
                thinkingLog = "• Проверка активного движка: нет подключённых API-провайдеров."
            )
            emitSettledState(sid)
            return saved
        }

        if (imagePath != null && !engine.isVisionReady) {
            val saved = store.insertMessage(
                role = "assistant",
                text = "Модуль зрения не готов. Выберите онлайн-провайдер с поддержкой фото или скачайте mmproj в разделе «Локальные модели».",
                sessionId = sid,
                thinkingLog = "• Ошибка: активный движок не поддерживает изображения."
            )
            emitSettledState(sid)
            return saved
        }

        val traceLines = mutableListOf<String>()
        traceLines.add("• Режим чата: ${activeMode.titleRu}")
        traceLines.add(
            "• Контекст: ${contextAssembly.recentTurns.size} сообщ. (окно $windowSize)" +
                if (contextAssembly.summaryText.isNotBlank()) " + summary старой части" else ""
        )
        if (!activeSceneMemory.isEmpty()) {
            traceLines.add("• Память сцены фото: ${activeSceneMemory.frameCount} кадр(ов)")
        }

        // Refresh rolling summary asynchronously-before-request if older turns crossed threshold
        var effectiveSummary = contextAssembly.summaryText
        if (contextAssembly.shouldRefreshSummary && contextAssembly.olderTurnsToSummarize.isNotEmpty()) {
            traceLines.add("• Обновление краткого резюме старой части диалога (${contextAssembly.olderTurnsToSummarize.size} сообщ.)…")
            effectiveSummary = refreshRollingSummary(
                sessionId = sid,
                previousSummary = session.contextSummary,
                olderTurns = contextAssembly.olderTurnsToSummarize,
                upToMsgId = contextAssembly.newSummaryUpToMessageId,
                baseConfig = config
            )
        }

        val assistantPlaceholder = store.insertMessage(
            role = "assistant",
            text = "…",
            mathVerifiedNote = mathNote,
            sessionId = sid,
            thinkingLog = traceLines.joinToString("\n")
        )

        val toolsActive = toolExecutor != null && config.agentToolsEnabled
        val baseEffectiveConfig = config.copy(
            chatMode = activeMode,
            temperature = activeMode.temperatureHint ?: config.temperature,
            contextSummary = effectiveSummary,
            contextWindowSize = windowSize,
            agentToolsEnabled = toolsActive,
            imageGenerationEnabled = hasImageGenerator(),
            imageSceneSummary = activeSceneMemory.compactSummary()
        ).let { cfg ->
            if (toolsActive) {
                val snap = runCatching { toolExecutor!!.captureContextSnapshot() }.getOrNull()
                if (snap != null) {
                    cfg.copy(
                        installedAppsHint = snap.installedAppNames,
                        accessibilityReady = snap.accessibilityReady
                    )
                } else cfg
            } else cfg
        }

        val initialPrompt = buildString {
            append(userText)
            if (mathEval != null) {
                append("\n\n[Точный локальный расчёт: ${mathEval.expression} = ${mathEval.formattedAnswer}. Используй этот точный ответ.]")
            }
            if (naturalPhotoIntent.isPhotoRequest && hasImageGenerator()) {
                append("\n\n[Подсказка системы: пользователь просит фото/изображение. Ответь естественно от своего лица — НЕ говори, что не умеешь делать фото — и добавь в конце ответа тег [GEN_IMAGE: подробный визуальный промпт на английском с учётом текущей сцены, внешности и обстановки].]")
            }
        }

        val actionBudget = agentMaxStepsProvider().coerceIn(MIN_AGENT_STEP_LIMIT, MAX_AGENT_STEP_LIMIT)

        return runAgentGenerationLoop(
            sessionId = sid,
            assistantMsgId = assistantPlaceholder.id,
            originalGoal = userText,
            workingHistory = contextAssembly.recentTurns.toMutableList(),
            initialPrompt = initialPrompt,
            initialImagePath = imagePath,
            effectiveConfig = baseEffectiveConfig,
            mathEvalNote = mathEval?.formattedAnswer,
            executedActions = mutableListOf(),
            traceLines = traceLines,
            stepsAlreadyDone = 0,
            stepBudget = actionBudget,
            naturalPhotoIntent = naturalPhotoIntent
        )
    }

    /**
     * A8: Resumes a paused multi-step agent task for [extraSteps] additional actions (5..50).
     */
    suspend fun continueAgentGoal(extraSteps: Int): ChatMessageEntity? {
        val paused = _uiState.value.agentLimitPrompt ?: return null
        val clampedExtra = extraSteps.coerceIn(MIN_AGENT_STEP_LIMIT, MAX_AGENT_STEP_LIMIT)
        cancelRequested.set(false)
        _uiState.value = _uiState.value.copy(agentLimitPrompt = null)

        val traceLines = paused.thinkingTraceLines.toMutableList()
        traceLines.add("• Пользователь разрешил продолжить ещё на $clampedExtra действий.")

        return runAgentGenerationLoop(
            sessionId = paused.sessionId,
            assistantMsgId = paused.messageId,
            originalGoal = paused.goalSummaryRu,
            workingHistory = paused.workingHistory.toMutableList(),
            initialPrompt = paused.nextPrompt,
            initialImagePath = null,
            effectiveConfig = paused.effectiveConfig,
            mathEvalNote = null,
            executedActions = paused.completedActions.toMutableList(),
            traceLines = traceLines,
            stepsAlreadyDone = paused.stepsExecuted,
            stepBudget = paused.stepsExecuted + clampedExtra
        )
    }

    private suspend fun runAgentGenerationLoop(
        sessionId: Long,
        assistantMsgId: Long,
        originalGoal: String,
        workingHistory: MutableList<ChatTurn>,
        initialPrompt: String,
        initialImagePath: String?,
        effectiveConfig: GenerationConfig,
        mathEvalNote: String?,
        executedActions: MutableList<String>,
        traceLines: MutableList<String>,
        stepsAlreadyDone: Int,
        stepBudget: Int,
        naturalPhotoIntent: NaturalPhotoIntent = NaturalPhotoIntent(false)
    ): ChatMessageEntity {
        val toolsActive = toolExecutor != null && effectiveConfig.agentToolsEnabled
        val multiStepUserRequest = AgentToolParser.looksLikeMultiStepRequest(originalGoal)
        val startedMs = System.currentTimeMillis()

        _isGenerating.value = true
        val sessions = store.listSessions()
        val currentSession = sessions.firstOrNull { it.id == sessionId }
        _uiState.value = ChatUiState(
            activeSessionId = sessionId,
            activeSessionTitle = currentSession?.title ?: "Чат",
            activeMode = currentSession?.mode ?: effectiveConfig.chatMode,
            sessions = sessions,
            messages = store.getMessages(sessionId),
            isGenerating = true,
            liveStreamingText = "",
            statusBannerRu = if (initialImagePath != null) "Анализирую фото…" else "Анализирую запрос…",
            agentActionCounterRu = if (stepsAlreadyDone > 0) "$stepsAlreadyDone/$stepBudget" else null
        )

        var currentPrompt = initialPrompt
        var currentImagePath = initialImagePath
        var stepsExecuted = stepsAlreadyDone
        var launchedExternalApp = false
        var finalText = ""
        var pausedAtLimit = false
        var unrecoverableErrorRu: String? = null
        val maxModelRounds = if (toolsActive) (stepBudget - stepsAlreadyDone + 4).coerceAtLeast(1) else 1

        try {
            for (round in 1..maxModelRounds) {
                if (cancelRequested.get()) {
                    traceLines.add("• Выполнение остановлено пользователем.")
                    finalText = formatFinalWithActions("", executedActions, fallback = "Выполнение остановлено.")
                    break
                }

                traceLines.add(
                    if (round == 1 && stepsExecuted == 0) "• Запрос к модели…"
                    else "• Анализ результата и выбор следующего шага (раунд $round, действий: $stepsExecuted/$stepBudget)…"
                )
                updateLiveMessageAndTrace(
                    messageId = assistantMsgId,
                    text = executedActions.joinToString("\n").ifBlank { "…" },
                    thinkingLog = traceLines.joinToString("\n"),
                    statusBanner = if (stepsExecuted > 0) "Шаг $stepsExecuted/$stepBudget • анализирую…" else "Думаю…",
                    counter = if (stepsExecuted > 0) "$stepsExecuted/$stepBudget" else null
                )

                val streamBuf = StringBuilder()
                val modelThoughtBuf = StringBuilder()
                var lastUiUpdateMs = 0L

                val roundConfig = effectiveConfig.copy(
                    onThought = { thoughtPiece ->
                        if (thoughtPiece.isNotEmpty()) {
                            modelThoughtBuf.append(thoughtPiece)
                        }
                    }
                )

                val result = engine.generate(
                    history = workingHistory.toList(),
                    userPrompt = currentPrompt,
                    imagePath = currentImagePath,
                    config = roundConfig
                ) { token ->
                    streamBuf.append(token)
                    val now = System.currentTimeMillis()
                    if (now - lastUiUpdateMs >= 65L) {
                        lastUiUpdateMs = now
                        val rawStream = streamBuf.toString()
                        val inlineThink = extractInlineThinkBlock(rawStream)
                        val cleaned = LlamaInferenceEngine.cleanAssistantOutput(rawStream, keepThinking = false)
                        val withoutTools = if (toolsActive) AgentToolParser.stripToolMarkupForDisplay(cleaned) else cleaned
                        val visible = ImageIntentDetector.stripPhotoTagsForDisplay(withoutTools)
                        val banner = when {
                            toolsActive && AgentToolParser.hasPartialToolTag(cleaned) -> "Подготавливаю действие…"
                            ImageIntentDetector.hasPartialPhotoTag(cleaned) -> "Подготавливаю фото…"
                            else -> null
                        }

                        val liveTrace = buildLiveThinkingText(traceLines, modelThoughtBuf.toString(), inlineThink)
                        val previewText = when {
                            visible.isNotBlank() -> visible
                            executedActions.isNotEmpty() -> executedActions.joinToString("\n")
                            else -> "…"
                        }
                        updateLiveMessageAndTrace(
                            messageId = assistantMsgId,
                            text = previewText,
                            thinkingLog = liveTrace,
                            statusBanner = banner,
                            counter = if (stepsExecuted > 0) "$stepsExecuted/$stepBudget" else null
                        )
                    }
                }

                when (result) {
                    is GenerationResult.Cancelled -> {
                        val partialVisible = if (toolsActive) {
                            AgentToolParser.stripToolMarkupForDisplay(result.partialText.trim())
                        } else result.partialText.trim()
                        traceLines.add("• Остановлено пользователем.")
                        finalText = formatFinalWithActions(partialVisible, executedActions, fallback = "Генерация остановлена.")
                        break
                    }
                    is GenerationResult.Failed -> {
                        val rawReason = result.reasonRu
                        if (rawReason.contains(PerchanceWebViewBridge.PERCHANCE_VERIFY_REQUIRED_TOKEN)) {
                            val cleanReason = rawReason.replace(PerchanceWebViewBridge.PERCHANCE_VERIFY_REQUIRED_TOKEN, "").trim()
                            traceLines.add("• Требуется проверка Perchance (Cloudflare).")
                            finalText = cleanReason
                            triggerPerchanceVerifyDialog()
                            break
                        }
                        traceLines.add("• Ошибка: $rawReason")
                        unrecoverableErrorRu = rawReason
                        finalText = if (mathEvalNote != null) {
                            "$mathEvalNote\n\n($rawReason)"
                        } else {
                            formatFinalWithActions("Ошибка на шаге $stepsExecuted/$stepBudget: $rawReason", executedActions)
                        }
                        break
                    }
                    is GenerationResult.Completed -> {
                        val rawRound = result.text
                        val inlineThink = extractInlineThinkBlock(rawRound)
                        val combinedThink = buildString {
                            if (modelThoughtBuf.isNotBlank()) append(modelThoughtBuf.toString().trim())
                            if (inlineThink.isNotBlank()) {
                                if (isNotEmpty()) append("\n")
                                append(inlineThink)
                            }
                        }.trim()
                        if (combinedThink.isNotEmpty()) {
                            traceLines.add("• Рассуждение модели:\n${combinedThink.take(1200)}")
                        }

                        val cleanedRound = LlamaInferenceEngine.cleanAssistantOutput(rawRound, keepThinking = false)
                        val calls = if (toolsActive) AgentToolParser.parseToolCalls(cleanedRound) else emptyList()
                        val visibleRound = if (toolsActive) {
                            AgentToolParser.stripToolMarkupForDisplay(cleanedRound)
                        } else cleanedRound

                        if (calls.isEmpty() || toolExecutor == null) {
                            val elapsedSec = (System.currentTimeMillis() - startedMs) / 1000.0
                            traceLines.add(String.format("• Готово (действий: %d, время: %.1f сек).", stepsExecuted, elapsedSec))
                            finalText = formatFinalWithActions(visibleRound, executedActions)
                            break
                        }

                        val toolResultBlocks = mutableListOf<String>()
                        var allSucceeded = true
                        var fatalAccessibilityOff = false
                        var lastStepError = ""

                        for (call in calls) {
                            if (cancelRequested.get()) break

                            // A8: Enforce configurable step limit 5..50 cleanly with continuation option!
                            if (stepsExecuted >= stepBudget) {
                                pausedAtLimit = true
                                break
                            }

                            stepsExecuted++
                            val counterStr = "$stepsExecuted/$stepBudget"
                            val banner = "Шаг $counterStr: ${AgentToolParser.statusBannerForTool(call)}"
                            traceLines.add("• [$counterStr] ${AgentToolParser.statusBannerForTool(call)}")

                            val interim = buildString {
                                if (visibleRound.isNotBlank()) append(visibleRound).append("\n\n")
                                if (executedActions.isNotEmpty()) append(executedActions.joinToString("\n")).append("\n")
                                append(banner)
                            }.trim()
                            updateLiveMessageAndTrace(
                                messageId = assistantMsgId,
                                text = interim,
                                thinkingLog = traceLines.joinToString("\n"),
                                statusBanner = banner,
                                counter = counterStr
                            )

                            // Execute with smart transient UI retry for tap_text / type_text when screen is still settling
                            var execRes = toolExecutor.execute(call)
                            if (!execRes.success && (call.name == "tap_text" || call.name == "type_text") &&
                                !execRes.outputForModel.startsWith("BLOCKED_BY_SAFETY") &&
                                !execRes.outputForModel.startsWith("ACCESSIBILITY_")
                            ) {
                                traceLines.add("  ↳ Элемент не сразу найден — жду 700 мс и пробую повторно…")
                                delay(700L)
                                if (!cancelRequested.get()) {
                                    execRes = toolExecutor.execute(call)
                                }
                            }

                            if (execRes.launchedExternalApp) launchedExternalApp = true
                            if (!execRes.success) {
                                allSucceeded = false
                                lastStepError = execRes.summaryRu
                                if (execRes.outputForModel.startsWith("ACCESSIBILITY_")) {
                                    fatalAccessibilityOff = true
                                }
                            }

                            val statusIcon = if (execRes.success) "ОК" else "ОШИБКА"
                            traceLines.add("  ↳ $statusIcon: ${execRes.summaryRu}")

                            val marker = if (execRes.success) "[[ACTION]]" else "[[WARN]]"
                            if (call.name != "wait") {
                                executedActions.add("$marker [$counterStr] ${execRes.summaryRu}")
                            }
                            toolResultBlocks.add("[Результат инструмента ${call.name} (шаг $counterStr)]: ${execRes.outputForModel}")
                        }

                        if (cancelRequested.get()) {
                            traceLines.add("• Выполнение остановлено пользователем на шаге $stepsExecuted/$stepBudget.")
                            finalText = formatFinalWithActions(visibleRound, executedActions, fallback = "Выполнение остановлено.")
                            break
                        }

                        if (fatalAccessibilityOff) {
                            unrecoverableErrorRu = lastStepError
                            traceLines.add("• Остановка: $lastStepError")
                            finalText = formatFinalWithActions(
                                "Не удалось продолжить выполнение (шаг $stepsExecuted/$stepBudget): $lastStepError. " +
                                    "Включите Спецвозможности Android в Меню → «Действия и агенты».",
                                executedActions
                            )
                            break
                        }

                        // Fast-path: single one-shot launch/intent tool with reply already written (and NOT a multi-step goal)
                        val singleOneShot = round == 1 &&
                            calls.size == 1 &&
                            calls.first().name in AgentToolParser.ONE_SHOT_LAUNCH_TOOLS &&
                            allSucceeded &&
                            visibleRound.isNotBlank() &&
                            !multiStepUserRequest

                        if (singleOneShot) {
                            traceLines.add("• Одношаговое действие успешно выполнено.")
                            finalText = formatFinalWithActions(visibleRound, executedActions)
                            break
                        }

                        val nextContinuationPrompt = buildString {
                            append(toolResultBlocks.joinToString("\n"))
                            append("\n\nВыполнено действий: $stepsExecuted из $stepBudget. ")
                            append("Проверь, достигнута ли цель пользователя полностью («$originalGoal»). ")
                            append("Если цель ещё НЕ завершена — проверь экран через get_screen (если нужно) и вызови следующий <tool>. ")
                            append("Если шаг не удался — попробуй разумную альтернативу (прокрутку, поиск, tap_xy). ")
                            append("Если задача полностью выполнена ИЛИ продолжить невозможно — дай понятный финальный ответ пользователю на русском без тегов <tool>.")
                        }

                        workingHistory.add(ChatTurn("user", currentPrompt))
                        workingHistory.add(ChatTurn("assistant", rawRound))
                        currentImagePath = null
                        currentPrompt = nextContinuationPrompt

                        // A8: Reached configured step limit -> DO NOT silently abort; offer user to continue +N actions!
                        if (pausedAtLimit || stepsExecuted >= stepBudget) {
                            traceLines.add("• Достигнут лимит $stepBudget действий — ожидание решения пользователя (Продолжить / Остановить).")
                            finalText = formatFinalWithActions(
                                "Достигнут лимит $stepBudget действий. Вы можете продолжить выполнение ещё на N действий или остановить задачу.",
                                executedActions
                            )
                            val limitPrompt = AgentLimitPromptState(
                                sessionId = sessionId,
                                messageId = assistantMsgId,
                                stepsExecuted = stepsExecuted,
                                currentLimit = stepBudget,
                                goalSummaryRu = originalGoal,
                                completedActions = executedActions.toList(),
                                workingHistory = workingHistory.toList(),
                                nextPrompt = nextContinuationPrompt,
                                effectiveConfig = effectiveConfig,
                                thinkingTraceLines = traceLines.toList()
                            )
                            store.updateMessageText(assistantMsgId, finalText)
                            store.updateMessageThinking(assistantMsgId, traceLines.joinToString("\n"))
                            emitSettledState(sessionId, lastReply = finalText, agentLimitPrompt = limitPrompt)
                            if (launchedExternalApp) {
                                onAgentNeedsReturnToApp?.invoke("Достигнут лимит $stepBudget действий — выберите продолжение в Jarvis.")
                            }
                            return store.getMessages(sessionId).last { it.id == assistantMsgId }
                        }
                    }
                }
            }
        } finally {
            _isGenerating.value = false
        }

        val rawSettledText = finalText.trim().ifEmpty { "Готово." }
        val extractedPhoto = ImageIntentDetector.extractAiPhotoTag(rawSettledText)
        var settledText = extractedPhoto.visibleText
        var autoImagePrompt = extractedPhoto.imagePrompt

        if (!cancelRequested.get() && hasImageGenerator() && unrecoverableErrorRu == null) {
            if (autoImagePrompt == null && naturalPhotoIntent.isPhotoRequest) {
                val sessionNow = store.listSessions().firstOrNull { it.id == sessionId }
                val sceneMemNow = ImageSceneMemory.fromJson(sessionNow?.imageSceneMemory)
                val recentTexts = store.getMessages(sessionId)
                    .filter { it.id != assistantMsgId && (it.role == "user" || it.role == "assistant") }
                    .takeLast(4)
                    .map { it.text }
                autoImagePrompt = ImageIntentDetector.buildFallbackPrompt(
                    userText = originalGoal,
                    intent = naturalPhotoIntent,
                    recentMessages = recentTexts,
                    sceneMemory = sceneMemNow,
                    assistantName = effectiveConfig.assistantName
                )
                traceLines.add("• Авто-фото (по просьбе в чате): ИИ не добавила тег, подхват контекста чата.")
                if (ImageIntentDetector.looksLikeTextOnlyRefusal(settledText)) {
                    settledText = "Вот готовое фото:"
                }
            }

            if (!autoImagePrompt.isNullOrBlank()) {
                val defaults = imageDefaultsProvider()
                val sessionNow = store.listSessions().firstOrNull { it.id == sessionId }
                val sceneMemNow = ImageSceneMemory.fromJson(sessionNow?.imageSceneMemory)
                val recentTexts = store.getMessages(sessionId)
                    .filter { it.id != assistantMsgId && (it.role == "user" || it.role == "assistant") }
                    .takeLast(4)
                    .map { it.text }
                val enriched = ImageSceneMemory.buildEnrichedPrompt(
                    userRequest = autoImagePrompt,
                    memory = sceneMemNow,
                    recentChatTexts = recentTexts,
                    useSceneMemory = true
                ).ifBlank { autoImagePrompt }

                traceLines.add("• ИИ инициировала генерацию фото: «${autoImagePrompt.take(180)}»")
                if (!sceneMemNow.isEmpty()) {
                    traceLines.add("• Память сцены чата: учтено ${sceneMemNow.frameCount} пред. кадр(ов)")
                }
                val captionPrefix = settledText.trim().ifEmpty { "Вот фото:" }
                val generatedMsg = runImageGenerationIntoMessage(
                    sessionId = sessionId,
                    messageId = assistantMsgId,
                    rawPrompt = autoImagePrompt,
                    effectivePrompt = enriched,
                    resolution = defaults.resolution,
                    qualityMode = defaults.qualityMode,
                    style = defaults.style,
                    sceneMemory = sceneMemNow,
                    useSceneMemory = true,
                    prefixAssistantReply = captionPrefix,
                    traceLines = traceLines
                )
                onReplySettled?.invoke(captionPrefix)
                return generatedMsg
            }
        }

        val finalDisplayText = settledText.ifEmpty { "Готово." }
        val finalTrace = traceLines.joinToString("\n")
        store.updateMessageText(assistantMsgId, finalDisplayText)
        store.updateMessageThinking(assistantMsgId, finalTrace)
        emitSettledState(sessionId, lastReply = finalDisplayText)
        onReplySettled?.invoke(finalDisplayText)

        // A8: Never go silent after leaving the app if an unrecoverable failure happened!
        if (unrecoverableErrorRu != null && launchedExternalApp) {
            onAgentNeedsReturnToApp?.invoke("Агент остановился на шаге $stepsExecuted/$stepBudget: $unrecoverableErrorRu")
        }

        return store.getMessages(sessionId).last { it.id == assistantMsgId }
    }

    private suspend fun refreshRollingSummary(
        sessionId: Long,
        previousSummary: String,
        olderTurns: List<ChatTurn>,
        upToMsgId: Long,
        baseConfig: GenerationConfig
    ): String {
        val fallback = ChatContextManager.buildDeterministicSummary(previousSummary, olderTurns)
        val summaryPrompt = ChatContextManager.buildSummarizationPrompt(previousSummary, olderTurns)
        val summaryCfg = baseConfig.copy(
            agentToolsEnabled = false,
            temperature = 0.2f,
            maxTokens = 320,
            chatMode = ChatMode.NORMAL,
            contextSummary = "",
            customSystemPrompt = "Ты — модуль сжатия памяти диалога. Верни только краткий структурированный список фактов на русском."
        )
        val summaryResult = runCatching {
            engine.generate(
                history = emptyList(),
                userPrompt = summaryPrompt,
                imagePath = null,
                config = summaryCfg,
                onToken = {}
            )
        }.getOrNull()

        val finalSummary = when (summaryResult) {
            is GenerationResult.Completed -> {
                LlamaInferenceEngine.cleanAssistantOutput(summaryResult.text, keepThinking = false)
                    .trim()
                    .take(1600)
                    .ifBlank { fallback }
            }
            else -> fallback
        }
        store.updateSessionSummary(sessionId, finalSummary, upToMsgId)
        return finalSummary
    }

    private fun triggerPerchanceVerifyDialog() {
        _uiState.value = _uiState.value.copy(perchanceVerifyPromptTick = System.currentTimeMillis())
        onPerchanceVerifyRequired?.invoke()
    }

    private fun extractInlineThinkBlock(raw: String): String {
        val m = Regex("<think>([\\s\\S]*?)(?:</think>|$)", RegexOption.IGNORE_CASE).find(raw)
        return m?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    private fun buildLiveThinkingText(
        traceLines: List<String>,
        apiThoughts: String,
        inlineThink: String
    ): String = buildString {
        append(traceLines.joinToString("\n"))
        if (apiThoughts.isNotBlank()) {
            append("\n• Мысли модели:\n").append(apiThoughts.trim().take(1200))
        }
        if (inlineThink.isNotBlank()) {
            append("\n• Размышление:\n").append(inlineThink.take(1200))
        }
    }

    private fun formatFinalWithActions(
        visibleText: String,
        actions: List<String>,
        fallback: String = ""
    ): String {
        val text = visibleText.trim()
        if (actions.isEmpty()) return text.ifEmpty { fallback }
        val actionBlock = actions.distinct().joinToString("\n")
        return if (text.isNotEmpty()) "$text\n\n$actionBlock" else actionBlock
    }

    private fun emitSettledState(
        sessionId: Long,
        lastReply: String = "",
        agentLimitPrompt: AgentLimitPromptState? = null
    ) {
        val sessions = store.listSessions()
        val active = sessions.firstOrNull { it.id == sessionId }
        _uiState.value = ChatUiState(
            activeSessionId = sessionId,
            activeSessionTitle = active?.title ?: "Чат",
            activeMode = active?.mode ?: ChatMode.NORMAL,
            sessions = sessions,
            messages = store.getMessages(sessionId),
            isGenerating = false,
            liveStreamingText = lastReply,
            statusBannerRu = null,
            agentActionCounterRu = null,
            agentLimitPrompt = agentLimitPrompt
        )
    }

    private fun updateLiveMessageAndTrace(
        messageId: Long,
        text: String,
        thinkingLog: String,
        statusBanner: String? = null,
        counter: String? = null
    ) {
        val current = _uiState.value
        val updated = current.messages.map { msg ->
            if (msg.id == messageId) msg.copy(text = text, thinkingLog = thinkingLog) else msg
        }
        _uiState.value = current.copy(
            messages = updated,
            liveStreamingText = text,
            statusBannerRu = statusBanner ?: current.statusBannerRu,
            agentActionCounterRu = counter ?: current.agentActionCounterRu
        )
    }

    companion object {
        const val MIN_AGENT_STEP_LIMIT = 5
        const val MAX_AGENT_STEP_LIMIT = 50
        const val DEFAULT_AGENT_STEP_LIMIT = 50
        const val MAX_AGENT_ROUNDS = 50
    }
}
