package ru.jarvis.assistant.feature.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import kotlin.coroutines.resume

data class AccessibilityStepOutcome(
    val success: Boolean,
    val blockedBySafety: Boolean = false,
    val messageRu: String
)

/**
 * Opt-in Android AccessibilityService for Jarvis.
 * - Disabled by default; user must explicitly enable it in Android System Settings.
 * - NEVER logs or uploads background screen events.
 * - Inspects the active target app window (skipping Jarvis's own Dynamic Island overlay)
 *   ONLY when explicitly requested by a user action or AI agent tool call.
 * - Immediately halts on any password, PIN, MFA/OTP, payment, CAPTCHA, or biometric screen.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeInstance = this
        val prefs = JarvisPreferences(applicationContext)
        if (!prefs.accessibilityUserDisabled) {
            prefs.accessibilityMasterSwitch = true
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally passive: never log or inspect background screen events.
    }

    override fun onInterrupt() {
        // Nothing running in background
    }

    override fun onDestroy() {
        if (activeInstance === this) {
            activeInstance = null
        }
        super.onDestroy()
    }

    private fun isMasterSwitchOn(): Boolean =
        JarvisPreferences(applicationContext).accessibilityMasterSwitch

    /**
     * Resolves the foreground target application window, deliberately skipping Jarvis's own
     * Dynamic Island overlay window so screen reading and taps always target the app underneath.
     */
    private fun obtainTargetWindowRoot(): AccessibilityNodeInfo? {
        val ownPkg = applicationContext.packageName
        val allWindows = runCatching { windows }.getOrNull().orEmpty()
        val targetAppWindow = allWindows
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .sortedByDescending { it.isActive }
            .firstOrNull { win ->
                val r = runCatching { win.root }.getOrNull()
                val pkg = r?.packageName?.toString()
                val match = r != null && pkg != null && pkg != ownPkg
                if (!match && r != null) {
                    @Suppress("DEPRECATION")
                    runCatching { r.recycle() }
                }
                match
            }
        if (targetAppWindow != null) {
            val r = runCatching { targetAppWindow.root }.getOrNull()
            if (r != null) return r
        }
        return rootInActiveWindow
    }

    /**
     * Produces a compact, safety-checked snapshot of visible UI elements on the current screen
     * (package name, screen dimensions, clickable/editable/text items with center coordinates).
     */
    fun dumpVisibleScreen(): AccessibilityStepOutcome {
        if (!isMasterSwitchOn()) {
            return AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации в Jarvis выключен. Включите его в Меню → «Действия и права»."
            )
        }
        val root = obtainTargetWindowRoot() ?: return AccessibilityStepOutcome(
            success = false,
            messageRu = "Активное окно недоступно для чтения через Accessibility API."
        )

        return try {
            val safety = inspectNodeTreeForSafety(root)
            if (safety.isSensitiveBlocked) {
                return AccessibilityStepOutcome(
                    success = false,
                    blockedBySafety = true,
                    messageRu = safety.reasonRu ?: "Защищённый экран — чтение заблокировано."
                )
            }

            val dm = resources.displayMetrics
            val pkg = root.packageName?.toString() ?: "unknown"
            val lines = mutableListOf<String>()
            val seen = HashSet<String>()
            val rect = Rect()

            fun walk(node: AccessibilityNodeInfo?, depth: Int) {
                if (node == null || depth > 24 || lines.size >= 60) return
                if (!node.isVisibleToUser) return

                val isPass = node.isPassword
                val text = if (isPass) "" else node.text?.toString()?.trim().orEmpty()
                val desc = if (isPass) "" else node.contentDescription?.toString()?.trim().orEmpty()
                val hint = if (isPass) "" else node.hintText?.toString()?.trim().orEmpty()
                val label = when {
                    text.isNotEmpty() -> text
                    desc.isNotEmpty() -> desc
                    hint.isNotEmpty() -> hint
                    else -> ""
                }.replace('\n', ' ').take(64)

                val clickable = node.isClickable && node.isEnabled
                val editable = node.isEditable && !isPass && node.isEnabled

                if (label.isNotEmpty() || editable) {
                    node.getBoundsInScreen(rect)
                    val cx = rect.centerX()
                    val cy = rect.centerY()
                    if (rect.width() > 4 && rect.height() > 4 && cx in 0..dm.widthPixels && cy in 0..dm.heightPixels) {
                        val kind = when {
                            editable -> "edit"
                            clickable -> "click"
                            else -> "text"
                        }
                        val dedupKey = "$kind|$label|${cx / 24}|${cy / 24}"
                        if (seen.add(dedupKey)) {
                            val display = label.ifEmpty { "(текстовое поле)" }
                            lines.add("[${lines.size + 1}] \"$display\" ($kind, x=$cx, y=$cy)")
                        }
                    }
                }

                for (i in 0 until node.childCount) {
                    walk(node.getChild(i), depth + 1)
                }
            }

            walk(root, 0)

            val summary = buildString {
                append("Приложение на экране: $pkg (разрешение ${dm.widthPixels}x${dm.heightPixels})\n")
                if (lines.isEmpty()) {
                    append("Видимые элементы интерфейса не найдены.")
                } else {
                    append("Видимые элементы (${lines.size}):\n")
                    append(lines.joinToString("\n"))
                }
            }
            AccessibilityStepOutcome(success = true, messageRu = summary)
        } finally {
            @Suppress("DEPRECATION")
            runCatching { root.recycle() }
        }
    }

    /** Backwards-compatible synchronous click (used by ActionsFragment). */
    fun executeFindAndClick(targetText: String): AccessibilityStepOutcome {
        if (!isMasterSwitchOn()) {
            return AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации в Jarvis выключен. Включите его во вкладке «Действия»."
            )
        }

        val root = obtainTargetWindowRoot() ?: return AccessibilityStepOutcome(
            success = false,
            messageRu = "Активное окно недоступно для Accessibility API (возможно, системный или защищённый экран)."
        )

        return try {
            val safety = inspectNodeTreeForSafety(root)
            if (safety.isSensitiveBlocked) {
                return AccessibilityStepOutcome(
                    success = false,
                    blockedBySafety = true,
                    messageRu = safety.reasonRu ?: "Защищённый экран — автоматизация остановлена."
                )
            }

            val node = findMatchingNode(root, targetText)
            if (node == null) {
                return AccessibilityStepOutcome(
                    success = false,
                    messageRu = "Элемент «$targetText» не найден на текущем экране."
                )
            }

            val clickable = findClickableAncestor(node)
            if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return AccessibilityStepOutcome(
                    success = true,
                    messageRu = "Нажат элемент «$targetText»."
                )
            }

            AccessibilityStepOutcome(
                success = false,
                messageRu = "Элемент «$targetText» найден, но недоступен для прямого ACTION_CLICK."
            )
        } finally {
            @Suppress("DEPRECATION")
            runCatching { root.recycle() }
        }
    }

    /**
     * Suspend-capable smart tap: tries ACTION_CLICK on clickable ancestor first,
     * and seamlessly falls back to a real dispatchGesture tap at the element's center bounds.
     */
    suspend fun executeTapText(targetText: String): AccessibilityStepOutcome = withContext(Dispatchers.Main) {
        if (!isMasterSwitchOn()) {
            return@withContext AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации в Jarvis выключен. Включите его в Меню → «Действия и права»."
            )
        }

        val root = obtainTargetWindowRoot() ?: return@withContext AccessibilityStepOutcome(
            success = false,
            messageRu = "Активное окно недоступно для Accessibility API."
        )

        var fallbackCoords: Pair<Float, Float>? = null
        val directResult: AccessibilityStepOutcome? = try {
            val safety = inspectNodeTreeForSafety(root)
            if (safety.isSensitiveBlocked) {
                return@withContext AccessibilityStepOutcome(
                    success = false,
                    blockedBySafety = true,
                    messageRu = safety.reasonRu ?: "Защищённый экран — нажатие запрещено."
                )
            }

            val node = findMatchingNode(root, targetText)
            if (node == null) {
                return@withContext AccessibilityStepOutcome(
                    success = false,
                    messageRu = "Элемент «$targetText» не найден на текущем экране."
                )
            }

            val clickable = findClickableAncestor(node)
            if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                AccessibilityStepOutcome(success = true, messageRu = "Нажат элемент «$targetText».")
            } else {
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (rect.width() > 2 && rect.height() > 2) {
                    fallbackCoords = rect.centerX().toFloat() to rect.centerY().toFloat()
                    null
                } else {
                    AccessibilityStepOutcome(
                        success = false,
                        messageRu = "Элемент «$targetText» найден, но его координаты вне экрана."
                    )
                }
            }
        } finally {
            @Suppress("DEPRECATION")
            runCatching { root.recycle() }
        }

        if (directResult != null) return@withContext directResult

        val (cx, cy) = fallbackCoords ?: return@withContext AccessibilityStepOutcome(
            success = false,
            messageRu = "Не удалось определить координаты элемента «$targetText»."
        )

        val gestured = performGestureTap(cx, cy)
        if (gestured) {
            AccessibilityStepOutcome(
                success = true,
                messageRu = "Нажат элемент «$targetText» (жест x=${cx.toInt()}, y=${cy.toInt()})."
            )
        } else {
            AccessibilityStepOutcome(
                success = false,
                messageRu = "Система отклонила жест нажатия на «$targetText»."
            )
        }
    }

    suspend fun executeTapCoordinates(x: Int, y: Int): AccessibilityStepOutcome = withContext(Dispatchers.Main) {
        if (!isMasterSwitchOn()) {
            return@withContext AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации выключен."
            )
        }
        val root = obtainTargetWindowRoot()
        if (root != null) {
            try {
                val safety = inspectNodeTreeForSafety(root)
                if (safety.isSensitiveBlocked) {
                    return@withContext AccessibilityStepOutcome(
                        success = false,
                        blockedBySafety = true,
                        messageRu = safety.reasonRu ?: "Защищённый экран — нажатие запрещено."
                    )
                }
            } finally {
                @Suppress("DEPRECATION")
                runCatching { root.recycle() }
            }
        }

        val dm = resources.displayMetrics
        val cx = x.coerceIn(4, (dm.widthPixels - 4).coerceAtLeast(4)).toFloat()
        val cy = y.coerceIn(4, (dm.heightPixels - 4).coerceAtLeast(4)).toFloat()
        val ok = performGestureTap(cx, cy)
        if (ok) {
            AccessibilityStepOutcome(success = true, messageRu = "Выполнено нажатие по координатам (${cx.toInt()}, ${cy.toInt()}).")
        } else {
            AccessibilityStepOutcome(success = false, messageRu = "Не удалось выполнить жест нажатия (${cx.toInt()}, ${cy.toInt()}).")
        }
    }

    fun executeInputText(textPayload: String, submit: Boolean = false): AccessibilityStepOutcome {
        if (!isMasterSwitchOn()) {
            return AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации выключен."
            )
        }

        val root = obtainTargetWindowRoot() ?: return AccessibilityStepOutcome(
            success = false,
            messageRu = "Активное окно недоступно."
        )

        return try {
            val safety = inspectNodeTreeForSafety(root)
            if (safety.isSensitiveBlocked) {
                return AccessibilityStepOutcome(
                    success = false,
                    blockedBySafety = true,
                    messageRu = safety.reasonRu ?: "Защищённый экран — ввод текста запрещён."
                )
            }

            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: findFirstEditableNonPassword(root)

            if (focused == null) {
                return AccessibilityStepOutcome(
                    success = false,
                    messageRu = "Не найдено активное текстовое поле (или оно защищено как поле пароля)."
                )
            }

            if (focused.isPassword) {
                return AccessibilityStepOutcome(
                    success = false,
                    blockedBySafety = true,
                    messageRu = "Поле помечено как парольное — ввод запрещён. Введите данные вручную."
                )
            }

            if (!focused.isFocused) {
                focused.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                focused.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }

            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textPayload)
            }
            val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (!ok) {
                return AccessibilityStepOutcome(
                    success = false,
                    messageRu = "Не удалось вставить текст через Accessibility API."
                )
            }

            var submittedNote = ""
            if (submit) {
                val imeSent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                } else false
                submittedNote = if (imeSent) " и отправлен (Enter)" else " (нажмите поиск/отправку отдельно при необходимости)"
            }

            AccessibilityStepOutcome(success = true, messageRu = "Текст вставлен в поле$submittedNote.")
        } finally {
            @Suppress("DEPRECATION")
            runCatching { root.recycle() }
        }
    }

    suspend fun executeScroll(direction: String): AccessibilityStepOutcome = withContext(Dispatchers.Main) {
        if (!isMasterSwitchOn()) {
            return@withContext AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации выключен."
            )
        }
        val root = obtainTargetWindowRoot()
        if (root != null) {
            try {
                val safety = inspectNodeTreeForSafety(root)
                if (safety.isSensitiveBlocked) {
                    return@withContext AccessibilityStepOutcome(
                        success = false,
                        blockedBySafety = true,
                        messageRu = safety.reasonRu ?: "Защищённый экран — прокрутка запрещена."
                    )
                }
            } finally {
                @Suppress("DEPRECATION")
                runCatching { root.recycle() }
            }
        }

        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val (sx, sy, ex, ey) = when (direction.lowercase().trim()) {
            "up" -> arrayOf(w * 0.5f, h * 0.30f, w * 0.5f, h * 0.72f)
            "left" -> arrayOf(w * 0.80f, h * 0.5f, w * 0.20f, h * 0.5f)
            "right" -> arrayOf(w * 0.20f, h * 0.5f, w * 0.80f, h * 0.5f)
            else -> arrayOf(w * 0.5f, h * 0.72f, w * 0.5f, h * 0.30f) // "down"
        }

        val ok = performGestureSwipe(sx, sy, ex, ey, 280L)
        if (ok) {
            AccessibilityStepOutcome(success = true, messageRu = "Экран прокручен ($direction).")
        } else {
            AccessibilityStepOutcome(success = false, messageRu = "Не удалось выполнить жест прокрутки ($direction).")
        }
    }

    fun executeGlobalKey(key: String): AccessibilityStepOutcome {
        if (!isMasterSwitchOn()) {
            return AccessibilityStepOutcome(
                success = false,
                messageRu = "Мастер-выключатель автоматизации выключен."
            )
        }
        val action = when (key.lowercase().trim()) {
            "back", "назад" -> GLOBAL_ACTION_BACK
            "home", "домой" -> GLOBAL_ACTION_HOME
            "recents", "недавние" -> GLOBAL_ACTION_RECENTS
            "notifications", "уведомления", "шторка" -> GLOBAL_ACTION_NOTIFICATIONS
            else -> return AccessibilityStepOutcome(
                success = false,
                messageRu = "Неизвестная системная кнопка: $key (доступны: back, home, recents, notifications)."
            )
        }
        val ok = performGlobalAction(action)
        return if (ok) {
            AccessibilityStepOutcome(success = true, messageRu = "Нажата системная кнопка «$key».")
        } else {
            AccessibilityStepOutcome(success = false, messageRu = "Не удалось выполнить системное действие «$key».")
        }
    }

    private suspend fun performGestureTap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGestureSuspend(gesture)
    }

    private suspend fun performGestureSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long
    ): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGestureSuspend(gesture)
    }

    private suspend fun dispatchGestureSuspend(gesture: GestureDescription): Boolean {
        val result = withTimeoutOrNull(2500L) {
            suspendCancellableCoroutine { cont ->
                val dispatched = dispatchGesture(
                    gesture,
                    object : GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            if (cont.isActive) cont.resume(true)
                        }

                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            if (cont.isActive) cont.resume(false)
                        }
                    },
                    null
                )
                if (!dispatched && cont.isActive) {
                    cont.resume(false)
                }
            }
        }
        if (result == true) {
            delay(180L)
        }
        return result == true
    }

    private fun inspectNodeTreeForSafety(root: AccessibilityNodeInfo): ScreenSafetyInspection {
        val visibleTexts = mutableListOf<String>()
        var hasPassword = false

        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 24 || visibleTexts.size > 160) return
            if (node.isPassword) {
                hasPassword = true
            }
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { visibleTexts.add(it.take(80)) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { visibleTexts.add(it.take(80)) }
            node.hintText?.toString()?.takeIf { it.isNotBlank() }?.let { visibleTexts.add(it.take(80)) }

            for (i in 0 until node.childCount) {
                walk(node.getChild(i), depth + 1)
            }
        }

        walk(root, 0)
        return AccessibilitySafetyGuard.inspectScreen(
            packageName = root.packageName?.toString(),
            visibleTexts = visibleTexts,
            hasPasswordField = hasPassword
        )
    }

    private fun findMatchingNode(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val needle = target.trim().lowercase()
        if (needle.isEmpty()) return null

        val direct = root.findAccessibilityNodeInfosByText(target)
        if (!direct.isNullOrEmpty()) {
            val visibleDirect = direct.filter { it.isVisibleToUser }
            val pool = visibleDirect.ifEmpty { direct }
            val exact = pool.firstOrNull {
                it.text?.toString()?.trim()?.equals(target, ignoreCase = true) == true ||
                    it.contentDescription?.toString()?.trim()?.equals(target, ignoreCase = true) == true
            }
            return exact ?: pool.first()
        }

        fun dfs(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
            if (node == null || depth > 24) return null
            if (node.isVisibleToUser) {
                val t = node.text?.toString()?.lowercase().orEmpty()
                val d = node.contentDescription?.toString()?.lowercase().orEmpty()
                val h = node.hintText?.toString()?.lowercase().orEmpty()
                if (t.contains(needle) || d.contains(needle) || h.contains(needle)) return node
            }
            for (i in 0 until node.childCount) {
                val found = dfs(node.getChild(i), depth + 1)
                if (found != null) return found
            }
            return null
        }

        return dfs(root, 0)
    }

    private fun findClickableAncestor(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable && cur.isEnabled) return cur
            cur = cur.parent
            hops++
        }
        return null
    }

    private fun findFirstEditableNonPassword(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        fun dfs(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
            if (node == null || depth > 20) return null
            if (node.isVisibleToUser && node.isEditable && !node.isPassword && node.isEnabled) return node
            for (i in 0 until node.childCount) {
                val found = dfs(node.getChild(i), depth + 1)
                if (found != null) return found
            }
            return null
        }
        return dfs(root, 0)
    }

    companion object {
        @Volatile
        var activeInstance: JarvisAccessibilityService? = null
            private set

        fun isSystemServiceConnected(): Boolean = activeInstance != null
    }
}
