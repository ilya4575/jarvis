package ru.jarvis.assistant.feature.agent

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.core.agent.AgentContextSnapshot
import ru.jarvis.assistant.core.agent.AgentToolCall
import ru.jarvis.assistant.core.agent.AgentToolExecutor
import ru.jarvis.assistant.core.agent.AgentToolResult
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import ru.jarvis.assistant.feature.accessibility.AppActionPlanner
import ru.jarvis.assistant.feature.accessibility.JarvisAccessibilityService
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Real Android device tool executor invoked by Jarvis's LLM agent loop.
 * - App listing, app launching, deep-link / Telegram / web URLs, settings, timers, alarms,
 *   and device info work immediately out-of-the-box via standard Android APIs.
 * - Screen inspection, tapping (text or x/y), typing, scrolling, and navigation keys
 *   use JarvisAccessibilityService (with hard password/PIN/OTP/payment/CAPTCHA safety guard).
 */
class AndroidAgentToolExecutor(
    private val context: Context,
    private val planner: AppActionPlanner,
    private val prefs: JarvisPreferences
) : AgentToolExecutor {

    /**
     * Optional UI hook (registered by IslandForegroundService) so that when Jarvis is about to
     * inspect or tap an underlying app screen, the expanded Dynamic Island smoothly collapses
     * to its top pill and never blocks the touch target.
     */
    @Volatile
    var onBeforeScreenInteraction: (() -> Unit)? = null

    override fun captureContextSnapshot(): AgentContextSnapshot {
        val apps = runCatching { planner.listLaunchableApps() }.getOrDefault(emptyList())
        val a11yReady = JarvisAccessibilityService.isSystemServiceConnected() && prefs.accessibilityMasterSwitch
        return AgentContextSnapshot(
            installedAppNames = apps.map { it.displayName },
            totalInstalledApps = apps.size,
            accessibilityReady = a11yReady
        )
    }

    override suspend fun execute(call: AgentToolCall): AgentToolResult {
        return when (call.name) {
            "list_apps" -> execListApps(call)
            "open_app" -> execOpenApp(call)
            "open_url" -> execOpenUrl(call)
            "open_search" -> execOpenSearch(call)
            "open_settings" -> execOpenSettings(call)
            "set_timer" -> execSetTimer(call)
            "set_alarm" -> execSetAlarm(call)
            "get_device_info" -> execGetDeviceInfo()
            "get_screen" -> execGetScreen()
            "tap_text" -> execTapText(call)
            "tap_xy" -> execTapXy(call)
            "type_text" -> execTypeText(call)
            "scroll" -> execScroll(call)
            "press_key" -> execPressKey(call)
            "wait" -> execWait(call)
            else -> AgentToolResult(
                toolName = call.name,
                success = false,
                summaryRu = "Неизвестная команда: ${call.name}",
                outputForModel = "ERROR: неизвестная команда '${call.name}'. Используй одну из доступных команд."
            )
        }
    }

    private suspend fun execListApps(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.IO) {
        val query = call.args["query"]?.trim().orEmpty()
        val all = planner.listLaunchableApps()
        val matched = if (query.isBlank()) all.take(100) else planner.searchApps(query, limit = 25)

        if (matched.isEmpty()) {
            val sample = all.take(40).joinToString(", ") { "${it.displayName} (${it.packageName})" }
            return@withContext AgentToolResult(
                toolName = "list_apps",
                success = true,
                summaryRu = "По запросу «$query» совпадений нет",
                outputForModel = "По запросу '$query' ничего не найдено. Всего установлено ${all.size} приложений. Примеры: $sample"
            )
        }

        val lines = matched.joinToString("\n") { "- ${it.displayName} | ${it.packageName}" }
        val header = if (query.isBlank()) {
            "Установленные приложения (показано ${matched.size} из ${all.size}):"
        } else {
            "Найдено приложений по запросу '$query' (${matched.size}):"
        }
        AgentToolResult(
            toolName = "list_apps",
            success = true,
            summaryRu = "Найдено приложений: ${matched.size}",
            outputForModel = "$header\n$lines"
        )
    }

    private suspend fun execOpenApp(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.Main) {
        val query = call.args["app"]
            ?: call.args["name"]
            ?: call.args["package"]
            ?: call.args["packageName"]
            ?: ""
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            return@withContext AgentToolResult(
                toolName = "open_app",
                success = false,
                summaryRu = "Не указано название приложения",
                outputForModel = "ERROR: параметр 'app' пуст. Укажи название или packageName."
            )
        }

        val resolved = withContext(Dispatchers.IO) { planner.resolveApp(trimmed) }
        if (resolved == null) {
            val suggestions = withContext(Dispatchers.IO) {
                val close = planner.searchApps(trimmed, limit = 10)
                if (close.isNotEmpty()) close else planner.listLaunchableApps().take(30)
            }
            val listText = suggestions.joinToString(", ") { "${it.displayName} (${it.packageName})" }
            return@withContext AgentToolResult(
                toolName = "open_app",
                success = false,
                summaryRu = "Приложение «$trimmed» не найдено",
                outputForModel = "NOT_FOUND: приложение '$trimmed' не найдено. Попробуй точное название или packageName из списка на этом телефоне: $listText"
            )
        }

        val (displayName, packageName) = resolved
        withContext(Dispatchers.Main) { onBeforeScreenInteraction?.invoke() }
        val launchRes = planner.launchAppDirectly(packageName)
        if (launchRes.isSuccess) {
            // Brief settle so any follow-up get_screen sees the newly launched app
            delay(950L)
            AgentToolResult(
                toolName = "open_app",
                success = true,
                summaryRu = "Открыто: $displayName",
                outputForModel = "OK: успешно запущено приложение «$displayName» ($packageName).",
                launchedExternalApp = true
            )
        } else {
            val reason = launchRes.exceptionOrNull()?.message ?: "ошибка запуска"
            AgentToolResult(
                toolName = "open_app",
                success = false,
                summaryRu = "Ошибка запуска $displayName",
                outputForModel = "ERROR: не удалось запустить «$displayName» ($packageName): $reason"
            )
        }
    }

    private suspend fun execOpenUrl(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.Main) {
        var raw = (call.args["url"] ?: call.args["link"] ?: "").trim()
        if (raw.isEmpty()) {
            return@withContext AgentToolResult(
                toolName = "open_url",
                success = false,
                summaryRu = "Ссылка не указана",
                outputForModel = "ERROR: укажи параметр 'url'."
            )
        }

        // Normalize common Telegram handles or bare domains cleanly
        raw = when {
            raw.startsWith("@") && !raw.contains(" ") -> "https://t.me/${raw.removePrefix("@")}"
            raw.startsWith("t.me/", ignoreCase = true) -> "https://$raw"
            !raw.contains("://") && !raw.startsWith("tel:") && !raw.startsWith("mailto:") && !raw.startsWith("geo:") ->
                "https://$raw"
            else -> raw
        }

        val allowedSchemes = setOf("https", "http", "tg", "tel", "mailto", "geo")
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        val scheme = uri?.scheme?.lowercase().orEmpty()
        if (uri == null || scheme !in allowedSchemes) {
            return@withContext AgentToolResult(
                toolName = "open_url",
                success = false,
                summaryRu = "Неподдерживаемая ссылка",
                outputForModel = "ERROR: неподдерживаемая схема URL ($raw). Разрешены: https, http, tg, tel, mailto, geo."
            )
        }

        return@withContext try {
            onBeforeScreenInteraction?.invoke()
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            delay(850L)
            AgentToolResult(
                toolName = "open_url",
                success = true,
                summaryRu = "Открыта ссылка: $raw",
                outputForModel = "OK: открыта ссылка $raw на устройстве.",
                launchedExternalApp = true
            )
        } catch (e: Exception) {
            AgentToolResult(
                toolName = "open_url",
                success = false,
                summaryRu = "Не удалось открыть ссылку",
                outputForModel = "ERROR: не удалось открыть $raw (${e.message ?: "нет подходящего приложения"})."
            )
        }
    }

    private suspend fun execOpenSearch(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.Main) {
        val query = (call.args["query"] ?: call.args["q"] ?: "").trim()
        if (query.isEmpty()) {
            return@withContext AgentToolResult(
                toolName = "open_search",
                success = false,
                summaryRu = "Пустой поисковый запрос",
                outputForModel = "ERROR: укажи параметр 'query'."
            )
        }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://www.google.com/search?q=$encoded"
        return@withContext try {
            onBeforeScreenInteraction?.invoke()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            delay(800L)
            AgentToolResult(
                toolName = "open_search",
                success = true,
                summaryRu = "Поиск: $query",
                outputForModel = "OK: открыт поиск в браузере по запросу «$query».",
                launchedExternalApp = true
            )
        } catch (e: Exception) {
            AgentToolResult(
                toolName = "open_search",
                success = false,
                summaryRu = "Ошибка открытия поиска",
                outputForModel = "ERROR: не удалось открыть браузер (${e.message})."
            )
        }
    }

    private suspend fun execOpenSettings(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.Main) {
        val section = (call.args["section"] ?: "main").lowercase().trim()
        val action = when (section) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth", "bt" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "sound", "volume", "звук" -> Settings.ACTION_SOUND_SETTINGS
            "display", "screen", "экран" -> Settings.ACTION_DISPLAY_SETTINGS
            "battery", "батарея" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "apps", "приложения" -> Settings.ACTION_APPLICATION_SETTINGS
            "accessibility", "спецвозможности" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return@withContext try {
            onBeforeScreenInteraction?.invoke()
            val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            delay(750L)
            AgentToolResult(
                toolName = "open_settings",
                success = true,
                summaryRu = "Открыты настройки ($section)",
                outputForModel = "OK: открыт экран настроек Android ($section).",
                launchedExternalApp = true
            )
        } catch (e: Exception) {
            AgentToolResult(
                toolName = "open_settings",
                success = false,
                summaryRu = "Не удалось открыть настройки",
                outputForModel = "ERROR: не удалось открыть настройки ($section): ${e.message}"
            )
        }
    }

    private suspend fun execSetTimer(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.Main) {
        val seconds = call.args["seconds"]?.toIntOrNull()
            ?: (call.args["minutes"]?.toIntOrNull()?.times(60))
            ?: 0
        if (seconds <= 0) {
            return@withContext AgentToolResult(
                toolName = "set_timer",
                success = false,
                summaryRu = "Некорректная длительность таймера",
                outputForModel = "ERROR: укажи положительное число в 'seconds'."
            )
        }
        val msg = call.args["message"]?.trim().orEmpty().ifEmpty { "Таймер Jarvis" }
        return@withContext try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, msg)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            AgentToolResult(
                toolName = "set_timer",
                success = true,
                summaryRu = "Таймер на ${formatDurationRu(seconds)}",
                outputForModel = "OK: передан таймер на ${formatDurationRu(seconds)} («$msg») в системные Часы.",
                launchedExternalApp = true
            )
        } catch (e: Exception) {
            AgentToolResult(
                toolName = "set_timer",
                success = false,
                summaryRu = "Не удалось запустить таймер",
                outputForModel = "ERROR: приложение Часы не обработало таймер (${e.message})."
            )
        }
    }

    private suspend fun execSetAlarm(call: AgentToolCall): AgentToolResult = withContext(Dispatchers.Main) {
        val hour = call.args["hour"]?.toIntOrNull()
        val minute = call.args["minute"]?.toIntOrNull() ?: 0
        if (hour == null || hour !in 0..23 || minute !in 0..59) {
            return@withContext AgentToolResult(
                toolName = "set_alarm",
                success = false,
                summaryRu = "Некорректное время будильника",
                outputForModel = "ERROR: укажи 'hour' (0..23) и 'minute' (0..59)."
            )
        }
        val msg = call.args["message"]?.trim().orEmpty().ifEmpty { "Будильник Jarvis" }
        return@withContext try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, msg)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val timeStr = String.format(Locale.US, "%02d:%02d", hour, minute)
            AgentToolResult(
                toolName = "set_alarm",
                success = true,
                summaryRu = "Будильник на $timeStr",
                outputForModel = "OK: создан будильник на $timeStr («$msg») в системных Часах.",
                launchedExternalApp = true
            )
        } catch (e: Exception) {
            AgentToolResult(
                toolName = "set_alarm",
                success = false,
                summaryRu = "Не удалось поставить будильник",
                outputForModel = "ERROR: приложение Часы не обработало будильник (${e.message})."
            )
        }
    }

    private suspend fun execGetDeviceInfo(): AgentToolResult = withContext(Dispatchers.IO) {
        val nowStr = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru", "RU")).format(Date())
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batteryPct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val isCharging = bm?.isCharging ?: false

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
        val netLabel = when {
            caps == null -> "нет сети"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Мобильная сеть"
            else -> "Подключено"
        }

        val appCount = runCatching { planner.listLaunchableApps().size }.getOrDefault(0)
        val a11yConnected = JarvisAccessibilityService.isSystemServiceConnected()
        val a11yEnabled = a11yConnected && prefs.accessibilityMasterSwitch

        val info = buildString {
            append("Время: $nowStr\n")
            if (batteryPct >= 0) {
                append("Батарея: $batteryPct% (${if (isCharging) "заряжается" else "от батареи"})\n")
            }
            append("Сеть: $netLabel\n")
            append("Установленных приложений: $appCount\n")
            append("Спецвозможности Jarvis (чтение экрана и нажатия): ${if (a11yEnabled) "ВКЛЮЧЕНЫ" else "выключены"}")
        }
        AgentToolResult(
            toolName = "get_device_info",
            success = true,
            summaryRu = "Данные устройства получены",
            outputForModel = info
        )
    }

    private suspend fun prepareAccessibility(toolName: String): Pair<JarvisAccessibilityService?, AgentToolResult?> {
        val svc = JarvisAccessibilityService.activeInstance
        if (svc == null) {
            return null to AgentToolResult(
                toolName = toolName,
                success = false,
                summaryRu = "Нужны Спецвозможности Android",
                outputForModel = "ACCESSIBILITY_DISABLED: сервис Спецвозможностей Jarvis не включён в настройках Android. " +
                    "Сообщи пользователю, что для чтения экрана и нажатий внутри приложений нужно один раз включить Jarvis в " +
                    "Меню → «Действия и ИИ-Агент» → «Включить в настройках Android»."
            )
        }
        if (!prefs.accessibilityMasterSwitch) {
            return null to AgentToolResult(
                toolName = toolName,
                success = false,
                summaryRu = "Мастер-выключатель автоматизации выключен",
                outputForModel = "ACCESSIBILITY_SWITCH_OFF: переключатель автоматизации выключен в Меню → «Действия и ИИ-Агент»."
            )
        }
        // Collapse expanded Dynamic Island card so it never covers the underlying app UI
        withContext(Dispatchers.Main) {
            onBeforeScreenInteraction?.invoke()
        }
        delay(220L)
        return svc to null
    }

    private suspend fun execGetScreen(): AgentToolResult {
        val (svc, err) = prepareAccessibility("get_screen")
        if (err != null) return err
        val outcome = withContext(Dispatchers.Main) { svc!!.dumpVisibleScreen() }
        return AgentToolResult(
            toolName = "get_screen",
            success = outcome.success,
            summaryRu = if (outcome.success) "Экран прочитан" else outcome.messageRu,
            outputForModel = if (outcome.blockedBySafety) {
                "BLOCKED_BY_SAFETY: ${outcome.messageRu}"
            } else {
                outcome.messageRu
            }
        )
    }

    private suspend fun execTapText(call: AgentToolCall): AgentToolResult {
        val text = (call.args["text"] ?: call.args["target"] ?: "").trim()
        if (text.isEmpty()) {
            return AgentToolResult(
                toolName = "tap_text",
                success = false,
                summaryRu = "Не указан текст элемента",
                outputForModel = "ERROR: укажи параметр 'text'."
            )
        }
        val (svc, err) = prepareAccessibility("tap_text")
        if (err != null) return err
        val outcome = svc!!.executeTapText(text)
        return AgentToolResult(
            toolName = "tap_text",
            success = outcome.success,
            summaryRu = outcome.messageRu,
            outputForModel = if (outcome.blockedBySafety) {
                "BLOCKED_BY_SAFETY: ${outcome.messageRu}"
            } else if (outcome.success) {
                "OK: ${outcome.messageRu}"
            } else {
                "ERROR: ${outcome.messageRu}. Можешь вызвать get_screen чтобы увидеть точные надписи и координаты."
            }
        )
    }

    private suspend fun execTapXy(call: AgentToolCall): AgentToolResult {
        val x = call.args["x"]?.toFloatOrNull()?.toInt()
        val y = call.args["y"]?.toFloatOrNull()?.toInt()
        if (x == null || y == null) {
            return AgentToolResult(
                toolName = "tap_xy",
                success = false,
                summaryRu = "Некорректные координаты",
                outputForModel = "ERROR: укажи числовые координаты 'x' и 'y' из get_screen."
            )
        }
        val (svc, err) = prepareAccessibility("tap_xy")
        if (err != null) return err
        val outcome = svc!!.executeTapCoordinates(x, y)
        return AgentToolResult(
            toolName = "tap_xy",
            success = outcome.success,
            summaryRu = outcome.messageRu,
            outputForModel = if (outcome.blockedBySafety) "BLOCKED_BY_SAFETY: ${outcome.messageRu}" else outcome.messageRu
        )
    }

    private suspend fun execTypeText(call: AgentToolCall): AgentToolResult {
        val text = call.args["text"] ?: ""
        val submit = call.args["submit"]?.equals("true", ignoreCase = true) == true
        if (text.isEmpty()) {
            return AgentToolResult(
                toolName = "type_text",
                success = false,
                summaryRu = "Пустой текст для ввода",
                outputForModel = "ERROR: укажи непустой параметр 'text'."
            )
        }
        val (svc, err) = prepareAccessibility("type_text")
        if (err != null) return err
        val outcome = withContext(Dispatchers.Main) { svc!!.executeInputText(text, submit = submit) }
        return AgentToolResult(
            toolName = "type_text",
            success = outcome.success,
            summaryRu = outcome.messageRu,
            outputForModel = if (outcome.blockedBySafety) "BLOCKED_BY_SAFETY: ${outcome.messageRu}" else outcome.messageRu
        )
    }

    private suspend fun execScroll(call: AgentToolCall): AgentToolResult {
        val dir = (call.args["direction"] ?: "down").trim()
        val (svc, err) = prepareAccessibility("scroll")
        if (err != null) return err
        val outcome = svc!!.executeScroll(dir)
        return AgentToolResult(
            toolName = "scroll",
            success = outcome.success,
            summaryRu = outcome.messageRu,
            outputForModel = if (outcome.blockedBySafety) "BLOCKED_BY_SAFETY: ${outcome.messageRu}" else outcome.messageRu
        )
    }

    private suspend fun execPressKey(call: AgentToolCall): AgentToolResult {
        val key = (call.args["key"] ?: "back").trim()
        val (svc, err) = prepareAccessibility("press_key")
        if (err != null) return err
        val outcome = withContext(Dispatchers.Main) { svc!!.executeGlobalKey(key) }
        return AgentToolResult(
            toolName = "press_key",
            success = outcome.success,
            summaryRu = outcome.messageRu,
            outputForModel = outcome.messageRu
        )
    }

    private suspend fun execWait(call: AgentToolCall): AgentToolResult {
        val ms = (call.args["ms"]?.toLongOrNull() ?: 1000L).coerceIn(300L, 3000L)
        delay(ms)
        return AgentToolResult(
            toolName = "wait",
            success = true,
            summaryRu = "Пауза ${ms} мс",
            outputForModel = "OK: ожидание ${ms} мс завершено."
        )
    }

    private fun formatDurationRu(totalSec: Int): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return buildString {
            if (h > 0) append("$h ч ")
            if (m > 0) append("$m мин ")
            if (s > 0 || isEmpty()) append("$s сек")
        }.trim()
    }
}
