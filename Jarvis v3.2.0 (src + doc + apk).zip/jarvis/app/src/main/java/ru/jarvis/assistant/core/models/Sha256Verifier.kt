package ru.jarvis.assistant.core.models

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

data class Sha256Result(
    val matches: Boolean,
    val actualSha256: String?,
    val expectedSha256: String,
    val error: String? = null
)

object Sha256Verifier {
    private val HEX_CHARS = "0123456789abcdef".toCharArray()

    fun computeSha256(file: File, onBytesRead: ((Long) -> Unit)? = null): String {
        require(file.exists() && file.isFile) { "Файл не найден: ${file.name}" }
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        var total = 0L
        FileInputStream(file).use { fis ->
            while (true) {
                val read = fis.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
                total += read
                onBytesRead?.invoke(total)
            }
        }
        return toHex(digest.digest())
    }

    fun verifyFile(file: File, expectedSha256: String): Sha256Result {
        val normalizedExpected = expectedSha256.trim().lowercase()
        if (!file.exists() || !file.isFile) {
            return Sha256Result(
                matches = false,
                actualSha256 = null,
                expectedSha256 = normalizedExpected,
                error = "Файл отсутствует на устройстве"
            )
        }
        return try {
            val actual = computeSha256(file)
            val ok = actual.equals(normalizedExpected, ignoreCase = true)
            Sha256Result(
                matches = ok,
                actualSha256 = actual,
                expectedSha256 = normalizedExpected,
                error = if (ok) null else "Контрольная сумма SHA-256 не совпадает"
            )
        } catch (e: Exception) {
            Sha256Result(
                matches = false,
                actualSha256 = null,
                expectedSha256 = normalizedExpected,
                error = e.message ?: "Ошибка чтения файла при проверке SHA-256"
            )
        }
    }

    fun toHex(bytes: ByteArray): String {
        val out = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            out[i * 2] = HEX_CHARS[v ushr 4]
            out[i * 2 + 1] = HEX_CHARS[v and 0x0F]
        }
        return String(out)
    }
}
