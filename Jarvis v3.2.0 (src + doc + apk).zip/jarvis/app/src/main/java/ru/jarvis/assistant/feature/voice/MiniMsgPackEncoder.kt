package ru.jarvis.assistant.feature.voice

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * Compact pure-Kotlin MessagePack encoder supporting the exact types needed by Fish Audio's
 * `/v1/tts` zero-shot voice cloning endpoint (`map`, `array`, `str`, `bin`, `bool`, `int`, `float64`, `nil`).
 */
object MiniMsgPackEncoder {

    fun encode(value: Any?): ByteArray {
        val out = ByteArrayOutputStream(256)
        writeValue(out, value)
        return out.toByteArray()
    }

    private fun writeValue(out: ByteArrayOutputStream, value: Any?) {
        when (value) {
            null -> out.write(0xc0)
            is Boolean -> out.write(if (value) 0xc3 else 0xc2)
            is Int -> writeLong(out, value.toLong())
            is Long -> writeLong(out, value)
            is Float -> writeDouble(out, value.toDouble())
            is Double -> writeDouble(out, value)
            is String -> writeString(out, value)
            is ByteArray -> writeBytes(out, value)
            is List<*> -> writeArray(out, value)
            is Map<*, *> -> writeMap(out, value)
            else -> writeString(out, value.toString())
        }
    }

    private fun writeLong(out: ByteArrayOutputStream, v: Long) {
        when {
            v in 0..127 -> out.write(v.toInt())
            v in -32..-1 -> out.write(v.toInt() and 0xff)
            v in 0..0xff -> {
                out.write(0xcc)
                out.write(v.toInt())
            }
            v in 0..0xffff -> {
                out.write(0xcd)
                out.write(((v shr 8) and 0xff).toInt())
                out.write((v and 0xff).toInt())
            }
            v in Int.MIN_VALUE..Int.MAX_VALUE -> {
                out.write(0xd2)
                out.write(ByteBuffer.allocate(4).putInt(v.toInt()).array())
            }
            else -> {
                out.write(0xd3)
                out.write(ByteBuffer.allocate(8).putLong(v).array())
            }
        }
    }

    private fun writeDouble(out: ByteArrayOutputStream, v: Double) {
        out.write(0xcb)
        out.write(ByteBuffer.allocate(8).putDouble(v).array())
    }

    private fun writeString(out: ByteArrayOutputStream, s: String) {
        val bytes = s.toByteArray(Charsets.UTF_8)
        val len = bytes.size
        when {
            len <= 31 -> out.write(0xa0 or len)
            len <= 0xff -> {
                out.write(0xd9)
                out.write(len)
            }
            len <= 0xffff -> {
                out.write(0xda)
                out.write((len shr 8) and 0xff)
                out.write(len and 0xff)
            }
            else -> {
                out.write(0xdb)
                out.write(ByteBuffer.allocate(4).putInt(len).array())
            }
        }
        out.write(bytes)
    }

    private fun writeBytes(out: ByteArrayOutputStream, bytes: ByteArray) {
        val len = bytes.size
        when {
            len <= 0xff -> {
                out.write(0xc4)
                out.write(len)
            }
            len <= 0xffff -> {
                out.write(0xc5)
                out.write((len shr 8) and 0xff)
                out.write(len and 0xff)
            }
            else -> {
                out.write(0xc6)
                out.write(ByteBuffer.allocate(4).putInt(len).array())
            }
        }
        out.write(bytes)
    }

    private fun writeArray(out: ByteArrayOutputStream, list: List<*>) {
        val len = list.size
        when {
            len <= 15 -> out.write(0x90 or len)
            len <= 0xffff -> {
                out.write(0xdc)
                out.write((len shr 8) and 0xff)
                out.write(len and 0xff)
            }
            else -> {
                out.write(0xdd)
                out.write(ByteBuffer.allocate(4).putInt(len).array())
            }
        }
        for (item in list) writeValue(out, item)
    }

    private fun writeMap(out: ByteArrayOutputStream, map: Map<*, *>) {
        val len = map.size
        when {
            len <= 15 -> out.write(0x80 or len)
            len <= 0xffff -> {
                out.write(0xde)
                out.write((len shr 8) and 0xff)
                out.write(len and 0xff)
            }
            else -> {
                out.write(0xdf)
                out.write(ByteBuffer.allocate(4).putInt(len).array())
            }
        }
        for ((k, v) in map) {
            writeValue(out, k)
            writeValue(out, v)
        }
    }
}
