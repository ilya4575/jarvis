package ru.jarvis.assistant.core.cloud

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import ru.jarvis.assistant.core.inference.ChatTurn
import ru.jarvis.assistant.core.inference.EngineState
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.GenerationResult
import ru.jarvis.assistant.core.inference.InferenceEngine
import ru.jarvis.assistant.core.models.ModelProfile
import ru.jarvis.assistant.core.models.ModelProfileId
import ru.jarvis.assistant.core.prefs.JarvisPreferences

/**
 * Clean hybrid inference router (v3.0):
 *  - Core 4 API providers: Gemini, Groq, OpenRouter, Custom API (1..10)
 *  - Perchance (free WebView bridge for chat + image generation, isolated Cloudflare gate)
 *  - Puter API (Bearer Auth Token, SSE + 4-step OpenAI Function Calling + quota metering + TTS)
 *  - Local GGUF offline fallback (optional)
 */
class HybridInferenceEngine(
    private val prefs: JarvisPreferences,
    val localEngine: InferenceEngine,
    val cloudClient: CloudLlmClient = CloudLlmClient(),
    val perchanceBridge: PerchanceWebViewBridge? = null,
    val puterClient: PuterApiClient? = null
) : InferenceEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow<EngineState>(EngineState.Unloaded)
    override val state: StateFlow<EngineState> = _state.asStateFlow()

    private val _lastUsedProviderRu = MutableStateFlow<String?>(null)
    val lastUsedProviderRu: StateFlow<String?> = _lastUsedProviderRu.asStateFlow()

    init {
        refreshEffectiveState()
        scope.launch {
            localEngine.state.collect { refreshEffectiveState() }
        }
    }

    fun refreshEffectiveState() {
        val localSt = localEngine.state.value
        val chatProvider = prefs.chatPrimaryProvider
        val hasCloud = prefs.hasAnyCloudKey()

        if (!hasCloud) {
            _state.value = localSt
            return
        }

        if (chatProvider == CloudProvider.LOCAL && localSt is EngineState.Ready) {
            _state.value = localSt
            return
        }

        val active = resolveRoutingOrder(RequestSource.CHAT).firstOrNull { isProviderConfigured(it) }
            ?: resolveRoutingOrder(RequestSource.DYNAMIC_ISLAND).firstOrNull { isProviderConfigured(it) }
        if (active == null || active == CloudProvider.LOCAL) {
            _state.value = localSt
            return
        }

        val (title, modelName) = when (active) {
            CloudProvider.PUTER -> "Puter" to prefs.effectivePuterModel()
            CloudProvider.PERCHANCE -> "Perchance" to "WebView-мост"
            CloudProvider.OPENROUTER -> "OpenRouter" to prefs.openRouterModel
            CloudProvider.GEMINI -> "Gemini" to prefs.geminiModel
            CloudProvider.GROQ -> "Groq" to prefs.groqLlmModel
            CloudProvider.CUSTOM_API -> {
                val cfg = prefs.getActiveCustomProvider()
                (cfg?.name?.ifBlank { "Custom" } ?: "Custom") to (cfg?.effectiveModel() ?: "gpt-4o-mini")
            }
            CloudProvider.LOCAL -> "Локальная" to prefs.activeProfileId.shortTitleRu
        }

        _state.value = EngineState.Ready(
            profileId = ModelProfileId.SMART,
            profileTitle = title,
            modelName = modelName,
            visionSupported = true,
            contextSize = if (active == CloudProvider.PERCHANCE) 16_000 else 128_000
        )
    }

    override val isVisionReady: Boolean
        get() = prefs.hasAnyCloudKey() || localEngine.isVisionReady

    override suspend fun loadProfile(profile: ModelProfile): Result<Unit> {
        val res = localEngine.loadProfile(profile)
        refreshEffectiveState()
        return res
    }

    override suspend fun generate(
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult {
        val order = resolveRoutingOrder(config.requestSource)
        val primary = order.first()

        // A2: If the user explicitly selected Perchance as primary and it is NOT verified,
        // signal UI immediately to open the verification dialog (without silently blocking other providers).
        if (primary == CloudProvider.PERCHANCE && prefs.perchanceEnabled && perchanceBridge != null && !perchanceBridge.isVerified()) {
            return GenerationResult.Failed(
                "${PerchanceWebViewBridge.PERCHANCE_VERIFY_REQUIRED_TOKEN} Провайдер Perchance не прошёл проверку Cloudflare. Нажмите «Проверить» в открывшемся окне."
            )
        }

        val candidates = if (prefs.autoFallbackEnabled) {
            order.filter { isProviderConfigured(it) }
        } else {
            order.take(1).filter { isProviderConfigured(it) }
        }

        if (candidates.isEmpty()) {
            return GenerationResult.Failed(
                "Нет настроенных провайдеров. Откройте меню → «Провайдеры и API-ключи» и настройте Gemini, Groq, OpenRouter, Custom, Perchance или Puter."
            )
        }

        val errors = mutableListOf<String>()
        for (provider in candidates) {
            if (provider == CloudProvider.PERCHANCE && provider != primary && perchanceBridge?.isVerified() != true) {
                continue
            }

            val streamedAny = booleanArrayOf(false)
            val wrappedOnToken: (String) -> Unit = { tok ->
                if (tok.isNotEmpty()) streamedAny[0] = true
                onToken(tok)
            }

            val res = when (provider) {
                CloudProvider.PUTER -> {
                    val client = puterClient
                    if (client == null) {
                        GenerationResult.Failed("Puter API клиент недоступен.")
                    } else {
                        client.streamChatWithTools(
                            authToken = prefs.puterAuthToken,
                            model = prefs.effectivePuterModel(),
                            history = history,
                            userPrompt = userPrompt,
                            imagePath = imagePath,
                            config = config,
                            onToken = wrappedOnToken
                        )
                    }
                }
                CloudProvider.PERCHANCE -> {
                    val bridge = perchanceBridge
                    if (bridge == null) {
                        GenerationResult.Failed("Perchance WebView-мост недоступен.")
                    } else {
                        bridge.stream(
                            history = history,
                            userPrompt = userPrompt,
                            imagePath = imagePath,
                            config = config,
                            onToken = wrappedOnToken
                        )
                    }
                }
                CloudProvider.GEMINI -> cloudClient.streamGemini(
                    apiKey = prefs.geminiApiKey,
                    model = prefs.geminiModel,
                    endpointMode = prefs.geminiEndpointMode,
                    cachedUseVertex = prefs.geminiDetectedVertex,
                    history = history,
                    userPrompt = userPrompt,
                    imagePath = imagePath,
                    config = config,
                    onToken = wrappedOnToken,
                    onDetectedVertexChanged = { prefs.geminiDetectedVertex = it }
                )
                CloudProvider.OPENROUTER -> cloudClient.streamOpenRouter(
                    apiKey = prefs.openRouterApiKey,
                    model = prefs.openRouterModel,
                    history = history,
                    userPrompt = userPrompt,
                    imagePath = imagePath,
                    config = config,
                    onToken = wrappedOnToken
                )
                CloudProvider.GROQ -> cloudClient.streamGroq(
                    apiKey = prefs.groqApiKey,
                    model = prefs.groqLlmModel,
                    visionModel = CloudLlmClient.DEFAULT_GROQ_VISION_MODEL,
                    history = history,
                    userPrompt = userPrompt,
                    imagePath = imagePath,
                    config = config,
                    onToken = wrappedOnToken
                )
                CloudProvider.CUSTOM_API -> executeCustomProviders(
                    history = history,
                    userPrompt = userPrompt,
                    imagePath = imagePath,
                    config = config,
                    onToken = wrappedOnToken
                )
                CloudProvider.LOCAL -> localEngine.generate(
                    history = history,
                    userPrompt = userPrompt,
                    imagePath = imagePath,
                    config = config,
                    onToken = wrappedOnToken
                )
            }

            when (res) {
                is GenerationResult.Completed -> {
                    _lastUsedProviderRu.value = if (provider == CloudProvider.CUSTOM_API) {
                        prefs.getActiveCustomProvider()?.name ?: provider.shortLabelRu
                    } else provider.shortLabelRu
                    return res
                }
                is GenerationResult.Cancelled -> return res
                is GenerationResult.Failed -> {
                    errors.add(res.reasonRu)
                    if (streamedAny[0]) return res
                }
            }
        }

        return GenerationResult.Failed(
            "Не удалось получить ответ:\n• " + errors.joinToString("\n• ")
        )
    }

    private suspend fun executeCustomProviders(
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult {
        val enabled = prefs.getCustomProviders().filter { it.enabled && it.baseUrl.isNotBlank() }
        if (enabled.isEmpty()) {
            return GenerationResult.Failed("Нет включённых Custom-провайдеров.")
        }
        val active = prefs.getActiveCustomProvider()
        val ordered = if (active != null && prefs.autoFallbackEnabled) {
            listOf(active) + enabled.filter { it.id != active.id }
        } else {
            listOf(active ?: enabled.first())
        }

        var lastErr = "Ошибка Custom API"
        for (cfg in ordered) {
            val streamed = booleanArrayOf(false)
            val res = cloudClient.streamCustomProvider(
                providerConfig = cfg,
                history = history,
                userPrompt = userPrompt,
                imagePath = imagePath,
                config = config,
                onToken = { tok ->
                    if (tok.isNotEmpty()) streamed[0] = true
                    onToken(tok)
                }
            )
            when (res) {
                is GenerationResult.Completed -> return res
                is GenerationResult.Cancelled -> return res
                is GenerationResult.Failed -> {
                    lastErr = res.reasonRu
                    if (streamed[0]) return res
                }
            }
        }
        return GenerationResult.Failed(lastErr)
    }

    fun resolveRoutingOrder(source: RequestSource): List<CloudProvider> {
        val primary = when (source) {
            RequestSource.DYNAMIC_ISLAND -> prefs.islandPrimaryProvider
            RequestSource.CHAT -> prefs.chatPrimaryProvider
        }
        val baseChain = when (source) {
            RequestSource.DYNAMIC_ISLAND -> listOf(
                CloudProvider.GROQ,
                CloudProvider.PUTER,
                CloudProvider.GEMINI,
                CloudProvider.CUSTOM_API,
                CloudProvider.OPENROUTER,
                CloudProvider.PERCHANCE,
                CloudProvider.LOCAL
            )
            RequestSource.CHAT -> listOf(
                CloudProvider.CUSTOM_API,
                CloudProvider.OPENROUTER,
                CloudProvider.GEMINI,
                CloudProvider.PUTER,
                CloudProvider.GROQ,
                CloudProvider.PERCHANCE,
                CloudProvider.LOCAL
            )
        }
        return (listOf(primary) + baseChain).distinct()
    }

    private fun isProviderConfigured(provider: CloudProvider): Boolean = when (provider) {
        CloudProvider.PUTER -> prefs.puterAuthToken.isNotBlank() && puterClient != null
        CloudProvider.PERCHANCE -> prefs.perchanceEnabled && perchanceBridge != null
        CloudProvider.GEMINI -> prefs.geminiApiKey.isNotBlank()
        CloudProvider.GROQ -> prefs.groqApiKey.isNotBlank()
        CloudProvider.OPENROUTER -> prefs.openRouterApiKey.isNotBlank()
        CloudProvider.CUSTOM_API -> prefs.hasAnyCustomProviderReady()
        CloudProvider.LOCAL -> localEngine.state.value is EngineState.Ready
    }

    override fun cancelGeneration() {
        cloudClient.cancelActive()
        puterClient?.cancelActive()
        perchanceBridge?.cancelActive()
        localEngine.cancelGeneration()
    }

    override fun unload() {
        localEngine.unload()
        refreshEffectiveState()
    }
}
