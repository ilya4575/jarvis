package ru.jarvis.assistant.feature.overlay

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import ru.jarvis.assistant.JarvisApplication
import java.util.concurrent.ConcurrentHashMap

/**
 * B1 + B2 + B3 NotificationListenerService:
 * - Intercepts live notifications from ALL apps and extracts ONLY real system Notification.Action
 *   buttons (including RemoteInput quick reply). NEVER fabricates fake actions and NEVER keeps history.
 * - Also relays live CATEGORY_CALL notifications to IslandCallManager for Layer 1 call actions.
 * - Grants MediaSessionManager active-session permission so IslandMediaController tracks music live.
 */
class JarvisNotificationListenerService : NotificationListenerService() {

    private data class ActiveNotifBundle(
        val sbn: StatusBarNotification,
        val actions: List<Notification.Action>
    )

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        _isConnected.value = true
        onListenerStateChanged?.invoke(true)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance === this) instance = null
        _isConnected.value = false
        liveRecords.clear()
        mediaArtworkByPackage.clear()
        _currentNotification.value = null
        _currentNotificationIcon.value = null
        _currentCallNotification.value = null
        onListenerStateChanged?.invoke(false)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Ignore our own foreground / verification notifications so the island doesn't echo itself
        if (sbn.packageName == packageName) return
        val prefs = runCatching { JarvisApplication.instance.prefs }.getOrNull() ?: return
        val notif = sbn.notification ?: return

        val isCallCategory = notif.category == Notification.CATEGORY_CALL ||
            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && notif.extras?.containsKey(Notification.EXTRA_CALL_PERSON) == true)

        if (isCallCategory) {
            handleCallNotification(sbn, notif)
            return
        }

        // Media transport notifications (e.g. SoundCloud, Spotify, Yandex Music, VK):
        // Cache their LargeIcon/Picture artwork for IslandMediaController BEFORE skipping standard notif display!
        val extras = notif.extras ?: Bundle.EMPTY
        val isMediaNotif = notif.category == Notification.CATEGORY_TRANSPORT ||
            extras.containsKey(Notification.EXTRA_MEDIA_SESSION) ||
            extras.getString(Notification.EXTRA_TEMPLATE).orEmpty().contains("MediaStyle", ignoreCase = true)

        if (isMediaNotif) {
            val artBmp = extractMediaArtworkBitmap(notif, extras)
            if (artBmp != null) {
                mediaArtworkByPackage[sbn.packageName] = artBmp
                onMediaArtworkUpdated?.invoke(sbn.packageName, artBmp)
            }
            if ((notif.flags and Notification.FLAG_ONGOING_EVENT) != 0 || notif.category == Notification.CATEGORY_TRANSPORT) {
                return
            }
        }

        if (!prefs.islandNotificationsEnabled) return
        // Phase 9: Per-app blacklist filter applies ONLY to notifications (calls & music unaffected)
        if (!IslandNotifFilterPolicy.shouldShowNotification(sbn.packageName, prefs.islandBlockedNotifPackages)) {
            return
        }
        if ((notif.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return

        val realActions = notif.actions?.toList().orEmpty()
        val actionInfos = realActions.mapIndexed { idx, act ->
            val ri = act.remoteInputs?.firstOrNull()
            IslandNotificationActionInfo(
                index = idx,
                title = act.title?.toString()?.trim().orEmpty().ifBlank { "Действие" },
                hasRemoteInput = ri != null,
                remoteInputHint = ri?.label?.toString()?.trim()
            )
        }

        liveRecords[sbn.key] = ActiveNotifBundle(sbn, realActions)

        val appLabel = resolveAppLabel(sbn.packageName)
        val iconBmp = resolveNotificationIcon(sbn)
        _currentNotificationIcon.value = iconBmp
        _currentNotification.value = IslandNotificationInfo(
            key = sbn.key,
            packageName = sbn.packageName,
            appLabel = appLabel,
            title = title.ifBlank { appLabel },
            text = text,
            postedAtMs = sbn.postTime,
            actions = actionInfos
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        liveRecords.remove(sbn.key)
        if (_currentNotification.value?.key == sbn.key) {
            _currentNotification.value = null
            _currentNotificationIcon.value = null
        }
        if (_currentCallNotification.value?.notificationKey == sbn.key) {
            _currentCallNotification.value = null
        }
    }

    private fun handleCallNotification(sbn: StatusBarNotification, notif: Notification) {
        val extras = notif.extras ?: Bundle.EMPTY
        val caller = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()
            ?: resolveAppLabel(sbn.packageName)
        val sub = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val realActions = notif.actions?.toList().orEmpty()
        liveRecords[sbn.key] = ActiveNotifBundle(sbn, realActions)

        var acceptIdx: Int? = null
        var declineIdx: Int? = null
        realActions.forEachIndexed { idx, act ->
            val t = act.title?.toString()?.lowercase().orEmpty()
            if (acceptIdx == null && (t.contains("ответить") || t.contains("принять") || t.contains("answer") || t.contains("accept"))) {
                acceptIdx = idx
            } else if (declineIdx == null && (t.contains("отклонить") || t.contains("сбросить") || t.contains("завершить") || t.contains("decline") || t.contains("hang") || t.contains("end") || t.contains("reject"))) {
                declineIdx = idx
            }
        }

        val isIncoming = acceptIdx != null || sub.contains("входящ", ignoreCase = true) || sub.contains("incoming", ignoreCase = true)
        _currentCallNotification.value = IslandCallInfo(
            callId = sbn.key,
            callerName = caller.ifBlank { "Звонок" },
            callerNumber = sub,
            isIncoming = isIncoming,
            isActive = !isIncoming,
            fromInCallService = false,
            notificationKey = sbn.key,
            acceptActionIndex = acceptIdx,
            declineActionIndex = declineIdx
        )
    }

    /** Executes ONLY a genuine system Notification.Action (with optional RemoteInput reply text). */
    fun executeRealAction(notificationKey: String, actionIndex: Int, replyText: String? = null): Boolean {
        val record = liveRecords[notificationKey] ?: return false
        val action = record.actions.getOrNull(actionIndex) ?: return false
        val pi = action.actionIntent ?: return false

        return try {
            val remoteInputs = action.remoteInputs
            if (!remoteInputs.isNullOrEmpty() && !replyText.isNullOrBlank()) {
                val fillIn = Intent()
                val bundle = Bundle()
                for (ri in remoteInputs) {
                    bundle.putCharSequence(ri.resultKey, replyText)
                }
                RemoteInput.addResultsToIntent(remoteInputs, fillIn, bundle)
                pi.send(this, 0, fillIn)
            } else {
                pi.send()
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun openNotificationContent(notificationKey: String): Boolean {
        val record = liveRecords[notificationKey] ?: return false
        val pi = record.sbn.notification?.contentIntent ?: return false
        return try {
            pi.send()
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun dismissSystemNotification(notificationKey: String) {
        runCatching { cancelNotification(notificationKey) }
        liveRecords.remove(notificationKey)
        if (_currentNotification.value?.key == notificationKey) {
            _currentNotification.value = null
            _currentNotificationIcon.value = null
        }
    }

    private fun resolveAppLabel(pkg: String): String = runCatching {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString()
    }.getOrDefault(pkg)

    private fun resolveNotificationIcon(sbn: StatusBarNotification): Bitmap? = runCatching {
        val drawable: Drawable? = sbn.notification?.getLargeIcon()?.loadDrawable(this)
            ?: packageManager.getApplicationIcon(sbn.packageName)
        drawable?.toSmallBitmap(96)
    }.getOrNull()

    private fun extractMediaArtworkBitmap(notif: Notification, extras: Bundle): Bitmap? = runCatching {
        // 1) Notification.getLargeIcon() (standard Android 10–14 media cover art — used by SoundCloud!)
        val largeIconDrawable = notif.getLargeIcon()?.loadDrawable(this)
        if (largeIconDrawable != null) {
            return@runCatching largeIconDrawable.toArtworkBitmap(256)
        }
        // 2) EXTRA_LARGE_ICON_BIG or EXTRA_PICTURE (Bitmap or Icon)
        @Suppress("DEPRECATION")
        val rawExtra = extras.get(Notification.EXTRA_LARGE_ICON_BIG)
            ?: extras.get(Notification.EXTRA_PICTURE)
            ?: extras.get(Notification.EXTRA_LARGE_ICON)
        when (rawExtra) {
            is Bitmap -> if (!rawExtra.isRecycled) rawExtra.copy(Bitmap.Config.ARGB_8888, false) else null
            is Icon -> rawExtra.loadDrawable(this)?.toArtworkBitmap(256)
            else -> null
        }
    }.getOrNull()

    fun findMediaArtworkForPackage(packageName: String): Bitmap? {
        mediaArtworkByPackage[packageName]?.let { if (!it.isRecycled) return it }
        val active = runCatching { activeNotifications }.getOrNull() ?: return null
        for (sbn in active) {
            if (sbn.packageName != packageName) continue
            val notif = sbn.notification ?: continue
            val extras = notif.extras ?: Bundle.EMPTY
            val isMedia = notif.category == Notification.CATEGORY_TRANSPORT ||
                extras.containsKey(Notification.EXTRA_MEDIA_SESSION) ||
                extras.getString(Notification.EXTRA_TEMPLATE).orEmpty().contains("MediaStyle", ignoreCase = true)
            if (isMedia) {
                val bmp = extractMediaArtworkBitmap(notif, extras)
                if (bmp != null) {
                    mediaArtworkByPackage[packageName] = bmp
                    return bmp
                }
            }
        }
        return null
    }

    private fun Drawable.toSmallBitmap(sizePx: Int): Bitmap {
        if (this is BitmapDrawable && bitmap != null && !bitmap.isRecycled) {
            return Bitmap.createScaledBitmap(bitmap, sizePx, sizePx, true)
        }
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        setBounds(0, 0, sizePx, sizePx)
        draw(c)
        return bmp
    }

    private fun Drawable.toArtworkBitmap(maxDimPx: Int): Bitmap {
        if (this is BitmapDrawable && bitmap != null && !bitmap.isRecycled) {
            val w = bitmap.width.coerceAtLeast(1)
            val h = bitmap.height.coerceAtLeast(1)
            if (w <= maxDimPx && h <= maxDimPx) return bitmap
            val scale = maxDimPx.toFloat() / maxOf(w, h).toFloat()
            return Bitmap.createScaledBitmap(bitmap, (w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1), true)
        }
        return toSmallBitmap(maxDimPx)
    }

    companion object {
        @Volatile
        var instance: JarvisNotificationListenerService? = null
            private set

        private val liveRecords = ConcurrentHashMap<String, ActiveNotifBundle>()
        private val mediaArtworkByPackage = ConcurrentHashMap<String, Bitmap>()

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _currentNotification = MutableStateFlow<IslandNotificationInfo?>(null)
        val currentNotification: StateFlow<IslandNotificationInfo?> = _currentNotification.asStateFlow()

        private val _currentNotificationIcon = MutableStateFlow<Bitmap?>(null)
        val currentNotificationIcon: StateFlow<Bitmap?> = _currentNotificationIcon.asStateFlow()

        private val _currentCallNotification = MutableStateFlow<IslandCallInfo?>(null)
        val currentCallNotification: StateFlow<IslandCallInfo?> = _currentCallNotification.asStateFlow()

        var onListenerStateChanged: ((Boolean) -> Unit)? = null
        var onMediaArtworkUpdated: ((packageName: String, artwork: Bitmap) -> Unit)? = null

        fun getCachedMediaArtwork(packageName: String): Bitmap? {
            mediaArtworkByPackage[packageName]?.let { if (!it.isRecycled) return it }
            return instance?.findMediaArtworkForPackage(packageName)
        }

        fun isPermissionGranted(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
            val expected = ComponentName(context, JarvisNotificationListenerService::class.java).flattenToString()
            return flat.contains(expected) || flat.contains(context.packageName)
        }

        fun componentName(context: Context): ComponentName =
            ComponentName(context, JarvisNotificationListenerService::class.java)
    }
}
