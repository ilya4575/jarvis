package ru.jarvis.assistant.feature.voice

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

/**
 * Pure Kotlin OkHttp WebSocket client for Microsoft Edge Neural TTS using the mandatory
 * October 2026 Sec-MS-GEC v2 token (CS64 + modified SHA-256).
 * Produces studio-quality 24 kHz Russian MP3 audio completely independently of the phone's
 * system Android TTS (solves Chinese ROM TTS completely, with zero API key needed).
 */
class EdgeNeuralTtsClient {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val activeWs = AtomicReference<WebSocket?>(null)

    @Volatile
    private var clockSkewSeconds: Long = 0L

    fun cancelActive() {
        activeWs.getAndSet(null)?.cancel()
    }

    suspend fun synthesizeToMp3File(
        text: String,
        voice: NeuralVoicePreset,
        extraRatePct: Int = 0,
        extraPitchHz: Int = 0,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Пустой текст для озвучки."))
        }
        val pitch = (voice.defaultPitchHz + extraPitchHz).coerceIn(-40, 40)
        val rate = (voice.defaultRatePct + extraRatePct).coerceIn(-40, 60)
        val pitchStr = if (pitch >= 0) "+${pitch}Hz" else "${pitch}Hz"
        val rateStr = if (rate >= 0) "+${rate}%" else "${rate}%"

        // First attempt; if 403 due to clock skew, auto-adjust clock from server Date header and retry once
        val first = runSingleWebSocket(clean, voice, pitchStr, rateStr)
        val bytesResult = if (first.isFailure && first.exceptionOrNull()?.message?.contains("403") == true) {
            runSingleWebSocket(clean, voice, pitchStr, rateStr)
        } else first

        bytesResult.mapCatching { mp3Bytes ->
            outputFile.parentFile?.mkdirs()
            outputFile.writeBytes(mp3Bytes)
            outputFile
        }
    }

    private suspend fun runSingleWebSocket(
        text: String,
        voice: NeuralVoicePreset,
        pitchStr: String,
        rateStr: String
    ): Result<ByteArray> {
        val nowSec = (System.currentTimeMillis() / 1000L) + clockSkewSeconds
        val token = generateSecMsGecV2(nowSec)
        val connId = UUID.randomUUID().toString().replace("-", "")
        val muid = randomHex(16)
        val url = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
            "?TrustedClientToken=$TRUSTED_CLIENT_TOKEN" +
            "&Sec-MS-GEC=$token" +
            "&Sec-MS-GEC-Version=$SEC_MS_GEC_VERSION" +
            "&ConnectionId=$connId"

        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header("User-Agent", USER_AGENT)
            .header("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8")
            .header("Cookie", "muid=$muid;")
            .build()

        val result = withTimeoutOrNull(25_000L) {
            suspendCancellableCoroutine<Result<ByteArray>> { cont ->
                val audioOut = ByteArrayOutputStream(32_768)
                val finished = AtomicBoolean(false)

                fun finish(res: Result<ByteArray>, ws: WebSocket?) {
                    if (finished.compareAndSet(false, true)) {
                        activeWs.compareAndSet(ws, null)
                        runCatching { ws?.close(1000, "done") }
                        if (cont.isActive) cont.resume(res)
                    }
                }

                val ws = httpClient.newWebSocket(request, object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        val tsStr = formatJsUtcDate()
                        val cfgMsg = "X-Timestamp:$tsStr\r\n" +
                            "Content-Type:application/json; charset=utf-8\r\n" +
                            "Path:speech.config\r\n\r\n" +
                            "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{" +
                            "\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"}," +
                            "\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                        webSocket.send(cfgMsg)

                        val reqId = UUID.randomUUID().toString().replace("-", "")
                        val escaped = escapeXml(text)
                        val ssml = "X-RequestId:$reqId\r\n" +
                            "Content-Type:application/ssml+xml\r\n" +
                            "X-Timestamp:${tsStr}Z\r\n" +
                            "Path:ssml\r\n\r\n" +
                            "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${voice.edgeLang}'>" +
                            "<voice name='${voice.edgeVoiceFullName}'>" +
                            "<prosody pitch='$pitchStr' rate='$rateStr' volume='+0%'>$escaped</prosody>" +
                            "</voice></speak>"
                        webSocket.send(ssml)
                    }

                    override fun onMessage(webSocket: WebSocket, textMessage: String) {
                        if (textMessage.contains("Path:turn.end")) {
                            val bytes = audioOut.toByteArray()
                            if (bytes.isNotEmpty()) {
                                finish(Result.success(bytes), webSocket)
                            } else {
                                finish(Result.failure(IllegalStateException("Сервер озвучки вернул пустой аудиопоток.")), webSocket)
                            }
                        }
                    }

                    override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                        val raw = bytes.toByteArray()
                        if (raw.size < 2) return
                        val headerLen = ((raw[0].toInt() and 0xFF) shl 8) or (raw[1].toInt() and 0xFF)
                        val bodyOffset = 2 + headerLen
                        if (bodyOffset >= raw.size) return
                        val headerStr = String(raw, 2, headerLen, Charsets.UTF_8)
                        if (headerStr.contains("Path:audio")) {
                            audioOut.write(raw, bodyOffset, raw.size - bodyOffset)
                        }
                    }

                    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                        val bytes = audioOut.toByteArray()
                        if (bytes.isNotEmpty()) {
                            finish(Result.success(bytes), webSocket)
                        } else {
                            finish(Result.failure(IllegalStateException("Соединение закрыто ($code $reason)")), webSocket)
                        }
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        response?.header("Date")?.let { dateHdr ->
                            adjustClockFromServerHeader(dateHdr)
                        }
                        val codePart = response?.code?.let { "HTTP $it: " }.orEmpty()
                        finish(
                            Result.failure(IllegalStateException("Нейро-озвучка: $codePart${t.message ?: t.javaClass.simpleName}")),
                            webSocket
                        )
                    }
                })

                activeWs.set(ws)
                cont.invokeOnCancellation {
                    activeWs.compareAndSet(ws, null)
                    ws.cancel()
                }
            }
        }
        return result ?: Result.failure(IllegalStateException("Превышено время ожидания нейро-озвучки."))
    }

    private fun adjustClockFromServerHeader(dateHeader: String) {
        runCatching {
            val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("GMT")
            }
            val serverMs = fmt.parse(dateHeader)?.time ?: return
            val diffSec = (serverMs - System.currentTimeMillis()) / 1000L
            if (kotlin.math.abs(diffSec) > 30L) {
                clockSkewSeconds = diffSec
            }
        }
    }

    private fun formatJsUtcDate(): String {
        val fmt = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return fmt.format(Date())
    }

    private fun randomHex(numBytes: Int): String {
        val arr = ByteArray(numBytes)
        SecureRandom().nextBytes(arr)
        return arr.joinToString("") { "%02X".format(it) }
    }

    companion object {
        const val TRUSTED_CLIENT_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
        const val SEC_MS_GEC_VERSION = "2-143.0.3650.75"
        const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"

        private const val WIN_EPOCH = 11644473600L
        private const val U32 = 0xFFFFFFFFL

        private val SHA256_INITIAL = longArrayOf(
            0x6A09E667L, 0xBB67AE85L, 0x3C6EF372L, 0xA54FF53AL,
            0x510E527FL, 0x9B05688CL, 0x1F83D9ABL, 0x5BE0CD19L
        )
        private val SHA256_STATE = longArrayOf(
            0xFD9FBEA2L, 0x91243CE7L, 0xBE499094L, 0xCD2E1E0AL,
            0x6C006F49L, 0x04BD35ABL, 0xFEB0A7E4L, 0x03EFFBD2L
        )
        private val SHA256_SCHEDULE = longArrayOf(
            0xEB24BF9EL, 0x1558691FL, 0xA0C09EE2L, 0x0CFA32BAL,
            0xA622EE8CL, 0xD1DD9491L, 0xC0DD25A0L, 0xF9E70AB6L,
            0xF0C31573L, 0x7058CE4EL, 0x7188E606L, 0x00E5AB33L,
            0xD258B060L, 0x72766564L
        )
        private val SHA256_K = longArrayOf(
            0x428A2F98L, 0x71374491L, 0xB5C0FBCFL, 0xE9B5DBA5L, 0x3956C25BL, 0x59F111F1L, 0x923F82A4L, 0xAB1C5ED5L,
            0xD807AA98L, 0x12835B01L, 0x243185BEL, 0x550C7DC3L, 0x72BE5D74L, 0x80DEB1FEL, 0x9BDC06A7L, 0xC19BF174L,
            0xE49B69C1L, 0xEFBE4786L, 0x0FC19DC6L, 0x240CA1CCL, 0x2DE92C6FL, 0x4A7484AAL, 0x5CB0A9DCL, 0x76F988DAL,
            0x983E5152L, 0xA831C66DL, 0xB00327C8L, 0xBF597FC7L, 0xC6E00BF3L, 0xD5A79147L, 0x06CA6351L, 0x14292967L,
            0x27B70A85L, 0x2E1B2138L, 0x4D2C6DFCL, 0x53380D13L, 0x650A7354L, 0x766A0ABBL, 0x81C2C92EL, 0x92722C85L,
            0xA2BFE8A1L, 0xA81A664BL, 0xC24B8B70L, 0xC76C51A3L, 0xD192E819L, 0xD6990624L, 0xF40E3585L, 0x106AA070L,
            0x19A4C116L, 0x1E376C08L, 0x2748774CL, 0x34B0BCB5L, 0x391C0CB3L, 0x4ED8AA4AL, 0x5B9CCA4FL, 0x682E6FF3L,
            0x748F82EEL, 0x78A5636FL, 0x84C87814L, 0x8CC70208L, 0x90BEFFFAL, 0xA4506CEBL, 0xBEF9A3F7L, 0xC67178F2L
        )
        private const val SHA256_ADJ = 0xC9DC06A7L
        private val SHA256_BLOCK_K = SHA256_K.copyOf().apply { this[14] = SHA256_ADJ }

        private val CS64_COEFFS_A = longArrayOf(
            0xE82E91B1L, 0x44DE24C6L, 0x3BEB65BCL, 0xC89C5933L,
            0x8D1EC211L, 0x314EF5D5L, 0xE92491B1L, 0xF0A5B9D5L,
            0x06064CF3L, 0xDA79FA60L, 0xBED20560L, 0x89F9C9F8L,
            0x35FA38C6L, 0xCB49E3C6L
        )
        private val CS64_COEFFS_B = longArrayOf(
            0xB32700D0L, 0x88DFF51DL, 0x29514038L, 0xB328CBDFL,
            0xD405B4D5L, 0x26E55F3CL, 0x607801C6L, 0x82B2C1FBL,
            0xFA51A3DAL, 0x207CC464L, 0x3C3C74F3L, 0xD2D14B61L,
            0xBB04A2C1L, 0xC5626167L
        )

        private fun rol16(v: Long): Long {
            val u = v and U32
            return ((u shl 16) or (u ushr 16)) and U32
        }

        private fun rotr(v: Long, n: Int): Long {
            val u = v and U32
            return ((u ushr n) or (u shl (32 - n))) and U32
        }

        private fun sigma0(v: Long): Long = (rotr(v, 7) xor rotr(v, 18) xor ((v and U32) ushr 3)) and U32
        private fun sigma1(v: Long): Long = (rotr(v, 17) xor rotr(v, 19) xor ((v and U32) ushr 10)) and U32

        private fun shaRounds(state: LongArray, w: LongArray, first: Int = 0): LongArray {
            var a = state[0]; var b = state[1]; var c = state[2]; var d = state[3]
            var e = state[4]; var f = state[5]; var g = state[6]; var h = state[7]
            val kArr = if (first == 14) SHA256_BLOCK_K else SHA256_K
            for (i in first until 64) {
                val s1 = rotr(e, 6) xor rotr(e, 11) xor rotr(e, 25)
                val ch = (e and f) xor ((e.inv() and U32) and g)
                val t1 = (h + s1 + ch + kArr[i] + w[i]) and U32
                val s0 = rotr(a, 2) xor rotr(a, 13) xor rotr(a, 22)
                val maj = (a and b) xor (a and c) xor (b and c)
                val t2 = (s0 + maj) and U32
                h = g; g = f; f = e
                e = (d + t1) and U32
                d = c; c = b; b = a
                a = (t1 + t2) and U32
            }
            return longArrayOf(a, b, c, d, e, f, g, h)
        }

        private fun expandSchedule(w: LongArray, start: Int = 16) {
            for (i in start until 64) {
                w[i] = (sigma1(w[i - 2]) + w[i - 7] + sigma0(w[i - 15]) + w[i - 16]) and U32
            }
        }

        private fun shaDigest(data: ByteArray): ByteArray {
            val w = LongArray(64)
            w[14] = (((data[0].toLong() and 0xFFL) shl 16) or
                ((data[1].toLong() and 0xFFL) shl 8) or
                (data[2].toLong() and 0xFFL))
            w[15] = (((data[3].toLong() and 0xFFL) shl 24) or
                ((data[4].toLong() and 0xFFL) shl 16) or
                ((data[5].toLong() and 0xFFL) shl 8) or
                (data[6].toLong() and 0xFFL))

            for (i in 16 until 30) {
                var v = SHA256_SCHEDULE[i - 16]
                if (i - 2 >= 14) {
                    v += if (i == 16) (sigma1(w[i - 2]) xor 0x000B92C0L) else sigma1(w[i - 2])
                }
                if (i - 7 >= 14) {
                    v += w[i - 7]
                }
                if (i - 15 >= 14) {
                    v += if (i == 29) (sigma0(w[i - 15]) xor 0x059C0B80L) else sigma0(w[i - 15])
                }
                w[i] = v and U32
            }
            w[30] = (sigma1(w[28]) + w[23] + sigma0(w[15]) + w[14] + SHA256_ADJ - SHA256_K[14]) and U32
            expandSchedule(w, 31)

            val initWorked = shaRounds(SHA256_STATE, w, 14)
            val state = LongArray(8) { idx -> (SHA256_INITIAL[idx] + initWorked[idx]) and U32 }

            val length = 57 + data.size
            val tailLen = data.size - 7
            val zeroPadLen = Math.floorMod(55 - length, 64)
            val padded = ByteArray(tailLen + 1 + zeroPadLen + 8)
            System.arraycopy(data, 7, padded, 0, tailLen)
            padded[tailLen] = 0x80.toByte()
            val bitLen = length.toLong() * 8L
            val lenPos = padded.size - 8
            for (b in 0 until 8) {
                padded[lenPos + b] = ((bitLen ushr (56 - b * 8)) and 0xFFL).toByte()
            }

            var off = 0
            while (off < padded.size) {
                val blk = LongArray(64)
                for (j in 0 until 16) {
                    val p = off + j * 4
                    blk[j] = (((padded[p].toLong() and 0xFFL) shl 24) or
                        ((padded[p + 1].toLong() and 0xFFL) shl 16) or
                        ((padded[p + 2].toLong() and 0xFFL) shl 8) or
                        (padded[p + 3].toLong() and 0xFFL))
                }
                expandSchedule(blk, 16)
                val worked = shaRounds(state, blk, 0)
                for (k in 0 until 8) {
                    state[k] = (state[k] + worked[k]) and U32
                }
                off += 64
            }

            val out = ByteArray(32)
            for (i in 0 until 8) {
                val v = state[i]
                out[i * 4] = ((v ushr 24) and 0xFFL).toByte()
                out[i * 4 + 1] = ((v ushr 16) and 0xFFL).toByte()
                out[i * 4 + 2] = ((v ushr 8) and 0xFFL).toByte()
                out[i * 4 + 3] = (v and 0xFFL).toByte()
            }
            return out
        }

        private fun readLe32(buf: ByteArray, offset: Int): Long =
            ((buf[offset].toLong() and 0xFFL) or
                ((buf[offset + 1].toLong() and 0xFFL) shl 8) or
                ((buf[offset + 2].toLong() and 0xFFL) shl 16) or
                ((buf[offset + 3].toLong() and 0xFFL) shl 24))

        private fun cs64Digest(data: ByteArray, digest: ByteArray): Pair<Long, Long> {
            val keyA = readLe32(digest, 0) or 1L
            val keyB = readLe32(digest, 4) or 1L
            val fa = (keyA * 0x82893933L) and U32
            val fb = (keyB * 0x82893933L) and U32

            val terms = ArrayList<Long>(32)
            val offs = ArrayList<Long>(32)
            for (i in CS64_COEFFS_A.indices) {
                terms.add((CS64_COEFFS_A[i] * if (i % 2 == 0) fa else fb) and U32)
                offs.add(CS64_COEFFS_B[i])
            }

            val rawLen = 1 + data.size
            val padLen = (4 - (rawLen % 4)) % 4
            val raw = ByteArray(rawLen + padLen)
            System.arraycopy(data, 0, raw, 1, data.size)
            val words = ArrayList<Long>(raw.size / 4 + 1)
            var p = 0
            while (p < raw.size) {
                words.add(readLe32(raw, p))
                p += 4
            }
            if (words.size % 2 != 0) words.add(0L)

            for (idx in words.indices) {
                val word = words[idx]
                var t = (word * if (idx % 2 == 0) keyA else keyB) and U32
                var o = (rol16(word) * if (idx % 2 == 0) 0xEF0569FBL else 0xC31713DBL) and U32
                if (idx == 0) {
                    t = (t + ((0xF2F90B1AL * fa) and U32)) and U32
                    o = (o + 0x0B1A0000L) and U32
                }
                terms.add(t)
                offs.add(o)
            }

            var swapAcc = 0L
            var swapLast = 0L
            var state = 0L
            var acc = 0L

            var i = 0
            while (i < terms.size) {
                val x = terms[i]
                val y = terms[i + 1]
                var t = rol16((offs[i] + x) and U32)
                var q = (t * 0x76F50F34L) and U32
                swapAcc = (swapAcc + ((rol16(q) * 0xC3EFEA97L + q) and U32)) and U32
                t = rol16((offs[i + 1] + y) and U32)
                q = (t * 0x1881CE3CL) and U32
                swapLast = (rol16(q) * 0x35BD1EC9L + q) and U32
                swapAcc = (swapAcc + swapLast) and U32

                state = (state * keyA + x) and U32
                state = (rol16(state) * 0xCF98B111L) and U32
                state = (rol16(state) * 0x87085B9FL) and U32
                state = (rol16(state) * 0x12CEB96DL) and U32
                state = (rol16(state) * 0x257E1D83L) and U32
                acc = (acc + state) and U32

                t = (state * keyB + y) and U32
                t = (rol16(t) * 0xA27416F5L) and U32
                t = (rol16(t) * 0xD38396FFL) and U32
                state = (rol16((rol16(t) * 0x7C932B89L) and U32) * 0xBFA49F69L) and U32
                acc = (acc + state) and U32
                i += 2
            }
            return (swapLast xor state) to (swapAcc xor acc)
        }

        fun generateSecMsGecV2(unixSeconds: Long): String {
            var ticks = unixSeconds + WIN_EPOCH
            ticks -= ticks % 300L
            val ticks100ns = ticks * 10_000_000L
            val payload = "$ticks100ns$TRUSTED_CLIENT_TOKEN".toByteArray(Charsets.US_ASCII)
            val digest = shaDigest(payload)
            val (c0, c1) = cs64Digest(payload, digest)
            val csBytes = byteArrayOf(
                (c0 and 0xFFL).toByte(), ((c0 ushr 8) and 0xFFL).toByte(),
                ((c0 ushr 16) and 0xFFL).toByte(), ((c0 ushr 24) and 0xFFL).toByte(),
                (c1 and 0xFFL).toByte(), ((c1 ushr 8) and 0xFFL).toByte(),
                ((c1 ushr 16) and 0xFFL).toByte(), ((c1 ushr 24) and 0xFFL).toByte()
            )
            val csHex = csBytes.joinToString("") { "%02X".format(it) }
            val shaHex = digest.joinToString("") { "%02X".format(it) }
            return "$csHex-$shaHex"
        }

        fun escapeXml(input: String): String = input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
