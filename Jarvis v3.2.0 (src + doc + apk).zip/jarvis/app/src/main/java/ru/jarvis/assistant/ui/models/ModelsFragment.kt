package ru.jarvis.assistant.ui.models

import android.app.ActivityManager
import android.content.Context
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.inference.EngineState
import ru.jarvis.assistant.core.models.DownloadOutcome
import ru.jarvis.assistant.core.models.DownloadPhase
import ru.jarvis.assistant.core.models.LocalArtifactStatus
import ru.jarvis.assistant.core.models.ModelArtifact
import ru.jarvis.assistant.core.models.ModelCatalog
import ru.jarvis.assistant.core.models.ModelProfile
import ru.jarvis.assistant.core.models.ModelProfileId
import ru.jarvis.assistant.ui.MainActivity
import java.util.Locale

class ModelsFragment : Fragment() {

    private lateinit var ramInfoText: TextView
    private lateinit var profileRadioGroup: RadioGroup
    private lateinit var radioSmart: RadioButton
    private lateinit var radioBalanced: RadioButton
    private lateinit var radioLight: RadioButton
    private lateinit var profileSummaryText: TextView
    private lateinit var diskBudgetText: TextView
    private lateinit var downloadAllBtn: MaterialButton
    private lateinit var loadProfileBtn: MaterialButton
    private lateinit var unloadProfileBtn: MaterialButton
    private lateinit var checkSourcesBtn: MaterialButton
    private lateinit var thinkingSwitch: SwitchMaterial
    private lateinit var progressCard: LinearLayout
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var cancelDownloadBtn: MaterialButton
    private lateinit var retryDownloadBtn: MaterialButton
    private lateinit var artifactsContainer: LinearLayout

    private var lastFailedArtifacts: List<ModelArtifact> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_models, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance

        view.findViewById<ImageButton>(R.id.models_back_btn).setOnClickListener {
            (activity as? MainActivity)?.popToChat()
        }

        ramInfoText = view.findViewById(R.id.models_ram_info)
        profileRadioGroup = view.findViewById(R.id.models_profile_group)
        radioSmart = view.findViewById(R.id.models_radio_smart)
        radioBalanced = view.findViewById(R.id.models_radio_balanced)
        radioLight = view.findViewById(R.id.models_radio_light)
        profileSummaryText = view.findViewById(R.id.models_profile_summary)
        diskBudgetText = view.findViewById(R.id.models_disk_budget)
        downloadAllBtn = view.findViewById(R.id.models_download_all_btn)
        loadProfileBtn = view.findViewById(R.id.models_load_btn)
        unloadProfileBtn = view.findViewById(R.id.models_unload_btn)
        checkSourcesBtn = view.findViewById(R.id.models_check_sources_btn)
        thinkingSwitch = view.findViewById(R.id.models_thinking_switch)
        progressCard = view.findViewById(R.id.models_progress_card)
        progressText = view.findViewById(R.id.models_progress_text)
        progressBar = view.findViewById(R.id.models_progress_bar)
        cancelDownloadBtn = view.findViewById(R.id.models_cancel_btn)
        retryDownloadBtn = view.findViewById(R.id.models_retry_btn)
        artifactsContainer = view.findViewById(R.id.models_artifacts_container)

        when (app.prefs.activeProfileId) {
            ModelProfileId.SMART -> radioSmart.isChecked = true
            ModelProfileId.BALANCED -> radioBalanced.isChecked = true
            ModelProfileId.LIGHT -> radioLight.isChecked = true
        }

        thinkingSwitch.isChecked = app.prefs.enableThinking
        thinkingSwitch.setOnCheckedChangeListener { _, checked ->
            app.prefs.enableThinking = checked
        }

        profileRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            val chosen = when (checkedId) {
                R.id.models_radio_smart -> ModelProfileId.SMART
                R.id.models_radio_balanced -> ModelProfileId.BALANCED
                else -> ModelProfileId.LIGHT
            }
            val previous = app.prefs.activeProfileId
            if (chosen != previous) {
                onProfileSwitchRequested(previous, chosen)
            }
        }

        downloadAllBtn.setOnClickListener {
            val profile = ModelCatalog.profileFor(app.prefs.activeProfileId)
            confirmAndDownload(profile.allArtifacts, "Скачать профиль «${profile.id.shortTitleRu}»?")
        }

        loadProfileBtn.setOnClickListener {
            val profile = ModelCatalog.profileFor(app.prefs.activeProfileId)
            viewLifecycleOwner.lifecycleScope.launch {
                val res = app.inferenceEngine.loadProfile(profile)
                res.onSuccess {
                    Toast.makeText(requireContext(), "Модель ${profile.llm.displayName} загружена локально!", Toast.LENGTH_SHORT).show()
                }.onFailure { err ->
                    AlertDialog.Builder(requireContext())
                        .setTitle("Не удалось загрузить модель")
                        .setMessage(err.message ?: "Неизвестная ошибка")
                        .setPositiveButton("Понятно", null)
                        .show()
                }
                renderArtifacts()
            }
        }

        unloadProfileBtn.setOnClickListener {
            app.inferenceEngine.unload()
            Toast.makeText(requireContext(), "Модель выгружена из ОЗУ.", Toast.LENGTH_SHORT).show()
            renderArtifacts()
        }

        checkSourcesBtn.setOnClickListener {
            val profile = ModelCatalog.profileFor(app.prefs.activeProfileId)
            Toast.makeText(requireContext(), "Проверяю доступность источников…", Toast.LENGTH_SHORT).show()
            viewLifecycleOwner.lifecycleScope.launch {
                val results = app.downloadManager.checkSourcesAvailability(profile.allArtifacts)
                val summary = results.joinToString("\n\n") { r ->
                    val mark = if (r.reachable) "✓" else "✗"
                    "$mark ${r.displayName}\n${r.statusNoteRu}"
                }
                if (isAdded) {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Проверка источников моделей")
                        .setMessage(summary)
                        .setPositiveButton("Закрыть", null)
                        .show()
                }
            }
        }

        cancelDownloadBtn.setOnClickListener { app.downloadManager.cancelActiveDownload() }

        retryDownloadBtn.setOnClickListener {
            val toRetry = lastFailedArtifacts.ifEmpty {
                ModelCatalog.profileFor(app.prefs.activeProfileId).allArtifacts
            }
            startDownloadFlow(toRetry)
        }

        renderDeviceRamInfo()
        renderArtifacts()
        observeFlows()
    }

    private fun onProfileSwitchRequested(previous: ModelProfileId, chosen: ModelProfileId) {
        val app = JarvisApplication.instance
        app.prefs.activeProfileId = chosen
        app.inferenceEngine.unload()

        val prevProfile = ModelCatalog.profileFor(previous)
        val hasOldFiles = app.modelStorage.inspectQuickStatus(prevProfile.llm) != LocalArtifactStatus.MISSING ||
            app.modelStorage.inspectQuickStatus(prevProfile.visionProjector) != LocalArtifactStatus.MISSING

        if (hasOldFiles) {
            AlertDialog.Builder(requireContext())
                .setTitle("Смена профиля моделей")
                .setMessage(
                    "Удалить файлы предыдущего профиля (${prevProfile.llm.displayName} и его mmproj) " +
                        "для экономии места на диске? Офлайн-голос Vosk сохранится."
                )
                .setPositiveButton("Удалить старый профиль") { _, _ ->
                    app.modelStorage.deleteProfileSpecificModels(prevProfile)
                    renderArtifacts()
                }
                .setNegativeButton("Оставить оба") { _, _ -> renderArtifacts() }
                .show()
        } else {
            renderArtifacts()
        }
    }

    private fun observeFlows() {
        val app = JarvisApplication.instance

        viewLifecycleOwner.lifecycleScope.launch {
            app.downloadManager.state.collectLatest { st ->
                when (st.phase) {
                    DownloadPhase.IDLE -> progressCard.visibility = View.GONE
                    DownloadPhase.DOWNLOADING, DownloadPhase.VERIFYING_SHA256, DownloadPhase.EXTRACTING -> {
                        progressCard.visibility = View.VISIBLE
                        cancelDownloadBtn.visibility = View.VISIBLE
                        retryDownloadBtn.visibility = View.GONE
                        progressBar.isIndeterminate = st.phase != DownloadPhase.DOWNLOADING
                        progressBar.progress = st.progressPercent
                        val batchPrefix = if (st.batchTotal > 1) "[${st.batchIndex}/${st.batchTotal}] " else ""
                        progressText.text = "$batchPrefix${st.messageRu} (${st.progressPercent}%)"
                    }
                    DownloadPhase.COMPLETED -> {
                        progressCard.visibility = View.VISIBLE
                        cancelDownloadBtn.visibility = View.GONE
                        retryDownloadBtn.visibility = View.GONE
                        progressBar.isIndeterminate = false
                        progressBar.progress = 100
                        progressText.text = "✓ ${st.messageRu}"
                        renderArtifacts()
                    }
                    DownloadPhase.CANCELLED -> {
                        progressCard.visibility = View.VISIBLE
                        cancelDownloadBtn.visibility = View.GONE
                        retryDownloadBtn.visibility = View.VISIBLE
                        progressBar.isIndeterminate = false
                        progressText.text = st.messageRu
                        renderArtifacts()
                    }
                    DownloadPhase.ERROR -> {
                        progressCard.visibility = View.VISIBLE
                        cancelDownloadBtn.visibility = View.GONE
                        retryDownloadBtn.visibility = View.VISIBLE
                        progressBar.isIndeterminate = false
                        progressText.text = "Ошибка: ${st.messageRu}"
                        renderArtifacts()
                    }
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            app.inferenceEngine.state.collectLatest { engState ->
                unloadProfileBtn.isEnabled = engState is EngineState.Ready
            }
        }
    }

    private fun renderDeviceRamInfo() {
        val am = requireContext().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val totalGb = info.totalMem / (1024.0 * 1024.0 * 1024.0)
        val availGb = info.availMem / (1024.0 * 1024.0 * 1024.0)
        val recommendation = when {
            totalGb >= 7.5 -> "Рекомендуется «Умный» (Gemma 3 4B IT) — отличный русский язык и зрение."
            totalGb >= 4.5 -> "Рекомендуется «Баланс» (Qwen3-VL-2B-Instruct)."
            else -> "Рекомендуется «Лёгкий» (Qwen3.5-0.8B) для экономии ОЗУ."
        }
        ramInfoText.text = String.format(
            Locale.US,
            "ОЗУ: %.1f ГБ всего (свободно %.1f ГБ). %s",
            totalGb,
            availGb,
            recommendation
        )
    }

    private fun renderArtifacts() {
        val app = JarvisApplication.instance
        val profile: ModelProfile = ModelCatalog.profileFor(app.prefs.activeProfileId)
        val usedBytes = app.modelStorage.installedDiskUsageBytes()
        val freeBytes = app.modelStorage.availableSpaceBytes()

        thinkingSwitch.visibility = if (profile.id == ModelProfileId.LIGHT) View.VISIBLE else View.GONE

        profileSummaryText.text = "${profile.id.subtitleRu}\n" +
            "Общий объём скачивания профиля: ${ModelCatalog.formatBytes(profile.totalDownloadBytes)}."

        diskBudgetText.text = "Занято моделями: ${ModelCatalog.formatBytes(usedBytes)} • " +
            "Свободно: ${ModelCatalog.formatBytes(freeBytes)}"

        artifactsContainer.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())

        for (artifact in profile.allArtifacts) {
            val card = inflater.inflate(R.layout.item_model_artifact, artifactsContainer, false)
            val nameTv: TextView = card.findViewById(R.id.artifact_name)
            val roleTv: TextView = card.findViewById(R.id.artifact_role)
            val metaTv: TextView = card.findViewById(R.id.artifact_meta)
            val statusTv: TextView = card.findViewById(R.id.artifact_status)
            val downloadBtn: MaterialButton = card.findViewById(R.id.artifact_download_btn)
            val deleteBtn: MaterialButton = card.findViewById(R.id.artifact_delete_btn)

            val status = app.modelStorage.inspectQuickStatus(artifact)
            nameTv.text = artifact.displayName
            roleTv.text = artifact.role.displayNameRu
            metaTv.text = buildString {
                append("Размер: ").append(ModelCatalog.formatBytes(artifact.sizeBytes))
                append(" • Лицензия: ").append(artifact.licenseName).append('\n')
                append("Источник: ").append(artifact.repoName).append('\n')
                append("Ревизия: ").append(artifact.pinnedRevision.take(12))
                append(" • SHA-256: ").append(artifact.sha256.take(16)).append("…\n")
                append(artifact.notesRu)
            }

            when (status) {
                LocalArtifactStatus.INSTALLED_VERIFIED -> {
                    statusTv.text = "Статус: ✓ Установлено и проверено SHA-256"
                    downloadBtn.visibility = View.GONE
                    deleteBtn.visibility = View.VISIBLE
                }
                LocalArtifactStatus.PARTIAL -> {
                    val partLen = app.modelStorage.partFileFor(artifact).length()
                    statusTv.text = "Статус: Частично скачано (${ModelCatalog.formatBytes(partLen)}) — доступна докачка"
                    downloadBtn.visibility = View.VISIBLE
                    downloadBtn.text = "Докачать"
                    deleteBtn.visibility = View.VISIBLE
                }
                LocalArtifactStatus.CORRUPT_HASH_MISMATCH -> {
                    statusTv.text = "Статус: ✗ Повреждено / несовпадение SHA-256"
                    downloadBtn.visibility = View.VISIBLE
                    downloadBtn.text = "Перекачать"
                    deleteBtn.visibility = View.VISIBLE
                }
                LocalArtifactStatus.MISSING -> {
                    statusTv.text = "Статус: Не скачано"
                    downloadBtn.visibility = View.VISIBLE
                    downloadBtn.text = "Скачать"
                    deleteBtn.visibility = View.GONE
                }
            }

            downloadBtn.setOnClickListener {
                confirmAndDownload(listOf(artifact), "Скачать ${artifact.displayName}?")
            }

            deleteBtn.setOnClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle("Удалить ${artifact.displayName}?")
                    .setMessage("Локальный файл (${ModelCatalog.formatBytes(artifact.sizeBytes)}) будет удалён.")
                    .setPositiveButton("Удалить") { _, _ ->
                        if (artifact.id == profile.llm.id || artifact.id == profile.visionProjector.id) {
                            app.inferenceEngine.unload()
                        } else if (artifact.id == ModelCatalog.VOSK_SMALL_RU.id) {
                            app.voiceEngine.releaseModel()
                        }
                        app.modelStorage.deleteArtifact(artifact)
                        renderArtifacts()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }

            artifactsContainer.addView(card)
        }
    }

    private fun confirmAndDownload(artifacts: List<ModelArtifact>, title: String) {
        val app = JarvisApplication.instance
        val pending = artifacts.filter {
            app.modelStorage.inspectQuickStatus(it) != LocalArtifactStatus.INSTALLED_VERIFIED
        }
        if (pending.isEmpty()) {
            Toast.makeText(requireContext(), "Все выбранные модели уже установлены.", Toast.LENGTH_SHORT).show()
            return
        }

        val totalRemaining = pending.sumOf { artifact ->
            val partLen = app.modelStorage.partFileFor(artifact).takeIf { it.exists() }?.length() ?: 0L
            (artifact.sizeBytes - partLen).coerceAtLeast(0L)
        }
        val onCellular = isOnCellularNetwork()
        val lowBattery = isBatteryLow()

        val message = buildString {
            append("Файлы к загрузке (${pending.size}):\n")
            for (a in pending) {
                append("• ${a.displayName} (${ModelCatalog.formatBytes(a.sizeBytes)}, ${a.licenseName})\n")
            }
            append("\nОбщий объём: ${ModelCatalog.formatBytes(totalRemaining)}\n")
            append("После загрузки выполняется проверка SHA-256.\n")
            if (onCellular) {
                append("\nВНИМАНИЕ: вы на мобильной сети — скачивание расходует мобильный трафик.")
            }
            if (lowBattery) {
                append("\nВНИМАНИЕ: низкий заряд батареи (< 15%).")
            }
        }

        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (onCellular) "Скачать по мобильной сети" else "Скачать") { _, _ ->
                startDownloadFlow(pending)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun startDownloadFlow(artifacts: List<ModelArtifact>) {
        lastFailedArtifacts = artifacts
        val app = JarvisApplication.instance
        viewLifecycleOwner.lifecycleScope.launch {
            val outcome = app.downloadManager.downloadBatch(artifacts)
            if (outcome is DownloadOutcome.Success) {
                lastFailedArtifacts = emptyList()
                renderArtifacts()
            }
        }
    }

    private fun isOnCellularNetwork(): Boolean {
        val cm = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun isBatteryLow(): Boolean {
        val intent = requireContext().registerReceiver(null, IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
        return pct < 15
    }
}
