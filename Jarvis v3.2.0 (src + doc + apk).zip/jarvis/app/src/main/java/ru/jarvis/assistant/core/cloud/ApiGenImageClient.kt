package ru.jarvis.assistant.core.cloud

import android.content.Context
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Pure-Kotlin MQTT 3.1.1 binary codec (unit-testable on JVM, zero external dependencies).
 * Used over TLS WebSockets (wss://.../mqtt) so traffic is encrypted and passes Android
 * usesCleartextTraffic="false" and mobile carrier firewalls cleanly.
 */
object MiniMqttCodec {

    data class DecodedPacket(
        val headerByte: Int,
        val payload: ByteArray
    ) {
        val packetType: Int get() = (headerByte and 0xF0) ushr 4
        val qos: Int get() = (headerByte and 0x06) ushr 1
    }

    data class PublishMessage(
        val topic: String,
        val payloadUtf8: String
    )

    fun encodeUtf8String(value: String): ByteArray {
        val bytes = value.toByteArray(Charsets.UTF_8)
        val out = ByteArray(2 + bytes.size)
        out[0] = ((bytes.size ushr 8) and 0xFF).toByte()
        out[1] = (bytes.size and 0xFF).toByte()
        System.arraycopy(bytes, 0, out, 2, bytes.size)
        return out
    }

    fun encodeRemainingLength(length: Int): ByteArray {
        val out = ByteArrayOutputStream(4)
        var x = length.coerceAtLeast(0)
        do {
            var encodedByte = x % 128
            x /= 128
            if (x > 0) encodedByte = encodedByte or 128
            out.write(encodedByte)
        } while (x > 0)
        return out.toByteArray()
    }

    fun buildPacket(headerByte: Int, body: ByteArray): ByteArray {
        val remLen = encodeRemainingLength(body.size)
        val out = ByteArray(1 + remLen.size + body.size)
        out[0] = (headerByte and 0xFF).toByte()
        System.arraycopy(remLen, 0, out, 1, remLen.size)
        System.arraycopy(body, 0, out, 1 + remLen.size, body.size)
        return out
    }

    fun encodeConnect(clientId: String, keepAliveSeconds: Int = 60): ByteArray {
        val body = ByteArrayOutputStream()
        body.write(encodeUtf8String("MQTT"))
        body.write(0x04) // MQTT 3.1.1
        body.write(0x02) // Clean session
        body.write((keepAliveSeconds ushr 8) and 0xFF)
        body.write(keepAliveSeconds and 0xFF)
        body.write(encodeUtf8String(clientId))
        return buildPacket(0x10, body.toByteArray())
    }

    fun encodeSubscribe(packetId: Int, topic: String): ByteArray {
        val body = ByteArrayOutputStream()
        body.write((packetId ushr 8) and 0xFF)
        body.write(packetId and 0xFF)
        body.write(encodeUtf8String(topic))
        body.write(0x00) // QoS 0
        return buildPacket(0x82, body.toByteArray())
    }

    fun encodePublish(topic: String, payloadUtf8: String): ByteArray {
        val body = ByteArrayOutputStream()
        body.write(encodeUtf8String(topic))
        body.write(payloadUtf8.toByteArray(Charsets.UTF_8))
        return buildPacket(0x30, body.toByteArray())
    }

    fun encodeDisconnect(): ByteArray = byteArrayOf(0xE0.toByte(), 0x00)

    fun parsePublish(packet: DecodedPacket): PublishMessage? {
        if (packet.packetType != 3) return null
        val buf = packet.payload
        if (buf.size < 2) return null
        val topicLen = ((buf[0].toInt() and 0xFF) shl 8) or (buf[1].toInt() and 0xFF)
        var offset = 2 + topicLen
        if (offset > buf.size) return null
        val topic = String(buf, 2, topicLen, Charsets.UTF_8)
        if (packet.qos > 0) {
            offset += 2 // skip Packet Identifier
            if (offset > buf.size) return null
        }
        val body = String(buf, offset, buf.size - offset, Charsets.UTF_8)
        return PublishMessage(topic = topic, payloadUtf8 = body)
    }

    /** Streaming frame accumulator (handles split or coalesced MQTT packets inside WS frames). */
    class StreamDecoder {
        private var buffer = ByteArray(0)

        @Synchronized
        fun feed(chunk: ByteArray): List<DecodedPacket> {
            if (chunk.isEmpty()) return emptyList()
            val combined = ByteArray(buffer.size + chunk.size)
            System.arraycopy(buffer, 0, combined, 0, buffer.size)
            System.arraycopy(chunk, 0, combined, buffer.size, chunk.size)
            buffer = combined

            val out = mutableListOf<DecodedPacket>()
            var pos = 0
            while (pos + 2 <= buffer.size) {
                val header = buffer[pos].toInt() and 0xFF
                var mult = 1
                var remLen = 0
                var lenBytes = 0
                var completeLen = false
                while (pos + 1 + lenBytes < buffer.size && lenBytes < 4) {
                    val b = buffer[pos + 1 + lenBytes].toInt() and 0xFF
                    remLen += (b and 0x7F) * mult
                    lenBytes++
                    if ((b and 0x80) == 0) {
                        completeLen = true
                        break
                    }
                    mult *= 128
                }
                if (!completeLen) break
                val totalPacketSize = 1 + lenBytes + remLen
                if (pos + totalPacketSize > buffer.size) break
                val payload = ByteArray(remLen)
                System.arraycopy(buffer, pos + 1 + lenBytes, payload, 0, remLen)
                out.add(DecodedPacket(header, payload))
                pos += totalPacketSize
            }
            if (pos > 0) {
                val remaining = buffer.size - pos
                val nextBuf = ByteArray(remaining)
                if (remaining > 0) System.arraycopy(buffer, pos, nextBuf, 0, remaining)
                buffer = nextBuf
            }
            return out
        }
    }
}

/**
 * Curated list of real art styles supported by https://perchance.org/api-gen (t2i-styles).
 * Empty apiStyleId = "No Style" (pure prompt).
 */
data class ApiGenStyleOption(
    val apiStyleId: String,
    val labelRu: String
)

object ApiGenStyles {
    val PRESETS: List<ApiGenStyleOption> = listOf(
        ApiGenStyleOption("", "Без стиля (чистый промпт)"),
        ApiGenStyleOption("Painted Anime", "Аниме (живописное)"),
        ApiGenStyleOption("Anime", "Аниме (классика)"),
        ApiGenStyleOption("Studio Ghibli", "Студия Ghibli"),
        ApiGenStyleOption("Professional Photo", "Профессиональное фото"),
        ApiGenStyleOption("Casual Photo", "Живое фото"),
        ApiGenStyleOption("Cinematic", "Кинематограф"),
        ApiGenStyleOption("Digital Painting", "Цифровая живопись"),
        ApiGenStyleOption("Concept Art", "Концепт-арт"),
        ApiGenStyleOption("Fantasy Painting", "Фэнтези-арт"),
        ApiGenStyleOption("3D Disney Character", "3D / Pixar стиль"),
        ApiGenStyleOption("Oil Painting", "Масляная живопись"),
        ApiGenStyleOption("Watercolor", "Акварель"),
        ApiGenStyleOption("Neon Vintage Anime", "Неон / Ретро-аниме"),
        ApiGenStyleOption("Manga", "Манга"),
        ApiGenStyleOption("Pixel Art", "Пиксель-арт")
    )

    fun labelFor(styleId: String?): String {
        val clean = styleId?.trim().orEmpty()
        if (clean.isEmpty()) return PRESETS.first().labelRu
        return PRESETS.firstOrNull { it.apiStyleId.equals(clean, ignoreCase = true) }?.labelRu ?: clean
    }
}

/**
 * Direct client for https://perchance.org/api-gen over TLS WebSocket MQTT (wss://.../mqtt).
 * - Zero API keys, zero Cloudflare Turnstile, zero WebView overhead.
 * - Uses strict 6-second ACK timeout so if all api-gen browser workers are temporarily offline,
 *   the orchestrator immediately switches to fallback engines without hanging!
 */
class ApiGenImageClient(
    private val outDir: File,
    private val brokers: List<String> = DEFAULT_WSS_BROKERS
) {
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    suspend fun generate(
        request: ImageGenRequest,
        onStatus: ((String) -> Unit)? = null
    ): PerchanceImageResult = withContext(Dispatchers.IO) {
        val cleanPrompt = request.prompt.trim()
        if (cleanPrompt.isEmpty()) {
            return@withContext PerchanceImageResult(ok = false, errorRu = "Пустой промпт изображения.")
        }

        val brokerErrors = mutableListOf<String>()
        for (brokerUrl in brokers) {
            onStatus?.invoke("Подключение к api-gen (${brokerHostLabel(brokerUrl)})…")
            val attempt = attemptOnBroker(brokerUrl, request, onStatus)
            if (attempt.ok) return@withContext attempt
            brokerErrors.add("${brokerHostLabel(brokerUrl)}: ${attempt.errorRu}")
            // If workers explicitly rejected the prompt or generation failed after ACK, don't retry same error on next broker
            if (attempt.errorRu?.contains("отклонил", ignoreCase = true) == true) {
                return@withContext attempt
            }
        }

        PerchanceImageResult(
            ok = false,
            engineUsed = "perchance.org/api-gen",
            modelUsed = request.qualityMode.apiModelId,
            styleUsed = request.style,
            effectivePrompt = cleanPrompt,
            errorRu = "Воркеры api-gen не ответили (${brokerErrors.joinToString("; ")})"
        )
    }

    private suspend fun attemptOnBroker(
        brokerUrl: String,
        request: ImageGenRequest,
        onStatus: ((String) -> Unit)?
    ): PerchanceImageResult {
        val reqId = "jv_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val clientId = "jarvis_and_${UUID.randomUUID().toString().replace("-", "").take(8)}"

        val connAcked = CompletableDeferred<Boolean>()
        val subAcked = CompletableDeferred<Boolean>()
        val jobAcked = CompletableDeferred<Boolean>()
        val finalEvent = CompletableDeferred<ApiGenOutcome>()
        val decoder = MiniMqttCodec.StreamDecoder()
        val closed = AtomicBoolean(false)

        val wsReq = Request.Builder()
            .url(brokerUrl)
            .header("Sec-WebSocket-Protocol", "mqtt")
            .build()

        val ws = httpClient.newWebSocket(wsReq, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(MiniMqttCodec.encodeConnect(clientId).toByteString())
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val packets = decoder.feed(bytes.toByteArray())
                for (pkt in packets) {
                    when (pkt.packetType) {
                        2 -> { // CONNACK
                            val ok = pkt.payload.size >= 2 && pkt.payload[1].toInt() == 0
                            connAcked.complete(ok)
                        }
                        9 -> { // SUBACK
                            subAcked.complete(true)
                        }
                        3 -> { // PUBLISH
                            val pub = MiniMqttCodec.parsePublish(pkt) ?: continue
                            if (!pub.payloadUtf8.contains(reqId)) continue
                            val json = runCatching { JSONObject(pub.payloadUtf8) }.getOrNull() ?: continue
                            if (json.optString("id") != reqId) continue
                            when (json.optString("type")) {
                                "ack" -> {
                                    jobAcked.complete(true)
                                    val etaSec = (json.optLong("etaMs", 12_000L) / 1000L).coerceIn(5L, 90L)
                                    onStatus?.invoke("api-gen принял задачу (${request.qualityMode.shortRu}, ~${etaSec}с)…")
                                }
                                "progress" -> {
                                    jobAcked.complete(true)
                                    val stage = json.optString("stage").ifBlank { json.optString("status") }
                                    if (stage.isNotBlank()) onStatus?.invoke("api-gen: $stage…")
                                }
                                "image" -> {
                                    jobAcked.complete(true)
                                    val url = json.optString("url", "").trim()
                                    val seed = json.optLong("seed", -1L).takeIf { it > 0L }
                                    val model = json.optString("model", request.qualityMode.apiModelId)
                                    if (url.isNotEmpty()) {
                                        finalEvent.complete(ApiGenOutcome(ok = true, url = url, seed = seed, model = model))
                                    }
                                }
                                "result" -> {
                                    jobAcked.complete(true)
                                    val ok = json.optBoolean("ok", false)
                                    val images = json.optJSONArray("images")
                                    val first = images?.optJSONObject(0)
                                    val url = first?.optString("url", "")?.trim().orEmpty()
                                    val seed = first?.optLong("seed", -1L)?.takeIf { it > 0L }
                                    val model = first?.optString("model", request.qualityMode.apiModelId)
                                        ?: request.qualityMode.apiModelId
                                    if (ok && url.isNotEmpty()) {
                                        finalEvent.complete(ApiGenOutcome(ok = true, url = url, seed = seed, model = model))
                                    } else {
                                        val msg = json.optString("message").ifBlank { "Пустой результат api-gen" }
                                        finalEvent.complete(ApiGenOutcome(ok = false, errorRu = msg))
                                    }
                                }
                                "error" -> {
                                    jobAcked.complete(true)
                                    val code = json.optString("error", "error")
                                    val msg = json.optString("message").ifBlank { code }
                                    finalEvent.complete(ApiGenOutcome(ok = false, errorRu = "api-gen отклонил: $msg"))
                                }
                            }
                        }
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val err = t.message ?: response?.message ?: "Ошибка WebSocket"
                connAcked.complete(false)
                subAcked.complete(false)
                jobAcked.complete(false)
                finalEvent.complete(ApiGenOutcome(ok = false, errorRu = err))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                closed.set(true)
                if (!finalEvent.isCompleted) {
                    finalEvent.complete(ApiGenOutcome(ok = false, errorRu = "Соединение закрыто ($code)"))
                }
            }
        })

        try {
            val connected = withTimeoutOrNull(4_500L) { connAcked.await() } == true
            if (!connected) {
                return PerchanceImageResult(ok = false, errorRu = "Не удалось подключиться к MQTT")
            }

            ws.send(MiniMqttCodec.encodeSubscribe(1, TOPIC_RES).toByteString())
            val subscribed = withTimeoutOrNull(3_500L) { subAcked.await() } == true
            if (!subscribed) {
                return PerchanceImageResult(ok = false, errorRu = "Нет ответа SUBACK")
            }

            val payloadObj = buildGeneratePayload(reqId, request)
            ws.send(MiniMqttCodec.encodePublish(TOPIC_REQ, payloadObj.toString()).toByteString())

            // Fast 6-second ACK check: if no api-gen browser worker is online, bail quickly to fallback!
            val gotAck = withTimeoutOrNull(ACK_TIMEOUT_MS) { jobAcked.await() } == true
            if (!gotAck) {
                return PerchanceImageResult(ok = false, errorRu = "Нет ответа от воркеров за 6 сек")
            }

            val genTimeoutMs = if (request.qualityMode == ImageQualityMode.FULL) 95_000L else 48_000L
            val outcome = withTimeoutOrNull(genTimeoutMs) { finalEvent.await() }
                ?: return PerchanceImageResult(
                    ok = false,
                    errorRu = "Таймаут ожидания готового изображения api-gen (${genTimeoutMs / 1000}с)"
                )

            if (!outcome.ok || outcome.url.isNullOrBlank()) {
                return PerchanceImageResult(
                    ok = false,
                    errorRu = outcome.errorRu ?: "api-gen не вернул изображение"
                )
            }

            onStatus?.invoke("Скачивание готового изображения…")
            val localFile = downloadImageToDisk(outcome.url, prefix = "apigen")
                ?: return PerchanceImageResult(
                    ok = false,
                    remoteUrl = outcome.url,
                    errorRu = "Изображение создано, но не удалось скачать файл."
                )

            return PerchanceImageResult(
                ok = true,
                localFilePath = localFile.absolutePath,
                remoteUrl = outcome.url,
                seed = outcome.seed,
                engineUsed = "perchance.org/api-gen",
                modelUsed = outcome.model.ifBlank { request.qualityMode.apiModelId },
                styleUsed = request.style?.takeIf { it.isNotBlank() },
                effectivePrompt = request.prompt
            )
        } finally {
            runCatching {
                if (!closed.get()) {
                    ws.send(MiniMqttCodec.encodeDisconnect().toByteString())
                }
                ws.close(1000, "done")
            }
        }
    }

    private fun downloadImageToDisk(url: String, prefix: String): File? {
        outDir.mkdirs()
        val req = Request.Builder().url(url).get().build()
        return runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val bytes = resp.body?.bytes() ?: return@use null
                if (bytes.size < 512) return@use null
                val ct = resp.header("Content-Type").orEmpty().lowercase()
                val ext = when {
                    ct.contains("png") -> "png"
                    ct.contains("webp") -> "webp"
                    else -> "jpg"
                }
                val file = File(outDir, "${prefix}_${System.currentTimeMillis()}.$ext")
                file.writeBytes(bytes)
                file
            }
        }.getOrNull()
    }

    private data class ApiGenOutcome(
        val ok: Boolean,
        val url: String? = null,
        val seed: Long? = null,
        val model: String = "",
        val errorRu: String? = null
    )

    companion object {
        const val TOPIC_REQ = "perchance/api/n878vbm0ije9wwvais53/req"
        const val TOPIC_RES = "perchance/api/n878vbm0ije9wwvais53/res"
        const val PUBLIC_API_TOKEN = "6jjhok4f0c8q9ues"
        const val ACK_TIMEOUT_MS = 6_000L

        val DEFAULT_WSS_BROKERS = listOf(
            "wss://broker.emqx.io:8084/mqtt",
            "wss://broker.hivemq.com:8884/mqtt",
            "wss://test.mosquitto.org:8081/mqtt"
        )

        fun resolutionToShape(resolution: String): String = when (resolution.trim()) {
            "512x768" -> "Portrait"
            "768x512" -> "Landscape"
            else -> "Square"
        }

        fun buildGeneratePayload(reqId: String, request: ImageGenRequest): JSONObject = JSONObject().apply {
            put("id", reqId)
            put("token", PUBLIC_API_TOKEN)
            put("client", "jarvis-android")
            put("name", "Jarvis Android")
            put("type", "generate")
            put("prompt", request.prompt.trim())
            if (request.negativePrompt.isNotBlank()) {
                put("negativePrompt", request.negativePrompt.trim())
            }
            put("resolution", request.resolution.ifBlank { "768x768" })
            put("shape", resolutionToShape(request.resolution))
            put("numImages", 1)
            put("stream", true)
            put("model", request.qualityMode.apiModelId)
            put("verify", request.qualityMode == ImageQualityMode.FULL)
            request.style?.trim()?.takeIf { it.isNotEmpty() }?.let { put("style", it) }
            request.seed?.takeIf { it > 0L }?.let { put("seed", it) }
        }

        private fun brokerHostLabel(url: String): String =
            url.removePrefix("wss://").substringBefore(":").substringBefore("/")
    }
}

/**
 * Fallback #3: Free keyless HTTP image generator via Pollinations.ai (Sana/Flux).
 */
class PollinationsImageClient(private val outDir: File) {
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun generate(request: ImageGenRequest): PerchanceImageResult = withContext(Dispatchers.IO) {
        val cleanPrompt = buildString {
            append(request.prompt.trim())
            if (!request.style.isNullOrBlank()) {
                append(", ").append(request.style.trim()).append(" style")
            }
        }
        val dims = request.resolution.split("x")
        val width = dims.getOrNull(0)?.toIntOrNull()?.coerceIn(256, 1024) ?: 768
        val height = dims.getOrNull(1)?.toIntOrNull()?.coerceIn(256, 1024) ?: 768
        val seed = request.seed?.takeIf { it > 0L } ?: (System.currentTimeMillis() % 1_000_000L)
        val encoded = URLEncoder.encode(cleanPrompt.take(700), "UTF-8").replace("+", "%20")
        val url = "https://image.pollinations.ai/prompt/$encoded?width=$width&height=$height&nologo=true&seed=$seed"

        val req = Request.Builder()
            .url(url)
            .header("Accept", "image/jpeg,image/png,image/webp,*/*")
            .get()
            .build()

        runCatching {
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val retryAfter = resp.header("Retry-After")
                    val extra = if (!retryAfter.isNullOrBlank()) " (пауза ${retryAfter}с)" else ""
                    return@use PerchanceImageResult(
                        ok = false,
                        engineUsed = "Pollinations.ai",
                        errorRu = "Pollinations HTTP ${resp.code}$extra"
                    )
                }
                val bytes = resp.body?.bytes() ?: return@use PerchanceImageResult(
                    ok = false,
                    engineUsed = "Pollinations.ai",
                    errorRu = "Pollinations вернул пустой ответ"
                )
                val ct = resp.header("Content-Type").orEmpty().lowercase()
                if (!ct.startsWith("image/") || bytes.size < 1024) {
                    return@use PerchanceImageResult(
                        ok = false,
                        engineUsed = "Pollinations.ai",
                        errorRu = "Pollinations вернул не изображение ($ct)"
                    )
                }
                outDir.mkdirs()
                val ext = if (ct.contains("png")) "png" else if (ct.contains("webp")) "webp" else "jpg"
                val file = File(outDir, "pollinations_${System.currentTimeMillis()}.$ext")
                file.writeBytes(bytes)
                PerchanceImageResult(
                    ok = true,
                    localFilePath = file.absolutePath,
                    remoteUrl = url,
                    seed = seed,
                    engineUsed = "Pollinations.ai (резерв)",
                    modelUsed = "sana/flux",
                    styleUsed = request.style?.takeIf { it.isNotBlank() },
                    effectivePrompt = request.prompt
                )
            }
        }.getOrElse { err ->
            PerchanceImageResult(
                ok = false,
                engineUsed = "Pollinations.ai",
                errorRu = "Pollinations ошибка сети: ${err.message}"
            )
        }
    }
}

/**
 * 3-stage resilient image generation cascade requested by the user:
 *   1) perchance.org/api-gen (MQTT WSS, fast 6s worker ACK timeout, supports fast/full + 77 styles)
 *   2) Perchance official Embed (image-generation.perchance.org/embed via WebView)
 *   3) Pollinations.ai (free keyless HTTP fallback)
 */
class ImageGenerationOrchestrator(
    context: Context,
    private val perchanceBridge: PerchanceWebViewBridge
) {
    private val outDir = File(context.applicationContext.filesDir, "generated_images")
    private val apiGenClient = ApiGenImageClient(outDir)
    private val pollinationsClient = PollinationsImageClient(outDir)

    suspend fun generate(
        request: ImageGenRequest,
        onStatus: ((String) -> Unit)? = null
    ): PerchanceImageResult {
        val notes = mutableListOf<String>()

        // Stage 1: perchance.org/api-gen (primary)
        val r1 = apiGenClient.generate(request, onStatus)
        if (r1.ok) {
            return r1.copy(fallbackNotes = notes)
        }
        notes.add("api-gen: ${r1.errorRu ?: "недоступен"}")

        // Stage 2: Perchance official image-generation.perchance.org/embed (only if Perchance bridge is verified/ready)
        onStatus?.invoke("Переключение на резерв: Perchance Embed…")
        val styledPrompt = buildString {
            append(request.prompt.trim())
            if (!request.style.isNullOrBlank()) {
                append(", ").append(request.style.trim()).append(" style")
            }
        }
        val r2 = perchanceBridge.generateImage(
            prompt = styledPrompt,
            resolution = request.resolution,
            negativePrompt = request.negativePrompt
        )
        if (r2.ok) {
            return r2.copy(
                engineUsed = "Perchance Embed (резерв)",
                modelUsed = "image-generation.perchance.org",
                styleUsed = request.style?.takeIf { it.isNotBlank() },
                effectivePrompt = request.prompt,
                fallbackNotes = notes
            )
        }
        notes.add("Perchance Embed: ${r2.errorRu ?: "недоступен"}")

        // Stage 3: Pollinations.ai (free keyless HTTP)
        onStatus?.invoke("Переключение на резерв: Pollinations.ai…")
        val r3 = pollinationsClient.generate(request)
        if (r3.ok) {
            return r3.copy(fallbackNotes = notes)
        }
        notes.add("Pollinations: ${r3.errorRu ?: "недоступен"}")

        return PerchanceImageResult(
            ok = false,
            errorRu = "Не удалось сгенерировать изображение ни одним движком:\n• ${notes.joinToString("\n• ")}",
            fallbackNotes = notes
        )
    }
}
