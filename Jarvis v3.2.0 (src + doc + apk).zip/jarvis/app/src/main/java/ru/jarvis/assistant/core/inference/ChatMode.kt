package ru.jarvis.assistant.core.inference

/**
 * Per-chat behavioral mode selectable next to the "+" button in the chat composer.
 * Every new chat always starts in [NORMAL]. Switching mode changes the chat's persona/instructions
 * while keeping the user's selected API provider and model intact.
 */
enum class ChatMode(
    val shortLabelRu: String,
    val titleRu: String,
    val subtitleRu: String,
    val defaultPromptRu: String,
    val temperatureHint: Float? = null
) {
    NORMAL(
        shortLabelRu = "Обычный",
        titleRu = "Обычный помощник",
        subtitleRu = "Универсальный ассистент на каждый день",
        defaultPromptRu = "Режим: Обычный помощник. Отвечай понятно, полезно, дружелюбно и точно на русском языке.",
        temperatureHint = null
    ),
    CODER(
        shortLabelRu = "Кодер",
        titleRu = "Кодер",
        subtitleRu = "Код, архитектура, отладка, точные диффы и минимум воды",
        defaultPromptRu = "Режим: Кодер (Senior Software Engineer). Отвечай предельно технически точно, сразу давай чистый, рабочий, идиоматичный код в блоках ```язык, указывай крайние случаи, причины багов и конкретные шаги исправления. Без лишней воды.",
        temperatureHint = 0.25f
    ),
    ADULT_ROLEPLAY(
        shortLabelRu = "18+ флирт",
        titleRu = "18+ флирт / вирт",
        subtitleRu = "Романтический и откровенный ролевой режим (для разрешающих провайдеров)",
        defaultPromptRu = "Режим: 18+ флирт/вирт и откровенное ролевое общение между взрослыми по обоюдному согласию. Отвечай живо, чувственно, игриво, с яркими эмоциями и вовлечённостью, поддерживай заданный пользователем сюжет и стиль, сохраняя естественный русский язык.",
        temperatureHint = 0.85f
    );

    companion object {
        fun fromStored(raw: String?): ChatMode {
            if (raw.isNullOrBlank()) return NORMAL
            return runCatching { valueOf(raw.trim().uppercase()) }.getOrDefault(NORMAL)
        }
    }
}
