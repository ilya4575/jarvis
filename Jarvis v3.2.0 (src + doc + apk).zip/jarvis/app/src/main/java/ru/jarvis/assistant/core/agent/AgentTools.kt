package ru.jarvis.assistant.core.agent

import org.json.JSONObject

data class AgentToolCall(
    val name: String,
    val args: Map<String, String> = emptyMap()
)

data class AgentToolResult(
    val toolName: String,
    val success: Boolean,
    val summaryRu: String,
    val outputForModel: String,
    val launchedExternalApp: Boolean = false
)

data class AgentContextSnapshot(
    val installedAppNames: List<String> = emptyList(),
    val totalInstalledApps: Int = 0,
    val accessibilityReady: Boolean = false
)

interface AgentToolExecutor {
    fun captureContextSnapshot(): AgentContextSnapshot
    suspend fun execute(call: AgentToolCall): AgentToolResult
}

data class AppCandidate(
    val displayName: String,
    val packageName: String
)

/**
 * Universal structured tool-calling parser (<tool>{"name":"...","args":{...}}</tool>).
 * Works identically across OpenRouter (free models), Gemini, Groq, and local GGUF models
 * without depending on provider-specific function-calling schemas.
 */
object AgentToolParser {

    private val TOOL_BLOCK_REGEX = Regex(
        """<(?:tool|tool_call)>\s*(\{[\s\S]*?\})\s*</(?:tool|tool_call)>""",
        setOf(RegexOption.IGNORE_CASE)
    )

    private val FENCED_TOOL_REGEX = Regex(
        """```(?:tool|tool_call|jarvis_tool)\s*(\{[\s\S]*?\})\s*```""",
        setOf(RegexOption.IGNORE_CASE)
    )

    private val PARTIAL_TAIL_REGEX = Regex(
        """<(?:tool|tool_call)[\s\S]*$|```(?:tool|tool_call|jarvis_tool)[\s\S]*$""",
        setOf(RegexOption.IGNORE_CASE)
    )

    val ONE_SHOT_LAUNCH_TOOLS = setOf(
        "open_app",
        "open_url",
        "open_search",
        "open_settings",
        "set_timer",
        "set_alarm"
    )

    private val MULTI_STEP_HINTS = listOf(
        "и нажми", "и кликни", "и тапни", "и введи", "и напиши", "и отправ",
        "и найди", "и посмотр", "и прочитай", "и провер", "и перейд", "и выбер",
        "и пролист", "и прокрут", "нажми на", "тапни на", "кликни на",
        "что на экране", "посмотри на экране", "прочитай экран",
        "кто писал", "кто написал", "найди чат", "открой чат", "зайди в чат"
    )

    fun parseToolCalls(text: String): List<AgentToolCall> {
        val calls = mutableListOf<AgentToolCall>()
        val matches = mutableListOf<MatchResult>()
        matches.addAll(TOOL_BLOCK_REGEX.findAll(text))
        if (matches.isEmpty()) {
            matches.addAll(FENCED_TOOL_REGEX.findAll(text))
        }
        for (match in matches) {
            val rawJson = match.groupValues[1].trim()
            parseSingleJson(rawJson)?.let { calls.add(it) }
        }
        return calls
    }

    private fun parseSingleJson(rawJson: String): AgentToolCall? {
        return runCatching {
            val obj = JSONObject(rawJson)
            val name = obj.optString("name", "")
                .ifBlank { obj.optString("tool", "") }
                .ifBlank { obj.optString("action", "") }
                .trim()
                .lowercase()
            if (name.isEmpty()) return null

            val argsMap = linkedMapOf<String, String>()
            val argsObj = obj.optJSONObject("args") ?: obj.optJSONObject("arguments") ?: obj.optJSONObject("params")
            if (argsObj != null) {
                val keys = argsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = argsObj.opt(k)
                    if (v != null && v != JSONObject.NULL) {
                        argsMap[k] = v.toString()
                    }
                }
            } else {
                // Fallback: flat JSON like {"name": "open_app", "app": "Telegram"}
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    if (k == "name" || k == "tool" || k == "action") continue
                    val v = obj.opt(k)
                    if (v != null && v != JSONObject.NULL) {
                        argsMap[k] = v.toString()
                    }
                }
            }
            AgentToolCall(name = name, args = argsMap)
        }.getOrNull()
    }

    /**
     * Removes complete and in-progress <tool>...</tool> blocks so users never see raw JSON in chat/island.
     */
    fun stripToolMarkupForDisplay(text: String): String {
        var cleaned = TOOL_BLOCK_REGEX.replace(text, "")
        cleaned = FENCED_TOOL_REGEX.replace(cleaned, "")
        cleaned = PARTIAL_TAIL_REGEX.replace(cleaned, "")
        return cleaned.replace(Regex("\n{3,}"), "\n\n").trim()
    }

    fun hasPartialToolTag(text: String): Boolean {
        val strippedComplete = FENCED_TOOL_REGEX.replace(TOOL_BLOCK_REGEX.replace(text, ""), "")
        return PARTIAL_TAIL_REGEX.containsMatchIn(strippedComplete)
    }

    fun looksLikeMultiStepRequest(userPrompt: String): Boolean {
        val lower = userPrompt.lowercase()
        return MULTI_STEP_HINTS.any { lower.contains(it) }
    }

    fun statusBannerForTool(call: AgentToolCall): String = when (call.name) {
        "open_app" -> "Открываю ${call.args["app"] ?: "приложение"}…"
        "list_apps" -> "Ищу приложения на телефоне…"
        "open_url" -> "Открываю ссылку…"
        "open_search" -> "Открываю поиск…"
        "open_settings" -> "Открываю настройки…"
        "set_timer" -> "Ставлю таймер…"
        "set_alarm" -> "Ставлю будильник…"
        "get_device_info" -> "Проверяю состояние телефона…"
        "get_screen" -> "Смотрю на экран…"
        "tap_text" -> "Нажимаю «${call.args["text"] ?: "элемент"}»…"
        "tap_xy" -> "Нажимаю на экран…"
        "type_text" -> "Ввожу текст…"
        "scroll" -> "Прокручиваю экран…"
        "press_key" -> "Нажимаю кнопку навигации…"
        "wait" -> "Жду загрузку экрана…"
        else -> "Выполняю команду ${call.name}…"
    }
}

/**
 * Smart Russian/English alias + Cyrillic->Latin transliteration + Levenshtein fuzzy matcher
 * for resolving launchable Android apps from natural Russian speech & typos.
 */
object AppFuzzyMatcher {

    private val ALIAS_GROUPS: List<List<String>> = listOf(
        listOf("телеграм", "телеграмм", "телега", "тг", "telegram", "org.telegram", "nekogram", "ayugram", "telegram x"),
        listOf("ватсап", "вотсап", "вацап", "ватсапп", "whatsapp", "com.whatsapp"),
        listOf("вайбер", "viber", "com.viber"),
        listOf("ютуб", "ютьюб", "ютубчик", "youtube", "revanced"),
        listOf("вк", "вконтакте", "vk", "vkontakte", "com.vkontakte"),
        listOf("инста", "инстаграм", "инстаграмм", "instagram"),
        listOf("тикток", "тик ток", "tiktok", "musically"),
        listOf("дискорд", "discord"),
        listOf("настройки", "настройка", "параметры", "settings"),
        listOf("калькулятор", "кальк", "calculator"),
        listOf("камера", "фотик", "camera"),
        listOf("часы", "будильник", "таймер", "clock", "alarm"),
        listOf("браузер", "хром", "chrome", "browser", "firefox", "opera", "edge", "yandex browser"),
        listOf("галерея", "фото", "фотографии", "gallery", "photos", "альбом"),
        listOf("телефон", "звонилка", "звонки", "вызовы", "phone", "dialer"),
        listOf("сообщения", "смс", "sms", "messages"),
        listOf("контакты", "contacts"),
        listOf("карты", "навигатор", "maps", "яндекс карты", "google maps"),
        listOf("2гис", "2gis", "дубльгис"),
        listOf("почта", "гмейл", "gmail", "mail"),
        listOf("файлы", "проводник", "мои файлы", "files", "file manager"),
        listOf("заметки", "блокнот", "notes", "keep"),
        listOf("календарь", "calendar"),
        listOf("музыка", "плеер", "music", "яндекс музыка"),
        listOf("спотифай", "spotify"),
        listOf("вайлдберриз", "вб", "wildberries", "wb"),
        listOf("озон", "ozon"),
        listOf("яндекс", "yandex"),
        listOf("сбер", "сбербанк", "сбербанк онлайн", "sber", "sberbank"),
        listOf("тинькофф", "т-банк", "тбанк", "tbank", "tinkoff"),
        listOf("альфа", "альфабанк", "альфа-банк", "alfabank"),
        listOf("впн", "vpn", "v2ray", "amnezia", "outline", "wireguard", "hiddify", "nekobox"),
        listOf("стим", "steam"),
        listOf("твич", "twitch"),
        listOf("рутуб", "rutube"),
        listOf("кинопоиск", "kinopoisk"),
        listOf("авито", "avito"),
        listOf("госуслуги", "gosuslugi"),
        listOf("маркет", "плей маркет", "гугл плей", "play store", "play market", "rustore"),
        listOf("макс", "max", "oneme"),
        listOf("гугл", "google"),
        listOf("диктофон", "recorder"),
        listOf("погода", "weather")
    )

    private val CYRILLIC_TO_LATIN = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d",
        'е' to "e", 'ё' to "e", 'ж' to "zh", 'з' to "z", 'и' to "i",
        'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n",
        'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t",
        'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch",
        'ш' to "sh", 'щ' to "shch", 'ъ' to "", 'ы' to "y", 'ь' to "",
        'э' to "e", 'ю' to "yu", 'я' to "ya"
    )

    fun transliterateRuToLat(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input.lowercase()) {
            sb.append(CYRILLIC_TO_LATIN[ch] ?: ch)
        }
        return sb.toString()
    }

    private fun normalize(s: String): String =
        s.lowercase()
            .replace(Regex("[^a-zа-яё0-9.\\s-]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun expandNeedles(query: String): List<String> {
        val norm = normalize(query)
        if (norm.isEmpty()) return emptyList()
        val out = linkedSetOf(norm)
        val translit = transliterateRuToLat(norm)
        if (translit != norm) out.add(translit)
        // Strip Russian double trailing consonant typo like "телеграмм" -> "телеграм" / "telegramm" -> "telegram"
        if (norm.length >= 4 && norm[norm.length - 1] == norm[norm.length - 2]) {
            val dedup = norm.dropLast(1)
            out.add(dedup)
            out.add(transliterateRuToLat(dedup))
        }
        for (group in ALIAS_GROUPS) {
            if (group.any { alias -> norm == alias || (norm.length >= 3 && (norm.contains(alias) && alias.length >= 3 || alias == norm)) }) {
                out.addAll(group)
            }
        }
        return out.toList()
    }

    fun resolveBestMatch(apps: List<AppCandidate>, query: String): AppCandidate? {
        val ranked = searchRanked(apps, query)
        val best = ranked.firstOrNull() ?: return null
        return if (best.second >= 45) best.first else null
    }

    fun searchApps(apps: List<AppCandidate>, query: String, limit: Int = 15): List<AppCandidate> {
        if (query.isBlank()) return apps.take(limit)
        return searchRanked(apps, query)
            .filter { it.second >= 25 }
            .take(limit)
            .map { it.first }
    }

    private fun searchRanked(apps: List<AppCandidate>, query: String): List<Pair<AppCandidate, Int>> {
        val rawNorm = normalize(query)
        if (rawNorm.isEmpty()) return emptyList()
        val needles = expandNeedles(query)

        return apps.mapNotNull { app ->
            val nameNorm = normalize(app.displayName)
            val nameLat = transliterateRuToLat(nameNorm)
            val pkgNorm = app.packageName.lowercase()
            var bestScore = 0

            // Direct exact package match
            if (pkgNorm == rawNorm) bestScore = maxOf(bestScore, 120)
            // Direct exact display name match
            if (nameNorm == rawNorm || nameLat == rawNorm) bestScore = maxOf(bestScore, 110)

            for (needle in needles) {
                if (needle.isEmpty()) continue
                if (nameNorm == needle || nameLat == needle) {
                    bestScore = maxOf(bestScore, 100)
                } else if (nameNorm.startsWith(needle) || nameLat.startsWith(needle)) {
                    bestScore = maxOf(bestScore, 85)
                } else if (needle.length >= 3 && (nameNorm.contains(needle) || nameLat.contains(needle))) {
                    bestScore = maxOf(bestScore, 75)
                } else if (needle.length >= 3 && pkgNorm.contains(needle)) {
                    bestScore = maxOf(bestScore, 68)
                } else if (needle.length >= 4) {
                    val distName = levenshtein(needle, nameNorm)
                    val distLat = levenshtein(needle, nameLat)
                    val dist = minOf(distName, distLat)
                    val maxAllowed = if (needle.length >= 7) 2 else 1
                    if (dist <= maxAllowed) {
                        bestScore = maxOf(bestScore, 65 - dist * 10)
                    }
                }
            }

            if (bestScore > 0) app to bestScore else null
        }.sortedWith(compareByDescending<Pair<AppCandidate, Int>> { it.second }.thenBy { it.first.displayName.length })
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        val prev = IntArray(b.length + 1) { it }
        val curr = IntArray(b.length + 1)
        for (i in 1..a.length) {
            curr[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                curr[j] = minOf(
                    curr[j - 1] + 1,
                    prev[j] + 1,
                    prev[j - 1] + cost
                )
            }
            System.arraycopy(curr, 0, prev, 0, b.length + 1)
        }
        return prev[b.length]
    }
}

/**
 * Generates compact Russian tool instructions injected into the system prompt so any cloud or local model
 * can seamlessly search installed apps, launch them, open links/settings/timers, read the screen, and tap/type.
 */
object AgentSystemPromptBuilder {

    fun buildToolsPrompt(
        installedAppNames: List<String>,
        accessibilityReady: Boolean
    ): String = buildString {
        append("\n\n=== ИНСТРУМЕНТЫ УПРАВЛЕНИЯ ANDROID-ТЕЛЕФОНОМ ===\n")
        append("Ты работаешь прямо на Android-смартфоне пользователя и УМЕЕШЬ реально управлять телефоном через команды.\n")
        append("НИКОГДА не отказывайся открывать приложения/ссылки фразами вроде «у меня нет рук» или «я не имею доступа к системе» — вызывай нужный инструмент!\n")
        append("Формат вызова строго в теге:\n")
        append("<tool>{\"name\":\"имя_команды\",\"args\":{...}}</tool>\n\n")
        append("Доступные команды (работают всегда):\n")
        append("• open_app {\"app\":\"название или package\"} — запустить установленное приложение (например Telegram, YouTube, Настройки).\n")
        append("• list_apps {\"query\":\"необязательный фильтр\"} — получить список установленных приложений и их packageName.\n")
        append("• open_url {\"url\":\"https://t.me/username\"} — открыть любую ссылку, Telegram-профиль (https://t.me/...), сайт, tel:, mailto:.\n")
        append("• open_search {\"query\":\"текст\"} — открыть поиск в браузере.\n")
        append("• open_settings {\"section\":\"main|wifi|bluetooth|sound|display|battery|apps|accessibility\"} — открыть раздел настроек Android.\n")
        append("• set_timer {\"seconds\":300,\"message\":\"Чай\"} — запустить таймер.\n")
        append("• set_alarm {\"hour\":7,\"minute\":30,\"message\":\"Подъём\"} — поставить будильник.\n")
        append("• get_device_info {} — время, дата, заряд батареи, сеть и статус спецвозможностей.\n")

        if (accessibilityReady) {
            append("\nКоманды экрана и нажатий (Спецвозможности ВКЛЮЧЕНЫ и готовы к работе):\n")
        } else {
            append("\nКоманды экрана и нажатий (сейчас Спецвозможности выключены — для нажатий внутри чужих приложений пользователь может включить их в Меню → Действия и права):\n")
        }
        append("• get_screen {} — прочитать видимые элементы текущего экрана и их координаты (x, y).\n")
        append("• tap_text {\"text\":\"надпись на кнопке\"} — найти и нажать кнопку/элемент по тексту.\n")
        append("• tap_xy {\"x\":540,\"y\":1200} — нажать по координатам экрана из get_screen.\n")
        append("• type_text {\"text\":\"текст\",\"submit\":false} — ввести текст в текстовое поле (submit=true нажмёт поиск/отправку).\n")
        append("• scroll {\"direction\":\"down|up|left|right\"} — прокрутить экран.\n")
        append("• press_key {\"key\":\"back|home|recents|notifications\"} — системная кнопка.\n")
        append("• wait {\"ms\":1200} — подождать загрузку интерфейса перед get_screen.\n")

        append("\nПравила вызова (автономный многошаговый агент, до 50 шагов):\n")
        append("1. Для простого действия (например, просто открыть Telegram, ссылку t.me/..., настройки или таймер) сразу напиши короткий ответ и вставь <tool>...</tool>.\n")
        append("2. Для многошаговой задачи (например, открыть приложение → посмотреть экран → найти контакт/кнопку → нажать → ввести текст → проверить отправку) выводи ТОЛЬКО <tool>...</tool> без финального ответа: приложение выполнит действие и пришлёт [Результат инструмента], после чего ты проверяешь результат (при необходимости вызывая get_screen) и делаешь следующий шаг.\n")
        append("3. Не останавливайся на полпути: доводи многошаговую цель до конца (у тебя есть настраиваемый бюджет до 50 действий). Если элемент не найден с первой попытки — проверь get_screen, прокрути экран или используй координаты tap_xy.\n")
        append("4. Если пользователь дал Telegram @username или ссылку t.me/..., сразу вызывай open_url с \"https://t.me/<username>\".\n")
        append("5. Не выдумывай результаты команд и НИКОГДА не вводи пароли, PIN-коды, OTP, реквизиты оплаты, не удаляй данные и не обходи CAPTCHA без явного подтверждения пользователя.\n")

        if (installedAppNames.isNotEmpty()) {
            val preview = installedAppNames.take(75).joinToString(", ")
            append("\nУстановленные приложения на этом телефоне (${installedAppNames.size}): $preview")
            if (installedAppNames.size > 75) {
                append(" … (для поиска остальных вызови list_apps).")
            }
        }
    }
}
