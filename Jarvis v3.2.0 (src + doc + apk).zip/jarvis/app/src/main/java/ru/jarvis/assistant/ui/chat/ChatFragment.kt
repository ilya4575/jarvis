package ru.jarvis.assistant.ui.chat

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.cloud.ApiGenStyles
import ru.jarvis.assistant.core.cloud.CloudProvider
import ru.jarvis.assistant.core.cloud.ImageQualityMode
import ru.jarvis.assistant.core.inference.ChatMode
import ru.jarvis.assistant.core.inference.EngineState
import ru.jarvis.assistant.core.inference.ImagePreprocessor
import ru.jarvis.assistant.data.db.ChatMessageEntity
import ru.jarvis.assistant.feature.avatar.ZafkielClockAvatarView
import ru.jarvis.assistant.feature.voice.VoiceState
import ru.jarvis.assistant.ui.MainActivity
import ru.jarvis.assistant.ui.cloud.PerchanceVerifyDialogHelper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ChatFragment : Fragment() {

    private lateinit var menuBtn: ImageButton
    private lateinit var modelPill: LinearLayout
    private lateinit var modelPillText: TextView
    private lateinit var newChatBtn: ImageButton
    private lateinit var moreBtn: ImageButton

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyContainer: LinearLayout
    private lateinit var emptyAvatar: ZafkielClockAvatarView
    private lateinit var emptyTitle: TextView
    private lateinit var emptySubtitle: TextView

    private lateinit var agentLimitCard: LinearLayout
    private lateinit var agentLimitTitle: TextView
    private lateinit var agentLimitSubtitle: TextView
    private lateinit var agentContinue15Btn: TextView
    private lateinit var agentContinue50Btn: TextView
    private lateinit var agentStopBtn: TextView

    private lateinit var thinkingCard: LinearLayout
    private lateinit var thinkingAvatar: ZafkielClockAvatarView
    private lateinit var thinkingVideo: TextureView
    private lateinit var thinkingName: TextView
    private lateinit var thinkingStatus: TextView
    private lateinit var agentCounterBadge: TextView
    private var chatVideoPlayer: MediaPlayer? = null
    private var chatVideoSurface: Surface? = null

    private lateinit var voiceStatusBar: TextView
    private lateinit var attachedPhotoBar: FrameLayout
    private lateinit var attachedPhotoThumb: ImageView
    private lateinit var removePhotoBtn: ImageButton
    private lateinit var plusBtn: ImageButton
    private lateinit var modeChip: TextView
    private lateinit var inputEditText: EditText
    private lateinit var micBtn: ImageButton
    private lateinit var primaryActionBtn: ImageButton

    private lateinit var adapter: ChatAdapter
    private var pendingPhotoPath: String? = null
    private var isGeneratingNow = false
    private var isVoiceRecordingNow = false
    private var lastHandledVerifyTick = 0L

    private val photoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) processSelectedPhotoUri(uri)
    }

    private val fallbackDocumentPhotoLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) processSelectedPhotoUri(uri)
    }

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val savedPath = JarvisApplication.instance.prefs.pendingCameraFilePath
        if (success && !savedPath.isNullOrBlank()) {
            val file = File(savedPath)
            if (file.exists() && file.length() > 0L) processCameraFile(file)
            else Toast.makeText(requireContext(), "Камера вернула пустой файл снимка.", Toast.LENGTH_LONG).show()
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCameraCapture()
        else Toast.makeText(requireContext(), "Нет доступа к камере. Можно выбрать фото из галереи.", Toast.LENGTH_LONG).show()
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) Toast.makeText(requireContext(), "Микрофон разрешён.", Toast.LENGTH_SHORT).show()
        else Toast.makeText(requireContext(), "Нет доступа к микрофону.", Toast.LENGTH_LONG).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_chat, container, false)

    @SuppressLint("ClickableViewAccessibility")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance

        menuBtn = view.findViewById(R.id.chat_menu_btn)
        modelPill = view.findViewById(R.id.chat_model_pill)
        modelPillText = view.findViewById(R.id.chat_model_pill_text)
        newChatBtn = view.findViewById(R.id.chat_new_btn)
        moreBtn = view.findViewById(R.id.chat_more_btn)

        recyclerView = view.findViewById(R.id.chat_recycler)
        emptyContainer = view.findViewById(R.id.chat_empty_container)
        emptyAvatar = view.findViewById(R.id.chat_empty_avatar)
        emptyTitle = view.findViewById(R.id.chat_empty_title)
        emptySubtitle = view.findViewById(R.id.chat_empty_subtitle)

        agentLimitCard = view.findViewById(R.id.chat_agent_limit_card)
        agentLimitTitle = view.findViewById(R.id.chat_agent_limit_title)
        agentLimitSubtitle = view.findViewById(R.id.chat_agent_limit_subtitle)
        agentContinue15Btn = view.findViewById(R.id.chat_agent_continue_15_btn)
        agentContinue50Btn = view.findViewById(R.id.chat_agent_continue_50_btn)
        agentStopBtn = view.findViewById(R.id.chat_agent_stop_btn)

        thinkingCard = view.findViewById(R.id.chat_thinking_card)
        thinkingAvatar = view.findViewById(R.id.chat_thinking_avatar)
        thinkingVideo = view.findViewById(R.id.chat_thinking_video)
        thinkingName = view.findViewById(R.id.chat_thinking_name)
        thinkingStatus = view.findViewById(R.id.chat_thinking_status)
        agentCounterBadge = view.findViewById(R.id.chat_agent_counter_badge)

        thinkingVideo.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) {
                outline.setOval(0, 0, v.width, v.height)
            }
        }
        thinkingVideo.clipToOutline = true
        thinkingVideo.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                chatVideoSurface = Surface(surface)
                if (isGeneratingNow) startChatThinkingVideoIfNeeded()
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                stopChatThinkingVideo()
                chatVideoSurface?.release()
                chatVideoSurface = null
                return true
            }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }

        voiceStatusBar = view.findViewById(R.id.chat_voice_status)
        attachedPhotoBar = view.findViewById(R.id.chat_attached_photo_bar)
        attachedPhotoThumb = view.findViewById(R.id.chat_attached_thumb)
        removePhotoBtn = view.findViewById(R.id.chat_remove_photo_btn)
        plusBtn = view.findViewById(R.id.chat_plus_btn)
        modeChip = view.findViewById(R.id.chat_mode_chip)
        inputEditText = view.findViewById(R.id.chat_input_edit)
        micBtn = view.findViewById(R.id.chat_mic_btn)
        primaryActionBtn = view.findViewById(R.id.chat_primary_action_btn)

        val d = resources.displayMetrics.density
        attachedPhotoThumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) {
                outline.setRoundRect(0, 0, v.width, v.height, 14f * d)
            }
        }
        attachedPhotoThumb.clipToOutline = true
        removePhotoBtn.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) {
                outline.setOval(0, 0, v.width, v.height)
            }
        }
        removePhotoBtn.clipToOutline = true

        adapter = ChatAdapter(object : ChatMessageListener {
            override fun onCopy(message: ChatMessageEntity) = copyText(message.text)

            override fun onRegenerate(message: ChatMessageEntity) {
                if (isGeneratingNow) return
                viewLifecycleOwner.lifecycleScope.launch {
                    app.chatCoordinator.regenerateResponse(
                        assistantMessageId = message.id,
                        config = app.prefs.buildGenerationConfig(app.prefs.activeProfileId)
                    )
                }
            }

            override fun onSpeakTts(message: ChatMessageEntity) {
                app.ttsSpeaker.speak(
                    text = message.text,
                    onError = { errMsg ->
                        if (!isAdded) return@speak
                        AlertDialog.Builder(requireContext())
                            .setTitle("Озвучка (TTS)")
                            .setMessage(errMsg)
                            .setPositiveButton("Выбрать голос") { _, _ ->
                                (activity as? MainActivity)?.navigateToVoiceTtsScreen()
                            }
                            .setNegativeButton("Закрыть", null)
                            .show()
                    }
                ).onFailure { err ->
                    AlertDialog.Builder(requireContext())
                        .setTitle("Озвучка (TTS)")
                        .setMessage(err.message ?: "Не удалось запустить озвучку.")
                        .setPositiveButton("Выбрать голос") { _, _ ->
                            (activity as? MainActivity)?.navigateToVoiceTtsScreen()
                        }
                        .setNegativeButton("Закрыть", null)
                        .show()
                }
            }

            override fun onShowContextMenu(message: ChatMessageEntity) = showChatGptContextMenu(message)
            override fun onOpenGeneratedImage(path: String) = showFullscreenImageDialog(path)
            override fun onSaveGeneratedImage(path: String) = saveImageToGallery(path)
            override fun onShareGeneratedImage(path: String) = shareImageFile(path)
        })

        recyclerView.layoutManager = LinearLayoutManager(requireContext()).apply { stackFromEnd = true }
        recyclerView.adapter = adapter

        menuBtn.setOnClickListener { (activity as? MainActivity)?.openDrawer() }

        newChatBtn.setOnClickListener {
            app.chatCoordinator.createNewChat()
            clearPendingPhoto()
            inputEditText.setText("")
        }

        // A8: Agent step limit continuation buttons
        agentContinue15Btn.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch { app.chatCoordinator.continueAgentGoal(15) }
        }
        agentContinue50Btn.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch { app.chatCoordinator.continueAgentGoal(50) }
        }
        agentStopBtn.setOnClickListener {
            app.chatCoordinator.dismissAgentLimitPrompt()
        }

        moreBtn.setOnClickListener { anchor ->
            val popup = PopupMenu(requireContext(), anchor)
            popup.setForceShowIcon(true)
            popup.menu.add(0, 0, 0, "Провайдеры и API-ключи").setIcon(R.drawable.ic_cloud_api)
            popup.menu.add(0, 5, 1, "Голос и Диктор (TTS / Puter / Custom)").setIcon(R.drawable.ic_nav_voice)
            popup.menu.add(0, 6, 2, "Действия, Команды и Агент").setIcon(R.drawable.ic_nav_actions)
            popup.menu.add(0, 1, 3, "Манера общения и Промпт").setIcon(R.drawable.ic_edit)
            popup.menu.add(0, 2, 4, "Dynamic Island и Аватар").setIcon(R.drawable.ic_nav_island)
            popup.menu.add(0, 3, 5, "Локальные модели (Офлайн)").setIcon(R.drawable.ic_nav_models)
            popup.menu.add(0, 4, 6, "Очистить текущий чат").setIcon(R.drawable.ic_delete)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    0 -> (activity as? MainActivity)?.navigateToCloudApiScreen()
                    5 -> (activity as? MainActivity)?.navigateToVoiceTtsScreen()
                    6 -> (activity as? MainActivity)?.navigateToActionsScreen()
                    1 -> (activity as? MainActivity)?.navigateToPersonaScreen()
                    2 -> (activity as? MainActivity)?.navigateToIslandScreen()
                    3 -> (activity as? MainActivity)?.navigateToModelsTab()
                    4 -> confirmClearCurrentChat()
                }
                true
            }
            popup.show()
        }

        // A3 + Puter: Curated provider switcher (NO Cerebras / Mistral!)
        modelPill.setOnClickListener { anchor ->
            if (!app.prefs.hasAnyCloudKey() && app.inferenceEngine.state.value !is EngineState.Ready) {
                (activity as? MainActivity)?.navigateToCloudApiScreen()
                return@setOnClickListener
            }
            val popup = PopupMenu(requireContext(), anchor)
            popup.setForceShowIcon(true)
            val cur = app.prefs.chatPrimaryProvider
            fun addProviderItem(id: Int, order: Int, p: CloudProvider, label: String) {
                val mi = popup.menu.add(0, id, order, label)
                mi.setIcon(if (cur == p) R.drawable.ic_status_check else R.drawable.ic_cloud_api)
            }
            val activeCustom = app.prefs.getActiveCustomProvider()
            val customLabel = activeCustom?.let { "${it.displayTitle()} (${it.effectiveModel()})" } ?: "Custom API"
            addProviderItem(2, 0, CloudProvider.GEMINI, "Gemini (${app.prefs.geminiModel})")
            addProviderItem(3, 1, CloudProvider.GROQ, "Groq (${app.prefs.groqLlmModel})")
            addProviderItem(1, 2, CloudProvider.OPENROUTER, "OpenRouter (${app.prefs.openRouterModel})")
            addProviderItem(6, 3, CloudProvider.CUSTOM_API, customLabel)
            addProviderItem(8, 4, CloudProvider.PERCHANCE, "Perchance (чат и картинки)")
            addProviderItem(9, 5, CloudProvider.PUTER, "Puter (${app.prefs.effectivePuterModel()})")
            addProviderItem(4, 6, CloudProvider.LOCAL, "Локальная (${app.prefs.activeProfileId.shortTitleRu})")
            popup.menu.add(0, 5, 7, "Настроить провайдеры и ключи").setIcon(R.drawable.ic_settings_gear)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    2 -> { app.prefs.chatPrimaryProvider = CloudProvider.GEMINI; app.inferenceEngine.refreshEffectiveState() }
                    3 -> { app.prefs.chatPrimaryProvider = CloudProvider.GROQ; app.inferenceEngine.refreshEffectiveState() }
                    1 -> { app.prefs.chatPrimaryProvider = CloudProvider.OPENROUTER; app.inferenceEngine.refreshEffectiveState() }
                    6 -> { app.prefs.chatPrimaryProvider = CloudProvider.CUSTOM_API; app.inferenceEngine.refreshEffectiveState() }
                    8 -> {
                        app.prefs.perchanceEnabled = true
                        (activity as? MainActivity)?.reattachPerchanceHost(warmup = true)
                        app.prefs.chatPrimaryProvider = CloudProvider.PERCHANCE
                        app.inferenceEngine.refreshEffectiveState()
                        if (!app.perchanceBridge.isVerified()) {
                            activity?.let { act -> PerchanceVerifyDialogHelper.show(act, viewLifecycleOwner) }
                        }
                    }
                    9 -> {
                        if (app.prefs.puterAuthToken.isBlank()) {
                            Toast.makeText(requireContext(), "Введите Puter Auth Token в настройках провайдеров", Toast.LENGTH_LONG).show()
                            (activity as? MainActivity)?.navigateToCloudApiScreen()
                        } else {
                            app.prefs.chatPrimaryProvider = CloudProvider.PUTER
                            app.inferenceEngine.refreshEffectiveState()
                        }
                    }
                    4 -> {
                        app.prefs.chatPrimaryProvider = CloudProvider.LOCAL
                        app.inferenceEngine.refreshEffectiveState()
                        if (app.localLlamaEngine.state.value !is EngineState.Ready) {
                            (activity as? MainActivity)?.navigateToModelsTab()
                        }
                    }
                    5 -> (activity as? MainActivity)?.navigateToCloudApiScreen()
                }
                true
            }
            popup.show()
        }

        // "+" menu with Camera, Gallery, File, Photo settings (/фото & scene memory), Voice, Persona
        plusBtn.setOnClickListener { anchor ->
            val popup = PopupMenu(requireContext(), anchor)
            popup.setForceShowIcon(true)
            popup.menu.add(0, 10, 0, "Параметры /фото и сцена").setIcon(R.drawable.ic_sparkle)
            popup.menu.add(0, 1, 1, "Снять фото камерой").setIcon(R.drawable.ic_camera)
            popup.menu.add(0, 2, 2, "Выбрать из галереи").setIcon(R.drawable.ic_gallery)
            popup.menu.add(0, 3, 3, "Выбрать файл изображения").setIcon(R.drawable.ic_folder)
            popup.menu.add(0, 5, 4, "Голос и Диктор (TTS)").setIcon(R.drawable.ic_nav_voice)
            popup.menu.add(0, 4, 5, "Манера общения и Промпт").setIcon(R.drawable.ic_edit)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    10 -> showPhotoSettingsDialog()
                    1 -> requestCameraAndLaunch()
                    2 -> launchPhotoPicker()
                    3 -> fallbackDocumentPhotoLauncher.launch(arrayOf("image/*"))
                    5 -> (activity as? MainActivity)?.navigateToVoiceTtsScreen()
                    4 -> (activity as? MainActivity)?.navigateToPersonaScreen()
                }
                true
            }
            popup.show()
        }

        // A5: Per-chat Mode Selector directly next to "+" (NO age-gate dialog!)
        modeChip.setOnClickListener { anchor ->
            val popup = PopupMenu(requireContext(), anchor)
            popup.setForceShowIcon(true)
            val currentMode = app.chatCoordinator.uiState.value.activeMode
            val items = listOf(
                ChatMode.CODER to "1) Кодер",
                ChatMode.ADULT_ROLEPLAY to "2) 18+ флирт/вирт и т.д.",
                ChatMode.NORMAL to "3) Обычный помощник"
            )
            items.forEachIndexed { idx, (m, label) ->
                popup.menu.add(0, idx, idx, label)
                    .setIcon(if (currentMode == m) R.drawable.ic_status_check else R.drawable.ic_sparkle)
            }
            popup.setOnMenuItemClickListener { item ->
                val chosen = items[item.itemId].first
                app.chatCoordinator.setActiveSessionMode(chosen)
                Toast.makeText(requireContext(), "Режим чата: ${chosen.titleRu}", Toast.LENGTH_SHORT).show()
                true
            }
            popup.show()
        }

        removePhotoBtn.setOnClickListener { clearPendingPhoto() }

        inputEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updatePrimaryActionIcon()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        micBtn.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startInAppVoiceRecording(); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { app.voiceEngine.stopRecording(); true }
                else -> false
            }
        }

        primaryActionBtn.setOnClickListener {
            when {
                isGeneratingNow -> app.chatCoordinator.cancelGeneration()
                hasContentToSend() -> sendCurrentMessage()
                isVoiceRecordingNow -> app.voiceEngine.stopRecording()
                else -> startInAppVoiceRecording()
            }
        }

        refreshBrandTexts()
        updatePrimaryActionIcon()
        observeStates()
    }

    override fun onResume() {
        super.onResume()
        refreshBrandTexts()
    }

    /**
     * Phase 9: Settings for `/фото` and AI auto-photo generation (quality fast/full, style, aspect ratio,
     * and per-chat visual scene memory). Photos themselves are triggered naturally in chat or via `/фото`.
     */
    private fun showPhotoSettingsDialog() {
        val app = JarvisApplication.instance
        val d = resources.displayMetrics.density
        val scroll = ScrollView(requireContext())
        val box = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18 * d).toInt(), (12 * d).toInt(), (18 * d).toInt(), (8 * d).toInt())
        }
        scroll.addView(box)

        val hintTv = TextView(requireContext()).apply {
            text = "Как делать фото в чате:\n" +
                "• Напишите команду: /фото описание (или /фото hd ...)\n" +
                "• Или просто попросите ИИ: «сделай фотку себя», «скинь фото…», «нарисуй…» — ИИ сама поймёт и пришлёт фото.\n" +
                "Движок: api-gen → Perchance Embed → Pollinations."
            textSize = 12.5f
            setTextColor(Color.parseColor("#B8C4D8"))
            setPadding(0, 0, 0, (10 * d).toInt())
        }
        box.addView(hintTv)

        val qualityLabel = TextView(requireContext()).apply {
            text = "Режим качества (api-gen):"
            textSize = 13f
            setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
        }
        box.addView(qualityLabel)

        val qualityGroup = RadioGroup(requireContext()).apply { orientation = RadioGroup.VERTICAL }
        val rFast = RadioButton(requireContext()).apply {
            id = View.generateViewId()
            text = "Быстрый (sir-image-fast, ~10–15 сек)"
            isChecked = app.prefs.imageGenQualityMode == ImageQualityMode.FAST
        }
        val rFull = RadioButton(requireContext()).apply {
            id = View.generateViewId()
            text = "Макс. качество (sir-image-full, ИИ-улучшение)"
            isChecked = app.prefs.imageGenQualityMode == ImageQualityMode.FULL
        }
        qualityGroup.addView(rFast)
        qualityGroup.addView(rFull)
        box.addView(qualityGroup)

        val styleLabel = TextView(requireContext()).apply {
            text = "Стиль по умолчанию:"
            textSize = 13f
            setPadding(0, (10 * d).toInt(), 0, (4 * d).toInt())
        }
        box.addView(styleLabel)

        val stylePresets = ApiGenStyles.PRESETS
        val styleLabels = stylePresets.map { it.labelRu }
        val currentStyleIdx = stylePresets.indexOfFirst {
            (it.apiStyleId ?: "").equals(app.prefs.imageGenStyle, ignoreCase = true)
        }.coerceAtLeast(0)
        val styleSpinner = Spinner(requireContext()).apply {
            adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, styleLabels)
            setSelection(currentStyleIdx)
        }
        box.addView(styleSpinner)

        val resLabel = TextView(requireContext()).apply {
            text = "Формат кадра:"
            textSize = 13f
            setPadding(0, (10 * d).toInt(), 0, (4 * d).toInt())
        }
        box.addView(resLabel)

        val currentRes = app.prefs.imageGenResolution
        val rg = RadioGroup(requireContext()).apply { orientation = RadioGroup.HORIZONTAL }
        val rSquare = RadioButton(requireContext()).apply {
            id = View.generateViewId()
            text = "1:1"
            isChecked = currentRes == "768x768" || (currentRes != "512x768" && currentRes != "768x512")
        }
        val rPortrait = RadioButton(requireContext()).apply {
            id = View.generateViewId()
            text = "Портрет"
            isChecked = currentRes == "512x768"
        }
        val rLandscape = RadioButton(requireContext()).apply {
            id = View.generateViewId()
            text = "Альбом"
            isChecked = currentRes == "768x512"
        }
        rg.addView(rSquare)
        rg.addView(rPortrait)
        rg.addView(rLandscape)
        box.addView(rg)

        val sceneMem = app.chatCoordinator.getActiveImageSceneMemory()
        val sceneHeader = TextView(requireContext()).apply {
            text = "Память сцены этого чата (сбрасывается в новом чате):"
            textSize = 13f
            setPadding(0, (12 * d).toInt(), 0, (4 * d).toInt())
        }
        box.addView(sceneHeader)

        val sceneStatus = TextView(requireContext()).apply {
            text = sceneMem.summaryShortRu()
            textSize = 12f
            setTextColor(Color.parseColor("#93C5FD"))
        }
        box.addView(sceneStatus)

        if (!sceneMem.isEmpty()) {
            val resetBtn = Button(requireContext()).apply {
                text = "Сбросить память сцены в этом чате"
                isAllCaps = false
                setOnClickListener {
                    app.chatCoordinator.resetActiveImageSceneMemory()
                    sceneStatus.text = "Чистая сцена (кадров: 0)"
                    isEnabled = false
                    Toast.makeText(requireContext(), "Память сцены очищена", Toast.LENGTH_SHORT).show()
                }
            }
            box.addView(resetBtn)
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Параметры фото в чате")
            .setView(scroll)
            .setPositiveButton("Сохранить") { _, _ ->
                app.prefs.imageGenQualityMode = if (qualityGroup.checkedRadioButtonId == rFull.id) {
                    ImageQualityMode.FULL
                } else {
                    ImageQualityMode.FAST
                }
                val chosenStyle = stylePresets.getOrNull(styleSpinner.selectedItemPosition)?.apiStyleId.orEmpty()
                app.prefs.imageGenStyle = chosenStyle
                app.prefs.imageGenResolution = when (rg.checkedRadioButtonId) {
                    rPortrait.id -> "512x768"
                    rLandscape.id -> "768x512"
                    else -> "768x768"
                }
                Toast.makeText(requireContext(), "Параметры /фото сохранены", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Вставить /фото ") { _, _ ->
                app.prefs.imageGenQualityMode = if (qualityGroup.checkedRadioButtonId == rFull.id) {
                    ImageQualityMode.FULL
                } else {
                    ImageQualityMode.FAST
                }
                val chosenStyle = stylePresets.getOrNull(styleSpinner.selectedItemPosition)?.apiStyleId.orEmpty()
                app.prefs.imageGenStyle = chosenStyle
                app.prefs.imageGenResolution = when (rg.checkedRadioButtonId) {
                    rPortrait.id -> "512x768"
                    rLandscape.id -> "768x512"
                    else -> "768x768"
                }
                val existingText = inputEditText.text.toString().trim()
                val nextText = if (existingText.startsWith("/фото", ignoreCase = true)) existingText else "/фото $existingText"
                inputEditText.setText(nextText)
                inputEditText.setSelection(nextText.length)
                inputEditText.requestFocus()
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun showFullscreenImageDialog(path: String) {
        val file = File(path)
        if (!file.exists()) return
        val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return
        val iv = ImageView(requireContext()).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        AlertDialog.Builder(requireContext())
            .setView(iv)
            .setPositiveButton("Сохранить") { _, _ -> saveImageToGallery(path) }
            .setNeutralButton("Поделиться") { _, _ -> shareImageFile(path) }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun saveImageToGallery(path: String) {
        val src = File(path)
        if (!src.exists()) {
            Toast.makeText(requireContext(), "Файл изображения не найден.", Toast.LENGTH_SHORT).show()
            return
        }
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val savedOk = runCatching {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "jarvis_${System.currentTimeMillis()}.${src.extension.ifBlank { "png" }}")
                    put(MediaStore.Images.Media.MIME_TYPE, if (src.extension.equals("jpg", true)) "image/jpeg" else "image/png")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Jarvis")
                    }
                }
                val resolver = requireContext().contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore insert failed")
                resolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { it.copyTo(out) }
                } ?: error("Output stream null")
                true
            }.getOrDefault(false)
            withContext(Dispatchers.Main) {
                if (isAdded) {
                    Toast.makeText(
                        requireContext(),
                        if (savedOk) "Изображение сохранено в Галерею (Pictures/Jarvis)" else "Не удалось сохранить изображение",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun shareImageFile(path: String) {
        val file = File(path)
        if (!file.exists()) return
        runCatching {
            val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Поделиться изображением"))
        }.onFailure { err ->
            Toast.makeText(requireContext(), "Ошибка отправки: ${err.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshBrandTexts() {
        val app = JarvisApplication.instance
        val name = app.prefs.assistantName
        val kurumi = app.prefs.kurumiThemeEnabled
        inputEditText.hint = "Спросить $name"
        emptyTitle.text = if (kurumi) "$name на связи." else "На связи."
        emptySubtitle.text = if (app.prefs.hasAnyCloudKey()) {
            "Спроси $name о чём угодно — текст, голос, действия или фото (напиши /фото или просто попроси «сделай фотку…»)."
        } else {
            "Нажмите на кнопку сверху, чтобы подключить Gemini, Groq, OpenRouter, Custom, Perchance или Puter. Фото работает и по команде /фото."
        }

        val img = app.avatarManager.getStaticImageFile()
        val gif = app.avatarManager.getThinkingGifFile()
        emptyAvatar.bindMedia(img, gif, kurumi)
        thinkingAvatar.bindMedia(img, gif, kurumi)
        thinkingName.text = name
        thinkingName.setTextColor(if (kurumi) Color.parseColor("#FFD54F") else requireContext().getColor(R.color.jarvis_text_primary))
    }

    private fun startChatThinkingVideoIfNeeded() {
        val app = JarvisApplication.instance
        if (app.avatarManager.getThinkingGifFile() != null) {
            stopChatThinkingVideo()
            return
        }
        val videoFile = app.avatarManager.getVideoAvatarFile() ?: return
        thinkingVideo.visibility = View.VISIBLE
        val surf = chatVideoSurface ?: return
        stopChatThinkingVideo(hideView = false)
        try {
            val mp = MediaPlayer().apply {
                setDataSource(videoFile.absolutePath)
                setSurface(surf)
                isLooping = true
                setVolume(0f, 0f)
                setOnPreparedListener { p -> if (isGeneratingNow) p.start() else stopChatThinkingVideo() }
                setOnErrorListener { _, _, _ -> stopChatThinkingVideo(); true }
                prepareAsync()
            }
            chatVideoPlayer = mp
        } catch (_: Throwable) {
            stopChatThinkingVideo()
        }
    }

    private fun stopChatThinkingVideo(hideView: Boolean = true) {
        runCatching {
            chatVideoPlayer?.stop()
            chatVideoPlayer?.reset()
            chatVideoPlayer?.release()
        }
        chatVideoPlayer = null
        if (hideView && ::thinkingVideo.isInitialized) {
            thinkingVideo.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        stopChatThinkingVideo()
        if (::thinkingAvatar.isInitialized) thinkingAvatar.setThinking(false)
        super.onDestroyView()
    }

    private fun hasContentToSend(): Boolean =
        inputEditText.text.toString().trim().isNotEmpty() || pendingPhotoPath != null

    private var lastPrimaryIconRes: Int = 0

    private fun updatePrimaryActionIcon() {
        val resId = when {
            isGeneratingNow -> R.drawable.ic_stop_square
            hasContentToSend() -> R.drawable.ic_arrow_up
            isVoiceRecordingNow -> R.drawable.ic_stop_square
            else -> R.drawable.ic_voice_wave
        }
        if (resId == lastPrimaryIconRes) return
        lastPrimaryIconRes = resId
        primaryActionBtn.setImageResource(resId)
    }

    private fun observeStates() {
        val app = JarvisApplication.instance

        viewLifecycleOwner.lifecycleScope.launch {
            app.chatCoordinator.uiState.collectLatest { state ->
                isGeneratingNow = state.isGenerating
                adapter.submitList(state.messages)
                emptyContainer.visibility = if (state.messages.isEmpty()) View.VISIBLE else View.GONE
                if (state.messages.isNotEmpty()) {
                    recyclerView.scrollToPosition(state.messages.size - 1)
                }

                // A5: Update active per-chat mode chip next to "+"
                modeChip.text = state.activeMode.shortLabelRu
                modeChip.setTextColor(
                    when (state.activeMode) {
                        ChatMode.CODER -> Color.parseColor("#5EF2A5")
                        ChatMode.ADULT_ROLEPLAY -> Color.parseColor("#F472B6")
                        ChatMode.NORMAL -> Color.parseColor("#93C5FD")
                    }
                )

                // A2: Pop Perchance verification dialog if blocked on unverified Perchance
                if (state.perchanceVerifyPromptTick > lastHandledVerifyTick && state.perchanceVerifyPromptTick > 0L) {
                    lastHandledVerifyTick = state.perchanceVerifyPromptTick
                    activity?.let { act -> PerchanceVerifyDialogHelper.show(act, viewLifecycleOwner) }
                }

                // A8: Show step-limit continuation card if autonomous agent hit its limit
                val limit = state.agentLimitPrompt
                if (limit != null) {
                    agentLimitCard.visibility = View.VISIBLE
                    agentLimitTitle.text = "Достигнут лимит ${limit.currentLimit} действий (выполнено ${limit.stepsExecuted})"
                    agentLimitSubtitle.text = "Цель: ${limit.goalSummaryRu.take(70)}. Продолжить выполнение?"
                } else {
                    agentLimitCard.visibility = View.GONE
                }

                if (state.isGenerating) {
                    val kurumi = app.prefs.kurumiThemeEnabled
                    thinkingCard.visibility = View.VISIBLE
                    thinkingName.text = app.prefs.assistantName
                    thinkingStatus.text = state.statusBannerRu ?: if (kurumi) "Сверяется с часами Зафкиэля…" else "Размышляет над ответом…"
                    if (!state.agentActionCounterRu.isNullOrBlank()) {
                        agentCounterBadge.visibility = View.VISIBLE
                        agentCounterBadge.text = state.agentActionCounterRu
                    } else {
                        agentCounterBadge.visibility = View.GONE
                    }
                    thinkingAvatar.setThinking(true)
                    startChatThinkingVideoIfNeeded()
                } else {
                    thinkingAvatar.setThinking(false)
                    stopChatThinkingVideo()
                    thinkingCard.visibility = View.GONE
                }
                updatePrimaryActionIcon()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            app.inferenceEngine.state.collectLatest { eng ->
                when (eng) {
                    is EngineState.Unloaded -> modelPillText.text = "Подключить API / ИИ"
                    is EngineState.Loading -> modelPillText.text = "Загрузка…"
                    is EngineState.Ready -> {
                        val shortModel = eng.modelName.substringAfterLast('/').take(20)
                        modelPillText.text = "${eng.profileTitle} • $shortModel"
                    }
                    is EngineState.Error -> modelPillText.text = "Ошибка модели"
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            app.voiceEngine.state.collectLatest { vState ->
                when (vState) {
                    is VoiceState.Idle -> {
                        isVoiceRecordingNow = false
                        voiceStatusBar.visibility = View.GONE
                        updatePrimaryActionIcon()
                    }
                    is VoiceState.Recording -> {
                        isVoiceRecordingNow = true
                        voiceStatusBar.visibility = View.VISIBLE
                        voiceStatusBar.text = if (vState.partialText.isBlank()) "Слушаю…" else vState.partialText
                        updatePrimaryActionIcon()
                    }
                    is VoiceState.Transcribing -> {
                        isVoiceRecordingNow = false
                        voiceStatusBar.visibility = View.VISIBLE
                        voiceStatusBar.text = vState.statusRu
                        updatePrimaryActionIcon()
                    }
                    is VoiceState.ResultReady -> {
                        isVoiceRecordingNow = false
                        voiceStatusBar.visibility = View.GONE
                        val current = inputEditText.text.toString().trim()
                        val merged = if (current.isEmpty()) vState.recognizedText else "$current ${vState.recognizedText}"
                        inputEditText.setText(merged)
                        inputEditText.setSelection(merged.length)
                        app.voiceEngine.resetToIdle()
                        updatePrimaryActionIcon()
                    }
                    is VoiceState.Error -> {
                        isVoiceRecordingNow = false
                        voiceStatusBar.visibility = View.VISIBLE
                        voiceStatusBar.text = vState.messageRu
                        updatePrimaryActionIcon()
                    }
                }
            }
        }
    }

    private fun showChatGptContextMenu(message: ChatMessageEntity) {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_message_menu, null)

        val timeTv: TextView = dialogView.findViewById(R.id.menu_timestamp)
        val copyRow: View = dialogView.findViewById(R.id.menu_action_copy)
        val selectRow: View = dialogView.findViewById(R.id.menu_action_select)
        val editRow: View = dialogView.findViewById(R.id.menu_action_edit)
        val shareRow: View = dialogView.findViewById(R.id.menu_action_share)

        timeTv.text = formatTimestampRu(message.timestampMs)
        editRow.visibility = if (message.role == "user") View.VISIBLE else View.GONE

        val dialog = AlertDialog.Builder(requireContext()).setView(dialogView).create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        copyRow.setOnClickListener { dialog.dismiss(); copyText(message.text) }
        selectRow.setOnClickListener { dialog.dismiss(); showSelectableTextDialog(message.text) }
        editRow.setOnClickListener { dialog.dismiss(); showEditMessageDialog(message) }
        shareRow.setOnClickListener {
            dialog.dismiss()
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message.text)
            }
            startActivity(Intent.createChooser(shareIntent, "Поделиться сообщением"))
        }
        dialog.show()
    }

    private fun showSelectableTextDialog(text: String) {
        val tv = TextView(requireContext()).apply {
            this.text = text
            setTextIsSelectable(true)
            setTextColor(requireContext().getColor(R.color.jarvis_text_primary))
            textSize = 15f
            val pad = (18 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Выделить текст")
            .setView(tv)
            .setPositiveButton("Копировать всё") { _, _ -> copyText(text) }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun showEditMessageDialog(message: ChatMessageEntity) {
        val edit = EditText(requireContext()).apply {
            setText(message.text)
            setSelection(message.text.length)
            setTextColor(requireContext().getColor(R.color.jarvis_text_primary))
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Редактировать сообщение")
            .setView(edit)
            .setPositiveButton("Переотправить") { _, _ ->
                val updated = edit.text.toString().trim()
                if (updated.isNotEmpty()) {
                    val app = JarvisApplication.instance
                    viewLifecycleOwner.lifecycleScope.launch {
                        app.chatCoordinator.editAndResend(
                            userMessageId = message.id,
                            newText = updated,
                            config = app.prefs.buildGenerationConfig(app.prefs.activeProfileId)
                        )
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmClearCurrentChat() {
        AlertDialog.Builder(requireContext())
            .setTitle("Очистить текущий чат?")
            .setMessage("Сообщения этого чата будут удалены с устройства.")
            .setPositiveButton("Очистить") { _, _ ->
                JarvisApplication.instance.chatCoordinator.clearActiveChat()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun copyText(text: String) {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Jarvis", text))
        Toast.makeText(requireContext(), "Скопировано", Toast.LENGTH_SHORT).show()
    }

    private fun startInAppVoiceRecording() {
        val ctx = requireContext()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        JarvisApplication.instance.voiceEngine.startRecording()
    }

    private fun launchPhotoPicker() {
        try {
            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        } catch (_: Throwable) {
            fallbackDocumentPhotoLauncher.launch(arrayOf("image/*"))
        }
    }

    private fun requestCameraAndLaunch() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            launchCameraCapture()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchCameraCapture() {
        try {
            val captureDir = File(requireContext().cacheDir, "camera_captures").apply { mkdirs() }
            val photoFile = File(captureDir, "cam_${System.currentTimeMillis()}.jpg")
            JarvisApplication.instance.prefs.pendingCameraFilePath = photoFile.absolutePath
            val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", photoFile)
            cameraLauncher.launch(uri)
        } catch (e: Throwable) {
            Toast.makeText(requireContext(), "Не удалось открыть камеру: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun processCameraFile(file: File) {
        viewLifecycleOwner.lifecycleScope.launch {
            val prep = withContext(Dispatchers.IO) { ImagePreprocessor.prepareLocalFileForVision(requireContext(), file) }
            applyPreparedPhotoResult(prep)
        }
    }

    private fun processSelectedPhotoUri(uri: Uri) {
        viewLifecycleOwner.lifecycleScope.launch {
            val prep = withContext(Dispatchers.IO) { ImagePreprocessor.prepareLocalCopyForVision(requireContext(), uri) }
            applyPreparedPhotoResult(prep)
        }
    }

    private fun applyPreparedPhotoResult(prep: Result<File>) {
        prep.onSuccess { localCopy ->
            pendingPhotoPath = localCopy.absolutePath
            attachedPhotoBar.visibility = View.VISIBLE
            val bmp = BitmapFactory.decodeFile(localCopy.absolutePath)
            if (bmp != null) attachedPhotoThumb.setImageBitmap(bmp)
            updatePrimaryActionIcon()
        }.onFailure { err ->
            Toast.makeText(requireContext(), err.message ?: "Не удалось загрузить изображение", Toast.LENGTH_LONG).show()
        }
    }

    private fun clearPendingPhoto() {
        pendingPhotoPath = null
        attachedPhotoBar.visibility = View.GONE
        updatePrimaryActionIcon()
    }

    private fun sendCurrentMessage() {
        val text = inputEditText.text.toString().trim()
        val photo = pendingPhotoPath
        if (text.isEmpty() && photo == null) return

        val app = JarvisApplication.instance
        inputEditText.setText("")
        clearPendingPhoto()
        voiceStatusBar.visibility = View.GONE

        // A7: Check if user triggered one of their saved Custom Commands by phrase!
        if (photo == null) {
            val matchedCmd = app.customCommandRepository.findMatchingTrigger(text)
            if (matchedCmd != null) {
                Toast.makeText(requireContext(), "Запуск команды «${matchedCmd.name}»…", Toast.LENGTH_SHORT).show()
                viewLifecycleOwner.lifecycleScope.launch {
                    val rep = app.customCommandRepository.executeCommand(matchedCmd)
                    Toast.makeText(
                        requireContext(),
                        if (rep.succeeded) "Команда выполнена (${rep.completedSteps}/${rep.totalSteps})"
                        else rep.logsRu.lastOrNull() ?: "Команда остановлена",
                        Toast.LENGTH_LONG
                    ).show()
                }
                return
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            app.chatCoordinator.sendMessage(
                rawUserText = text,
                imagePath = photo,
                config = app.prefs.buildGenerationConfig(app.prefs.activeProfileId)
            )
        }
    }

    private fun formatTimestampRu(ts: Long): String {
        val calNow = Calendar.getInstance()
        val calMsg = Calendar.getInstance().apply { timeInMillis = ts }
        val sameDay = calNow.get(Calendar.YEAR) == calMsg.get(Calendar.YEAR) &&
            calNow.get(Calendar.DAY_OF_YEAR) == calMsg.get(Calendar.DAY_OF_YEAR)
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))
        return if (sameDay) "Сегодня, $timeStr" else SimpleDateFormat("d MMM, HH:mm", Locale("ru")).format(Date(ts))
    }
}
