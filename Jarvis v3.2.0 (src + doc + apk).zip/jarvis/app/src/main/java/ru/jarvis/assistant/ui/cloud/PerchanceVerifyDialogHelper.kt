package ru.jarvis.assistant.ui.cloud

import android.app.Activity
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.cloud.PerchanceVerifyStatus
import ru.jarvis.assistant.ui.MainActivity

/**
 * Reusable Perchance Cloudflare/WebView verification dialog (A2 + C3):
 * - Header with mandatory "×" button (closes WITHOUT marking verified -> reappears on next use).
 * - Live embedded WebView for Cloudflare Turnstile.
 * - "Проверить" button to start/repeat verification + "Очистить кэш" recovery option.
 * - Auto-closes immediately upon verification success + notifies user + invokes [onVerified].
 */
object PerchanceVerifyDialogHelper {

    private var activeDialog: AlertDialog? = null

    fun show(
        activity: Activity,
        lifecycleOwner: LifecycleOwner,
        onVerified: (() -> Unit)? = null
    ) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (activeDialog?.isShowing == true) return

        val app = JarvisApplication.instance
        val bridge = app.perchanceBridge
        val d = activity.resources.displayMetrics.density

        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#11131A"))
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (14 * d).toInt())
        }

        // Top Header with title + mandatory "×" close button
        val header = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(activity).apply {
            text = "Проверка Perchance (Cloudflare)"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeXBtn = ImageButton(activity).apply {
            setImageResource(R.drawable.ic_close)
            background = activity.getDrawable(R.drawable.bg_glass_circle)
            contentDescription = "Закрыть без подтверждения"
            val sz = (36 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz)
            setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
        }
        header.addView(titleTv)
        header.addView(closeXBtn)
        container.addView(header)

        val statusTv = TextView(activity).apply {
            text = bridge.bridgeState.value.statusRu
            setTextColor(Color.parseColor("#FFD166"))
            textSize = 12.5f
            setPadding(0, (8 * d).toInt(), 0, (6 * d).toInt())
        }
        container.addView(statusTv)

        val hintTv = TextView(activity).apply {
            text = "Дождитесь завершения проверки (~5–30 сек) или нажмите галочку Cloudflare ниже. Окно закроется автоматически после успеха. Закрытие крестиком не подтверждает проверку."
            setTextColor(Color.parseColor("#9CA3AF"))
            textSize = 11.5f
            setPadding(0, 0, 0, (8 * d).toInt())
        }
        container.addView(hintTv)

        val webHost = FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (270 * d).toInt()
            )
            setBackgroundColor(Color.parseColor("#181B26"))
        }
        container.addView(webHost)

        val actionsRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, (10 * d).toInt(), 0, 0)
        }
        val verifyBtn = MaterialButton(activity).apply {
            text = "Проверить"
            isAllCaps = false
            layoutParams = LinearLayout.LayoutParams(0, (42 * d).toInt(), 1.2f).apply {
                marginEnd = (8 * d).toInt()
            }
        }
        val clearBtn = MaterialButton(activity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Сброс cookies"
            isAllCaps = false
            setTextColor(Color.parseColor("#D1D5DB"))
            layoutParams = LinearLayout.LayoutParams(0, (42 * d).toInt(), 1f)
        }
        actionsRow.addView(verifyBtn)
        actionsRow.addView(clearBtn)
        container.addView(actionsRow)

        val dlg = AlertDialog.Builder(activity)
            .setView(container)
            .setCancelable(true)
            .create()
        activeDialog = dlg

        var completedSuccessfully = false
        var observerJob: Job? = null

        closeXBtn.setOnClickListener {
            dlg.dismiss()
        }

        verifyBtn.setOnClickListener {
            bridge.requestVerification(manualTrigger = true)
        }

        clearBtn.setOnClickListener {
            bridge.clearStorageAndReverify()
        }

        bridge.attachToContainer(webHost)
        bridge.warmup()
        if (!bridge.isVerified()) {
            bridge.requestVerification(manualTrigger = true)
        }

        observerJob = lifecycleOwner.lifecycleScope.launch {
            bridge.bridgeState.collectLatest { st ->
                statusTv.text = "Статус: ${st.verifyStatus.labelRu} • ${st.statusRu}"
                val color = when (st.verifyStatus) {
                    PerchanceVerifyStatus.VERIFIED -> Color.parseColor("#5EF2A5")
                    PerchanceVerifyStatus.CHECKING -> Color.parseColor("#64D2FF")
                    PerchanceVerifyStatus.NEEDS_VERIFICATION -> Color.parseColor("#FFD166")
                    PerchanceVerifyStatus.ERROR -> Color.parseColor("#FF7A7A")
                    PerchanceVerifyStatus.IDLE -> Color.parseColor("#9CA3AF")
                }
                statusTv.setTextColor(color)
                if (st.verified && !completedSuccessfully) {
                    completedSuccessfully = true
                    Toast.makeText(activity, "Проверка Perchance успешно пройдена", Toast.LENGTH_SHORT).show()
                    dlg.dismiss()
                    onVerified?.invoke()
                }
            }
        }

        dlg.setOnDismissListener {
            observerJob?.cancel()
            activeDialog = null
            bridge.detachFromContainer(webHost)
            (activity as? MainActivity)?.reattachPerchanceHost(warmup = false)
            if (!completedSuccessfully) {
                bridge.onVerifyDialogDismissedByUser()
            }
        }

        dlg.show()
    }
}
