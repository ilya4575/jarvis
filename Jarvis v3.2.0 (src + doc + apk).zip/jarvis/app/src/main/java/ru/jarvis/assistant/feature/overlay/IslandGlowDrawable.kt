package ru.jarvis.assistant.feature.overlay

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable

/**
 * Pitch-black Dynamic Island background with an optional animated CORTEX-style gradient border
 * (warm amber -> rose -> violet -> indigo) when actively listening, generating, or executing actions.
 */
class IslandGlowDrawable(
    private var cornerRadiusPx: Float = 44f
) : Drawable() {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FF000000")
    }

    private val idleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        color = Color.parseColor("#2AFFFFFF")
    }

    private val glowStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.2f
    }

    private val outerAuraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 9.0f
        alpha = 72
    }

    private val rect = RectF()
    private val shaderMatrix = Matrix()
    private var sweepShader: SweepGradient? = null

    var kurumiPalette: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                sweepShader = null
                idleStrokePaint.color = if (value) Color.parseColor("#55FFD54F") else Color.parseColor("#2AFFFFFF")
                invalidateSelf()
            }
        }

    var glowActive: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidateSelf()
            }
        }

    var glowAngleDeg: Float = 0f
        set(value) {
            field = value
            invalidateSelf()
        }

    var isExpandedSurface: Boolean = false
        set(value) {
            field = value
            bgPaint.color = if (value) Color.parseColor("#F50A0B10") else Color.parseColor("#FF000000")
            invalidateSelf()
        }

    fun setCornerRadiusPx(px: Float) {
        cornerRadiusPx = px
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return

        val inset = if (glowActive) 3.5f else 1.5f
        rect.set(
            b.left + inset,
            b.top + inset,
            b.right - inset,
            b.bottom - inset
        )
        val radius = cornerRadiusPx.coerceAtMost(rect.height() / 2f)

        canvas.drawRoundRect(rect, radius, radius, bgPaint)

        if (glowActive) {
            val cx = rect.centerX()
            val cy = rect.centerY()
            val colors = if (kurumiPalette) {
                intArrayOf(
                    Color.parseColor("#FFD54F"), // Zafkiel gold
                    Color.parseColor("#E11D48"), // Kurumi crimson
                    Color.parseColor("#881337"), // deep garnet
                    Color.parseColor("#F59E0B"), // antique clock amber
                    Color.parseColor("#FFD54F")  // loop smoothly
                )
            } else {
                intArrayOf(
                    Color.parseColor("#F59E0B"), // warm amber
                    Color.parseColor("#F43F5E"), // coral/rose
                    Color.parseColor("#A855F7"), // violet
                    Color.parseColor("#3B82F6"), // cobalt
                    Color.parseColor("#F59E0B")  // loop back smoothly
                )
            }
            val shader = sweepShader ?: SweepGradient(cx, cy, colors, null).also { sweepShader = it }

            shaderMatrix.reset()
            shaderMatrix.postRotate(glowAngleDeg, cx, cy)
            shader.setLocalMatrix(shaderMatrix)

            outerAuraPaint.shader = shader
            outerAuraPaint.alpha = 68
            canvas.drawRoundRect(rect, radius, radius, outerAuraPaint)

            glowStrokePaint.shader = shader
            canvas.drawRoundRect(rect, radius, radius, glowStrokePaint)
        } else {
            canvas.drawRoundRect(rect, radius, radius, idleStrokePaint)
        }
    }

    override fun onBoundsChange(bounds: android.graphics.Rect) {
        super.onBoundsChange(bounds)
        sweepShader = null
    }

    override fun setAlpha(alpha: Int) {
        bgPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        bgPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
