package ru.jarvis.assistant.core.chat

import ru.jarvis.assistant.core.inference.ChatTurn

data class ContextAssembly(
    val recentTurns: List<ChatTurn>,
    val summaryText: String,
    val shouldRefreshSummary: Boolean,
    val olderTurnsToSummarize: List<ChatTurn>,
    val newSummaryUpToMessageId: Long
)

data class StoredMessageForContext(
    val id: Long,
    val role: String,
    val text: String
)

/**
 * Manages long chat memory (20..50 recent messages) + compact rolling summary of older turns.
 * - Default window: 36 messages (configurable strictly in MIN_CONTEXT_MESSAGES..MAX_CONTEXT_MESSAGES).
 * - Never loses system prompt or active ChatMode instructions (summary is merged cleanly into context).
 * - Provides both LLM summarization prompt builder and reliable offline deterministic summary fallback.
 */
object ChatContextManager {

    const val MIN_CONTEXT_MESSAGES = 20
    const val MAX_CONTEXT_MESSAGES = 50
    const val DEFAULT_CONTEXT_MESSAGES = 36
    private const val MAX_SUMMARY_CHARS = 1600
    private const val SUMMARY_BATCH_TRIGGER = 6

    fun clampWindowSize(requested: Int): Int =
        requested.coerceIn(MIN_CONTEXT_MESSAGES, MAX_CONTEXT_MESSAGES)

    /**
     * Splits chat history into:
     * - recent [windowSize] messages sent verbatim (clamped to 20..50)
     * - older messages beyond the window that should be folded into [existingSummary]
     */
    fun assembleContext(
        allMessages: List<StoredMessageForContext>,
        existingSummary: String,
        existingSummaryUpToId: Long,
        windowSize: Int = DEFAULT_CONTEXT_MESSAGES,
        maxCharsPerTurn: Int = 2400
    ): ContextAssembly {
        val limit = clampWindowSize(windowSize)
        val dialog = allMessages.filter {
            (it.role == "user" || it.role == "assistant") &&
                it.text.isNotBlank() &&
                it.text.trim() != "…"
        }

        if (dialog.size <= limit) {
            return ContextAssembly(
                recentTurns = dialog.map {
                    ChatTurn(it.role, trimTurn(it.text, maxCharsPerTurn))
                },
                summaryText = existingSummary.trim(),
                shouldRefreshSummary = false,
                olderTurnsToSummarize = emptyList(),
                newSummaryUpToMessageId = existingSummaryUpToId
            )
        }

        val cutIndex = dialog.size - limit
        val older = dialog.subList(0, cutIndex)
        val recent = dialog.subList(cutIndex, dialog.size)

        val unsummarizedOlder = older.filter { it.id > existingSummaryUpToId }
        val shouldRefresh = unsummarizedOlder.size >= SUMMARY_BATCH_TRIGGER ||
            (existingSummary.isBlank() && unsummarizedOlder.isNotEmpty())

        val fallbackSummary = if (existingSummary.isBlank() && older.isNotEmpty()) {
            buildDeterministicSummary(existingSummary, older.map { ChatTurn(it.role, it.text) })
        } else {
            existingSummary.trim()
        }

        return ContextAssembly(
            recentTurns = recent.map {
                ChatTurn(it.role, trimTurn(it.text, maxCharsPerTurn))
            },
            summaryText = fallbackSummary,
            shouldRefreshSummary = shouldRefresh,
            olderTurnsToSummarize = unsummarizedOlder.map { ChatTurn(it.role, trimTurn(it.text, 500)) },
            newSummaryUpToMessageId = older.lastOrNull()?.id ?: existingSummaryUpToId
        )
    }

    /**
     * Prompt for an online LLM to compress older turns into a crisp Russian memory summary.
     */
    fun buildSummarizationPrompt(
        previousSummary: String,
        newOlderTurns: List<ChatTurn>
    ): String = buildString {
        append("Сожми старую часть диалога в краткое структурированное резюме на русском языке (до 900 символов).\n")
        append("Обязательно сохрани: 1) главную цель/тему, 2) важные факты, имена, числа и предпочтения пользователя, 3) принятые договорённости и ограничения, 4) ключевой текущий статус.\n")
        append("Не пиши вступлений, верни только само резюме списком.\n\n")
        if (previousSummary.isNotBlank()) {
            append("Предыдущее резюме:\n")
            append(previousSummary.take(900))
            append("\n\n")
        }
        append("Новые сообщения для добавления в резюме:\n")
        for (turn in newOlderTurns.takeLast(24)) {
            val who = if (turn.role == "user") "Пользователь" else "Ассистент"
            append(who).append(": ").append(turn.content.replace('\n', ' ').take(280)).append('\n')
        }
    }

    /**
     * Zero-dependency deterministic extractive summary fallback so long-chat memory NEVER breaks
     * even if the online summarization call fails, times out, or user is offline.
     */
    fun buildDeterministicSummary(
        previousSummary: String,
        newOlderTurns: List<ChatTurn>
    ): String {
        val bullets = mutableListOf<String>()
        if (previousSummary.isNotBlank()) {
            previousSummary.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .take(8)
                .forEach { bullets.add(it) }
        }

        val userTurns = newOlderTurns.filter { it.role == "user" && it.content.isNotBlank() }
        val assistantTurns = newOlderTurns.filter { it.role == "assistant" && it.content.isNotBlank() }

        if (bullets.isEmpty() && userTurns.isNotEmpty()) {
            val goal = firstSentence(userTurns.first().content, 160)
            bullets.add("• Цель/тема: $goal")
        }

        // Capture key user facts/preferences/requests
        val factHints = listOf(
            "меня зовут", "я ", "мой ", "моя ", "мне ", "нужно", "хочу", "сделай",
            "договорились", "помни", "запомни", "важно", "правило", "используй", "не используй"
        )
        for (u in userTurns) {
            val lower = u.content.lowercase()
            val snippet = firstSentence(u.content, 140)
            if (snippet.isEmpty()) continue
            val tagged = if (factHints.any { lower.contains(it) }) "• Факт/требование: $snippet" else "• Запрос: $snippet"
            if (bullets.none { it.equals(tagged, ignoreCase = true) }) {
                bullets.add(tagged)
            }
            if (bullets.size >= 11) break
        }

        assistantTurns.lastOrNull()?.let { lastA ->
            val conclusion = firstSentence(lastA.content, 150)
            if (conclusion.isNotEmpty()) {
                bullets.add("• Итог прошлого этапа: $conclusion")
            }
        }

        return bullets.joinToString("\n").take(MAX_SUMMARY_CHARS).trim()
    }

    private fun firstSentence(text: String, maxLen: Int): String {
        val flat = text.replace(Regex("\\s+"), " ").trim()
        if (flat.length <= maxLen) return flat
        val endIdx = flat.indexOfAny(charArrayOf('.', '!', '?'), startIndex = 24)
        return if (endIdx in 24..maxLen) {
            flat.substring(0, endIdx + 1)
        } else {
            flat.take(maxLen - 1).trimEnd() + "…"
        }
    }

    private fun trimTurn(text: String, maxChars: Int): String {
        val clean = text.trim()
        return if (clean.length > maxChars) clean.take(maxChars - 1) + "…" else clean
    }
}
