package ru.jarvis.assistant

import android.app.Application
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import ru.jarvis.assistant.core.cloud.AssistantNotesStore
import ru.jarvis.assistant.core.cloud.CloudLlmClient
import ru.jarvis.assistant.core.cloud.GroqWhisperClient
import ru.jarvis.assistant.core.cloud.HybridInferenceEngine
import ru.jarvis.assistant.core.cloud.ImageGenerationOrchestrator
import ru.jarvis.assistant.core.cloud.PerchanceWebViewBridge
import ru.jarvis.assistant.core.cloud.PuterApiClient
import ru.jarvis.assistant.core.inference.LlamaInferenceEngine
import ru.jarvis.assistant.core.models.ModelDownloadManager
import ru.jarvis.assistant.core.models.ModelStorage
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import ru.jarvis.assistant.data.db.ChatDatabase
import ru.jarvis.assistant.feature.accessibility.AppActionPlanner
import ru.jarvis.assistant.feature.agent.AndroidAgentToolExecutor
import ru.jarvis.assistant.feature.avatar.AvatarManager
import ru.jarvis.assistant.feature.chat.ChatCoordinator
import ru.jarvis.assistant.feature.chat.ImageGenDefaults
import ru.jarvis.assistant.feature.commands.CustomCommandRepository
import ru.jarvis.assistant.feature.voice.LocalTtsSpeaker
import ru.jarvis.assistant.feature.voice.OfflineVoiceEngine
import ru.jarvis.assistant.feature.voice.VoiceSampleManager
import ru.jarvis.assistant.ui.MainActivity
import java.io.File

class JarvisApplication : Application() {

    lateinit var appScope: CoroutineScope
        private set
    lateinit var prefs: JarvisPreferences
        private set
    lateinit var modelStorage: ModelStorage
        private set
    lateinit var downloadManager: ModelDownloadManager
        private set
    lateinit var chatDatabase: ChatDatabase
        private set
    lateinit var localLlamaEngine: LlamaInferenceEngine
        private set
    lateinit var cloudLlmClient: CloudLlmClient
        private set
    lateinit var perchanceBridge: PerchanceWebViewBridge
        private set
    lateinit var imageOrchestrator: ImageGenerationOrchestrator
        private set
    lateinit var assistantNotesStore: AssistantNotesStore
        private set
    lateinit var puterApiClient: PuterApiClient
        private set
    lateinit var groqWhisperClient: GroqWhisperClient
        private set
    lateinit var inferenceEngine: HybridInferenceEngine
        private set
    lateinit var chatCoordinator: ChatCoordinator
        private set
    lateinit var voiceEngine: OfflineVoiceEngine
        private set
    lateinit var ttsSpeaker: LocalTtsSpeaker
        private set
    lateinit var voiceSampleManager: VoiceSampleManager
        private set
    lateinit var avatarManager: AvatarManager
        private set
    lateinit var actionPlanner: AppActionPlanner
        private set
    lateinit var agentToolExecutor: AndroidAgentToolExecutor
        private set
    lateinit var customCommandRepository: CustomCommandRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        prefs = JarvisPreferences(this)
        modelStorage = ModelStorage(File(filesDir, "models"))
        downloadManager = ModelDownloadManager(modelStorage)
        chatDatabase = ChatDatabase(this)

        localLlamaEngine = LlamaInferenceEngine(this, modelStorage)
        cloudLlmClient = CloudLlmClient()
        perchanceBridge = PerchanceWebViewBridge(this, prefs)
        imageOrchestrator = ImageGenerationOrchestrator(this, perchanceBridge)
        groqWhisperClient = GroqWhisperClient()

        actionPlanner = AppActionPlanner(this)
        agentToolExecutor = AndroidAgentToolExecutor(this, actionPlanner, prefs)
        assistantNotesStore = AssistantNotesStore(File(filesDir, "assistant_notes_v1.json"))
        puterApiClient = PuterApiClient(
            notesStore = assistantNotesStore,
            toolExecutor = agentToolExecutor
        )

        inferenceEngine = HybridInferenceEngine(
            prefs = prefs,
            localEngine = localLlamaEngine,
            cloudClient = cloudLlmClient,
            perchanceBridge = perchanceBridge,
            puterClient = puterApiClient
        )

        customCommandRepository = CustomCommandRepository(this, agentToolExecutor)

        chatCoordinator = ChatCoordinator(
            store = chatDatabase,
            engine = inferenceEngine,
            toolExecutor = agentToolExecutor,
            agentMaxStepsProvider = { prefs.agentMaxSteps },
            contextWindowProvider = { prefs.contextWindowMessages },
            perchanceImageGenerator = { prompt, resolution ->
                perchanceBridge.generateImage(prompt = prompt, resolution = resolution)
            },
            imageOrchestrator = { request, onStatus ->
                imageOrchestrator.generate(request, onStatus)
            },
            imageDefaultsProvider = {
                ImageGenDefaults(
                    qualityMode = prefs.imageGenQualityMode,
                    style = prefs.imageGenStyle.takeIf { it.isNotBlank() },
                    resolution = prefs.imageGenResolution
                )
            }
        )

        voiceEngine = OfflineVoiceEngine(modelStorage, prefs, groqWhisperClient, context = this)
        ttsSpeaker = LocalTtsSpeaker(this, prefs, puterApiClient)
        voiceSampleManager = VoiceSampleManager(this, prefs)

        chatCoordinator.onReplySettled = { replyText ->
            if (prefs.ttsAutoSpeakReplies && replyText.isNotBlank()) {
                ttsSpeaker.speak(replyText)
            }
        }
        chatCoordinator.onAgentNeedsReturnToApp = { errorSummary ->
            runCatching {
                val intent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    putExtra(MainActivity.EXTRA_AGENT_RETURN_MESSAGE, errorSummary)
                }
                startActivity(intent)
            }
        }

        avatarManager = AvatarManager(this, prefs)
    }

    override fun onTerminate() {
        super.onTerminate()
        voiceEngine.releaseModel()
        ttsSpeaker.shutdown()
        perchanceBridge.destroy()
        puterApiClient.cancelActive()
        inferenceEngine.unload()
    }

    companion object {
        @Volatile
        lateinit var instance: JarvisApplication
            private set
    }
}
