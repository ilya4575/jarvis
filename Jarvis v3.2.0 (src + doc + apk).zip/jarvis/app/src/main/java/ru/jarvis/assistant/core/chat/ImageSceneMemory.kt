package ru.jarvis.assistant.core.chat

import org.json.JSONArray
import org.json.JSONObject

/**
 * Per-chat persistent visual scene/moment memory for AI image generation.
 * - Remembers characters, setting, visual details, style, and recent moments across generations
 *   within the SAME chat session so follow-up images stay coherent and rich.
 * - Automatically starts clean (empty) for every NEW chat or cleared chat.
 */
data class ImageSceneMemory(
    val sceneAnchor: String = "",
    val recentMoments: List<String> = emptyList(),
    val lastPrompt: String = "",
    val preferredStyle: String = "",
    val lastSeed: Long? = null,
    val frameCount: Int = 0
) {
    fun isEmpty(): Boolean = frameCount <= 0 && sceneAnchor.isBlank() && recentMoments.isEmpty()

    fun compactSummary(): String {
        if (isEmpty()) return ""
        return buildString {
            if (sceneAnchor.isNotBlank()) append(sceneAnchor)
            val tail = recentMoments
                .filter { !it.equals(sceneAnchor, ignoreCase = true) }
                .takeLast(2)
            if (tail.isNotEmpty()) {
                if (isNotEmpty()) append("; recent: ")
                append(tail.joinToString("; ") { it.take(120) })
            }
            if (preferredStyle.isNotBlank()) {
                if (isNotEmpty()) append(" [style: $preferredStyle]")
            }
        }.take(420)
    }

    fun summaryShortRu(): String {
        if (isEmpty()) return "Чистая сцена (кадров: 0)"
        val anchorPreview = sceneAnchor.take(64).let { if (sceneAnchor.length > 64) "$it…" else it }
        val stylePart = if (preferredStyle.isNotBlank()) " • стиль: $preferredStyle" else ""
        return "Кадров в сцене: $frameCount$stylePart\n$anchorPreview"
    }

    companion object {
        private const val MAX_MOMENTS = 4
        private const val MAX_ANCHOR_CHARS = 360
        private const val MAX_EFFECTIVE_PROMPT_CHARS = 950

        fun fromJson(raw: String?): ImageSceneMemory {
            if (raw.isNullOrBlank()) return ImageSceneMemory()
            return runCatching {
                val obj = JSONObject(raw)
                val momentsArr = obj.optJSONArray("recentMoments")
                val moments = mutableListOf<String>()
                if (momentsArr != null) {
                    for (i in 0 until momentsArr.length()) {
                        val m = momentsArr.optString(i, "").trim()
                        if (m.isNotEmpty()) moments.add(m)
                    }
                }
                val seedVal = if (obj.has("lastSeed") && !obj.isNull("lastSeed")) {
                    obj.optLong("lastSeed", -1L).takeIf { it > 0L }
                } else null
                ImageSceneMemory(
                    sceneAnchor = obj.optString("sceneAnchor", "").trim(),
                    recentMoments = moments.takeLast(MAX_MOMENTS),
                    lastPrompt = obj.optString("lastPrompt", "").trim(),
                    preferredStyle = obj.optString("preferredStyle", "").trim(),
                    lastSeed = seedVal,
                    frameCount = obj.optInt("frameCount", 0).coerceAtLeast(0)
                )
            }.getOrDefault(ImageSceneMemory())
        }

        fun toJson(memory: ImageSceneMemory): String {
            if (memory.isEmpty()) return ""
            return JSONObject().apply {
                put("sceneAnchor", memory.sceneAnchor.take(MAX_ANCHOR_CHARS))
                put("recentMoments", JSONArray(memory.recentMoments.takeLast(MAX_MOMENTS)))
                put("lastPrompt", memory.lastPrompt.take(500))
                put("preferredStyle", memory.preferredStyle.take(64))
                if (memory.lastSeed != null && memory.lastSeed > 0L) {
                    put("lastSeed", memory.lastSeed)
                }
                put("frameCount", memory.frameCount)
            }.toString()
        }

        /**
         * Combines the user's new image prompt with the active chat's remembered scene/moment
         * (and recent chat messages if the user wrote a short contextual request like "нарисуй это").
         */
        fun buildEnrichedPrompt(
            userRequest: String,
            memory: ImageSceneMemory,
            recentChatTexts: List<String> = emptyList(),
            useSceneMemory: Boolean = true
        ): String {
            val clean = userRequest.trim().replace(Regex("\\s+"), " ")
            if (clean.isEmpty()) return ""
            if (!useSceneMemory) return clean

            if (memory.isEmpty()) {
                // First image in this chat: check if user refers to recent dialog context
                val needsChatContext = looksContextualReference(clean) && recentChatTexts.isNotEmpty()
                if (!needsChatContext) return clean
                val chatSnippet = recentChatTexts
                    .map { it.trim().replace(Regex("\\s+"), " ") }
                    .filter { it.isNotBlank() && !it.startsWith("Ошибка") && !it.startsWith("Готово (") }
                    .takeLast(2)
                    .joinToString("; ") { it.take(180) }
                if (chatSnippet.isBlank()) return clean
                return "$clean. Scene context from conversation: $chatSnippet"
                    .take(MAX_EFFECTIVE_PROMPT_CHARS)
            }

            // Subsequent frame in the SAME chat: keep visual continuity (characters, world, lighting)
            // while focusing clearly on the new moment/action requested by the user.
            val prevMoments = memory.recentMoments
                .filter { !it.equals(memory.sceneAnchor, ignoreCase = true) && !it.equals(clean, ignoreCase = true) }
                .takeLast(2)

            return buildString {
                append(clean)
                if (memory.sceneAnchor.isNotBlank()) {
                    append(". Consistent scene & characters: ")
                    append(memory.sceneAnchor)
                }
                if (prevMoments.isNotEmpty()) {
                    append(". Previous moment details: ")
                    append(prevMoments.joinToString("; ") { it.take(140) })
                }
            }.take(MAX_EFFECTIVE_PROMPT_CHARS)
        }

        /**
         * Updates per-chat scene memory after a successful image generation.
         */
        fun recordGeneratedFrame(
            previous: ImageSceneMemory,
            userRequest: String,
            style: String?,
            seed: Long?
        ): ImageSceneMemory {
            val cleanReq = userRequest.trim().replace(Regex("\\s+"), " ")
            val newAnchor = if (previous.sceneAnchor.isBlank()) {
                cleanReq.take(MAX_ANCHOR_CHARS)
            } else {
                // Preserve original anchor (character/world identity) without blowing up length
                previous.sceneAnchor.take(MAX_ANCHOR_CHARS)
            }
            val updatedMoments = (previous.recentMoments + cleanReq.take(180))
                .filter { it.isNotBlank() }
                .distinct()
                .takeLast(MAX_MOMENTS)

            val resolvedStyle = style?.trim().takeUnless { it.isNullOrBlank() } ?: previous.preferredStyle
            val resolvedSeed = seed?.takeIf { it > 0L } ?: previous.lastSeed

            return ImageSceneMemory(
                sceneAnchor = newAnchor,
                recentMoments = updatedMoments,
                lastPrompt = cleanReq.take(500),
                preferredStyle = resolvedStyle,
                lastSeed = resolvedSeed,
                frameCount = previous.frameCount + 1
            )
        }

        private fun looksContextualReference(prompt: String): Boolean {
            val lower = prompt.lowercase()
            if (lower.length <= 28) return true
            val markers = listOf(
                "это", "эту", "этот", "этой", "её", "его", "их", "там", "тут",
                "сцену", "момент", "продолж", "дальше", "потом", "теперь", "так же",
                "same", "this scene", "her", "him", "continue", "next moment"
            )
            return markers.any { lower.contains(it) }
        }
    }
}
