package ru.jarvis.assistant.core.inference

import kotlinx.coroutines.flow.StateFlow
import ru.jarvis.assistant.core.cloud.RequestSource
import ru.jarvis.assistant.core.models.ModelProfile
import ru.jarvis.assistant.core.models.ModelProfileId
import ru.jarvis.assistant.core.models.PromptFormat

enum class ResponseLength(
    val labelRu: String,
    val maxTokens: Int,
    val promptHintRu: String
) {
    SHORT("Кратко", 260, "Отвечай кратко и по делу, в 1–3 предложениях без лишней воды."),
    MEDIUM("Средне", 768, "Отвечай сбалансированно, понятно и структурированно."),
    DETAILED("Подробно", 1600, "Давай подробный и развёрнутый ответ с пояснениями и примерами.")
}

enum class AssistantTone(
    val labelRu: String,
    val promptHintRu: String
) {
    FRIENDLY("Дружелюбный", "Общайся естественно, живо и дружелюбно на «ты»."),
    BUSINESS("Спокойный и деловой", "Общайся спокойно, чётко и в деловом стиле."),
    DIRECT("Прямолинейный", "Отвечай максимально прямо, без вежливых предисловий и лишних фраз."),
    HUMOROUS("Лёгкий с юмором", "Отвечай дружелюбно, иногда с уместной лёгкой шуткой.")
}

data class ChatTurn(
    val role: String, // "user" or "assistant"
    val content: String
)

data class GenerationConfig(
    val assistantName: String = "Jarvis",
    val maxTokens: Int = 768,
    val temperature: Float = 0.65f,
    val enableThinking: Boolean = false,
    val responseLength: ResponseLength = ResponseLength.MEDIUM,
    val tone: AssistantTone = AssistantTone.FRIENDLY,
    val customSystemPrompt: String = "",
    val chatMode: ChatMode = ChatMode.NORMAL,
    val contextSummary: String = "",
    val contextWindowSize: Int = 36,
    val promptFormat: PromptFormat = PromptFormat.GEMMA3_INSTRUCT,
    val requestSource: RequestSource = RequestSource.CHAT,
    val agentToolsEnabled: Boolean = false,
    val installedAppsHint: List<String> = emptyList(),
    val accessibilityReady: Boolean = false,
    val imageGenerationEnabled: Boolean = false,
    val imageSceneSummary: String = "",
    val onThought: ((String) -> Unit)? = null
)

sealed class EngineState {
    data object Unloaded : EngineState()
    data class Loading(val modelName: String) : EngineState()
    data class Ready(
        val profileId: ModelProfileId,
        val profileTitle: String,
        val modelName: String,
        val visionSupported: Boolean,
        val contextSize: Int
    ) : EngineState()
    data class Error(val messageRu: String) : EngineState()
}

sealed class GenerationResult {
    data class Completed(val text: String, val elapsedMs: Long) : GenerationResult()
    data class Cancelled(val partialText: String) : GenerationResult()
    data class Failed(val reasonRu: String) : GenerationResult()
}

interface InferenceEngine {
    val state: StateFlow<EngineState>
    val isVisionReady: Boolean

    suspend fun loadProfile(profile: ModelProfile): Result<Unit>
    suspend fun generate(
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult

    fun cancelGeneration()
    fun unload()
}
