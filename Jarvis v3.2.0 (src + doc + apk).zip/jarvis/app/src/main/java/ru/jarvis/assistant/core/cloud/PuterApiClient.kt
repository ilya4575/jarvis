package ru.jarvis.assistant.core.cloud

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import ru.jarvis.assistant.core.agent.AgentToolCall
import ru.jarvis.assistant.core.agent.AgentToolExecutor
import ru.jarvis.assistant.core.inference.ChatTurn
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.GenerationResult
import ru.jarvis.assistant.core.inference.LlamaInferenceEngine
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Local persistent notes/memory store exposed as Puter OpenAI function-calling tools
 * (`save_note`, `get_notes`, `delete_note`) alongside existing Android assistant tools.
 */
class AssistantNotesStore(private val storageFile: File) {

    @Synchronized
    fun saveNote(key: String, content: String): String {
        val cleanKey = key.trim().ifBlank { "note_${System.currentTimeMillis()}" }
        val cleanContent = content.trim()
        val notes = loadAll().toMutableMap()
        notes[cleanKey] = cleanContent
        persist(notes)
        return "Заметка «$cleanKey» сохранена."
    }

    @Synchronized
    fun getNotes(query: String = ""): String {
        val notes = loadAll()
        if (notes.isEmpty()) return "Сохранённых заметок пока нет."
        val q = query.trim().lowercase()
        val filtered = if (q.isEmpty()) notes else notes.filter { (k, v) ->
            k.lowercase().contains(q) || v.lowercase().contains(q)
        }
        if (filtered.isEmpty()) return "По запросу «$query» заметок не найдено."
        return filtered.entries.joinToString("\n") { (k, v) -> "• $k: $v" }
    }

    @Synchronized
    fun deleteNote(key: String): String {
        val notes = loadAll().toMutableMap()
        val removed = notes.remove(key.trim())
        persist(notes)
        return if (removed != null) "Заметка «$key» удалена." else "Заметка «$key» не найдена."
    }

    private fun loadAll(): Map<String, String> {
        if (!storageFile.exists()) return emptyMap()
        return runCatching {
            val obj = JSONObject(storageFile.readText())
            val map = linkedMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optString(k, "")
            }
            map
        }.getOrDefault(emptyMap())
    }

    private fun persist(map: Map<String, String>) {
        runCatching {
            storageFile.parentFile?.mkdirs()
            val obj = JSONObject()
            for ((k, v) in map) obj.put(k, v)
            storageFile.writeText(obj.toString())
        }
    }
}

/**
 * Puter API Client (https://developer.puter.com/tutorials/use-openai-sdk-with-puter/):
 * - Chat completions: POST https://api.puter.com/puterai/openai/v1/chat/completions
 * - Auth: Authorization: Bearer <PUTER_AUTH_TOKEN> (never hardcoded; stored in SecureKeyStorage)
 * - Never calls GET /v1/models (unsupported on Puter) — uses econ/smart presets + custom model input
 * - Quota-saving sliding window (10..12 latest messages + rolling summary)
 * - Monthly metering usage: GET https://api.puter.com/metering/usage (allowanceInfo in microcents, 1_000_000 = $0.01)
 * - SSE streaming (stream: true) + standard OpenAI Function Calling loop (max 4 steps per user turn)
 * - On-device image compression (JPEG <= 1024px, strictly < 4 MB) -> image_url data URI
 * - Puter TTS via POST https://api.puter.com/drivers/call (interface="puter-tts") with OpenAI audio fallback
 * - Robust error handling: 401, 402 insufficient_funds (:free suggestion), 429 retry-after backoff, network errors
 */
class PuterApiClient(
    private val chatCompletionsUrl: String = DEFAULT_CHAT_COMPLETIONS_URL,
    private val meteringUsageUrl: String = DEFAULT_METERING_USAGE_URL,
    private val driversCallUrl: String = DEFAULT_DRIVERS_CALL_URL,
    private val openAiAudioUrl: String = DEFAULT_OPENAI_AUDIO_URL,
    private val notesStore: AssistantNotesStore? = null,
    private val toolExecutor: AgentToolExecutor? = null
) {
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(95, TimeUnit.SECONDS)
        .writeTimeout(35, TimeUnit.SECONDS)
        .build()

    private val activeCall = AtomicReference<Call?>(null)
    private val cancelRequested = AtomicBoolean(false)

    fun cancelActive() {
        cancelRequested.set(true)
        activeCall.getAndSet(null)?.cancel()
    }

    /**
     * Fetches remaining Puter monthly allowance via GET https://api.puter.com/metering/usage.
     * Supports microcents (1_000_000 = $0.01) and credits unit.
     */
    suspend fun fetchMonthlyUsage(authToken: String): Result<PuterUsageInfo> = withContext(Dispatchers.IO) {
        val cleanToken = CloudLlmClient.sanitizeApiKey(authToken)
        if (cleanToken.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Укажите Puter Auth Token."))
        }
        val req = Request.Builder()
            .url(meteringUsageUrl)
            .header("Authorization", "Bearer $cleanToken")
            .header("Accept", "application/json")
            .get()
            .build()

        runCatching {
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException(formatPuterHttpError(resp.code, body))
                }
                parseMeteringUsageJson(body)
            }
        }
    }

    /**
     * Lightweight connection check via GET /metering/usage (NEVER calls unsupported GET /v1/models
     * and does NOT burn AI chat credits just to verify the token!).
     */
    suspend fun testConnection(authToken: String, selectedModel: String): CloudTestResult {
        val usageRes = fetchMonthlyUsage(authToken)
        return usageRes.fold(
            onSuccess = { info ->
                CloudTestResult(
                    provider = CloudProvider.PUTER,
                    ok = true,
                    summaryRu = "Puter подключён ($selectedModel) • ${info.summaryRu()}"
                )
            },
            onFailure = { err ->
                CloudTestResult(
                    provider = CloudProvider.PUTER,
                    ok = false,
                    summaryRu = err.message ?: "Ошибка подключения Puter"
                )
            }
        )
    }

    /**
     * Streams a Puter chat completion with SSE (`stream: true`) and standard OpenAI Function Calling
     * (max 4 tool steps per user request so it never loops or wastes monthly quota).
     */
    suspend fun streamChatWithTools(
        authToken: String,
        model: String,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult = withContext(Dispatchers.IO) {
        cancelRequested.set(false)
        val cleanToken = CloudLlmClient.sanitizeApiKey(authToken)
        if (cleanToken.isBlank()) {
            return@withContext GenerationResult.Failed(
                "Puter: пустой Auth Token (401). Откройте Puter Dashboard → Create token и вставьте его в настройках."
            )
        }
        val effectiveModel = model.trim().ifBlank { DEFAULT_ECON_MODEL }
        val startMs = System.currentTimeMillis()

        // Build quota-saving sliding window (last 10..12 messages + rolling summary inside system prompt!)
        val sysPrompt = buildPuterSystemPrompt(config)
        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", sysPrompt))
            for (turn in history.takeLast(MAX_PUTER_HISTORY_MESSAGES)) {
                val c = turn.content.trim()
                if (c.isEmpty()) continue
                val role = if (turn.role == "user") "user" else "assistant"
                put(JSONObject().put("role", role).put("content", c))
            }
            val cleanPrompt = userPrompt.trim().ifEmpty { "Опиши это изображение подробно на русском языке." }
            val compressedDataUrl = compressImageToJpegDataUrl(imagePath)
            if (compressedDataUrl != null) {
                val parts = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", cleanPrompt))
                    .put(
                        JSONObject()
                            .put("type", "image_url")
                            .put("image_url", JSONObject().put("url", compressedDataUrl))
                    )
                put(JSONObject().put("role", "user").put("content", parts))
            } else {
                put(JSONObject().put("role", "user").put("content", cleanPrompt))
            }
        }

        val includeTools = config.agentToolsEnabled && (toolExecutor != null || notesStore != null)
        val toolsSchema = if (includeTools) buildOpenAiToolsSchema() else null

        val allVisibleText = StringBuilder()
        var toolStepCount = 0

        for (round in 0..MAX_PUTER_TOOL_STEPS) {
            if (cancelRequested.get()) {
                return@withContext GenerationResult.Cancelled(allVisibleText.toString())
            }

            val payload = JSONObject().apply {
                put("model", effectiveModel)
                put("messages", messages)
                put("stream", true)
                put("temperature", config.temperature.toDouble().coerceIn(0.05, 1.4))
                put("max_tokens", config.maxTokens.coerceIn(128, 2048))
                if (toolsSchema != null && round < MAX_PUTER_TOOL_STEPS) {
                    put("tools", toolsSchema)
                    put("tool_choice", "auto")
                }
            }

            val roundOutcome = executeSingleSseRoundWith429Retry(
                token = cleanToken,
                payload = payload,
                onToken = { piece ->
                    allVisibleText.append(piece)
                    onToken(piece)
                },
                onThought = config.onThought
            )

            when (roundOutcome) {
                is SseRoundOutcome.Cancelled -> {
                    return@withContext GenerationResult.Cancelled(allVisibleText.toString())
                }
                is SseRoundOutcome.Failed -> {
                    return@withContext GenerationResult.Failed(roundOutcome.reasonRu)
                }
                is SseRoundOutcome.Success -> {
                    val toolCalls = roundOutcome.toolCalls
                    if (toolCalls.isEmpty() || !includeTools || toolStepCount >= MAX_PUTER_TOOL_STEPS) {
                        val finalStr = allVisibleText.toString().trim()
                        if (finalStr.isEmpty() && toolCalls.isEmpty()) {
                            return@withContext GenerationResult.Failed("Puter вернул пустой ответ.")
                        }
                        val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                        return@withContext GenerationResult.Completed(finalStr.ifEmpty { "Готово." }, elapsed)
                    }

                    // Append assistant message with tool_calls per OpenAI function-calling spec
                    val assistantToolCallsJson = JSONArray()
                    for (tc in toolCalls) {
                        assistantToolCallsJson.put(
                            JSONObject().apply {
                                put("id", tc.id)
                                put("type", "function")
                                put(
                                    "function",
                                    JSONObject()
                                        .put("name", tc.name)
                                        .put("arguments", tc.argumentsJson)
                                )
                            }
                        )
                    }
                    messages.put(
                        JSONObject().apply {
                            put("role", "assistant")
                            if (roundOutcome.text.isNotBlank()) put("content", roundOutcome.text)
                            else put("content", JSONObject.NULL)
                            put("tool_calls", assistantToolCallsJson)
                        }
                    )

                    // Execute each requested Kotlin function tool (strictly capped at MAX_PUTER_TOOL_STEPS = 4)
                    for (tc in toolCalls) {
                        if (cancelRequested.get()) {
                            return@withContext GenerationResult.Cancelled(allVisibleText.toString())
                        }
                        if (toolStepCount >= MAX_PUTER_TOOL_STEPS) break
                        toolStepCount++
                        config.onThought?.invoke("\n• [Puter Tool $toolStepCount/$MAX_PUTER_TOOL_STEPS] ${tc.name}(${tc.argumentsJson.take(120)})")

                        val toolOutput = executePuterTool(tc.name, tc.argumentsJson)
                        config.onThought?.invoke("\n  ↳ ${toolOutput.take(240)}")

                        messages.put(
                            JSONObject().apply {
                                put("role", "tool")
                                put("tool_call_id", tc.id)
                                put("name", tc.name)
                                put("content", toolOutput)
                            }
                        )
                    }
                }
            }
        }

        val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
        GenerationResult.Completed(allVisibleText.toString().trim().ifEmpty { "Выполнение завершено." }, elapsed)
    }

    private data class AccumulatedToolCall(
        val id: String,
        val name: String,
        val argumentsJson: String
    )

    private sealed class SseRoundOutcome {
        data class Success(val text: String, val toolCalls: List<AccumulatedToolCall>) : SseRoundOutcome()
        data class Cancelled(val partial: String) : SseRoundOutcome()
        data class Failed(val reasonRu: String) : SseRoundOutcome()
    }

    private suspend fun executeSingleSseRoundWith429Retry(
        token: String,
        payload: JSONObject,
        onToken: (String) -> Unit,
        onThought: ((String) -> Unit)?
    ): SseRoundOutcome {
        val bodyStr = payload.toString()
        for (attempt in 0..1) {
            if (cancelRequested.get()) return SseRoundOutcome.Cancelled("")

            val req = Request.Builder()
                .url(chatCompletionsUrl)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .header("Accept", "text/event-stream")
                .post(bodyStr.toRequestBody(JSON_MEDIA))
                .build()

            val call = httpClient.newCall(req)
            activeCall.set(call)
            try {
                val outcome = call.execute().use { resp ->
                    if (resp.code == 429 && attempt == 0) {
                        val retrySec = resp.header("Retry-After")?.trim()?.toLongOrNull()?.coerceIn(1L, 8L) ?: 3L
                        onThought?.invoke("\n• Puter HTTP 429 — пауза ${retrySec}с и повторная попытка…")
                        return@use Pair<SseRoundOutcome?, Long>(null, retrySec * 1000L)
                    }
                    if (!resp.isSuccessful) {
                        val errBody = resp.body?.string().orEmpty()
                        return@use Pair(SseRoundOutcome.Failed(formatPuterHttpError(resp.code, errBody)), 0L)
                    }

                    val contentType = resp.header("Content-Type").orEmpty().lowercase()
                    val textBuf = StringBuilder()
                    val toolAccum = linkedMapOf<Int, MutableToolBuilder>()

                    if (contentType.contains("application/json")) {
                        // Graceful non-SSE JSON response handling if server replies non-streamed
                        val raw = resp.body?.string().orEmpty()
                        parseNonStreamResponse(raw, textBuf, toolAccum, onToken)
                    } else {
                        val source = resp.body?.source()
                            ?: return@use Pair(SseRoundOutcome.Failed("Puter: пустой ответ сервера."), 0L)

                        while (!source.exhausted()) {
                            if (cancelRequested.get()) {
                                return@use Pair(SseRoundOutcome.Cancelled(textBuf.toString()), 0L)
                            }
                            val line = source.readUtf8Line() ?: break
                            val trimmed = line.trim()
                            if (trimmed.isEmpty() || !trimmed.startsWith("data:")) continue
                            val data = trimmed.removePrefix("data:").trim()
                            if (data == "[DONE]") break
                            parseSseChunk(data, textBuf, toolAccum, onToken, onThought)
                        }
                    }

                    val completedCalls = toolAccum.entries
                        .sortedBy { it.key }
                        .mapNotNull { (_, b) ->
                            val nm = b.name.toString().trim()
                            if (nm.isEmpty()) null
                            else AccumulatedToolCall(
                                id = b.id.ifBlank { "call_${System.currentTimeMillis()}_${nm.hashCode()}" },
                                name = nm,
                                argumentsJson = b.args.toString().ifBlank { "{}" }
                            )
                        }
                    Pair(SseRoundOutcome.Success(textBuf.toString(), completedCalls), 0L)
                }

                val (res, retryDelayMs) = outcome
                if (res != null) return res
                if (retryDelayMs > 0L) {
                    delay(retryDelayMs)
                    continue
                }
            } catch (e: IOException) {
                if (cancelRequested.get()) return SseRoundOutcome.Cancelled("")
                return SseRoundOutcome.Failed("Puter: обрыв сети (${e.message ?: "нет соединения"}). Проверьте интернет и повторите.")
            } catch (t: Throwable) {
                if (cancelRequested.get()) return SseRoundOutcome.Cancelled("")
                return SseRoundOutcome.Failed("Puter ошибка: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                activeCall.compareAndSet(call, null)
            }
        }
        return SseRoundOutcome.Failed("Puter: превышен лимит запросов (HTTP 429). Подождите немного и повторите.")
    }

    private class MutableToolBuilder {
        var id: String = ""
        val name = StringBuilder()
        val args = StringBuilder()
    }

    private fun parseSseChunk(
        data: String,
        textBuf: StringBuilder,
        toolAccum: MutableMap<Int, MutableToolBuilder>,
        onToken: (String) -> Unit,
        onThought: ((String) -> Unit)?
    ) {
        runCatching {
            val root = JSONObject(data)
            val choice = root.optJSONArray("choices")?.optJSONObject(0) ?: return
            val delta = choice.optJSONObject("delta") ?: choice.optJSONObject("message") ?: return

            val reasoning = delta.optString("reasoning_content", "")
                .ifEmpty { delta.optString("reasoning", "") }
            if (reasoning.isNotEmpty()) onThought?.invoke(reasoning)

            val content = delta.optString("content", "")
            if (content.isNotEmpty() && content != "null") {
                textBuf.append(content)
                onToken(content)
            }

            val tcArr = delta.optJSONArray("tool_calls") ?: return
            for (i in 0 until tcArr.length()) {
                val tc = tcArr.optJSONObject(i) ?: continue
                val idx = tc.optInt("index", i)
                val builder = toolAccum.getOrPut(idx) { MutableToolBuilder() }
                val id = tc.optString("id", "")
                if (id.isNotBlank()) builder.id = id
                val fn = tc.optJSONObject("function")
                if (fn != null) {
                    val fnName = fn.optString("name", "")
                    if (fnName.isNotEmpty()) builder.name.append(fnName)
                    val fnArgs = fn.optString("arguments", "")
                    if (fnArgs.isNotEmpty()) builder.args.append(fnArgs)
                }
            }
        }
    }

    private fun parseNonStreamResponse(
        raw: String,
        textBuf: StringBuilder,
        toolAccum: MutableMap<Int, MutableToolBuilder>,
        onToken: (String) -> Unit
    ) {
        runCatching {
            val root = JSONObject(raw)
            val msg = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return
            val content = msg.optString("content", "")
            if (content.isNotEmpty() && content != "null") {
                textBuf.append(content)
                onToken(content)
            }
            val tcArr = msg.optJSONArray("tool_calls") ?: return
            for (i in 0 until tcArr.length()) {
                val tc = tcArr.optJSONObject(i) ?: continue
                val builder = toolAccum.getOrPut(i) { MutableToolBuilder() }
                builder.id = tc.optString("id", "call_$i")
                val fn = tc.optJSONObject("function") ?: continue
                builder.name.append(fn.optString("name", ""))
                builder.args.append(fn.optString("arguments", "{}"))
            }
        }
    }

    private suspend fun executePuterTool(toolName: String, argumentsJson: String): String {
        val argsObj = runCatching { JSONObject(argumentsJson) }.getOrElse { JSONObject() }
        val argsMap = linkedMapOf<String, String>()
        val keys = argsObj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = argsObj.opt(k)
            if (v != null && v != JSONObject.NULL) argsMap[k] = v.toString()
        }

        return when (toolName.lowercase()) {
            "save_note" -> notesStore?.saveNote(
                key = argsMap["key"].orEmpty(),
                content = argsMap["content"].orEmpty()
            ) ?: "Хранилище заметок недоступно."
            "get_notes" -> notesStore?.getNotes(argsMap["query"].orEmpty()) ?: "Хранилище заметок недоступно."
            "delete_note" -> notesStore?.deleteNote(argsMap["key"].orEmpty()) ?: "Хранилище заметок недоступно."
            "get_current_datetime" -> {
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss (EEEE)", Locale("ru", "RU"))
                "Текущие дата и время: ${fmt.format(Date())}"
            }
            else -> {
                val exec = toolExecutor
                    ?: return "Инструмент $toolName недоступен в текущем окружении."
                val res = exec.execute(AgentToolCall(name = toolName.lowercase(), args = argsMap))
                if (res.success) res.outputForModel.ifBlank { res.summaryRu }
                else "Ошибка: ${res.summaryRu} (${res.outputForModel})"
            }
        }
    }

    /**
     * Synthesizes speech via Puter TTS:
     * 1) Primary: POST https://api.puter.com/drivers/call (interface="puter-tts", method="synthesize")
     * 2) Fallback: POST https://api.puter.com/puterai/openai/v1/audio/speech (OpenAI-compatible)
     */
    suspend fun synthesizeSpeechToFile(
        authToken: String,
        text: String,
        provider: String = "openai",
        voice: String = "nova",
        model: String = "gpt-4o-mini-tts",
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanToken = CloudLlmClient.sanitizeApiKey(authToken)
        if (cleanToken.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Укажите Puter Auth Token в меню → «Провайдеры и API-ключи» для Puter TTS.")
            )
        }
        val cleanText = text.trim().take(2900)
        if (cleanText.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Нет текста для озвучки."))
        }

        // Map provider alias to Puter driver name
        val driverName = when (provider.trim().lowercase()) {
            "aws-polly", "polly" -> "aws-polly"
            "elevenlabs", "eleven" -> "elevenlabs"
            "gemini", "google" -> "gemini"
            "xai", "grok" -> "xai"
            else -> "openai-tts"
        }

        val argsObj = JSONObject().apply {
            put("text", cleanText)
            if (voice.isNotBlank()) put("voice", voice.trim())
            if (driverName == "aws-polly") {
                put("language", "ru-RU")
                put("engine", "neural")
            } else {
                if (model.isNotBlank()) put("model", model.trim())
                put("response_format", "mp3")
            }
        }
        val driverPayload = JSONObject().apply {
            put("interface", "puter-tts")
            put("driver", driverName)
            put("method", "synthesize")
            put("args", argsObj)
        }

        val req1 = Request.Builder()
            .url(driversCallUrl)
            .header("Authorization", "Bearer $cleanToken")
            .header("Content-Type", "application/json")
            .post(driverPayload.toString().toRequestBody(JSON_MEDIA))
            .build()

        val firstRes = executeAudioRequest(req1, outputFile)
        if (firstRes.isSuccess) return@withContext firstRes

        // Fallback to Puter OpenAI-compatible audio/speech endpoint
        val oaiPayload = JSONObject().apply {
            put("model", model.trim().ifBlank { "gpt-4o-mini-tts" })
            put("voice", voice.trim().ifBlank { "nova" })
            put("input", cleanText)
            put("response_format", "mp3")
        }
        val req2 = Request.Builder()
            .url(openAiAudioUrl)
            .header("Authorization", "Bearer $cleanToken")
            .header("Content-Type", "application/json")
            .post(oaiPayload.toString().toRequestBody(JSON_MEDIA))
            .build()

        val secondRes = executeAudioRequest(req2, outputFile)
        if (secondRes.isSuccess) secondRes else firstRes
    }

    private fun executeAudioRequest(req: Request, outputFile: File): Result<File> {
        val call = httpClient.newCall(req)
        activeCall.set(call)
        return try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty()
                    return Result.failure(IllegalStateException(formatPuterHttpError(resp.code, err)))
                }
                val ct = resp.header("Content-Type").orEmpty().lowercase()
                val rawBytes = resp.body?.bytes() ?: ByteArray(0)
                if (rawBytes.isEmpty()) {
                    return Result.failure(IllegalStateException("Puter TTS вернул пустой ответ."))
                }
                if (ct.contains("application/json")) {
                    val jsonStr = String(rawBytes, Charsets.UTF_8)
                    val obj = runCatching { JSONObject(jsonStr) }.getOrNull()
                    if (obj?.optBoolean("success", true) == false) {
                        val msg = obj.optJSONObject("error")?.optString("message")
                            ?: obj.optString("message", "Ошибка Puter TTS")
                        return Result.failure(IllegalStateException("Puter TTS: $msg"))
                    }
                    val resultStr = obj?.optString("result", "").orEmpty()
                    if (resultStr.contains("base64,")) {
                        val decoded = decodeBase64(resultStr.substringAfter("base64,"))
                        if (decoded != null && decoded.size > 64) {
                            outputFile.parentFile?.mkdirs()
                            outputFile.writeBytes(decoded)
                            return Result.success(outputFile)
                        }
                    }
                    return Result.failure(IllegalStateException("Puter TTS: неожиданный JSON-ответ без аудиоданных."))
                }
                outputFile.parentFile?.mkdirs()
                outputFile.writeBytes(rawBytes)
                Result.success(outputFile)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    private fun decodeBase64(b64: String): ByteArray? =
        runCatching { Base64.decode(b64, Base64.DEFAULT) }
            .recoverCatching { java.util.Base64.getDecoder().decode(b64) }
            .getOrNull()

    private fun buildPuterSystemPrompt(config: GenerationConfig): String {
        // For Puter we rely on native OpenAI function-calling `tools`, so disable <tool> XML instructions
        // to save tokens & avoid duplicate tool-calling syntax!
        return LlamaInferenceEngine.buildSystemInstruction(config.copy(agentToolsEnabled = false))
    }

    companion object {
        const val DEFAULT_CHAT_COMPLETIONS_URL = "https://api.puter.com/puterai/openai/v1/chat/completions"
        const val DEFAULT_METERING_USAGE_URL = "https://api.puter.com/metering/usage"
        const val DEFAULT_DRIVERS_CALL_URL = "https://api.puter.com/drivers/call"
        const val DEFAULT_OPENAI_AUDIO_URL = "https://api.puter.com/puterai/openai/v1/audio/speech"
        const val DASHBOARD_ACCOUNT_URL = "https://puter.com/dashboard#account"

        const val DEFAULT_ECON_MODEL = "gpt-5.4-nano"
        const val ALT_ECON_MODEL = "gpt-5-nano"
        const val DEFAULT_SMART_MODEL = "claude-sonnet-5-5"
        const val ALT_SMART_MODEL = "google/gemini-3.1-pro-preview"
        const val DEFAULT_FREE_MODEL = "openrouter:meta-llama/llama-3.3-70b-instruct:free"

        val ECON_PRESETS = listOf(DEFAULT_ECON_MODEL, ALT_ECON_MODEL)
        val SMART_PRESETS = listOf(DEFAULT_SMART_MODEL, ALT_SMART_MODEL)

        const val MAX_PUTER_HISTORY_MESSAGES = 12
        const val MAX_PUTER_TOOL_STEPS = 4
        const val MAX_IMAGE_SIDE_PX = 1024
        const val MAX_IMAGE_BYTES = 3_800_000 // strictly < 4 MB

        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        /**
         * Parses GET https://api.puter.com/metering/usage JSON.
         * Microcents conversion: 1_000_000 microcents = $0.01 -> 100_000_000 = $1.00.
         */
        fun parseMeteringUsageJson(rawJson: String): PuterUsageInfo {
            val root = JSONObject(rawJson)
            val info = root.optJSONObject("allowanceInfo") ?: root
            val remaining = info.optDouble("remaining", 0.0)
            val total = info.optDouble("monthUsageAllowance", 0.0)
            val unit = info.optString("unit", "microcents").ifBlank { "microcents" }

            val pct = if (total > 0.0) {
                ((remaining / total) * 100.0).toInt().coerceIn(0, 100)
            } else 0

            val (remFmt, totFmt) = if (unit.equals("credits", ignoreCase = true)) {
                String.format(Locale.US, "%.2f кред.", remaining) to
                    String.format(Locale.US, "%.0f кред.", total)
            } else {
                // 1_000_000 microcents = $0.01 => divide by 100_000_000 for USD
                val remUsd = remaining / 100_000_000.0
                val totUsd = total / 100_000_000.0
                String.format(Locale.US, "$%.4f", remUsd) to
                    String.format(Locale.US, "$%.2f", totUsd)
            }
            return PuterUsageInfo(
                remainingRaw = remaining,
                monthAllowanceRaw = total,
                unit = unit,
                remainingFormatted = remFmt,
                allowanceFormatted = totFmt,
                percentRemaining = pct
            )
        }

        fun formatPuterHttpError(code: Int, rawBody: String): String {
            val msg = CloudLlmClient.extractErrorMessage(rawBody)
            return when {
                code == 401 ->
                    "Puter (401): неверный или пустой Auth Token. Откройте puter.com/dashboard#account → Create token."
                code == 402 || rawBody.contains("insufficient_funds", ignoreCase = true) ->
                    "Puter (402 insufficient_funds): кончился месячный лимит. Переключитесь на :free модель (например, $DEFAULT_FREE_MODEL) или проверьте баланс в Puter Dashboard."
                code == 429 ->
                    "Puter (429): слишком частые запросы — подождите пару секунд и повторите ($msg)."
                else ->
                    "Puter HTTP $code: $msg"
            }
        }

        /**
         * Compresses a local photo/screenshot to JPEG <= 1024px and strictly < 4 MB,
         * returning a `data:image/jpeg;base64,...` URI for OpenAI vision `image_url`.
         */
        fun compressImageToJpegDataUrl(imagePath: String?): String? {
            if (imagePath.isNullOrBlank()) return null
            val file = File(imagePath)
            if (!file.exists() || !file.isFile || file.length() <= 0L) return null

            // Try Android Bitmap downscale + JPEG compression
            val compressedBytes = runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

                var sampleSize = 1
                val longest = maxOf(bounds.outWidth, bounds.outHeight)
                while (longest / sampleSize > MAX_IMAGE_SIDE_PX * 2) {
                    sampleSize *= 2
                }
                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                val decoded = BitmapFactory.decodeFile(file.absolutePath, decodeOpts) ?: return@runCatching null

                val scale = minOf(
                    1f,
                    MAX_IMAGE_SIDE_PX.toFloat() / maxOf(decoded.width, decoded.height).toFloat()
                )
                val scaled = if (scale < 0.99f) {
                    Bitmap.createScaledBitmap(
                        decoded,
                        (decoded.width * scale).toInt().coerceAtLeast(1),
                        (decoded.height * scale).toInt().coerceAtLeast(1),
                        true
                    ).also { if (it !== decoded) decoded.recycle() }
                } else decoded

                var quality = 85
                var outBytes: ByteArray
                do {
                    val baos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
                    outBytes = baos.toByteArray()
                    quality -= 12
                } while (outBytes.size > MAX_IMAGE_BYTES && quality >= 35)
                scaled.recycle()
                outBytes.takeIf { it.size <= MAX_IMAGE_BYTES }
            }.getOrNull()

            val finalBytes = compressedBytes ?: file.takeIf { it.length() <= MAX_IMAGE_BYTES }?.readBytes()
                ?: return null
            val b64 = runCatching { Base64.encodeToString(finalBytes, Base64.NO_WRAP) }
                .getOrElse { java.util.Base64.getEncoder().encodeToString(finalBytes) }
            return "data:image/jpeg;base64,$b64"
        }

        /** Standard OpenAI JSON schema for Jarvis tools callable via Puter function calling. */
        fun buildOpenAiToolsSchema(): JSONArray = JSONArray().apply {
            put(fnTool("get_current_datetime", "Возвращает текущие дату и время устройства."))
            put(
                fnTool(
                    "save_note",
                    "Сохраняет короткую заметку или факт в локальную память помощника.",
                    mapOf("key" to "Короткое название заметки", "content" to "Текст заметки"),
                    listOf("key", "content")
                )
            )
            put(
                fnTool(
                    "get_notes",
                    "Читает сохранённые заметки пользователя (можно указать поисковый фильтр).",
                    mapOf("query" to "Необязательный фильтр поиска")
                )
            )
            put(
                fnTool(
                    "delete_note",
                    "Удаляет заметку по названию (key).",
                    mapOf("key" to "Название заметки"),
                    listOf("key")
                )
            )
            put(
                fnTool(
                    "set_timer",
                    "Ставит таймер на Android-устройстве.",
                    mapOf("seconds" to "Длительность в секундах (целое число)", "message" to "Подпись таймера"),
                    listOf("seconds")
                )
            )
            put(
                fnTool(
                    "set_alarm",
                    "Ставит будильник на Android-устройстве.",
                    mapOf("hour" to "Час (0..23)", "minute" to "Минута (0..59)", "message" to "Подпись будильника"),
                    listOf("hour", "minute")
                )
            )
            put(
                fnTool(
                    "open_app",
                    "Открывает установленное Android-приложение (например Telegram, YouTube, Настройки).",
                    mapOf("app" to "Название или packageName приложения"),
                    listOf("app")
                )
            )
            put(
                fnTool(
                    "open_url",
                    "Открывает веб-ссылку или deep-link (https://..., tg://..., tel:...).",
                    mapOf("url" to "URL для открытия"),
                    listOf("url")
                )
            )
            put(
                fnTool(
                    "open_search",
                    "Открывает веб-поиск по запросу в браузере.",
                    mapOf("query" to "Поисковый запрос"),
                    listOf("query")
                )
            )
            put(fnTool("get_device_info", "Возвращает время, заряд батареи, статус сети и спецвозможностей."))
        }

        private fun fnTool(
            name: String,
            description: String,
            props: Map<String, String> = emptyMap(),
            required: List<String> = emptyList()
        ): JSONObject = JSONObject().apply {
            put("type", "function")
            put(
                "function",
                JSONObject().apply {
                    put("name", name)
                    put("description", description)
                    put(
                        "parameters",
                        JSONObject().apply {
                            put("type", "object")
                            val propsObj = JSONObject()
                            for ((k, desc) in props) {
                                propsObj.put(k, JSONObject().put("type", "string").put("description", desc))
                            }
                            put("properties", propsObj)
                            if (required.isNotEmpty()) put("required", JSONArray(required))
                        }
                    )
                }
            )
        }
    }
}
