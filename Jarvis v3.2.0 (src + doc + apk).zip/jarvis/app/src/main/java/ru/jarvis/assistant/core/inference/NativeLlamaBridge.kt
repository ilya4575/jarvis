package ru.jarvis.assistant.core.inference

fun interface NativeTokenCallback {
    /** Return true to continue generation, false to abort. */
    fun onToken(piece: String): Boolean
}

/**
 * Low-level JNI bridge to libjarvis_llama.so (llama.cpp v1.0.0 + libmtmd).
 * Gracefully reports unavailability if running on JVM tests or unsupported ABI.
 */
object NativeLlamaBridge {
    @Volatile
    var isLibraryLoaded: Boolean = false
        private set

    @Volatile
    var loadError: String? = null
        private set

    init {
        try {
            System.loadLibrary("jarvis_llama")
            nativeInitBackend()
            isLibraryLoaded = true
        } catch (t: Throwable) {
            isLibraryLoaded = false
            loadError = t.message ?: t.javaClass.simpleName
        }
    }

    external fun nativeInitBackend()

    external fun nativeGetLastError(handlePtr: Long): String

    external fun nativeLoadModel(
        modelPath: String,
        mmprojPath: String?,
        nCtx: Int,
        nThreads: Int
    ): Long

    external fun nativeSupportsVision(handlePtr: Long): Boolean

    external fun nativeDefaultMediaMarker(): String

    external fun nativeCancel(handlePtr: Long)

    external fun nativeFreeModel(handlePtr: Long)

    external fun nativeGenerate(
        handlePtr: Long,
        prompt: String,
        imagePath: String?,
        maxTokens: Int,
        temperature: Float,
        callback: NativeTokenCallback
    ): Int
}
