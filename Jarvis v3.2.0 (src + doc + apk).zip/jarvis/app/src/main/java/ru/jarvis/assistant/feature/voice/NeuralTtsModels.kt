package ru.jarvis.assistant.feature.voice

enum class TtsEngineMode(val labelRu: String, val subtitleRu: String) {
    EDGE_NEURAL(
        "Нейро-голос (бесплатно, без ключа)",
        "Живые русские нейроголоса Microsoft Neural (включая стиль Куруми) — работает без ключей"
    ),
    SYSTEM_ANDROID(
        "Локальный TTS Android (бесплатно)",
        "Встроенный синтезатор телефона: локально, без API и интернета (качество зависит от установленного русского голоса)"
    ),
    GROK_TTS(
        "Grok TTS (xAI API)",
        "Естественная многоязычная озвучка Grok через ваш xAI API-ключ; голос можно выбрать в настройках API"
    ),
    PUTER_TTS(
        "Puter AI TTS (OpenAI / Polly / ElevenLabs / Gemini)",
        "Озвучка через ваш Puter Auth Token (провайдеры openai, aws-polly, elevenlabs, gemini, xai)"
    ),
    CUSTOM_CLONE_URL(
        "Кастомный TTS / Cloning сервер (URL + ключ + голос)",
        "Любой свой TTS-сервер: OpenAI /v1/audio/speech, Piper, Kokoro, XTTS-v2, F5-TTS, Chatterbox"
    ),
    FISH_AUDIO_CLONE(
        "Fish Audio — клон голоса (ID или свой MP3)",
        "Реальный голос Куруми Токисаки: по готовому reference_id из базы Fish Audio или по вашему 10–15 сек MP3/WAV-сэмплу"
    ),
    ELEVENLABS_CLONE(
        "ElevenLabs — клон голоса (voice_id)",
        "Студийное клонирование голоса ElevenLabs Multilingual v2 по вашему voice_id"
    ),
    GEMINI_NATIVE(
        "Gemini Neural TTS (по ключу Gemini)",
        "Студийные голоса Google Gemini 2.5 Flash TTS с откатом на бесплатный нейро-голос"
    ),
    CUSTOM_OPENAI(
        "Кастомный OpenAI API TTS (/audio/speech)",
        "Озвучка через активный Custom API-провайдер из раздела провайдеров"
    )
}

enum class NeuralVoicePreset(
    val id: String,
    val titleRu: String,
    val descriptionRu: String,
    val genderRu: String,
    val edgeVoiceFullName: String,
    val edgeLang: String,
    val defaultPitchHz: Int,
    val defaultRatePct: Int,
    val geminiVoiceName: String,
    val openAiVoiceName: String
) {
    KURUMI_STYLE(
        id = "kurumi_style",
        titleRu = "Куруми (стиль Токисаки)",
        descriptionRu = "Бархатистый, игривый и загадочный женский голос (или ваш клон выше)",
        genderRu = "Женский",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (ru-RU, SvetlanaNeural)",
        edgeLang = "ru-RU",
        defaultPitchHz = 9,
        defaultRatePct = -2,
        geminiVoiceName = "Leda",
        openAiVoiceName = "shimmer"
    ),
    SVETLANA(
        id = "svetlana",
        titleRu = "Светлана",
        descriptionRu = "Чистый, естественный женский русский голос",
        genderRu = "Женский",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (ru-RU, SvetlanaNeural)",
        edgeLang = "ru-RU",
        defaultPitchHz = 0,
        defaultRatePct = 0,
        geminiVoiceName = "Aoede",
        openAiVoiceName = "nova"
    ),
    NYASHKA_SOFT(
        id = "nyashka_soft",
        titleRu = "Няшка (мягкий)",
        descriptionRu = "Лёгкий, нежный и живой молодой женский голос",
        genderRu = "Женский",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (ru-RU, SvetlanaNeural)",
        edgeLang = "ru-RU",
        defaultPitchHz = 14,
        defaultRatePct = 4,
        geminiVoiceName = "Leda",
        openAiVoiceName = "shimmer"
    ),
    AVA_HD(
        id = "ava_hd",
        titleRu = "Ава HD",
        descriptionRu = "Очень живой и выразительный дикторский голос",
        genderRu = "Женский",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (en-US, AvaMultilingualNeural)",
        edgeLang = "en-US",
        defaultPitchHz = 0,
        defaultRatePct = 0,
        geminiVoiceName = "Kore",
        openAiVoiceName = "coral"
    ),
    EMMA_HD(
        id = "emma_hd",
        titleRu = "Эмма HD",
        descriptionRu = "Тёплый, плавный и дружелюбный женский голос",
        genderRu = "Женский",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (en-US, EmmaMultilingualNeural)",
        edgeLang = "en-US",
        defaultPitchHz = 0,
        defaultRatePct = 0,
        geminiVoiceName = "Aoede",
        openAiVoiceName = "sage"
    ),
    DMITRY(
        id = "dmitry",
        titleRu = "Дмитрий",
        descriptionRu = "Чёткий, уверенный мужской русский голос (для Jarvis)",
        genderRu = "Мужской",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (ru-RU, DmitryNeural)",
        edgeLang = "ru-RU",
        defaultPitchHz = 0,
        defaultRatePct = 0,
        geminiVoiceName = "Charon",
        openAiVoiceName = "onyx"
    ),
    ANDREW_HD(
        id = "andrew_hd",
        titleRu = "Эндрю HD",
        descriptionRu = "Спокойный, мягкий мужской нейроголос",
        genderRu = "Мужской",
        edgeVoiceFullName = "Microsoft Server Speech Text to Speech Voice (en-US, AndrewMultilingualNeural)",
        edgeLang = "en-US",
        defaultPitchHz = 0,
        defaultRatePct = 0,
        geminiVoiceName = "Puck",
        openAiVoiceName = "echo"
    );

    companion object {
        fun fromId(raw: String?): NeuralVoicePreset =
            entries.firstOrNull { it.id == raw || it.name == raw } ?: SVETLANA
    }
}
