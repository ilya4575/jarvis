package ru.jarvis.assistant.core.models

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

enum class DownloadPhase {
    IDLE,
    DOWNLOADING,
    VERIFYING_SHA256,
    EXTRACTING,
    COMPLETED,
    CANCELLED,
    ERROR
}

data class DownloadState(
    val phase: DownloadPhase = DownloadPhase.IDLE,
    val activeArtifactId: String? = null,
    val activeArtifactName: String? = null,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val batchIndex: Int = 0,
    val batchTotal: Int = 0,
    val messageRu: String = ""
) {
    val progressPercent: Int
        get() = if (totalBytes > 0L) {
            ((downloadedBytes.coerceAtMost(totalBytes) * 100L) / totalBytes).toInt()
        } else 0
}

sealed class DownloadOutcome {
    data object Success : DownloadOutcome()
    data object Cancelled : DownloadOutcome()
    data class Failure(val reasonRu: String) : DownloadOutcome()
}

data class EndpointCheckResult(
    val artifactId: String,
    val displayName: String,
    val reachable: Boolean,
    val contentLength: Long?,
    val statusNoteRu: String
)

/**
 * Handles explicit user-initiated model downloads with HTTP Range resume, cancellation,
 * free-space checks, mandatory SHA-256 verification, and safe zip extraction.
 * Makes zero background/hidden network requests.
 */
class ModelDownloadManager(
    private val storage: ModelStorage,
    private val httpClient: OkHttpClient = defaultClient()
) {
    private val _state = MutableStateFlow(DownloadState())
    val state: StateFlow<DownloadState> = _state.asStateFlow()

    private val cancelled = AtomicBoolean(false)
    private val activeCall = AtomicReference<Call?>(null)

    fun cancelActiveDownload() {
        cancelled.set(true)
        activeCall.getAndSet(null)?.cancel()
    }

    fun resetState() {
        _state.value = DownloadState()
    }

    suspend fun downloadBatch(artifacts: List<ModelArtifact>): DownloadOutcome = withContext(Dispatchers.IO) {
        cancelled.set(false)
        val pending = artifacts.filter { storage.inspectQuickStatus(it) != LocalArtifactStatus.INSTALLED_VERIFIED }
        if (pending.isEmpty()) {
            _state.value = DownloadState(
                phase = DownloadPhase.COMPLETED,
                messageRu = "Все выбранные модели уже загружены и проверены."
            )
            return@withContext DownloadOutcome.Success
        }

        // Verify enough free disk space (models + 150 MiB safety headroom for zip unpack)
        val neededBytes = pending.sumOf { artifact ->
            val partLen = storage.partFileFor(artifact).takeIf { it.exists() }?.length() ?: 0L
            val extra = if (artifact.isZipArchive) artifact.sizeBytes * 2L else artifact.sizeBytes
            (extra - partLen).coerceAtLeast(0L)
        } + 150L * 1024L * 1024L

        val avail = storage.availableSpaceBytes()
        if (avail < neededBytes) {
            val msg = "Недостаточно памяти: требуется ~${ModelCatalog.formatBytes(neededBytes)}, " +
                "доступно ${ModelCatalog.formatBytes(avail)}."
            _state.value = DownloadState(phase = DownloadPhase.ERROR, messageRu = msg)
            return@withContext DownloadOutcome.Failure(msg)
        }

        for ((idx, artifact) in pending.withIndex()) {
            if (cancelled.get()) {
                _state.value = DownloadState(
                    phase = DownloadPhase.CANCELLED,
                    messageRu = "Загрузка отменена пользователем."
                )
                return@withContext DownloadOutcome.Cancelled
            }
            val res = downloadSingleInternal(artifact, idx + 1, pending.size)
            if (res !is DownloadOutcome.Success) {
                return@withContext res
            }
        }

        _state.value = DownloadState(
            phase = DownloadPhase.COMPLETED,
            batchIndex = pending.size,
            batchTotal = pending.size,
            messageRu = "Все модели успешно загружены и прошли проверку SHA-256."
        )
        DownloadOutcome.Success
    }

    suspend fun downloadSingle(artifact: ModelArtifact): DownloadOutcome = downloadBatch(listOf(artifact))

    private suspend fun downloadSingleInternal(
        artifact: ModelArtifact,
        batchIndex: Int,
        batchTotal: Int
    ): DownloadOutcome = withContext(Dispatchers.IO) {
        val partFile = storage.partFileFor(artifact)
        val finalFile = storage.finalFileFor(artifact)

        var existingBytes = if (partFile.exists()) partFile.length() else 0L
        if (existingBytes > artifact.sizeBytes) {
            partFile.delete()
            existingBytes = 0L
        }

        val reqBuilder = Request.Builder()
            .url(artifact.downloadUrl)
            .header("User-Agent", "Jarvis-Android-Local-Assistant/1.0")
        if (existingBytes > 0L) {
            reqBuilder.header("Range", "bytes=$existingBytes-")
        }

        val call = httpClient.newCall(reqBuilder.build())
        activeCall.set(call)

        try {
            _state.value = DownloadState(
                phase = DownloadPhase.DOWNLOADING,
                activeArtifactId = artifact.id,
                activeArtifactName = artifact.displayName,
                downloadedBytes = existingBytes,
                totalBytes = artifact.sizeBytes,
                batchIndex = batchIndex,
                batchTotal = batchTotal,
                messageRu = "Подключение к источнику (${artifact.displayName})…"
            )

            call.execute().use { response ->
                if (cancelled.get()) {
                    _state.value = DownloadState(phase = DownloadPhase.CANCELLED, messageRu = "Загрузка отменена.")
                    return@withContext DownloadOutcome.Cancelled
                }

                // Handle 416 Range Not Satisfiable (file might already be complete in .part)
                val appendMode: Boolean
                var bytesWritten: Long
                val skipStream = response.code == 416 && existingBytes == artifact.sizeBytes

                if (!skipStream) {
                    if (response.code == 206 && existingBytes > 0L) {
                        appendMode = true
                        bytesWritten = existingBytes
                    } else if (response.isSuccessful) {
                        appendMode = false
                        bytesWritten = 0L
                    } else {
                        val msg = "Ошибка сервера HTTP ${response.code} при скачивании ${artifact.displayName}"
                        _state.value = DownloadState(phase = DownloadPhase.ERROR, messageRu = msg)
                        return@withContext DownloadOutcome.Failure(msg)
                    }

                    val body = response.body ?: run {
                        val msg = "Пустой ответ от сервера для ${artifact.displayName}"
                        _state.value = DownloadState(phase = DownloadPhase.ERROR, messageRu = msg)
                        return@withContext DownloadOutcome.Failure(msg)
                    }

                    val expectedTotal = if (appendMode) {
                        val rem = body.contentLength()
                        if (rem > 0) existingBytes + rem else artifact.sizeBytes
                    } else {
                        val cl = body.contentLength()
                        if (cl > 0) cl else artifact.sizeBytes
                    }

                    body.byteStream().use { input ->
                        FileOutputStream(partFile, appendMode).use { fos ->
                            val buf = ByteArray(64 * 1024)
                            var lastEmitMs = 0L
                            while (true) {
                                if (cancelled.get()) {
                                    _state.value = DownloadState(
                                        phase = DownloadPhase.CANCELLED,
                                        activeArtifactId = artifact.id,
                                        activeArtifactName = artifact.displayName,
                                        downloadedBytes = bytesWritten,
                                        totalBytes = expectedTotal,
                                        messageRu = "Загрузка приостановлена — частичный файл сохранён для докачки."
                                    )
                                    return@withContext DownloadOutcome.Cancelled
                                }
                                val read = input.read(buf)
                                if (read <= 0) break
                                fos.write(buf, 0, read)
                                bytesWritten += read
                                val now = System.currentTimeMillis()
                                if (now - lastEmitMs >= 150L) {
                                    lastEmitMs = now
                                    _state.value = DownloadState(
                                        phase = DownloadPhase.DOWNLOADING,
                                        activeArtifactId = artifact.id,
                                        activeArtifactName = artifact.displayName,
                                        downloadedBytes = bytesWritten,
                                        totalBytes = expectedTotal,
                                        batchIndex = batchIndex,
                                        batchTotal = batchTotal,
                                        messageRu = "Скачивание ${artifact.displayName}: ${ModelCatalog.formatBytes(bytesWritten)} / ${ModelCatalog.formatBytes(expectedTotal)}"
                                    )
                                }
                            }
                            fos.flush()
                        }
                    }
                }
            }

            if (cancelled.get()) {
                _state.value = DownloadState(phase = DownloadPhase.CANCELLED, messageRu = "Загрузка отменена.")
                return@withContext DownloadOutcome.Cancelled
            }

            // Mandatory SHA-256 verification before promoting or extracting
            _state.value = DownloadState(
                phase = DownloadPhase.VERIFYING_SHA256,
                activeArtifactId = artifact.id,
                activeArtifactName = artifact.displayName,
                downloadedBytes = artifact.sizeBytes,
                totalBytes = artifact.sizeBytes,
                batchIndex = batchIndex,
                batchTotal = batchTotal,
                messageRu = "Проверка контрольной суммы SHA-256 (${artifact.displayName})…"
            )

            val check = Sha256Verifier.verifyFile(partFile, artifact.sha256)
            if (!check.matches) {
                partFile.delete()
                storage.verifiedMarkerFor(artifact).delete()
                val msg = "Несовпадение SHA-256 для ${artifact.displayName}! " +
                    "Файл удалён ради безопасности. Ожидалось: ${check.expectedSha256.take(12)}…, " +
                    "получено: ${check.actualSha256?.take(12) ?: "ошибка"}."
                _state.value = DownloadState(phase = DownloadPhase.ERROR, messageRu = msg)
                return@withContext DownloadOutcome.Failure(msg)
            }

            if (artifact.isZipArchive) {
                _state.value = DownloadState(
                    phase = DownloadPhase.EXTRACTING,
                    activeArtifactId = artifact.id,
                    activeArtifactName = artifact.displayName,
                    downloadedBytes = artifact.sizeBytes,
                    totalBytes = artifact.sizeBytes,
                    batchIndex = batchIndex,
                    batchTotal = batchTotal,
                    messageRu = "Распаковка офлайн-модели речи (${artifact.displayName})…"
                )
                storage.extractedDirFor(artifact)?.deleteRecursively()
                storage.extractZipSafely(partFile, storage.rootDir())
                partFile.delete()
                storage.writeVerifiedMarker(artifact)
            } else {
                if (finalFile.exists()) finalFile.delete()
                if (!partFile.renameTo(finalFile)) {
                    partFile.copyTo(finalFile, overwrite = true)
                    partFile.delete()
                }
                storage.writeVerifiedMarker(artifact)
            }

            DownloadOutcome.Success
        } catch (ce: CancellationException) {
            _state.value = DownloadState(phase = DownloadPhase.CANCELLED, messageRu = "Загрузка отменена.")
            DownloadOutcome.Cancelled
        } catch (e: IOException) {
            if (cancelled.get()) {
                _state.value = DownloadState(
                    phase = DownloadPhase.CANCELLED,
                    messageRu = "Загрузка отменена (можно продолжить докачку позже)."
                )
                DownloadOutcome.Cancelled
            } else {
                val msg = "Сетевой обрыв при загрузке ${artifact.displayName}: ${e.message ?: "нет связи"}. " +
                    "Нажмите «Повторить» — файл докачается с места обрыва."
                _state.value = DownloadState(phase = DownloadPhase.ERROR, messageRu = msg)
                DownloadOutcome.Failure(msg)
            }
        } catch (e: Exception) {
            val msg = "Ошибка установки ${artifact.displayName}: ${e.message ?: e.javaClass.simpleName}"
            _state.value = DownloadState(phase = DownloadPhase.ERROR, messageRu = msg)
            DownloadOutcome.Failure(msg)
        } finally {
            activeCall.set(null)
        }
    }

    /** Explicit user-triggered availability check via HTTP HEAD (zero background calls). */
    suspend fun checkSourcesAvailability(artifacts: List<ModelArtifact>): List<EndpointCheckResult> =
        withContext(Dispatchers.IO) {
            artifacts.map { artifact ->
                try {
                    val req = Request.Builder()
                        .url(artifact.downloadUrl)
                        .head()
                        .header("User-Agent", "Jarvis-Android-Local-Assistant/1.0")
                        .build()
                    httpClient.newCall(req).execute().use { resp ->
                        val len = resp.header("Content-Length")?.toLongOrNull()
                        val ok = resp.isSuccessful
                        val sizeMatch = len == null || len == artifact.sizeBytes
                        EndpointCheckResult(
                            artifactId = artifact.id,
                            displayName = artifact.displayName,
                            reachable = ok && sizeMatch,
                            contentLength = len,
                            statusNoteRu = when {
                                !ok -> "HTTP ${resp.code}"
                                !sizeMatch -> "Размер изменился (${len} != ${artifact.sizeBytes})"
                                else -> "Доступен, ревизия закреплена (${ModelCatalog.formatBytes(artifact.sizeBytes)})"
                            }
                        )
                    }
                } catch (e: Exception) {
                    EndpointCheckResult(
                        artifactId = artifact.id,
                        displayName = artifact.displayName,
                        reachable = false,
                        contentLength = null,
                        statusNoteRu = "Недоступен: ${e.message ?: "нет сети"}"
                    )
                }
            }
        }

    companion object {
        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}
