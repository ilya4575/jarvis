package ru.jarvis.assistant.ui.island

import android.app.Dialog
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.feature.overlay.IslandAppEntry
import ru.jarvis.assistant.feature.overlay.IslandNotifFilterPolicy
import java.util.concurrent.ConcurrentHashMap

/**
 * Full-height selector dialog for per-app Dynamic Island notification filtering.
 * Displays each installed app with:
 * - Left: 40dp app icon
 * - Center: bold app name + monospace package name underneath
 * - Right: toggle switch (all enabled by default; turning off adds package to blacklist)
 */
object IslandNotifAppFilterDialog {

    fun show(
        context: Context,
        lifecycleOwner: LifecycleOwner,
        onDismissed: () -> Unit = {}
    ) {
        val prefs = JarvisApplication.instance.prefs
        val dialog = Dialog(context, android.R.style.Theme_Material_NoActionBar)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_island_app_filter, null)
        dialog.setContentView(view)
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)

        val counterTv = view.findViewById<TextView>(R.id.app_filter_counter)
        val closeBtn = view.findViewById<MaterialButton>(R.id.app_filter_close_btn)
        val searchEdit = view.findViewById<EditText>(R.id.app_filter_search)
        val systemSwitch = view.findViewById<SwitchMaterial>(R.id.app_filter_system_switch)
        val enableAllBtn = view.findViewById<MaterialButton>(R.id.app_filter_enable_all_btn)
        val disableAllBtn = view.findViewById<MaterialButton>(R.id.app_filter_disable_all_btn)
        val recycler = view.findViewById<RecyclerView>(R.id.app_filter_recycler)
        val progress = view.findViewById<ProgressBar>(R.id.app_filter_progress)
        val emptyTv = view.findViewById<TextView>(R.id.app_filter_empty)

        val pm = context.packageManager
        val iconCache = ConcurrentHashMap<String, Drawable>()
        var allApps: List<IslandAppEntry> = emptyList()
        var displayedApps: List<IslandAppEntry> = emptyList()
        val blockedSet = prefs.islandBlockedNotifPackages.toMutableSet()

        fun refreshCounter() {
            val totalVisible = displayedApps.size
            val enabledVisible = displayedApps.count { it.packageName !in blockedSet }
            counterTv.text = "Включено: $enabledVisible из $totalVisible • всего скрыто: ${blockedSet.size}"
        }

        val adapter = AppFilterAdapter(
            pm = pm,
            iconCache = iconCache,
            isEnabledProvider = { pkg -> pkg !in blockedSet },
            onToggle = { pkg, enabled ->
                if (enabled) blockedSet.remove(pkg) else blockedSet.add(pkg)
                prefs.setAppAllowedInIslandNotifications(pkg, enabled)
                refreshCounter()
            }
        )

        recycler.layoutManager = LinearLayoutManager(context)
        recycler.adapter = adapter

        fun applyFilter() {
            val query = searchEdit.text?.toString().orEmpty()
            val showSys = systemSwitch.isChecked
            displayedApps = IslandNotifFilterPolicy.filterApps(allApps, query, showSys)
            adapter.submit(displayedApps)
            emptyTv.visibility = if (displayedApps.isEmpty() && allApps.isNotEmpty()) View.VISIBLE else View.GONE
            refreshCounter()
        }

        searchEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { applyFilter() }
            override fun afterTextChanged(s: Editable?) {}
        })

        systemSwitch.setOnCheckedChangeListener { _, _ -> applyFilter() }

        enableAllBtn.setOnClickListener {
            if (displayedApps.isEmpty()) return@setOnClickListener
            for (app in displayedApps) blockedSet.remove(app.packageName)
            prefs.islandBlockedNotifPackages = blockedSet.toSet()
            adapter.notifyDataSetChanged()
            refreshCounter()
            Toast.makeText(context, "Включено для списка (${displayedApps.size})", Toast.LENGTH_SHORT).show()
        }

        disableAllBtn.setOnClickListener {
            if (displayedApps.isEmpty()) return@setOnClickListener
            for (app in displayedApps) blockedSet.add(app.packageName)
            prefs.islandBlockedNotifPackages = blockedSet.toSet()
            adapter.notifyDataSetChanged()
            refreshCounter()
            Toast.makeText(context, "Отключено для списка (${displayedApps.size})", Toast.LENGTH_SHORT).show()
        }

        closeBtn.setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener { onDismissed() }

        dialog.show()

        lifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            val ownPkg = context.packageName
            val installed = runCatching { pm.getInstalledApplications(PackageManager.GET_META_DATA) }
                .getOrDefault(emptyList())
                .filter { it.packageName != ownPkg }
                .map { ai ->
                    val label = runCatching { pm.getApplicationLabel(ai).toString().trim() }
                        .getOrDefault(ai.packageName)
                        .ifBlank { ai.packageName }
                    val hasLauncher = pm.getLaunchIntentForPackage(ai.packageName) != null
                    val isFlagSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val isUpdatedSystem = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                    // Treat non-launchable pure system packages as "system apps", while user-visible preinstalled
                    // apps with launcher icons (Chrome, YouTube, Gmail, etc.) show up right away!
                    val isHiddenSystem = isFlagSystem && !isUpdatedSystem && !hasLauncher
                    IslandAppEntry(
                        packageName = ai.packageName,
                        appLabel = label,
                        isSystemApp = isHiddenSystem
                    )
                }

            withContext(Dispatchers.Main) {
                if (!dialog.isShowing) return@withContext
                allApps = installed
                progress.visibility = View.GONE
                applyFilter()
            }
        }
    }

    private class AppFilterAdapter(
        private val pm: PackageManager,
        private val iconCache: ConcurrentHashMap<String, Drawable>,
        private val isEnabledProvider: (String) -> Boolean,
        private val onToggle: (packageName: String, enabled: Boolean) -> Unit
    ) : RecyclerView.Adapter<AppFilterAdapter.VH>() {

        private var items: List<IslandAppEntry> = emptyList()

        fun submit(newItems: List<IslandAppEntry>) {
            items = newItems
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_island_app_filter, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val entry = items[position]
            holder.nameTv.text = entry.appLabel
            holder.pkgTv.text = entry.packageName

            val cached = iconCache[entry.packageName]
            if (cached != null) {
                holder.iconIv.setImageDrawable(cached)
            } else {
                val loaded = runCatching { pm.getApplicationIcon(entry.packageName) }.getOrNull()
                if (loaded != null) {
                    iconCache[entry.packageName] = loaded
                    holder.iconIv.setImageDrawable(loaded)
                } else {
                    holder.iconIv.setImageResource(R.drawable.ic_jarvis_launcher)
                }
            }

            holder.toggle.setOnCheckedChangeListener(null)
            holder.toggle.isChecked = isEnabledProvider(entry.packageName)
            holder.toggle.setOnCheckedChangeListener { _, isChecked ->
                onToggle(entry.packageName, isChecked)
            }
            holder.itemView.setOnClickListener {
                holder.toggle.isChecked = !holder.toggle.isChecked
            }
        }

        override fun getItemCount(): Int = items.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val iconIv: ImageView = v.findViewById(R.id.app_filter_icon)
            val nameTv: TextView = v.findViewById(R.id.app_filter_name)
            val pkgTv: TextView = v.findViewById(R.id.app_filter_package)
            val toggle: SwitchMaterial = v.findViewById(R.id.app_filter_switch)
        }
    }
}
