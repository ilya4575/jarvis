package ru.jarvis.assistant.feature.avatar

import ru.jarvis.assistant.core.models.ModelCatalog

data class VideoAvatarMetadata(
    val mimeType: String?,
    val fileName: String?,
    val sizeBytes: Long,
    val durationMs: Long,
    val hasVideoTrack: Boolean
)

sealed class VideoAvatarValidationResult {
    data class Valid(val warningRu: String? = null) : VideoAvatarValidationResult()
    data class Invalid(val reasonRu: String) : VideoAvatarValidationResult()
}

/**
 * Validates user-selected MP4 video avatar before accepting or playing it in Dynamic Island.
 * Enforces user-specified bounds (MP4, <= 30 s, <= 100 MB) without transcoding the original file,
 * while warning about possible overlay stutter if file size exceeds 15 MB.
 */
object VideoAvatarValidator {
    const val MAX_DURATION_MS: Long = 30_000L
    const val MAX_SIZE_BYTES: Long = 100L * 1024L * 1024L // 100 MiB
    const val RECOMMENDED_SMOOTH_BYTES: Long = 15L * 1024L * 1024L // 15 MiB

    fun validate(meta: VideoAvatarMetadata): VideoAvatarValidationResult {
        val isMp4Mime = meta.mimeType.equals("video/mp4", ignoreCase = true)
        val isMp4Name = meta.fileName?.lowercase()?.endsWith(".mp4") == true
        if (!isMp4Mime && !isMp4Name) {
            return VideoAvatarValidationResult.Invalid(
                "Поддерживается только формат MP4 (получен: ${meta.mimeType ?: meta.fileName ?: "неизвестный формат"})."
            )
        }

        if (!meta.hasVideoTrack) {
            return VideoAvatarValidationResult.Invalid("В выбранном файле не найдена видеодорожка.")
        }

        if (meta.sizeBytes <= 0L) {
            return VideoAvatarValidationResult.Invalid("Выбранный видеофайл пуст или недоступен.")
        }

        if (meta.sizeBytes > MAX_SIZE_BYTES) {
            return VideoAvatarValidationResult.Invalid(
                "Размер видео (${ModelCatalog.formatBytes(meta.sizeBytes)}) превышает лимит 100 МиБ."
            )
        }

        if (meta.durationMs <= 0L) {
            return VideoAvatarValidationResult.Invalid("Не удалось определить длительность видео.")
        }

        if (meta.durationMs > MAX_DURATION_MS) {
            val sec = meta.durationMs / 1000.0
            return VideoAvatarValidationResult.Invalid(
                String.format(
                    java.util.Locale.US,
                    "Длительность видео (%.1f с) превышает допустимые 30 секунд.",
                    sec
                )
            )
        }

        val warning = if (meta.sizeBytes > RECOMMENDED_SMOOTH_BYTES) {
            "Внимание: видео весит ${ModelCatalog.formatBytes(meta.sizeBytes)} — оригинал сохранён без перекодирования, " +
                "но в компактном островке возможны задержки и повышенный расход ОЗУ. " +
                "Для максимальной плавности на старых телефонах рекомендуется ролик до 10–15 МиБ (480p–720p, 3–10 с)."
        } else null

        return VideoAvatarValidationResult.Valid(warningRu = warning)
    }
}
