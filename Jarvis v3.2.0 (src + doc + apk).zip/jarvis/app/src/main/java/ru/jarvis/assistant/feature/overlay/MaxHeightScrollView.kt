package ru.jarvis.assistant.feature.overlay

import android.content.Context
import android.util.AttributeSet
import android.widget.ScrollView
import kotlin.math.roundToInt

/**
 * ScrollView that enforces a hard vertical cap so the expanded Dynamic Island answer card
 * always leaves comfortable space for the input bar above the soft keyboard.
 */
class MaxHeightScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ScrollView(context, attrs, defStyleAttr) {

    var maxHeightPx: Int = (200f * context.resources.displayMetrics.density).roundToInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val screenCap = (context.resources.displayMetrics.heightPixels * 0.30f).roundToInt()
        val effectiveCap = minOf(maxHeightPx, screenCap).coerceAtLeast(120)
        val cappedSpec = MeasureSpec.makeMeasureSpec(effectiveCap, MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, cappedSpec)
    }
}
