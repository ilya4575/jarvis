package ru.jarvis.assistant.core.chat

import ru.jarvis.assistant.core.cloud.ImageQualityMode

/**
 * Result of parsing an explicit slash-command like `/фото кот в космосе` or `/photo hd portrait fox`.
 */
data class SlashPhotoCommand(
    val prompt: String,
    val qualityOverride: ImageQualityMode? = null,
    val resolutionOverride: String? = null,
    val useChatContextIfBlank: Boolean = false
)

/**
 * Result of analyzing natural language user text for an image/selfie/photo request.
 */
data class NaturalPhotoIntent(
    val isPhotoRequest: Boolean,
    val isSelfieOrSelf: Boolean = false,
    val extractedSubject: String = ""
)

/**
 * Result of extracting a model-emitted `[GEN_IMAGE: ...]` tag from assistant text.
 */
data class ExtractedAiPhotoTag(
    val visibleText: String,
    val imagePrompt: String?
)

/**
 * Pure-Kotlin detector & parser for:
 * 1) Explicit slash commands (`/фото`, `/photo`, `/картинка`, `/нарисуй`, `/img`, `/image`)
 * 2) AI-emitted photo trigger tags (`[GEN_IMAGE: ...]`, `<gen_image>...</gen_image>`, etc.)
 * 3) Natural user requests ("сделай фотку себя", "скинь селфи", "нарисуй...", "покажи как ты выглядишь")
 *    used both to nudge the LLM and as an automatic safety fallback if a small model forgets the tag.
 */
object ImageIntentDetector {

    private val SLASH_COMMAND_REGEX = Regex(
        """^/(фото|фотку|фотка|photo|img|image|картинка|картинку|нарисуй|рисунок|pic|art)(?:\s+([\s\S]*))?$""",
        RegexOption.IGNORE_CASE
    )

    private val COMPLETED_AI_TAG_REGEX = Regex(
        """(?:\[{1,2}\s*(?:GEN_IMAGE|GENERATE_IMAGE|SEND_PHOTO|MAKE_PHOTO|PHOTO|IMAGE)\s*:\s*([\s\S]*?)\]{1,2}|<\s*(?:gen_image|image|photo)\s*>([\s\S]*?)<\s*/\s*(?:gen_image|image|photo)\s*>)""",
        RegexOption.IGNORE_CASE
    )

    private val PARTIAL_AI_TAG_REGEX = Regex(
        """(?:\[{1,2}\s*(?:GEN_IMAGE|GENERATE_IMAGE|SEND_PHOTO|MAKE_PHOTO|PHOTO|IMAGE)\s*:[\s\S]*$|<\s*(?:gen_image|image|photo)\s*>[\s\S]*$)""",
        RegexOption.IGNORE_CASE
    )

    // Android ART (ICU) & JVM portable Unicode word boundary helpers (avoids JVM-only `(?U)` flag)
    private const val WB = """(?<![\p{L}\p{N}_])"""
    private const val WE = """(?![\p{L}\p{N}_])"""

    private val NEGATIVE_OR_NON_GEN_PATTERNS = listOf(
        Regex("""$WB(не\s+делай|не\s+скидывай|не\s+отправляй|не\s+рисуй|не\s+генерируй|без\s+фото|без\s+фот|без\s+картин)$WE""", RegexOption.IGNORE_CASE),
        Regex("""$WB(удали|удалить|сотри|убери|открой|посмотри|найди\s+в\s+галерее|в\s+галерее|как\s+сделать\s+фото\s+на|почему\s+не\s+(?:загруж|открыв))""", RegexOption.IGNORE_CASE),
        Regex("""$WB(что\s+на\s+(?:этом|этой)\s+(?:фото|фотке|картинке)|опиши\s+(?:это|эту)\s+(?:фото|фотку|картинку))$WE""", RegexOption.IGNORE_CASE),
        Regex("""\b(don't\s+(?:send|make|take|generate|draw)|delete\s+(?:the\s+)?photo|open\s+gallery)\b""", RegexOption.IGNORE_CASE)
    )

    private val SELF_PHOTO_PATTERNS = listOf(
        Regex("""$WB(?:сделай|скинь|пришли|отправь|покажи|дай|вышли|запили|сфоткай|сними)\s+(?:мне\s+)?(?:свою\s+|своё\s+|свое\s+)?(?:фотку|фото|фотографию|снимок|кадр|селфи|себя)$WE""", RegexOption.IGNORE_CASE),
        Regex("""$WB(?:фотку|фото|фотографию|селфи|снимок)\s+(?:себя|своё|свое|свою|тебя|твое|твоё|твою)$WE""", RegexOption.IGNORE_CASE),
        Regex("""$WB(?:сфоткайся|сфоткай\s+себя|сделай\s+селфи|скинь\s+селфи|пришли\s+селфи|отправь\s+селфи|хочу\s+(?:твоё|твое|твою)\s+(?:фото|фотку|селфи))$WE""", RegexOption.IGNORE_CASE),
        Regex("""$WB(?:покажи\s+(?:как\s+ты\s+выглядишь|себя|своё\s+лицо|свое\s+лицо|как\s+выглядишь)|как\s+ты\s+сейчас\s+выглядишь)$WE""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:send|take|make|show)\s+(?:me\s+)?(?:a\s+)?(?:selfie|pic\s+of\s+yourself|photo\s+of\s+yourself|picture\s+of\s+yourself)\b""", RegexOption.IGNORE_CASE)
    )

    private val GENERAL_PHOTO_PATTERNS = listOf(
        Regex("""$WB(?:сделай|скинь|пришли|отправь|создай|сгенерируй|сгенерь|выдай|запили|покажи|сфоткай|сними)\s+(?:мне\s+)?(?:красивую\s+|крутую\s+|реалистичную\s+|новую\s+|ещё\s+одну\s+|еще\s+одну\s+)?(?:фотку|фото|фотографию|картинку|изображение|арт|иллюстрацию|рисунок|снимок|портрет|обои)$WE""", RegexOption.IGNORE_CASE),
        Regex("""$WB(?:нарисуй|сгенерируй\s+(?:арт|картинку|изображение|фото|фотку)|изобрази|визуализируй)$WE""", RegexOption.IGNORE_CASE),
        Regex("""$WB(?:хочу\s+(?:фотку|фото|картинку|арт|рисунок)|можешь\s+(?:сделать|скинуть|прислать|нарисовать|сгенерировать)\s+(?:мне\s+)?(?:фотку|фото|картинку|арт|изображение|селфи))$WE""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:generate|create|draw|paint|render|make|send|show)\s+(?:me\s+)?(?:an?\s+)?(?:image|photo|picture|pic|illustration|artwork|portrait|wallpaper)\b""", RegexOption.IGNORE_CASE)
    )

    private val REFUSAL_PATTERNS = listOf(
        Regex("""$WB(?:не\s+могу|не\s+умею|не\s+способн[\p{L}]*)\s+(?:отправлять|отправить|делать|сделать|создавать|создать|генерировать|сгенерировать|рисовать|нарисовать|присылать|скидывать|показывать)\s+(?:тебе\s+|вам\s+)?(?:фото|фотки|фотку|фотографии|фотографию|картинки|картинку|изображения|изображение|селфи)$WE""", RegexOption.IGNORE_CASE),
        Regex("""${WB}текстов(?:ая|ой|ый|ым)\s+(?:модел[\p{L}]*|ии|ассистент[\p{L}]*|помощник[\p{L}]*|нейросет[\p{L}]*)$WE""", RegexOption.IGNORE_CASE),
        Regex("""${WB}нет\s+(?:физического\s+тела|камеры|возможности\s+(?:отправлять|создавать|генерировать|делать)\s+(?:фото|фотки|картинки|изображения))""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:cannot|can't|unable\s+to)\s+(?:generate|create|send|take|show)\s+(?:images|photos|pictures|selfies)\b""", RegexOption.IGNORE_CASE)
    )

    /**
     * Parses `/фото ...` / `/photo ...` / `/картинка ...` / `/нарисуй ...` / `/img ...` commands.
     * Supports optional leading flags:
     * - `hd` / `full` / `качество` -> forces FULL quality mode
     * - `fast` / `быстро` -> forces FAST quality mode
     * - `портрет` / `portrait` -> `512x768`
     * - `альбом` / `landscape` / `широкий` -> `768x512`
     * - `квадрат` / `square` / `1:1` -> `768x768`
     */
    fun parseSlashPhotoCommand(rawText: String): SlashPhotoCommand? {
        val trimmed = rawText.trim()
        val match = SLASH_COMMAND_REGEX.matchEntire(trimmed) ?: return null
        var body = match.groupValues.getOrNull(2)?.trim().orEmpty()

        var qualityOverride: ImageQualityMode? = null
        var resolutionOverride: String? = null

        // Parse up to 2 optional leading modifier tokens (e.g. "/фото hd портрет девушка в кафе")
        repeat(2) {
            val parts = body.split(Regex("\\s+"), limit = 2)
            val head = parts.firstOrNull()?.lowercase()?.removePrefix("--").orEmpty()
            val rest = parts.getOrNull(1)?.trim().orEmpty()
            var consumed = false
            when (head) {
                "hd", "full", "качество", "макс", "hq" -> {
                    if (qualityOverride == null) {
                        qualityOverride = ImageQualityMode.FULL
                        consumed = true
                    }
                }
                "fast", "быстро", "быстрый" -> {
                    if (qualityOverride == null) {
                        qualityOverride = ImageQualityMode.FAST
                        consumed = true
                    }
                }
                "портрет", "portrait", "вертикально", "вертикальный" -> {
                    if (resolutionOverride == null) {
                        resolutionOverride = "512x768"
                        consumed = true
                    }
                }
                "альбом", "landscape", "горизонтально", "широкий" -> {
                    if (resolutionOverride == null) {
                        resolutionOverride = "768x512"
                        consumed = true
                    }
                }
                "квадрат", "square", "1:1" -> {
                    if (resolutionOverride == null) {
                        resolutionOverride = "768x768"
                        consumed = true
                    }
                }
            }
            if (consumed) {
                body = rest
            }
        }

        return SlashPhotoCommand(
            prompt = body,
            qualityOverride = qualityOverride,
            resolutionOverride = resolutionOverride,
            useChatContextIfBlank = body.isBlank()
        )
    }

    /**
     * Detects natural-language photo/selfie/drawing requests from the user.
     */
    fun detectNaturalPhotoRequest(rawText: String, hasAttachedUserImage: Boolean = false): NaturalPhotoIntent {
        val text = rawText.trim()
        if (text.isBlank() || hasAttachedUserImage) return NaturalPhotoIntent(false)
        if (parseSlashPhotoCommand(text) != null) return NaturalPhotoIntent(false)

        if (NEGATIVE_OR_NON_GEN_PATTERNS.any { it.containsMatchIn(text) }) {
            return NaturalPhotoIntent(false)
        }

        val isSelfie = SELF_PHOTO_PATTERNS.any { it.containsMatchIn(text) }
        val isGeneral = GENERAL_PHOTO_PATTERNS.any { it.containsMatchIn(text) }

        if (!isSelfie && !isGeneral) {
            return NaturalPhotoIntent(false)
        }

        // Extra check for SELF_PHOTO_PATTERNS matching "сделай фотку кота" (the first pattern matches
        // "сделай фотку", so distinguish whether the user actually refers to self vs something else!)
        val explicitlySelf = Regex(
            """$WB(себя|своё|свое|свою|собой|селфи|сфоткайся|выглядишь|твоё\s+(?:фото|селфи)|твое\s+(?:фото|селфи)|твою\s+фотку|selfie|yourself)$WE""",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(text)

        val cleanedSubject = text
            .replace(Regex("""^(?:пожалуйста[,\s]*|эй[,\s]*|джарвис[,\s]*|слушай[,\s]*|ну\s+)""", RegexOption.IGNORE_CASE), "")
            .trim()

        return NaturalPhotoIntent(
            isPhotoRequest = true,
            isSelfieOrSelf = explicitlySelf,
            extractedSubject = cleanedSubject
        )
    }

    /**
     * Extracts the first `[GEN_IMAGE: ...]` / `<gen_image>...</gen_image>` tag from an assistant reply
     * and returns the clean user-visible message alongside the image prompt.
     */
    fun extractAiPhotoTag(assistantText: String): ExtractedAiPhotoTag {
        val match = COMPLETED_AI_TAG_REGEX.find(assistantText)
            ?: return ExtractedAiPhotoTag(visibleText = assistantText.trim(), imagePrompt = null)

        val rawPrompt = (match.groupValues[1].ifBlank { match.groupValues[2] })
            .replace('\n', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('"', '\'', '`')

        val cleanedVisible = COMPLETED_AI_TAG_REGEX.replace(assistantText, "")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()

        return ExtractedAiPhotoTag(
            visibleText = cleanedVisible,
            imagePrompt = rawPrompt.takeIf { it.length >= 3 }
        )
    }

    /**
     * Strips both completed and partially streamed `[GEN_IMAGE:...` tags so the user never sees
     * raw markup in the live chat bubble.
     */
    fun stripPhotoTagsForDisplay(text: String): String {
        val withoutDone = COMPLETED_AI_TAG_REGEX.replace(text, "")
        val withoutPartial = PARTIAL_AI_TAG_REGEX.replace(withoutDone, "")
        return withoutPartial.replace(Regex("\\n{3,}"), "\n\n").trim()
    }

    fun hasPartialPhotoTag(text: String): Boolean =
        PARTIAL_AI_TAG_REGEX.containsMatchIn(text) || COMPLETED_AI_TAG_REGEX.containsMatchIn(text)

    /**
     * Detects when an LLM mistakenly replied "I am a text model and cannot take/send photos".
     */
    fun looksLikeTextOnlyRefusal(assistantText: String): Boolean {
        val trimmed = assistantText.trim()
        if (trimmed.isEmpty()) return true
        return REFUSAL_PATTERNS.any { it.containsMatchIn(trimmed) }
    }

    /**
     * Builds the compact system-prompt block teaching ANY LLM (cloud or local) how and when
     * to emit `[GEN_IMAGE: ...]` naturally during chat, aware of the per-chat scene memory.
     */
    fun buildAutoPhotoSystemInstruction(
        assistantName: String,
        sceneMemorySummary: String = ""
    ): String = buildString {
        append("\n\n=== ВСТРОЕННАЯ ГЕНЕРАЦИЯ ФОТО В ЧАТЕ ===\n")
        append("У тебя ЕСТЬ встроенная камера/генератор фотографий и изображений прямо в этом чате. ")
        append("НИКОГДА не говори «я текстовая модель и не умею делать/отправлять фото».\n")
        append("Когда пользователь просит сделать фото, селфи, картинку, рисунок, показать себя или что-либо ")
        append("(например: «сделай фотку себя», «скинь фото», «нарисуй...», «покажи, как это выглядит») ")
        append("ИЛИ когда в текущей сцене беседы действительно уместно прислать фотографию — ")
        append("ответь живо и естественно от своего лица, а в самом конце сообщения добавь ровно один скрытый тег:\n")
        append("[GEN_IMAGE: подробный визуальный промпт на английском языке — кто/что в кадре, внешность/одежда, поза, окружение, освещение, ракурс, настроение, реалистичные детали]\n")
        append("Правила:\n")
        append("1) Если просят фото «себя» — опиши себя в соответствии с образом/персонажем текущей беседы (или как стильного AI-помощника $assistantName, если персонаж не задан) в текущей обстановке чата.\n")
        append("2) Внутри одного чата сохраняй единую внешность, обстановку и атмосферу текущей сцены.\n")
        append("3) НЕ пиши тег [GEN_IMAGE: ...], если пользователь НЕ просил фото/картинку и визуальный кадр сейчас не нужен.")
        if (sceneMemorySummary.isNotBlank()) {
            append("\nТекущая визуальная сцена этого чата: ")
            append(sceneMemorySummary.take(420))
        }
    }

    /**
     * Builds a fallback visual prompt when the user clearly requested a photo (or typed bare `/фото`)
     * and either no LLM is loaded or the LLM forgot to emit `[GEN_IMAGE: ...]`.
     */
    fun buildFallbackPrompt(
        userText: String,
        intent: NaturalPhotoIntent,
        recentMessages: List<String>,
        sceneMemory: ImageSceneMemory,
        assistantName: String
    ): String {
        val recentContext = recentMessages
            .map { it.replace('\n', ' ').trim() }
            .filter { it.length >= 6 && !it.startsWith("/") && !it.startsWith("Ошибка") }
            .takeLast(3)
            .joinToString("; ")
            .take(280)

        if (intent.isSelfieOrSelf) {
            return buildString {
                if (sceneMemory.sceneAnchor.isNotBlank()) {
                    append("Natural candid selfie photo matching established character & scene: ")
                    append(sceneMemory.sceneAnchor)
                } else if (recentContext.isNotBlank()) {
                    append("Natural candid selfie photo matching current chat character and moment (")
                    append(recentContext)
                    append(")")
                } else {
                    append("Photorealistic stylish candid selfie portrait of $assistantName, a charismatic futuristic AI assistant with subtle glowing cyan accents in a cozy modern room, warm cinematic lighting, sharp focus")
                }
                if (intent.extractedSubject.length > 22) {
                    append(", user request detail: ")
                    append(intent.extractedSubject.take(180))
                }
            }
        }

        val cleaned = intent.extractedSubject.ifBlank { userText.trim() }
        if (cleaned.isNotBlank() && !cleaned.equals("/фото", ignoreCase = true)) {
            return buildString {
                append(cleaned)
                if (recentContext.isNotBlank() && cleaned.length < 48) {
                    append(", context: ")
                    append(recentContext.take(180))
                }
            }
        }

        // Bare `/фото` without prompt: photograph the active chat scene / recent moment!
        return when {
            !sceneMemory.isEmpty() -> buildString {
                append("Next natural moment of the scene: ")
                append(sceneMemory.compactSummary())
                if (recentContext.isNotBlank()) {
                    append(". Latest chat moment: ")
                    append(recentContext.take(180))
                }
            }
            recentContext.isNotBlank() ->
                "Photorealistic vivid scene depicting the current chat moment: $recentContext"
            else ->
                "Photorealistic atmospheric portrait of $assistantName AI assistant in a sleek modern evening workspace, warm lighting, high detail"
        }
    }
}
