package ru.jarvis.assistant.core.inference

import android.app.ActivityManager
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.core.agent.AgentSystemPromptBuilder
import ru.jarvis.assistant.core.chat.ImageIntentDetector
import ru.jarvis.assistant.core.models.LocalArtifactStatus
import ru.jarvis.assistant.core.models.ModelProfile
import ru.jarvis.assistant.core.models.ModelProfileId
import ru.jarvis.assistant.core.models.ModelStorage
import ru.jarvis.assistant.core.models.PromptFormat
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Production on-device LLM & Vision engine backed by llama.cpp v1.0.0 + libmtmd.
 * Enforces mandatory SHA-256 verification before passing any file to native code,
 * uses the exact chat template for each model family (Qwen3-VL-Instruct, Qwen3.5, Gemma 3 IT),
 * adapts context size and threads to device RAM/CPU, and runs strictly offline.
 */
class LlamaInferenceEngine(
    private val context: Context,
    private val storage: ModelStorage
) : InferenceEngine {

    private val _state = MutableStateFlow<EngineState>(EngineState.Unloaded)
    override val state: StateFlow<EngineState> = _state.asStateFlow()

    private val handlePtr = AtomicLong(0L)
    private val cancelled = AtomicBoolean(false)
    private val mutex = Mutex()

    @Volatile
    private var loadedProfileId: ModelProfileId? = null

    @Volatile
    private var loadedVisionSupported: Boolean = false

    override val isVisionReady: Boolean
        get() = handlePtr.get() != 0L && loadedVisionSupported

    override suspend fun loadProfile(profile: ModelProfile): Result<Unit> = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!NativeLlamaBridge.isLibraryLoaded) {
                val msg = "Нативный движок llama.cpp недоступен на этом устройстве (${NativeLlamaBridge.loadError ?: "ABI не поддерживается"})."
                _state.value = EngineState.Error(msg)
                return@withContext Result.failure(UnsupportedOperationException(msg))
            }

            freeNativeLocked()
            _state.value = EngineState.Loading(profile.llm.displayName)

            val llmCheck = storage.verifyAndGetModelFile(profile.llm)
            val llmFile: File = llmCheck.getOrElse { err ->
                val msg = err.message ?: "Ошибка проверки SHA-256 модели"
                _state.value = EngineState.Error(msg)
                return@withContext Result.failure(err)
            }

            var mmprojPath: String? = null
            val mmQuick = storage.inspectQuickStatus(profile.visionProjector)
            if (mmQuick == LocalArtifactStatus.INSTALLED_VERIFIED ||
                mmQuick == LocalArtifactStatus.CORRUPT_HASH_MISMATCH
            ) {
                storage.verifyAndGetModelFile(profile.visionProjector)
                    .onSuccess { file -> mmprojPath = file.absolutePath }
                    .onFailure { mmprojPath = null }
            }

            val memInfo = getDeviceMemoryInfo()
            val availMb = memInfo.availMem / (1024L * 1024L)
            val totalMb = memInfo.totalMem / (1024L * 1024L)
            val minSafeAvailMb = when {
                profile.llm.sizeBytes > 2_000_000_000L -> 1800L
                profile.llm.sizeBytes > 900_000_000L -> 750L
                else -> 420L
            }
            if (availMb < minSafeAvailMb) {
                val msg = "Мало свободной ОЗУ (${availMb} МБ из ${totalMb} МБ). " +
                    "Закройте фоновые приложения или выберите более лёгкий профиль."
                _state.value = EngineState.Error(msg)
                return@withContext Result.failure(OutOfMemoryError(msg))
            }

            val nCtx = when {
                totalMb >= 7500L -> 4096
                totalMb >= 5500L -> 2048
                totalMb >= 3500L -> 1536
                else -> 1024
            }
            val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
            val nThreads = when {
                cores >= 8 -> 6
                cores >= 6 -> 4
                else -> (cores - 1).coerceIn(2, 4)
            }

            val ptr = NativeLlamaBridge.nativeLoadModel(
                modelPath = llmFile.absolutePath,
                mmprojPath = mmprojPath,
                nCtx = nCtx,
                nThreads = nThreads
            )
            if (ptr == 0L) {
                val detail = runCatching { NativeLlamaBridge.nativeGetLastError(0L) }.getOrNull().orEmpty()
                val msg = buildString {
                    append("Не удалось загрузить модель ${profile.llm.displayName} в память")
                    if (detail.isNotBlank()) append(": ").append(detail)
                }
                _state.value = EngineState.Error(msg)
                return@withContext Result.failure(IllegalStateException(msg))
            }

            val visionOk = NativeLlamaBridge.nativeSupportsVision(ptr)
            handlePtr.set(ptr)
            loadedProfileId = profile.id
            loadedVisionSupported = visionOk

            _state.value = EngineState.Ready(
                profileId = profile.id,
                profileTitle = profile.id.shortTitleRu,
                modelName = profile.llm.displayName,
                visionSupported = visionOk,
                contextSize = nCtx
            )
            Result.success(Unit)
        }
    }

    override suspend fun generate(
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult = withContext(Dispatchers.Default) {
        val ptr = handlePtr.get()
        if (ptr == 0L) {
            return@withContext GenerationResult.Failed("Модель не загружена. Откройте меню → «Модели» и загрузите профиль.")
        }
        if (imagePath != null && !loadedVisionSupported) {
            return@withContext GenerationResult.Failed("Модуль зрения (mmproj) не скачан или не загружен. Скачайте его в разделе «Модели» и перезагрузите модель.")
        }

        mutex.withLock {
            val currentPtr = handlePtr.get()
            if (currentPtr == 0L) {
                return@withContext GenerationResult.Failed("Модель была выгружена.")
            }

            cancelled.set(false)
            val mediaMarker = if (imagePath != null) {
                NativeLlamaBridge.nativeDefaultMediaMarker()
            } else null

            val activeFormat = loadedProfileId?.promptFormat ?: config.promptFormat
            val effectiveConfig = config.copy(
                promptFormat = activeFormat,
                maxTokens = config.maxTokens.coerceAtLeast(64)
            )

            val promptText = buildPromptForModel(
                history = history,
                userPrompt = userPrompt,
                mediaMarker = mediaMarker,
                config = effectiveConfig
            )

            val startedMs = System.currentTimeMillis()
            val accumulated = StringBuilder()

            val rc = NativeLlamaBridge.nativeGenerate(
                handlePtr = currentPtr,
                prompt = promptText,
                imagePath = imagePath,
                maxTokens = effectiveConfig.maxTokens,
                temperature = effectiveConfig.temperature,
                callback = NativeTokenCallback { piece ->
                    if (cancelled.get()) return@NativeTokenCallback false
                    accumulated.append(piece)
                    onToken(piece)
                    !cancelled.get()
                }
            )

            val elapsed = System.currentTimeMillis() - startedMs
            val cleanText = cleanAssistantOutput(
                raw = accumulated.toString(),
                keepThinking = effectiveConfig.enableThinking && activeFormat == PromptFormat.QWEN35_THINKING
            )

            val nativeErr = runCatching { NativeLlamaBridge.nativeGetLastError(currentPtr) }.getOrNull().orEmpty()

            when (rc) {
                0 -> GenerationResult.Completed(
                    text = cleanText.ifEmpty { "Модель не вернула текст. Попробуйте переформулировать вопрос." },
                    elapsedMs = elapsed
                )
                1 -> GenerationResult.Cancelled(cleanText)
                -4 -> GenerationResult.Failed(
                    if (nativeErr.isNotBlank()) "Ошибка анализа фото: $nativeErr"
                    else "Не удалось обработать фото локальным модулем зрения."
                )
                else -> GenerationResult.Failed(
                    if (nativeErr.isNotBlank()) "Ошибка локальной генерации: $nativeErr"
                    else "Ошибка локальной генерации (код $rc). Попробуйте начать новый чат."
                )
            }
        }
    }

    override fun cancelGeneration() {
        cancelled.set(true)
        val ptr = handlePtr.get()
        if (ptr != 0L) {
            NativeLlamaBridge.nativeCancel(ptr)
        }
    }

    override fun unload() {
        cancelled.set(true)
        val ptr = handlePtr.getAndSet(0L)
        loadedProfileId = null
        loadedVisionSupported = false
        if (ptr != 0L) {
            NativeLlamaBridge.nativeFreeModel(ptr)
        }
        _state.value = EngineState.Unloaded
    }

    private fun freeNativeLocked() {
        val ptr = handlePtr.getAndSet(0L)
        loadedProfileId = null
        loadedVisionSupported = false
        if (ptr != 0L) {
            NativeLlamaBridge.nativeFreeModel(ptr)
        }
    }

    private fun getDeviceMemoryInfo(): ActivityManager.MemoryInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info
    }

    companion object {
        fun buildSystemInstruction(config: GenerationConfig): String {
            val custom = config.customSystemPrompt.trim()
            return buildString {
                if (custom.isNotEmpty()) {
                    append(custom)
                    append("\n")
                } else {
                    append("Ты — ${config.assistantName}, умный ИИ-помощник на Android-смартфоне пользователя. Отвечай на русском языке естественно и по существу. ")
                }
                append("\n")
                append(config.chatMode.defaultPromptRu)
                append(' ')
                append(config.tone.promptHintRu)
                append(' ')
                append(config.responseLength.promptHintRu)
                if (config.contextSummary.isNotBlank()) {
                    append("\n\n=== КРАТКАЯ ПАМЯТЬ ПРОШЛОЙ ЧАСТИ ЭТОГО ЧАТА ===\n")
                    append(config.contextSummary.trim())
                    append("\n(Учитывай эти факты и договорённости как достоверный контекст текущей беседы.)")
                }
                if (config.imageGenerationEnabled) {
                    append(
                        ImageIntentDetector.buildAutoPhotoSystemInstruction(
                            assistantName = config.assistantName,
                            sceneMemorySummary = config.imageSceneSummary
                        )
                    )
                }
                if (config.agentToolsEnabled) {
                    append(
                        AgentSystemPromptBuilder.buildToolsPrompt(
                            installedAppNames = config.installedAppsHint,
                            accessibilityReady = config.accessibilityReady
                        )
                    )
                }
            }.trim()
        }

        fun buildPromptForModel(
            history: List<ChatTurn>,
            userPrompt: String,
            mediaMarker: String?,
            config: GenerationConfig
        ): String {
            // Keep local GGUF context compact by omitting the full 75-app list (local model can still call list_apps/open_app)
            val localConfig = if (config.installedAppsHint.isNotEmpty()) {
                config.copy(installedAppsHint = emptyList())
            } else config
            val sysText = buildSystemInstruction(localConfig)
            // Keep alternating clean recent turns to stay sharp and prevent drift
            val cleanedHistory = normalizeAlternatingHistory(history.takeLast(8))

            return when (config.promptFormat) {
                PromptFormat.GEMMA3_INSTRUCT -> buildGemma3Prompt(sysText, cleanedHistory, userPrompt, mediaMarker)
                PromptFormat.QWEN3_INSTRUCT -> buildQwen3InstructPrompt(sysText, cleanedHistory, userPrompt, mediaMarker)
                PromptFormat.QWEN35_THINKING -> buildQwen35ThinkingPrompt(sysText, cleanedHistory, userPrompt, mediaMarker, config.enableThinking)
            }
        }

        /**
         * Official Gemma 3 IT template:
         * - No separate system role: system text is prepended to the first user message separated by \n\n.
         * - Strictly alternating user / model turns using <start_of_turn>...<end_of_turn>\n.
         * - BOS token is added automatically by llama_tokenize via llama_vocab_get_add_bos(vocab).
         */
        fun buildGemma3Prompt(
            systemPrompt: String,
            history: List<ChatTurn>,
            userPrompt: String,
            mediaMarker: String?
        ): String {
            val sb = StringBuilder()
            val prefix = if (systemPrompt.isNotBlank()) "$systemPrompt\n\n" else ""
            var usedPrefix = false

            for (turn in history) {
                val role = if (turn.role == "assistant") "model" else "user"
                sb.append("<start_of_turn>").append(role).append('\n')
                if (role == "user" && !usedPrefix) {
                    sb.append(prefix)
                    usedPrefix = true
                }
                sb.append(turn.content.take(1200).trim()).append("<end_of_turn>\n")
            }

            sb.append("<start_of_turn>user\n")
            if (!usedPrefix) {
                sb.append(prefix)
            }
            if (!mediaMarker.isNullOrEmpty()) {
                sb.append(mediaMarker).append('\n')
            }
            sb.append(userPrompt.trim())
            sb.append("<end_of_turn>\n<start_of_turn>model\n")
            return sb.toString()
        }

        /**
         * Official Qwen3-VL-2B-Instruct template:
         * - Standard ChatML WITHOUT <think> tags (this model is non-thinking Instruct!).
         */
        fun buildQwen3InstructPrompt(
            systemPrompt: String,
            history: List<ChatTurn>,
            userPrompt: String,
            mediaMarker: String?
        ): String {
            val sb = StringBuilder()
            if (systemPrompt.isNotBlank()) {
                sb.append("<|im_start|>system\n").append(systemPrompt).append("<|im_end|>\n")
            }
            for (turn in history) {
                val role = if (turn.role == "assistant") "assistant" else "user"
                sb.append("<|im_start|>").append(role).append('\n')
                sb.append(turn.content.take(1000).trim()).append("<|im_end|>\n")
            }
            sb.append("<|im_start|>user\n")
            if (!mediaMarker.isNullOrEmpty()) {
                sb.append(mediaMarker).append('\n')
            }
            sb.append(userPrompt.trim())
            sb.append("<|im_end|>\n<|im_start|>assistant\n")
            return sb.toString()
        }

        /**
         * Official Qwen3.5-0.8B template:
         * - ChatML WITH <think>\n\n</think>\n\n when thinking is disabled, or <think>\n when enabled.
         */
        fun buildQwen35ThinkingPrompt(
            systemPrompt: String,
            history: List<ChatTurn>,
            userPrompt: String,
            mediaMarker: String?,
            enableThinking: Boolean
        ): String {
            val sb = StringBuilder()
            if (systemPrompt.isNotBlank()) {
                sb.append("<|im_start|>system\n").append(systemPrompt).append("<|im_end|>\n")
            }
            for (turn in history) {
                val role = if (turn.role == "assistant") "assistant" else "user"
                sb.append("<|im_start|>").append(role).append('\n')
                sb.append(turn.content.take(900).trim()).append("<|im_end|>\n")
            }
            sb.append("<|im_start|>user\n")
            if (!mediaMarker.isNullOrEmpty()) {
                sb.append(mediaMarker).append('\n')
            }
            sb.append(userPrompt.trim())
            sb.append("<|im_end|>\n<|im_start|>assistant\n")
            if (enableThinking) {
                sb.append("<think>\n")
            } else {
                sb.append("<think>\n\n</think>\n\n")
            }
            return sb.toString()
        }

        /**
         * Ensures history always starts with a user turn and alternates user -> assistant pairs
         * (required by Gemma 3 and keeps Qwen multi-turn clean).
         */
        fun normalizeAlternatingHistory(raw: List<ChatTurn>): List<ChatTurn> {
            val out = mutableListOf<ChatTurn>()
            for (turn in raw) {
                val role = if (turn.role == "assistant") "assistant" else "user"
                val content = turn.content.trim()
                if (content.isEmpty() || content == "…") continue
                if (out.isEmpty()) {
                    if (role == "user") out.add(ChatTurn("user", content))
                } else if (out.last().role == role) {
                    // Merge consecutive same-role turns
                    val prev = out.removeAt(out.lastIndex)
                    out.add(ChatTurn(role, "${prev.content}\n$content"))
                } else {
                    out.add(ChatTurn(role, content))
                }
            }
            // Drop dangling trailing user message so next userPrompt strictly follows assistant
            if (out.isNotEmpty() && out.last().role == "user") {
                out.removeAt(out.lastIndex)
            }
            return out
        }

        fun cleanAssistantOutput(raw: String, keepThinking: Boolean): String {
            var txt = raw
            if (!keepThinking) {
                txt = txt.replace(Regex("<think>[\\s\\S]*?</think>\\s*"), "")
                    .replace("<think>", "")
                    .replace("</think>", "")
            }
            val stopMarkers = listOf(
                "<|im_end|>",
                "<|im_start|>",
                "<end_of_turn>",
                "<start_of_turn>",
                "<|endoftext|>",
                "\nuser\n",
                "\nassistant\n",
                "\nmodel\n"
            )
            for (m in stopMarkers) {
                val idx = txt.indexOf(m)
                if (idx >= 0) txt = txt.substring(0, idx)
            }
            return txt.trim()
        }
    }
}
