package ru.jarvis.assistant.ui.about

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import ru.jarvis.assistant.BuildConfig
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.inference.NativeLlamaBridge
import ru.jarvis.assistant.core.models.ModelCatalog
import ru.jarvis.assistant.ui.MainActivity
import java.util.Locale

class AboutFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_about, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<ImageButton>(R.id.about_back_btn).setOnClickListener {
            (activity as? MainActivity)?.popToChat()
        }

        val diagText: TextView = view.findViewById(R.id.about_diagnostics_text)
        val privacyText: TextView = view.findViewById(R.id.about_privacy_text)
        val endpointsText: TextView = view.findViewById(R.id.about_endpoints_text)
        val licensesText: TextView = view.findViewById(R.id.about_licenses_text)

        val am = requireContext().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val totalGb = mem.totalMem / (1024.0 * 1024.0 * 1024.0)
        val availGb = mem.availMem / (1024.0 * 1024.0 * 1024.0)
        val app = JarvisApplication.instance
        val customCount = app.prefs.getCustomProviders().size

        diagText.text = buildString {
            append("Версия приложения: ").append(BuildConfig.VERSION_NAME).append(" (code ").append(BuildConfig.VERSION_CODE).append(")\n")
            append("Сборка APK: ").append(BuildConfig.ABI_LABEL).append('\n')
            append("Устройство: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(" • Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
            append("ABI устройства: ").append(Build.SUPPORTED_ABIS.joinToString(", ")).append('\n')
            append(String.format(Locale.US, "ОЗУ: %.2f ГБ всего / %.2f ГБ свободно\n", totalGb, availGb))
            append("Движок llama.cpp: ").append(BuildConfig.LLAMA_CPP_VERSION)
                .append(if (NativeLlamaBridge.isLibraryLoaded) " (загружен)" else " (недоступен)").append('\n')
            append("Провайдеры: ")
                .append("Gemini=").append(if (app.prefs.geminiApiKey.isNotBlank()) "Да" else "—").append(", ")
                .append("Groq=").append(if (app.prefs.groqApiKey.isNotBlank()) "Да" else "—").append(", ")
                .append("OpenRouter=").append(if (app.prefs.openRouterApiKey.isNotBlank()) "Да" else "—").append(", ")
                .append("Custom=").append(customCount).append("/10, ")
                .append("Perchance=").append(if (app.prefs.perchanceEnabled) "Вкл" else "—").append(", ")
                .append("Puter=").append(if (app.prefs.puterAuthToken.isNotBlank()) "Да" else "—").append('\n')
            append("Озвучка (TTS): ").append(app.prefs.ttsEngineMode.labelRu).append('\n')
            append("Голосовой ввод (STT): ").append(app.prefs.voiceSttMode.labelRu).append('\n')
            append("Контекст чата: ").append(app.prefs.contextWindowMessages).append(" сообщ. • Лимит агента: ").append(app.prefs.agentMaxSteps).append(" шагов")
        }

        privacyText.text = buildString {
            append("• Все API-ключи и токены (включая Puter Auth Token и Custom API/TTS ключи) шифруются локально на устройстве (AES-256-GCM).\n")
            append("• История чатов, пользовательские команды и заметки ассистента хранятся только локально в приватной памяти приложения.\n")
            append("• В приложении нет телеметрии, аналитики и рекламных SDK.\n")
            append("• Dynamic Island не хранит историю системных уведомлений — отображаются только активные уведомления и системные действия.\n")
            append("• По умолчанию голосовой ввод (Android SpeechRecognizer) и озвучка (Android TextToSpeech) работают средствами Android без расхода облачной квоты.")
        }

        val cloudEndpoints = listOf(
            "wss://broker.emqx.io:8084/mqtt, wss://broker.hivemq.com:8884/mqtt, wss://test.mosquitto.org:8081/mqtt (Perchance api-gen — основной генератор фото)",
            "https://text-generation.perchance.org/embed & https://image-generation.perchance.org/embed (Perchance — текст и резервный генератор фото)",
            "https://image.pollinations.ai (Pollinations.ai — дополнительный резерв генерации фото)",
            "https://api.puter.com/puterai/openai/v1/chat/completions & /metering/usage (Puter AI — чат, функции, зрение, квота и Puter TTS)",
            "https://generativelanguage.googleapis.com/v1beta & aiplatform.googleapis.com (Google Gemini)",
            "https://api.groq.com/openai/v1 (Groq LLM + опционально Whisper STT)",
            "https://openrouter.ai/api/v1 (OpenRouter)",
            "Пользовательские API 1–10 (OpenAI / Anthropic совместимые) и Custom TTS",
            "wss://speech.platform.bing.com (Microsoft Edge Neural TTS — опционально)"
        )
        endpointsText.text = (cloudEndpoints + ModelCatalog.allowedNetworkEndpoints).joinToString("\n\n")

        licensesText.text = buildString {
            append("1. Приложение Jarvis — MIT License.\n\n")
            append("2. llama.cpp (${BuildConfig.LLAMA_CPP_VERSION}) + libmtmd — MIT License.\n\n")
            append("3. Gemma 3 4B IT GGUF — Gemma Terms of Use.\n\n")
            append("4. Qwen3-VL-2B-Instruct GGUF & Qwen3.5-0.8B GGUF — Apache-2.0.\n\n")
            append("5. Vosk Android SDK 0.3.75 и модель vosk-model-small-ru-0.22 — Apache-2.0.\n\n")
            append("6. OkHttp 4.12.0, AndroidX, Material Components, Kotlin Coroutines — Apache-2.0.")
        }
    }
}
