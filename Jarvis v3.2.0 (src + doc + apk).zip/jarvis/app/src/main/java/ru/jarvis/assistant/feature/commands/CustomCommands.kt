package ru.jarvis.assistant.feature.commands

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Supported user-programmable command step types (A7).
 * Includes the 3 mandatory core types (OPEN_URL, OPEN_APP, TAP_XY) + practical extensible automation steps.
 */
enum class CommandStepType(
    val titleRu: String,
    val hintRu: String,
    val requiredParams: List<String>
) {
    OPEN_URL(
        titleRu = "Открыть страницу (URL)",
        hintRu = "url (например https://example.com)",
        requiredParams = listOf("url")
    ),
    OPEN_APP(
        titleRu = "Открыть приложение",
        hintRu = "app (название или packageName, например Telegram)",
        requiredParams = listOf("app")
    ),
    TAP_XY(
        titleRu = "Нажать X & Y (координаты)",
        hintRu = "x, y (пиксели — запишите прицелом)",
        requiredParams = listOf("x", "y")
    ),
    WAIT(
        titleRu = "Ожидание / задержка",
        hintRu = "ms (миллисекунды, например 1200)",
        requiredParams = listOf("ms")
    ),
    TYPE_TEXT(
        titleRu = "Ввод текста",
        hintRu = "text (и необязательно submit=true/false)",
        requiredParams = listOf("text")
    ),
    TAP_TEXT(
        titleRu = "Нажать по тексту (Accessibility)",
        hintRu = "text (надпись на кнопке или элементе)",
        requiredParams = listOf("text")
    ),
    SWIPE(
        titleRu = "Свайп / прокрутка",
        hintRu = "direction (down|up|left|right)",
        requiredParams = listOf("direction")
    ),
    PRESS_BACK(
        titleRu = "Кнопка «Назад»",
        hintRu = "без параметров",
        requiredParams = emptyList()
    ),
    PRESS_HOME(
        titleRu = "Кнопка «Домой»",
        hintRu = "без параметров",
        requiredParams = emptyList()
    ),
    OPEN_NOTIFICATIONS(
        titleRu = "Открыть шторку уведомлений",
        hintRu = "без параметров",
        requiredParams = emptyList()
    ),
    CHECK_SCREEN_TEXT(
        titleRu = "Проверить текст на экране (условие)",
        hintRu = "text (остановить команду, если текст не найден)",
        requiredParams = listOf("text")
    ),
    SHOW_MESSAGE(
        titleRu = "Показать сообщение пользователю",
        hintRu = "message (текст уведомления)",
        requiredParams = listOf("message")
    );

    companion object {
        fun fromRaw(raw: String?): CommandStepType? {
            if (raw.isNullOrBlank()) return null
            val norm = raw.trim().uppercase()
                .replace('-', '_')
                .replace(' ', '_')
            return when (norm) {
                "OPEN_URL", "URL", "OPEN_PAGE", "OPEN_LINK" -> OPEN_URL
                "OPEN_APP", "LAUNCH_APP", "APP" -> OPEN_APP
                "TAP_XY", "CLICK_XY", "TAP_COORDS", "COORDINATES" -> TAP_XY
                "WAIT", "DELAY", "SLEEP" -> WAIT
                "TYPE_TEXT", "INPUT_TEXT", "ENTER_TEXT", "TYPE" -> TYPE_TEXT
                "TAP_TEXT", "CLICK_TEXT", "TAP_ELEMENT" -> TAP_TEXT
                "SWIPE", "SCROLL" -> SWIPE
                "PRESS_BACK", "BACK" -> PRESS_BACK
                "PRESS_HOME", "HOME" -> PRESS_HOME
                "OPEN_NOTIFICATIONS", "NOTIFICATIONS", "QUICK_SETTINGS" -> OPEN_NOTIFICATIONS
                "CHECK_SCREEN_TEXT", "CHECK_TEXT", "ASSERT_TEXT", "CONDITION" -> CHECK_SCREEN_TEXT
                "SHOW_MESSAGE", "MESSAGE", "TOAST", "NOTIFY" -> SHOW_MESSAGE
                else -> runCatching { valueOf(norm) }.getOrNull()
            }
        }
    }
}

data class CustomCommandStep(
    val id: String = UUID.randomUUID().toString().take(10),
    val type: CommandStepType,
    val params: Map<String, String> = emptyMap(),
    val noteRu: String = "",
    val needsManualEdit: Boolean = false
) {
    fun summaryRu(): String {
        val detail = when (type) {
            CommandStepType.OPEN_URL -> params["url"].orEmpty()
            CommandStepType.OPEN_APP -> params["app"].orEmpty()
            CommandStepType.TAP_XY -> {
                val x = params["x"].orEmpty()
                val y = params["y"].orEmpty()
                if (x.isNotBlank() && y.isNotBlank()) "X=$x, Y=$y" else "[Запишите координаты прицелом]"
            }
            CommandStepType.WAIT -> "${params["ms"] ?: "1000"} мс"
            CommandStepType.TYPE_TEXT -> {
                val sub = if (params["submit"] == "true") " + Enter" else ""
                "«${params["text"].orEmpty()}»$sub"
            }
            CommandStepType.TAP_TEXT -> "«${params["text"].orEmpty()}»"
            CommandStepType.SWIPE -> params["direction"] ?: "down"
            CommandStepType.CHECK_SCREEN_TEXT -> "проверить «${params["text"].orEmpty()}»"
            CommandStepType.SHOW_MESSAGE -> "«${params["message"].orEmpty()}»"
            else -> ""
        }
        val flag = if (needsManualEdit) " [Нужно уточнить]" else ""
        return if (detail.isNotBlank()) "${type.titleRu}: $detail$flag" else "${type.titleRu}$flag"
    }
}

data class CustomCommand(
    val id: String = UUID.randomUUID().toString().take(12),
    val name: String,
    val description: String = "",
    val triggerPhrase: String = "",
    val steps: List<CustomCommandStep> = emptyList(),
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis()
)

data class CommandValidationResult(
    val valid: Boolean,
    val errorsRu: List<String> = emptyList()
)

data class AiGeneratedCommandDraft(
    val name: String,
    val description: String,
    val triggerPhrase: String,
    val steps: List<CustomCommandStep>,
    val warningsRu: List<String> = emptyList()
)

/**
 * Pure-Kotlin JSON codec, validator, and AI structured command generator prompt/parser (unit-testable on JVM).
 */
object CustomCommandCodec {

    fun serializeList(commands: List<CustomCommand>): String {
        val arr = JSONArray()
        for (cmd in commands) {
            arr.put(serializeOne(cmd))
        }
        return arr.toString()
    }

    fun serializeOne(cmd: CustomCommand): JSONObject = JSONObject().apply {
        put("id", cmd.id)
        put("name", cmd.name.trim())
        put("description", cmd.description.trim())
        put("triggerPhrase", cmd.triggerPhrase.trim())
        put("createdAtMs", cmd.createdAtMs)
        put("updatedAtMs", cmd.updatedAtMs)
        val stepsArr = JSONArray()
        for (s in cmd.steps) {
            stepsArr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("type", s.type.name)
                    put("noteRu", s.noteRu)
                    put("needsManualEdit", s.needsManualEdit)
                    val pObj = JSONObject()
                    for ((k, v) in s.params) pObj.put(k, v)
                    put("params", pObj)
                }
            )
        }
        put("steps", stepsArr)
    }

    fun deserializeList(rawJson: String?): List<CustomCommand> {
        if (rawJson.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(rawJson)
            val list = mutableListOf<CustomCommand>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                parseOne(obj)?.let { list.add(it) }
            }
            list
        }.getOrDefault(emptyList())
    }

    private fun parseOne(obj: JSONObject): CustomCommand? {
        val name = obj.optString("name", "").trim()
        if (name.isEmpty()) return null
        val stepsArr = obj.optJSONArray("steps") ?: JSONArray()
        val steps = mutableListOf<CustomCommandStep>()
        for (j in 0 until stepsArr.length()) {
            val sObj = stepsArr.optJSONObject(j) ?: continue
            val type = CommandStepType.fromRaw(sObj.optString("type")) ?: continue
            val params = linkedMapOf<String, String>()
            val pObj = sObj.optJSONObject("params")
            if (pObj != null) {
                val keys = pObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = pObj.opt(k)
                    if (v != null && v != JSONObject.NULL) params[k] = v.toString()
                }
            }
            steps.add(
                CustomCommandStep(
                    id = sObj.optString("id", "").ifBlank { UUID.randomUUID().toString().take(10) },
                    type = type,
                    params = params,
                    noteRu = sObj.optString("noteRu", ""),
                    needsManualEdit = sObj.optBoolean("needsManualEdit", false)
                )
            )
        }
        return CustomCommand(
            id = obj.optString("id", "").ifBlank { UUID.randomUUID().toString().take(12) },
            name = name,
            description = obj.optString("description", ""),
            triggerPhrase = obj.optString("triggerPhrase", ""),
            steps = steps,
            createdAtMs = obj.optLong("createdAtMs", System.currentTimeMillis()),
            updatedAtMs = obj.optLong("updatedAtMs", System.currentTimeMillis())
        )
    }

    fun validateCommand(cmd: CustomCommand): CommandValidationResult {
        val errors = mutableListOf<String>()
        if (cmd.name.trim().isEmpty()) {
            errors.add("Укажите название команды.")
        }
        if (cmd.steps.isEmpty()) {
            errors.add("Добавьте хотя бы один шаг.")
        }
        cmd.steps.forEachIndexed { idx, step ->
            val num = idx + 1
            for (req in step.type.requiredParams) {
                val v = step.params[req]?.trim().orEmpty()
                if (v.isEmpty()) {
                    errors.add("Шаг $num (${step.type.titleRu}): не заполнен параметр «$req».")
                }
            }
            when (step.type) {
                CommandStepType.OPEN_URL -> {
                    val url = step.params["url"]?.trim().orEmpty()
                    if (url.isNotEmpty() && !url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("tg://") && !url.startsWith("tel:")) {
                        errors.add("Шаг $num: URL должен начинаться с https://, http://, tg:// или tel:")
                    }
                }
                CommandStepType.TAP_XY -> {
                    val x = step.params["x"]?.trim()?.toIntOrNull()
                    val y = step.params["y"]?.trim()?.toIntOrNull()
                    if (x == null || y == null || x < 0 || y < 0) {
                        errors.add("Шаг $num: координаты X и Y должны быть целыми числами ≥ 0 (или запишите прицелом).")
                    }
                }
                CommandStepType.WAIT -> {
                    val ms = step.params["ms"]?.trim()?.toLongOrNull()
                    if (ms == null || ms !in 100L..60_000L) {
                        errors.add("Шаг $num: задержка должна быть от 100 до 60000 мс.")
                    }
                }
                CommandStepType.SWIPE -> {
                    val dir = step.params["direction"]?.trim()?.lowercase().orEmpty()
                    if (dir !in setOf("up", "down", "left", "right")) {
                        errors.add("Шаг $num: направление свайпа должно быть up, down, left или right.")
                    }
                }
                else -> Unit
            }
        }
        return CommandValidationResult(valid = errors.isEmpty(), errorsRu = errors)
    }

    /**
     * Builds the strict structured-output prompt for AI command generation (A7).
     */
    fun buildAiGenerationPrompt(
        userTaskDescription: String,
        installedAppNames: List<String> = emptyList()
    ): String = buildString {
        append("Преобразуй описание задачи пользователя в исполняемую Android-команду в СТРОГОМ формате JSON.\n")
        append("Верни ТОЛЬКО валидный JSON-объект без лишнего текста вокруг.\n\n")
        append("Схема ответа:\n")
        append(
            """
            {
              "name": "Короткое название команды на русском",
              "description": "Что делает команда",
              "triggerPhrase": "Короткая голосовая/текстовая фраза запуска",
              "steps": [
                {
                  "type": "ОДИН_ИЗ_ДОПУСТИМЫХ_ТИПОВ",
                  "params": { ... },
                  "noteRu": "Пояснение шага или что нужно проверить пользователю",
                  "needsManualEdit": false
                }
              ]
            }
            """.trimIndent()
        )
        append("\n\nДОПУСТИМЫЕ ТИПЫ ШАГОВ (используй ТОЛЬКО их, не выдумывай новые):\n")
        append("1. OPEN_APP — params: {\"app\": \"Telegram\"}\n")
        append("2. OPEN_URL — params: {\"url\": \"https://...\"}\n")
        append("3. TAP_XY — params: {\"x\": \"\", \"y\": \"\"} (если точные координаты неизвестны, ставь needsManualEdit: true и noteRu: \"Запишите точку прицелом\")\n")
        append("4. WAIT — params: {\"ms\": \"1200\"} (добавляй после OPEN_APP чтобы приложение успело открыться)\n")
        append("5. TAP_TEXT — params: {\"text\": \"Поиск\"}\n")
        append("6. TYPE_TEXT — params: {\"text\": \"текст\", \"submit\": \"true|false\"}\n")
        append("7. SWIPE — params: {\"direction\": \"down|up|left|right\"}\n")
        append("8. PRESS_BACK — params: {}\n")
        append("9. PRESS_HOME — params: {}\n")
        append("10. OPEN_NOTIFICATIONS — params: {}\n")
        append("11. CHECK_SCREEN_TEXT — params: {\"text\": \"ожидаемый текст\"}\n")
        append("12. SHOW_MESSAGE — params: {\"message\": \"Готово\"}\n\n")
        append("Правила:\n")
        append("- Разбей задачу на логические, практичные шаги (с короткими WAIT после запуска приложений и переходов).\n")
        append("- Если данных не хватает (нет точного контакта, URL или координат), НЕ выдумывай фальшивые значения: поставь понятный плейсхолдер вроде \"[Укажите контакт]\" и \"needsManualEdit\": true.\n")
        if (installedAppNames.isNotEmpty()) {
            append("- Установленные приложения на телефоне: ")
            append(installedAppNames.take(50).joinToString(", "))
            append("\n")
        }
        append("\nЗадача пользователя: ")
        append(userTaskDescription.trim())
    }

    /**
     * Parses & validates the LLM JSON response into an editable [AiGeneratedCommandDraft].
     * Never invents unsupported step types; collects clear warnings for any skipped/incomplete steps.
     */
    fun parseAiGeneratedResponse(rawResponse: String): Result<AiGeneratedCommandDraft> {
        val jsonCandidate = extractJsonObject(rawResponse)
            ?: return Result.failure(IllegalArgumentException("Модель вернула ответ не в формате JSON. Попробуйте повторить генерацию или соберите команду вручную."))

        return runCatching {
            val root = JSONObject(jsonCandidate)
            val name = root.optString("name", "").trim().ifBlank { "Новая команда" }
            val description = root.optString("description", "").trim()
            val trigger = root.optString("triggerPhrase", "").trim()
            val rawSteps = root.optJSONArray("steps")
                ?: throw IllegalArgumentException("В ответе ИИ отсутствует массив steps.")

            val steps = mutableListOf<CustomCommandStep>()
            val warnings = mutableListOf<String>()

            for (i in 0 until rawSteps.length()) {
                val obj = rawSteps.optJSONObject(i) ?: continue
                val rawType = obj.optString("type", "")
                val stepType = CommandStepType.fromRaw(rawType)
                if (stepType == null) {
                    warnings.add("Пропущен неизвестный тип шага «$rawType».")
                    continue
                }
                val params = linkedMapOf<String, String>()
                val pObj = obj.optJSONObject("params")
                if (pObj != null) {
                    val keys = pObj.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val v = pObj.opt(k)
                        if (v != null && v != JSONObject.NULL) {
                            params[k] = v.toString().trim()
                        }
                    }
                }
                var needsEdit = obj.optBoolean("needsManualEdit", false)
                var note = obj.optString("noteRu", "").trim()

                // Auto-flag missing or placeholder required params for user review
                for (req in stepType.requiredParams) {
                    val valStr = params[req].orEmpty()
                    if (valStr.isBlank() || (valStr.startsWith("[") && valStr.endsWith("]"))) {
                        needsEdit = true
                        if (note.isBlank()) {
                            note = if (stepType == CommandStepType.TAP_XY) {
                                "Запишите координаты X и Y с помощью прицела"
                            } else {
                                "Уточните поле «$req» перед сохранением"
                            }
                        }
                    }
                }
                if (stepType == CommandStepType.TAP_XY) {
                    val x = params["x"]?.toIntOrNull()
                    val y = params["y"]?.toIntOrNull()
                    if (x == null || y == null) {
                        needsEdit = true
                    }
                }
                steps.add(
                    CustomCommandStep(
                        type = stepType,
                        params = params,
                        noteRu = note,
                        needsManualEdit = needsEdit
                    )
                )
            }

            if (steps.isEmpty()) {
                throw IllegalArgumentException("ИИ не вернул ни одного поддерживаемого шага. Попробуйте уточнить описание.")
            }

            if (steps.any { it.needsManualEdit }) {
                warnings.add("Некоторые шаги помечены [Нужно уточнить] — заполните их перед сохранением.")
            }

            AiGeneratedCommandDraft(
                name = name,
                description = description,
                triggerPhrase = trigger,
                steps = steps,
                warningsRu = warnings
            )
        }
    }

    private fun extractJsonObject(raw: String): String? {
        val trimmed = raw.trim()
        val fenceMatch = Regex("""```(?:json)?\s*(\{[\s\S]*?\})\s*```""", RegexOption.IGNORE_CASE)
            .find(trimmed)
        if (fenceMatch != null) return fenceMatch.groupValues[1].trim()

        val firstBrace = trimmed.indexOf('{')
        val lastBrace = trimmed.lastIndexOf('}')
        if (firstBrace >= 0 && lastBrace > firstBrace) {
            return trimmed.substring(firstBrace, lastBrace + 1)
        }
        return null
    }
}
