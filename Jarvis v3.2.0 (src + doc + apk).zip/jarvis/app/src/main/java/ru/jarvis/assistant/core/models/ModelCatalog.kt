package ru.jarvis.assistant.core.models

enum class ModelRole(val displayNameRu: String) {
    LLM_TEXT("Основная языковая модель (GGUF)"),
    VISION_PROJECTOR("Модуль зрения / фото (mmproj GGUF)"),
    OFFLINE_VOICE("Офлайн-распознавание русской речи (Vosk)")
}

enum class PromptFormat {
    QWEN35_THINKING,
    QWEN3_INSTRUCT,
    GEMMA3_INSTRUCT
}

enum class ModelProfileId(
    val shortTitleRu: String,
    val titleRu: String,
    val subtitleRu: String,
    val minRecommendedRamGb: Int,
    val promptFormat: PromptFormat,
    val compactBudget2Gb: Boolean
) {
    LIGHT(
        shortTitleRu = "Qwen3.5-0.8B",
        titleRu = "Лёгкий (старые телефоны, 3–4 ГБ ОЗУ)",
        subtitleRu = "Qwen3.5-0.8B (текст + фото) + Vosk RU. ~747 МиБ скачивания.",
        minRecommendedRamGb = 3,
        promptFormat = PromptFormat.QWEN35_THINKING,
        compactBudget2Gb = true
    ),
    BALANCED(
        shortTitleRu = "Qwen3-VL-2B",
        titleRu = "Баланс (4–6 ГБ ОЗУ)",
        subtitleRu = "Qwen3-VL-2B-Instruct (текст + фото/OCR) + Vosk RU. ~1.49 ГиБ скачивания.",
        minRecommendedRamGb = 4,
        promptFormat = PromptFormat.QWEN3_INSTRUCT,
        compactBudget2Gb = true
    ),
    SMART(
        shortTitleRu = "Gemma 3 4B",
        titleRu = "Умный — Gemma 3 4B IT (8–12+ ГБ ОЗУ)",
        subtitleRu = "Gemma 3 4B IT (сильный русский + зрение SigLIP) + Vosk RU. ~3.16 ГиБ скачивания (для Realme GT 3 и флагманов).",
        minRecommendedRamGb = 8,
        promptFormat = PromptFormat.GEMMA3_INSTRUCT,
        compactBudget2Gb = false
    )
}

data class ModelArtifact(
    val id: String,
    val displayName: String,
    val role: ModelRole,
    val fileName: String,
    val downloadUrl: String,
    val repoName: String,
    val pinnedRevision: String,
    val licenseName: String,
    val licenseUrl: String,
    val sizeBytes: Long,
    val sha256: String,
    val isZipArchive: Boolean = false,
    val extractedDirName: String? = null,
    val optional: Boolean = false,
    val notesRu: String = ""
)

data class ModelProfile(
    val id: ModelProfileId,
    val llm: ModelArtifact,
    val visionProjector: ModelArtifact,
    val voice: ModelArtifact
) {
    val allArtifacts: List<ModelArtifact>
        get() = listOf(llm, visionProjector, voice)

    val totalDownloadBytes: Long
        get() = allArtifacts.sumOf { it.sizeBytes }
}

/**
 * Verified, commit-pinned model catalog.
 * Every SHA-256 hash comes either directly from the Hugging Face LFS pointer of the pinned commit
 * or from direct verification of the official Alpha Cephei release archive.
 * No floating `main` URLs are used.
 */
object ModelCatalog {
    /** Hard budget limit for compact profiles (Light & Balanced <= 2 GB). */
    const val MAX_PROFILE_BUDGET_BYTES: Long = 2_000_000_000L

    val VOSK_SMALL_RU = ModelArtifact(
        id = "vosk_small_ru_0_22",
        displayName = "Vosk Small Russian 0.22",
        role = ModelRole.OFFLINE_VOICE,
        fileName = "vosk-model-small-ru-0.22.zip",
        downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-ru-0.22.zip",
        repoName = "Alpha Cephei (alphacephei.com/vosk/models)",
        pinnedRevision = "0.22",
        licenseName = "Apache-2.0",
        licenseUrl = "https://www.apache.org/licenses/LICENSE-2.0",
        sizeBytes = 46_236_750L,
        sha256 = "961d5ff98a17f4aa6de69864d0aa71fa5bac682301d2b5d17a3f24c5c99a46d4",
        isZipArchive = true,
        extractedDirName = "vosk-model-small-ru-0.22",
        optional = true,
        notesRu = "Компактная офлайн-модель русской речи (~44 МиБ архив, ~87 МиБ распакованная)."
    )

    val QWEN35_08B_LLM = ModelArtifact(
        id = "qwen35_08b_q4km",
        displayName = "Qwen3.5-0.8B (Q4_K_M)",
        role = ModelRole.LLM_TEXT,
        fileName = "Qwen3.5-0.8B-Q4_K_M.gguf",
        downloadUrl = "https://huggingface.co/unsloth/Qwen3.5-0.8B-GGUF/resolve/6ab461498e2023f6e3c1baea90a8f0fe38ab64d0/Qwen3.5-0.8B-Q4_K_M.gguf",
        repoName = "unsloth/Qwen3.5-0.8B-GGUF (базовая Qwen/Qwen3.5-0.8B)",
        pinnedRevision = "6ab461498e2023f6e3c1baea90a8f0fe38ab64d0",
        licenseName = "Apache-2.0",
        licenseUrl = "https://www.apache.org/licenses/LICENSE-2.0",
        sizeBytes = 532_517_120L,
        sha256 = "bd258782e35f7f458f8aced1adc053e6e92e89bc735ba3be89d38a06121dc517",
        optional = false,
        notesRu = "Лёгкая модель для старых устройств (3–4 ГБ ОЗУ)."
    )

    val QWEN35_08B_MMPROJ = ModelArtifact(
        id = "qwen35_08b_mmproj_f16",
        displayName = "Qwen3.5-0.8B Vision Projector (F16)",
        role = ModelRole.VISION_PROJECTOR,
        fileName = "qwen35-0.8b-mmproj-F16.gguf",
        downloadUrl = "https://huggingface.co/unsloth/Qwen3.5-0.8B-GGUF/resolve/6ab461498e2023f6e3c1baea90a8f0fe38ab64d0/mmproj-F16.gguf",
        repoName = "unsloth/Qwen3.5-0.8B-GGUF",
        pinnedRevision = "6ab461498e2023f6e3c1baea90a8f0fe38ab64d0",
        licenseName = "Apache-2.0",
        licenseUrl = "https://www.apache.org/licenses/LICENSE-2.0",
        sizeBytes = 204_987_232L,
        sha256 = "56e4c6cfe73b0c82e3e82bc518d7591997e61d81f723fc41a586f4fa69ea2453",
        optional = true,
        notesRu = "Проектор зрения для анализа фото в паре с Qwen3.5-0.8B."
    )

    val QWEN3_VL_2B_LLM = ModelArtifact(
        id = "qwen3vl_2b_q4km",
        displayName = "Qwen3-VL-2B-Instruct (Q4_K_M)",
        role = ModelRole.LLM_TEXT,
        fileName = "Qwen3VL-2B-Instruct-Q4_K_M.gguf",
        downloadUrl = "https://huggingface.co/Qwen/Qwen3-VL-2B-Instruct-GGUF/resolve/52d6c8ffea26cc873ac5ad116f8631268d7eb503/Qwen3VL-2B-Instruct-Q4_K_M.gguf",
        repoName = "Qwen/Qwen3-VL-2B-Instruct-GGUF (официальная Qwen)",
        pinnedRevision = "52d6c8ffea26cc873ac5ad116f8631268d7eb503",
        licenseName = "Apache-2.0",
        licenseUrl = "https://www.apache.org/licenses/LICENSE-2.0",
        sizeBytes = 1_107_409_952L,
        sha256 = "089d75c52f4b7ffc56ba998ffc50aae89fcafc755f9e7208aacca281dca6c2ae",
        optional = false,
        notesRu = "Сбалансированная модель для 4–6 ГБ ОЗУ с точным Instruct-шаблоном."
    )

    val QWEN3_VL_2B_MMPROJ = ModelArtifact(
        id = "qwen3vl_2b_mmproj_q8",
        displayName = "Qwen3-VL-2B Vision Projector (Q8_0)",
        role = ModelRole.VISION_PROJECTOR,
        fileName = "mmproj-Qwen3VL-2B-Instruct-Q8_0.gguf",
        downloadUrl = "https://huggingface.co/Qwen/Qwen3-VL-2B-Instruct-GGUF/resolve/52d6c8ffea26cc873ac5ad116f8631268d7eb503/mmproj-Qwen3VL-2B-Instruct-Q8_0.gguf",
        repoName = "Qwen/Qwen3-VL-2B-Instruct-GGUF (официальная Qwen)",
        pinnedRevision = "52d6c8ffea26cc873ac5ad116f8631268d7eb503",
        licenseName = "Apache-2.0",
        licenseUrl = "https://www.apache.org/licenses/LICENSE-2.0",
        sizeBytes = 445_053_216L,
        sha256 = "f9a68fabba69c3b81e153367b2c7521030b0fa8bb0de400c9599c8e6725f9c82",
        optional = true,
        notesRu = "Проектор зрения Qwen3-VL-2B для распознавания фото и текста."
    )

    val GEMMA3_4B_LLM = ModelArtifact(
        id = "gemma3_4b_it_q4km",
        displayName = "Gemma 3 4B IT (Q4_K_M)",
        role = ModelRole.LLM_TEXT,
        fileName = "gemma-3-4b-it-Q4_K_M.gguf",
        downloadUrl = "https://huggingface.co/ggml-org/gemma-3-4b-it-GGUF/resolve/d0976223747697cb51e056d85c532013931fe52e/gemma-3-4b-it-Q4_K_M.gguf",
        repoName = "ggml-org/gemma-3-4b-it-GGUF (официальная конверсия llama.cpp)",
        pinnedRevision = "d0976223747697cb51e056d85c532013931fe52e",
        licenseName = "Gemma Terms of Use",
        licenseUrl = "https://ai.google.dev/gemma/terms",
        sizeBytes = 2_489_757_856L,
        sha256 = "882e8d2db44dc554fb0ea5077cb7e4bc49e7342a1f0da57901c0802ea21a0863",
        optional = false,
        notesRu = "Сильная русскоязычная модель Google Gemma 3 4B IT. Рекомендуется 8–12+ ГБ ОЗУ."
    )

    val GEMMA3_4B_MMPROJ = ModelArtifact(
        id = "gemma3_4b_mmproj_f16",
        displayName = "Gemma 3 4B Vision Projector (F16)",
        role = ModelRole.VISION_PROJECTOR,
        fileName = "gemma-3-4b-it-mmproj-f16.gguf",
        downloadUrl = "https://huggingface.co/ggml-org/gemma-3-4b-it-GGUF/resolve/d0976223747697cb51e056d85c532013931fe52e/mmproj-model-f16.gguf",
        repoName = "ggml-org/gemma-3-4b-it-GGUF",
        pinnedRevision = "d0976223747697cb51e056d85c532013931fe52e",
        licenseName = "Gemma Terms of Use",
        licenseUrl = "https://ai.google.dev/gemma/terms",
        sizeBytes = 851_251_104L,
        sha256 = "8c0fb064b019a6972856aaae2c7e4792858af3ca4561be2dbf649123ba6c40cb",
        optional = true,
        notesRu = "Модуль зрения SigLIP для Gemma 3 4B (анализ фото, скриншотов и задач)."
    )

    val LIGHT_PROFILE = ModelProfile(
        id = ModelProfileId.LIGHT,
        llm = QWEN35_08B_LLM,
        visionProjector = QWEN35_08B_MMPROJ,
        voice = VOSK_SMALL_RU
    )

    val BALANCED_PROFILE = ModelProfile(
        id = ModelProfileId.BALANCED,
        llm = QWEN3_VL_2B_LLM,
        visionProjector = QWEN3_VL_2B_MMPROJ,
        voice = VOSK_SMALL_RU
    )

    val SMART_PROFILE = ModelProfile(
        id = ModelProfileId.SMART,
        llm = GEMMA3_4B_LLM,
        visionProjector = GEMMA3_4B_MMPROJ,
        voice = VOSK_SMALL_RU
    )

    val allProfiles: List<ModelProfile> = listOf(LIGHT_PROFILE, BALANCED_PROFILE, SMART_PROFILE)

    val allUniqueArtifacts: List<ModelArtifact> = listOf(
        QWEN35_08B_LLM,
        QWEN35_08B_MMPROJ,
        QWEN3_VL_2B_LLM,
        QWEN3_VL_2B_MMPROJ,
        GEMMA3_4B_LLM,
        GEMMA3_4B_MMPROJ,
        VOSK_SMALL_RU
    )

    fun profileFor(id: ModelProfileId): ModelProfile = when (id) {
        ModelProfileId.LIGHT -> LIGHT_PROFILE
        ModelProfileId.BALANCED -> BALANCED_PROFILE
        ModelProfileId.SMART -> SMART_PROFILE
    }

    val allowedNetworkEndpoints: List<String> = allUniqueArtifacts.map { it.downloadUrl }

    fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes Б"
        val kib = bytes / 1024.0
        if (kib < 1024.0) return String.format(java.util.Locale.US, "%.1f КиБ", kib)
        val mib = kib / 1024.0
        if (mib < 1024.0) return String.format(java.util.Locale.US, "%.1f МиБ", mib)
        val gib = mib / 1024.0
        return String.format(java.util.Locale.US, "%.2f ГиБ", gib)
    }
}
