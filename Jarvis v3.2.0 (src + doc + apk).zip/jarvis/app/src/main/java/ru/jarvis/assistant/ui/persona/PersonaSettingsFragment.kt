package ru.jarvis.assistant.ui.persona

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.inference.AssistantTone
import ru.jarvis.assistant.core.inference.ResponseLength
import ru.jarvis.assistant.feature.voice.LocalTtsSpeaker
import ru.jarvis.assistant.ui.MainActivity

class PersonaSettingsFragment : Fragment() {

    private lateinit var lenShort: TextView
    private lateinit var lenMedium: TextView
    private lateinit var lenDetailed: TextView

    private lateinit var toneFriendly: TextView
    private lateinit var toneBusiness: TextView
    private lateinit var toneDirect: TextView
    private lateinit var toneHumor: TextView

    private lateinit var systemPromptEdit: EditText
    private lateinit var islandAnswerSwitch: SwitchMaterial

    private var selectedLength: ResponseLength = ResponseLength.MEDIUM
    private var selectedTone: AssistantTone = AssistantTone.FRIENDLY

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_persona, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance
        val prefs = app.prefs

        view.findViewById<ImageButton>(R.id.persona_back_btn).setOnClickListener {
            (activity as? MainActivity)?.popToChat()
        }
        view.findViewById<TextView>(R.id.persona_subtitle).text = "Как отвечает ${prefs.assistantName}"

        lenShort = view.findViewById(R.id.persona_len_short)
        lenMedium = view.findViewById(R.id.persona_len_medium)
        lenDetailed = view.findViewById(R.id.persona_len_detailed)

        toneFriendly = view.findViewById(R.id.persona_tone_friendly)
        toneBusiness = view.findViewById(R.id.persona_tone_business)
        toneDirect = view.findViewById(R.id.persona_tone_direct)
        toneHumor = view.findViewById(R.id.persona_tone_humor)

        systemPromptEdit = view.findViewById(R.id.persona_system_prompt_edit)
        islandAnswerSwitch = view.findViewById(R.id.persona_island_answer_switch)

        selectedLength = prefs.responseLength
        selectedTone = prefs.assistantTone
        systemPromptEdit.setText(prefs.customSystemPrompt)
        islandAnswerSwitch.isChecked = prefs.islandShowAnswerInside

        lenShort.setOnClickListener { selectedLength = ResponseLength.SHORT; renderChips() }
        lenMedium.setOnClickListener { selectedLength = ResponseLength.MEDIUM; renderChips() }
        lenDetailed.setOnClickListener { selectedLength = ResponseLength.DETAILED; renderChips() }

        toneFriendly.setOnClickListener { selectedTone = AssistantTone.FRIENDLY; renderChips() }
        toneBusiness.setOnClickListener { selectedTone = AssistantTone.BUSINESS; renderChips() }
        toneDirect.setOnClickListener { selectedTone = AssistantTone.DIRECT; renderChips() }
        toneHumor.setOnClickListener { selectedTone = AssistantTone.HUMOROUS; renderChips() }

        view.findViewById<View>(R.id.persona_preset_clear).setOnClickListener {
            systemPromptEdit.setText("")
        }
        view.findViewById<View>(R.id.persona_preset_jarvis).setOnClickListener {
            systemPromptEdit.setText(
                "Ты — ${prefs.assistantName}, высокоинтеллектуальный личный ИИ-помощник. " +
                    "Говоришь чётко, уверенно, без воды и помогаешь быстро решать любые задачи."
            )
        }
        view.findViewById<View>(R.id.persona_preset_tutor).setOnClickListener {
            systemPromptEdit.setText(
                "Ты — терпеливый репетитор. Объясняй сложные темы и задачи шаг за шагом простым русским языком с наглядными примерами."
            )
        }
        view.findViewById<View>(R.id.persona_preset_coder).setOnClickListener {
            systemPromptEdit.setText(
                "Ты — опытный разработчик. Давай чистый рабочий код, коротко объясняй ключевые решения и предупреждай о подводных камнях."
            )
        }

        islandAnswerSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.islandShowAnswerInside = checked
        }

        view.findViewById<MaterialButton>(R.id.persona_save_btn).setOnClickListener {
            prefs.responseLength = selectedLength
            prefs.assistantTone = selectedTone
            prefs.customSystemPrompt = systemPromptEdit.text.toString().trim()
            Toast.makeText(requireContext(), "Манера общения и системный промпт сохранены", Toast.LENGTH_SHORT).show()
        }

        view.findViewById<MaterialButton>(R.id.persona_tts_settings_btn).setOnClickListener {
            LocalTtsSpeaker.openSystemTtsSettings(requireContext())
        }

        renderChips()
    }

    private fun renderChips() {
        applyChipStyle(lenShort, selectedLength == ResponseLength.SHORT)
        applyChipStyle(lenMedium, selectedLength == ResponseLength.MEDIUM)
        applyChipStyle(lenDetailed, selectedLength == ResponseLength.DETAILED)

        applyChipStyle(toneFriendly, selectedTone == AssistantTone.FRIENDLY)
        applyChipStyle(toneBusiness, selectedTone == AssistantTone.BUSINESS)
        applyChipStyle(toneDirect, selectedTone == AssistantTone.DIRECT)
        applyChipStyle(toneHumor, selectedTone == AssistantTone.HUMOROUS)
    }

    private fun applyChipStyle(view: TextView, selected: Boolean) {
        if (selected) {
            view.setBackgroundResource(R.drawable.bg_chip_selected)
            view.setTextColor(Color.BLACK)
        } else {
            view.setBackgroundResource(R.drawable.bg_chip_unselected)
            view.setTextColor(requireContext().getColor(R.color.jarvis_text_primary))
        }
    }
}
