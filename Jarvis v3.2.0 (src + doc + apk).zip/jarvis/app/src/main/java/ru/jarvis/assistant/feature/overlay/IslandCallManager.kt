package ru.jarvis.assistant.feature.overlay

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * B3 Hybrid Call Manager for Dynamic Island:
 * Layer 1 (default — works immediately without replacing user's default dialer!):
 *   - TelephonyCallback / PhoneStateListener (READ_PHONE_STATE) + CATEGORY_CALL notifications
 *   - Accept/Decline/Hangup via TelecomManager (ANSWER_PHONE_CALLS) or real Notification.Action PendingIntent
 *   - Speakerphone toggle via AudioManager (API 31+ setCommunicationDevice + legacy fallback)
 * Layer 2 (optional enhanced mode — user explicitly opts into ROLE_DIALER):
 *   - Native android.telecom.Call control via JarvisInCallService
 */
class IslandCallManager(private val context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val telecomManager = appContext.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
    private val telephonyManager = appContext.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

    private var telephonyCallback: Any? = null
    @Suppress("DEPRECATION")
    private var legacyPhoneListener: PhoneStateListener? = null
    private var started = false

    private val _activeCall = MutableStateFlow<IslandCallInfo?>(null)
    val activeCall: StateFlow<IslandCallInfo?> = _activeCall.asStateFlow()

    private var telephonyCallState: Int = TelephonyManager.CALL_STATE_IDLE
    private var activeCallConnectedAtMs: Long = 0L

    private fun resolveConnectedAt(isActive: Boolean, nativeConnectMs: Long = 0L): Long {
        if (!isActive) {
            activeCallConnectedAtMs = 0L
            return 0L
        }
        if (nativeConnectMs > 0L) {
            activeCallConnectedAtMs = nativeConnectMs
            return nativeConnectMs
        }
        if (activeCallConnectedAtMs <= 0L) {
            activeCallConnectedAtMs = System.currentTimeMillis()
        }
        return activeCallConnectedAtMs
    }

    fun start() {
        if (started) return
        started = true
        registerTelephonyListenerIfPermitted()
        refreshCallState()
    }

    fun onCallNotificationChanged(notifCall: IslandCallInfo?) {
        refreshCallState(notifCall)
    }

    fun onInCallServiceChanged() {
        refreshCallState()
    }

    private fun refreshCallState(notifCallOverride: IslandCallInfo? = JarvisNotificationListenerService.currentCallNotification.value) {
        // Layer 2: Native InCallService takes precedence when active
        val nativeCall = JarvisInCallService.activeCall
        if (nativeCall != null) {
            val st = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                nativeCall.details.state
            } else {
                @Suppress("DEPRECATION")
                nativeCall.state
            }
            val isIncoming = st == Call.STATE_RINGING
            val isActive = st == Call.STATE_ACTIVE || st == Call.STATE_DIALING || st == Call.STATE_CONNECTING
            if (isIncoming || isActive) {
                val handle = nativeCall.details.handle?.schemeSpecificPart.orEmpty()
                val display = nativeCall.details.callerDisplayName?.takeIf { it.isNotBlank() }
                    ?: handle.ifBlank { "Звонок" }
                val connMs = resolveConnectedAt(isActive, nativeCall.details.connectTimeMillis)
                _activeCall.value = IslandCallInfo(
                    callId = "incall_${nativeCall.hashCode()}",
                    callerName = display,
                    callerNumber = handle,
                    isIncoming = isIncoming,
                    isActive = isActive,
                    isSpeakerOn = isSpeakerphoneOn(),
                    fromInCallService = true,
                    connectedAtMs = connMs
                )
                return
            }
        }

        // Layer 1: Combine CATEGORY_CALL notification + TelephonyManager call state
        if (notifCallOverride != null) {
            val isIncoming = when (telephonyCallState) {
                TelephonyManager.CALL_STATE_RINGING -> true
                TelephonyManager.CALL_STATE_OFFHOOK -> false
                else -> notifCallOverride.isIncoming
            }
            val isActive = !isIncoming
            val connMs = resolveConnectedAt(isActive)
            _activeCall.value = notifCallOverride.copy(
                isIncoming = isIncoming,
                isActive = isActive,
                isSpeakerOn = isSpeakerphoneOn(),
                connectedAtMs = connMs
            )
            return
        }

        when (telephonyCallState) {
            TelephonyManager.CALL_STATE_RINGING -> {
                resolveConnectedAt(false)
                _activeCall.value = IslandCallInfo(
                    callId = "telephony_ringing",
                    callerName = "Входящий звонок",
                    isIncoming = true,
                    isActive = false,
                    isSpeakerOn = isSpeakerphoneOn(),
                    connectedAtMs = 0L
                )
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                val connMs = resolveConnectedAt(true)
                _activeCall.value = IslandCallInfo(
                    callId = "telephony_active",
                    callerName = "Активный звонок",
                    isIncoming = false,
                    isActive = true,
                    isSpeakerOn = isSpeakerphoneOn(),
                    connectedAtMs = connMs
                )
            }
            else -> {
                resolveConnectedAt(false)
                _activeCall.value = null
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun acceptCall(): Boolean {
        val current = _activeCall.value ?: return false
        // 1) Native InCallService
        JarvisInCallService.activeCall?.let { call ->
            return runCatching {
                call.answer(0)
                true
            }.getOrDefault(false)
        }
        // 2) TelecomManager.acceptRingingCall() (requires ANSWER_PHONE_CALLS)
        if (hasAnswerPermission()) {
            val ok = runCatching {
                @Suppress("DEPRECATION")
                telecomManager?.acceptRingingCall()
                true
            }.getOrDefault(false)
            if (ok) return true
        }
        // 3) Real CATEGORY_CALL notification "Accept" PendingIntent
        val nKey = current.notificationKey
        val aIdx = current.acceptActionIndex
        if (nKey != null && aIdx != null) {
            return JarvisNotificationListenerService.instance?.executeRealAction(nKey, aIdx) == true
        }
        return false
    }

    @SuppressLint("MissingPermission")
    fun declineOrHangupCall(): Boolean {
        val current = _activeCall.value ?: return false
        // 1) Native InCallService
        JarvisInCallService.activeCall?.let { call ->
            return runCatching {
                if (current.isIncoming) call.reject(false, null) else call.disconnect()
                true
            }.getOrDefault(false)
        }
        // 2) TelecomManager.endCall() (requires ANSWER_PHONE_CALLS)
        if (hasAnswerPermission()) {
            val ok = runCatching {
                @Suppress("DEPRECATION")
                telecomManager?.endCall() == true
            }.getOrDefault(false)
            if (ok) return true
        }
        // 3) Real CATEGORY_CALL notification "Decline / Hangup" PendingIntent
        val nKey = current.notificationKey
        val dIdx = current.declineActionIndex
        if (nKey != null && dIdx != null) {
            return JarvisNotificationListenerService.instance?.executeRealAction(nKey, dIdx) == true
        }
        return false
    }

    fun toggleSpeakerphone(): Boolean {
        val desired = !isSpeakerphoneOn()
        // 1) Native InCallService audio route
        JarvisInCallService.instance?.let { svc ->
            runCatching {
                @Suppress("DEPRECATION")
                svc.setAudioRoute(
                    if (desired) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE
                )
            }
        }
        // 2) AudioManager (API 31+ setCommunicationDevice + fallback)
        val am = audioManager
        if (am != null) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (desired) {
                        val spk = am.availableCommunicationDevices.firstOrNull {
                            it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                        }
                        if (spk != null) am.setCommunicationDevice(spk)
                    } else {
                        am.clearCommunicationDevice()
                    }
                } else {
                    @Suppress("DEPRECATION")
                    am.isSpeakerphoneOn = desired
                }
            }
        }
        _activeCall.value = _activeCall.value?.copy(isSpeakerOn = desired)
        return desired
    }

    fun isSpeakerphoneOn(): Boolean {
        val am = audioManager ?: return false
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                am.communicationDevice?.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
            } else {
                @Suppress("DEPRECATION")
                am.isSpeakerphoneOn
            }
        }.getOrDefault(false)
    }

    private fun hasAnswerPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ANSWER_PHONE_CALLS) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasReadPhoneState(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_PHONE_STATE) ==
            PackageManager.PERMISSION_GRANTED

    private fun registerTelephonyListenerIfPermitted() {
        if (!hasReadPhoneState()) return
        val tm = telephonyManager ?: return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        telephonyCallState = state
                        refreshCallState()
                    }
                }
                tm.registerTelephonyCallback(appContext.mainExecutor, cb)
                telephonyCallback = cb
            } else {
                @Suppress("DEPRECATION")
                val listener = object : PhoneStateListener() {
                    @Deprecated("Deprecated in Java")
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                        telephonyCallState = state
                        refreshCallState()
                    }
                }
                @Suppress("DEPRECATION")
                tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
                legacyPhoneListener = listener
            }
        }
    }

    fun stop() {
        if (!started) return
        started = false
        val tm = telephonyManager
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (telephonyCallback as? TelephonyCallback)?.let { tm?.unregisterTelephonyCallback(it) }
            } else {
                @Suppress("DEPRECATION")
                legacyPhoneListener?.let { tm?.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        }
        telephonyCallback = null
        legacyPhoneListener = null
    }

    companion object {
        fun hasCallPermissions(context: Context): Boolean {
            val readOk = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) ==
                PackageManager.PERMISSION_GRANTED
            val answerOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.ANSWER_PHONE_CALLS) ==
                    PackageManager.PERMISSION_GRANTED
            } else true
            return readOk && answerOk
        }
    }
}

/**
 * Optional Layer 2 InCallService (ONLY active if the user explicitly opts into ROLE_DIALER in settings).
 */
class JarvisInCallService : InCallService() {

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            onCallUpdated?.invoke()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        activeCall = call
        call.registerCallback(callCallback)
        onCallUpdated?.invoke()
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        runCatching { call.unregisterCallback(callCallback) }
        if (activeCall === call) activeCall = null
        onCallUpdated?.invoke()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
        activeCall = null
        onCallUpdated?.invoke()
    }

    companion object {
        @Volatile
        var instance: JarvisInCallService? = null
            private set

        @Volatile
        var activeCall: Call? = null
            private set

        var onCallUpdated: (() -> Unit)? = null
    }
}
