package ru.jarvis.assistant.feature.overlay

/**
 * Pure-Kotlin representation of an installed app row for Dynamic Island notification filtering.
 */
data class IslandAppEntry(
    val packageName: String,
    val appLabel: String,
    val isSystemApp: Boolean
)

/**
 * Blacklist-mode per-app notification filtering policy for Dynamic Island:
 * - All apps are ENABLED by default (empty blocked set).
 * - Applies ONLY to notifications (calls and music are unaffected).
 * - Search matches both human app name and package name (case-insensitive).
 */
object IslandNotifFilterPolicy {

    fun shouldShowNotification(packageName: String, blockedPackages: Set<String>): Boolean {
        val pkg = packageName.trim()
        if (pkg.isEmpty()) return false
        return pkg !in blockedPackages
    }

    fun filterApps(
        allApps: List<IslandAppEntry>,
        query: String,
        showSystemApps: Boolean
    ): List<IslandAppEntry> {
        val q = query.trim().lowercase()
        return allApps
            .asSequence()
            .filter { entry -> showSystemApps || !entry.isSystemApp }
            .filter { entry ->
                q.isEmpty() ||
                    entry.appLabel.lowercase().contains(q) ||
                    entry.packageName.lowercase().contains(q)
            }
            .sortedWith(
                compareBy<IslandAppEntry> { it.appLabel.lowercase() }
                    .thenBy { it.packageName.lowercase() }
            )
            .toList()
    }

    fun summaryLabelRu(blockedCount: Int): String = when {
        blockedCount <= 0 -> "Приложения уведомлений: все включены"
        blockedCount == 1 -> "Приложения уведомлений: скрыто 1 прил."
        else -> "Приложения уведомлений: скрыто $blockedCount прил."
    }
}
