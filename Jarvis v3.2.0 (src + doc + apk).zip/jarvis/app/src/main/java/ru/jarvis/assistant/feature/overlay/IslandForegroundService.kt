package ru.jarvis.assistant.feature.overlay

import android.Manifest
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.cloud.RequestSource
import ru.jarvis.assistant.feature.avatar.ZafkielClockAvatarView
import ru.jarvis.assistant.feature.voice.VoiceState
import ru.jarvis.assistant.ui.MainActivity
import ru.jarvis.assistant.ui.common.RichTextFormatter
import java.io.File
import kotlin.math.roundToInt

/**
 * Dynamic Island Foreground Service (v3.0 — A1 + B1–B5):
 * - Strict priority engine: CALL > NOTIFICATION > MUSIC > IDLE, with automatic fallback restoration.
 * - Left button «Открыть «{assistantName}»» whenever occupied by Call, Notification, or Music.
 * - Live notifications from all apps with ONLY real system Notification.Action / RemoteInput (no history).
 * - Live Music: album artwork left, audio-reactive Visualizer equalizer right (with smooth fallback),
 *   track metadata + Prev/Play-Pause/Next controls.
 * - Hybrid Calls: immediate Telecom/AudioManager/Notification controls + optional InCallService.
 * - Preserves all v2.5.0 features (Kurumi/Zafkiel clock avatar, GIF/MP4 thinking, voice STT, quick chat).
 */
class IslandForegroundService : Service() {

    private enum class IslandVisualState {
        COLLAPSED_IDLE,
        VOICE_HOLD_PILL,
        EXPANDED_CARD
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val priorityEngine = IslandPriorityEngine()
    private var currentSnapshot = IslandPrioritySnapshot()
    private var mediaController: IslandMediaController? = null
    private var callManager: IslandCallManager? = null

    private var windowManager: WindowManager? = null
    private var rootView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var shellContainer: LinearLayout? = null
    private var pillContainer: LinearLayout? = null
    private var quickOpenAssistantBtn: TextView? = null
    private var avatarFrame: FrameLayout? = null
    private var avatarImage: ZafkielClockAvatarView? = null
    private var avatarVideo: TextureView? = null
    private var liveMediaIcon: ImageView? = null
    private var centerStatusText: TextView? = null
    private var waveformView: IslandWaveformView? = null
    private var collapseBtn: ImageButton? = null

    private var expandedPanel: LinearLayout? = null
    // B3 + Phase 9: Compact iPhone-style Call capsule
    private var callPanel: LinearLayout? = null
    private var callInfoArea: LinearLayout? = null
    private var callStatusLabel: TextView? = null
    private var callCallerName: TextView? = null
    private var callPrimaryBtn: ImageButton? = null
    private var callDeclineBtn: ImageButton? = null
    // B1 Notification panel
    private var notifPanel: LinearLayout? = null
    private var notifAppLabel: TextView? = null
    private var notifDismissBtn: TextView? = null
    private var notifTitleTv: TextView? = null
    private var notifBodyTv: TextView? = null
    private var notifActionsRow: LinearLayout? = null
    private var notifReplyRow: LinearLayout? = null
    private var notifReplyEdit: EditText? = null
    private var notifReplySend: TextView? = null
    private var pendingReplyActionKey: String? = null
    private var pendingReplyActionIdx: Int = -1
    // B2 + Phase 9: iOS 16 Lock Screen style Music player
    private var musicPanel: LinearLayout? = null
    private var musicCoverImg: ImageView? = null
    private var musicMetaArea: LinearLayout? = null
    private var musicSourceTv: TextView? = null
    private var musicTitleTv: TextView? = null
    private var musicArtistTv: TextView? = null
    private var musicEqView: IslandWaveformView? = null
    private var musicElapsedTv: TextView? = null
    private var musicSeekBar: SeekBar? = null
    private var musicRemainingTv: TextView? = null
    private var musicPrevBtn: ImageButton? = null
    private var musicPlayBtn: ImageButton? = null
    private var musicNextBtn: ImageButton? = null
    private var musicVolumeSeekBar: SeekBar? = null
    // Assistant panel
    private var assistantSection: LinearLayout? = null
    private var thinkingRow: LinearLayout? = null
    private var thinkingAvatar: ZafkielClockAvatarView? = null
    private var thinkingTitle: TextView? = null
    private var thinkingSubtitle: TextView? = null
    private var voiceBanner: TextView? = null
    private var answerScroll: ScrollView? = null
    private var answerText: TextView? = null
    private var copyBtn: TextView? = null
    private var ttsBtn: TextView? = null
    private var openChatBtn: TextView? = null
    private var inputEdit: EditText? = null
    private var micBtn: ImageButton? = null
    private var sendBtn: ImageButton? = null

    private lateinit var glowDrawable: IslandGlowDrawable
    private var glowAnimator: ValueAnimator? = null
    private var morphAnimator: ValueAnimator? = null

    private var touchController: IslandTouchController? = null
    private var longPressRunnable: Runnable? = null
    private var notifAutoDismissRunnable: Runnable? = null

    private var visualState: IslandVisualState = IslandVisualState.COLLAPSED_IDLE
    private var forceShowAssistantPanel = false
    private var autoExpandedForCall = false
    private var showTopBarDuringCall = false
    private var isUserSeekingTrack = false
    private var isUserAdjustingVolume = false
    private var liveTickerRunning = false
    private val liveTickerRunnable = object : Runnable {
        override fun run() {
            if (!liveTickerRunning) return
            updateLiveTimersAndProgress()
            mainHandler.postDelayed(this, 1000L)
        }
    }
    private var isRecordingVoice = false
    private var isGeneratingNow = false
    private var lastIslandAnswer: String = ""

    private var mediaPlayer: MediaPlayer? = null
    private var videoSurface: Surface? = null
    private var stateJobs: MutableList<Job> = mutableListOf()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        JarvisApplication.instance.agentToolExecutor.onBeforeScreenInteraction = {
            if (visualState == IslandVisualState.EXPANDED_CARD) {
                collapseToIdlePill()
            }
        }
        mediaController = IslandMediaController(this)
        callManager = IslandCallManager(this)
        JarvisInCallService.onCallUpdated = {
            mainHandler.post { callManager?.onInCallServiceChanged() }
        }
        JarvisNotificationListenerService.onListenerStateChanged = { connected ->
            if (connected) {
                mainHandler.post { mediaController?.start() }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                syncLiveIntegrations()
                applyVisualSettingsAndGeometry(animate = false)
                renderPriorityState()
                return START_STICKY
            }
            ACTION_STATUS_FLASH -> {
                val msg = intent.getStringExtra(EXTRA_STATUS_TEXT)
                if (!msg.isNullOrBlank()) showTransientStatus(msg)
                return START_STICKY
            }
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        val ok = startAsForeground(recordingMic = false)
        if (!ok) {
            stopSelf()
            return START_NOT_STICKY
        }
        JarvisApplication.instance.prefs.islandPendingRestore = false

        if (rootView == null) {
            try {
                attachOverlayWindow()
            } catch (t: Throwable) {
                // An optional overlay must never take down the host app process.
                android.util.Log.e("JarvisIsland", "Overlay inflation failed; stopping only the island service", t)
                runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
                stopSelf()
                return START_NOT_STICKY
            }
            syncLiveIntegrations()
            observeAppFlows()
        } else {
            syncLiveIntegrations()
            applyVisualSettingsAndGeometry(animate = false)
            renderPriorityState()
        }
        return START_STICKY
    }

    private fun syncLiveIntegrations() {
        val prefs = JarvisApplication.instance.prefs
        if (prefs.islandMusicEnabled && JarvisNotificationListenerService.isPermissionGranted(this)) {
            mediaController?.start()
        } else {
            mediaController?.stop()
        }
        if (prefs.islandCallsEnabled) {
            callManager?.start()
        } else {
            callManager?.stop()
        }
    }

    private fun startAsForeground(recordingMic: Boolean): Boolean {
        val notification = buildNotification(recordingMic)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val type = if (recordingMic) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                }
                startForeground(NOTIFICATION_ID, notification, type)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val type = if (recordingMic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
                startForeground(NOTIFICATION_ID, notification, type)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (_: SecurityException) {
            false
        } catch (_: RuntimeException) {
            false
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun attachOverlayWindow() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val root = LayoutInflater.from(this).inflate(R.layout.overlay_dynamic_island, null)
        rootView = root

        shellContainer = root.findViewById(R.id.island_shell)
        pillContainer = root.findViewById(R.id.island_pill_container)
        quickOpenAssistantBtn = root.findViewById(R.id.island_quick_open_assistant_btn)
        avatarFrame = root.findViewById(R.id.island_avatar_frame)
        avatarImage = root.findViewById(R.id.island_avatar_image)
        avatarVideo = root.findViewById(R.id.island_avatar_video)
        liveMediaIcon = root.findViewById(R.id.island_live_media_icon)
        centerStatusText = root.findViewById(R.id.island_center_status)
        waveformView = root.findViewById(R.id.island_waveform)
        collapseBtn = root.findViewById(R.id.island_collapse_btn)

        expandedPanel = root.findViewById(R.id.island_expanded_panel)
        callPanel = root.findViewById(R.id.island_call_panel)
        callInfoArea = root.findViewById(R.id.island_call_info_area)
        callStatusLabel = root.findViewById(R.id.island_call_status_label)
        callCallerName = root.findViewById(R.id.island_call_caller_name)
        callPrimaryBtn = root.findViewById(R.id.island_call_primary_btn)
        callDeclineBtn = root.findViewById(R.id.island_call_decline_btn)

        notifPanel = root.findViewById(R.id.island_notif_panel)
        notifAppLabel = root.findViewById(R.id.island_notif_app_label)
        notifDismissBtn = root.findViewById(R.id.island_notif_dismiss_btn)
        notifTitleTv = root.findViewById(R.id.island_notif_title)
        notifBodyTv = root.findViewById(R.id.island_notif_body)
        notifActionsRow = root.findViewById(R.id.island_notif_actions_row)
        notifReplyRow = root.findViewById(R.id.island_notif_reply_row)
        notifReplyEdit = root.findViewById(R.id.island_notif_reply_edit)
        notifReplySend = root.findViewById(R.id.island_notif_reply_send)

        musicPanel = root.findViewById(R.id.island_music_panel)
        musicCoverImg = root.findViewById(R.id.island_music_cover)
        musicMetaArea = root.findViewById(R.id.island_music_meta_area)
        musicSourceTv = root.findViewById(R.id.island_music_source)
        musicTitleTv = root.findViewById(R.id.island_music_title)
        musicArtistTv = root.findViewById(R.id.island_music_artist)
        musicEqView = root.findViewById(R.id.island_music_eq)
        musicElapsedTv = root.findViewById(R.id.island_music_elapsed)
        musicSeekBar = root.findViewById(R.id.island_music_seekbar)
        musicRemainingTv = root.findViewById(R.id.island_music_remaining)
        musicPrevBtn = root.findViewById(R.id.island_music_prev_btn)
        musicPlayBtn = root.findViewById(R.id.island_music_play_btn)
        musicNextBtn = root.findViewById(R.id.island_music_next_btn)
        musicVolumeSeekBar = root.findViewById(R.id.island_music_volume_seekbar)

        assistantSection = root.findViewById(R.id.island_assistant_section)
        thinkingRow = root.findViewById(R.id.island_thinking_row)
        thinkingAvatar = root.findViewById(R.id.island_thinking_avatar)
        thinkingTitle = root.findViewById(R.id.island_thinking_title)
        thinkingSubtitle = root.findViewById(R.id.island_thinking_subtitle)
        voiceBanner = root.findViewById(R.id.island_voice_banner)
        answerScroll = root.findViewById(R.id.island_answer_scroll)
        answerText = root.findViewById(R.id.island_answer_text)
        copyBtn = root.findViewById(R.id.island_copy_btn)
        ttsBtn = root.findViewById(R.id.island_tts_btn)
        openChatBtn = root.findViewById(R.id.island_open_chat_btn)
        inputEdit = root.findViewById(R.id.island_input_edit)
        micBtn = root.findViewById(R.id.island_mic_btn)
        sendBtn = root.findViewById(R.id.island_send_btn)

        val circleOutline = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        avatarVideo?.outlineProvider = circleOutline
        avatarVideo?.clipToOutline = true
        liveMediaIcon?.outlineProvider = circleOutline
        liveMediaIcon?.clipToOutline = true

        val coverCornerPx = dpToPx(12).toFloat()
        musicCoverImg?.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, coverCornerPx)
            }
        }
        musicCoverImg?.clipToOutline = true

        val prefs = JarvisApplication.instance.prefs
        glowDrawable = IslandGlowDrawable(dpToPx(prefs.islandCornerRadiusDp).toFloat()).apply {
            kurumiPalette = prefs.kurumiThemeEnabled
        }
        shellContainer?.background = glowDrawable

        val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat().coerceAtLeast(16f)
        touchController = IslandTouchController(
            touchSlopPx = slop,
            longPressThresholdMs = 340L,
            dragLocked = prefs.islandLockDrag
        )

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val initialWidthPx = dpToPx(prefs.islandWidthDp)
        val screenW = resources.displayMetrics.widthPixels
        val startX = if (prefs.islandPosX < 0) ((screenW - initialWidthPx) / 2).coerceAtLeast(0) else prefs.islandPosX
        val startY = prefs.islandPosY

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        layoutParams = params

        pillContainer?.setOnTouchListener { _, event -> handlePillTouch(event) }

        // B5: Left quick-open assistant launcher when island is occupied by call/notif/music
        quickOpenAssistantBtn?.setOnClickListener {
            forceShowAssistantPanel = true
            expandToCard(prefillText = null, focusKeyboard = true)
            renderPriorityState()
        }

        collapseBtn?.setOnClickListener { collapseToIdlePill() }

        // B3 + Phase 9: Compact iPhone-style Call actions (accept morphs to circular speaker toggle)
        callInfoArea?.setOnClickListener {
            showTopBarDuringCall = !showTopBarDuringCall
            renderPriorityState()
        }
        callPrimaryBtn?.setOnClickListener {
            val active = currentSnapshot.activeCall ?: return@setOnClickListener
            if (active.isIncoming) {
                val ok = callManager?.acceptCall() == true
                if (!ok) {
                    Toast.makeText(this, "Разрешите «Управление звонками» в настройках Dynamic Island", Toast.LENGTH_SHORT).show()
                }
            } else {
                callManager?.toggleSpeakerphone()
                renderPriorityState()
            }
        }
        callDeclineBtn?.setOnClickListener {
            val ok = callManager?.declineOrHangupCall() == true
            if (!ok) {
                Toast.makeText(this, "Не удалось сбросить звонок — проверьте разрешения звонков", Toast.LENGTH_SHORT).show()
            }
        }

        // B1: Notification actions
        notifDismissBtn?.setOnClickListener {
            val key = currentSnapshot.activeNotification?.key
            if (key != null) {
                JarvisNotificationListenerService.instance?.dismissSystemNotification(key)
                currentSnapshot = priorityEngine.dismissNotificationByKey(key, JarvisApplication.instance.prefs.assistantName)
                notifReplyRow?.visibility = View.GONE
                renderPriorityState()
            }
        }
        notifPanel?.setOnClickListener {
            val key = currentSnapshot.activeNotification?.key
            if (key != null && notifReplyRow?.visibility != View.VISIBLE) {
                JarvisNotificationListenerService.instance?.openNotificationContent(key)
                collapseToIdlePill()
            }
        }
        notifReplySend?.setOnClickListener { sendInlineNotificationReply() }
        notifReplyEdit?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendInlineNotificationReply()
                true
            } else false
        }

        // B2 + Phase 9: iOS 16 Lock Screen Music controls, seek bar, volume bar & tap-cover to open player
        musicPrevBtn?.setOnClickListener { mediaController?.skipToPrevious() }
        musicPlayBtn?.setOnClickListener { mediaController?.togglePlayPause() }
        musicNextBtn?.setOnClickListener { mediaController?.skipToNext() }
        val openMusicPlayerAction = View.OnClickListener {
            mediaController?.openPlayerApp()
            collapseToIdlePill()
        }
        musicCoverImg?.setOnClickListener(openMusicPlayerAction)
        musicMetaArea?.setOnClickListener(openMusicPlayerAction)

        musicSeekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val dur = currentSnapshot.activeMusic?.durationMs ?: 0L
                if (dur > 0L) {
                    val pos = (dur * progress) / 1000L
                    musicElapsedTv?.text = IslandPriorityEngine.formatMediaDuration(pos)
                    musicRemainingTv?.text = IslandPriorityEngine.formatMediaRemaining(pos, dur)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserSeekingTrack = true
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val dur = currentSnapshot.activeMusic?.durationMs ?: 0L
                val prog = seekBar?.progress ?: 0
                isUserSeekingTrack = false
                if (dur > 0L) {
                    mediaController?.seekTo((dur * prog) / 1000L)
                }
            }
        })

        musicVolumeSeekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaController?.setMediaVolumePercent(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isUserAdjustingVolume = true
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isUserAdjustingVolume = false
            }
        })

        // Assistant controls
        openChatBtn?.setOnClickListener {
            collapseToIdlePill()
            openMainActivity()
        }
        copyBtn?.setOnClickListener {
            if (lastIslandAnswer.isNotBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Jarvis", lastIslandAnswer))
                Toast.makeText(this, "Ответ скопирован", Toast.LENGTH_SHORT).show()
            }
        }
        ttsBtn?.setOnClickListener {
            if (lastIslandAnswer.isNotBlank()) {
                JarvisApplication.instance.ttsSpeaker.speak(lastIslandAnswer).onFailure { err ->
                    Toast.makeText(this, err.message ?: "TTS недоступен", Toast.LENGTH_LONG).show()
                }
            }
        }
        micBtn?.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startVoiceHold(fromExpanded = true); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { stopVoiceHold(); true }
                else -> false
            }
        }
        sendBtn?.setOnClickListener {
            if (isGeneratingNow) JarvisApplication.instance.chatCoordinator.cancelGeneration()
            else submitIslandMessage()
        }
        inputEdit?.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitIslandMessage()
                true
            } else false
        }

        avatarVideo?.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                videoSurface = Surface(surface)
                if (isGeneratingNow) startVideoAvatarPlayback()
            }
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                releaseVideoAvatar()
                videoSurface?.release()
                videoSurface = null
                return true
            }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }

        windowManager?.addView(root, params)
        applyVisualSettingsAndGeometry(animate = false)
    }

    private fun sendInlineNotificationReply() {
        val key = pendingReplyActionKey ?: return
        val idx = pendingReplyActionIdx
        val replyText = notifReplyEdit?.text?.toString()?.trim().orEmpty()
        if (replyText.isEmpty() || idx < 0) return
        val ok = JarvisNotificationListenerService.instance?.executeRealAction(key, idx, replyText) == true
        notifReplyEdit?.setText("")
        notifReplyRow?.visibility = View.GONE
        pendingReplyActionKey = null
        pendingReplyActionIdx = -1
        if (ok) {
            currentSnapshot = priorityEngine.dismissNotificationByKey(key, JarvisApplication.instance.prefs.assistantName)
            Toast.makeText(this, "Ответ отправлен", Toast.LENGTH_SHORT).show()
            renderPriorityState()
        }
    }

    private fun handlePillTouch(event: MotionEvent): Boolean {
        val ctrl = touchController ?: return false
        val params = layoutParams ?: return false
        val now = System.currentTimeMillis()

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ctrl.onDown(params.x, params.y, event.rawX, event.rawY, now)
                scheduleLongPressTimer()
            }
            MotionEvent.ACTION_MOVE -> {
                val res = ctrl.onMove(event.rawX, event.rawY)
                if (res is IslandTouchController.GestureEvent.DragMove) {
                    cancelLongPressTimer()
                    val screenW = resources.displayMetrics.widthPixels
                    val screenH = resources.displayMetrics.heightPixels
                    params.x = res.newX.coerceIn(0, (screenW - dpToPx(80)).coerceAtLeast(0))
                    params.y = res.newY.coerceIn(0, (screenH - dpToPx(60)).coerceAtLeast(0))
                    runCatching { windowManager?.updateViewLayout(rootView, params) }
                }
            }
            MotionEvent.ACTION_UP -> {
                cancelLongPressTimer()
                when (ctrl.onUp(event.rawX, event.rawY, now)) {
                    is IslandTouchController.GestureEvent.DragEnd -> {
                        if (visualState == IslandVisualState.COLLAPSED_IDLE) {
                            JarvisApplication.instance.prefs.islandPosX = params.x
                            JarvisApplication.instance.prefs.islandPosY = params.y
                        }
                    }
                    is IslandTouchController.GestureEvent.ShortTap -> {
                        if (visualState == IslandVisualState.EXPANDED_CARD) {
                            collapseToIdlePill()
                        } else {
                            forceShowAssistantPanel = !currentSnapshot.isOccupiedByLiveContent
                            expandToCard(prefillText = null, focusKeyboard = !currentSnapshot.isOccupiedByLiveContent)
                            renderPriorityState()
                        }
                    }
                    is IslandTouchController.GestureEvent.StopVoiceRecording -> stopVoiceHold()
                    else -> Unit
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                cancelLongPressTimer()
                if (ctrl.onCancel() is IslandTouchController.GestureEvent.StopVoiceRecording) {
                    stopVoiceHold()
                }
            }
        }
        return true
    }

    private fun scheduleLongPressTimer() {
        cancelLongPressTimer()
        val r = Runnable {
            val res = touchController?.onLongPressTimerFired(System.currentTimeMillis())
            if (res is IslandTouchController.GestureEvent.StartVoiceRecording) {
                startVoiceHold(fromExpanded = false)
            }
        }
        longPressRunnable = r
        mainHandler.postDelayed(r, 340L)
    }

    private fun cancelLongPressTimer() {
        longPressRunnable?.let { mainHandler.removeCallbacks(it) }
        longPressRunnable = null
    }

    private fun startVoiceHold(fromExpanded: Boolean) {
        if (isRecordingVoice) return
        val app = JarvisApplication.instance

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            forceShowAssistantPanel = true
            expandToCard(prefillText = null, focusKeyboard = false)
            voiceBanner?.visibility = View.VISIBLE
            voiceBanner?.text = "Разрешите микрофон в настройках Jarvis для голосового ввода."
            return
        }

        val micFgsOk = startAsForeground(recordingMic = true)
        if (!micFgsOk) {
            forceShowAssistantPanel = true
            expandToCard(prefillText = null, focusKeyboard = true)
            voiceBanner?.visibility = View.VISIBLE
            voiceBanner?.text = "Android ограничил микрофон в фоне — введите запрос текстом или откройте Jarvis."
            return
        }

        isRecordingVoice = true
        if (!fromExpanded && visualState == IslandVisualState.COLLAPSED_IDLE) {
            morphToVoiceHoldPill()
        }
        setGlowActive(true)
        waveformView?.setMode(IslandWaveformView.Mode.LISTENING)
        centerStatusText?.text = "Слушаю…"
        voiceBanner?.visibility = View.VISIBLE
        voiceBanner?.text = "Слушаю… отпустите для остановки"

        app.voiceEngine.startRecording { recognized, errorMsg ->
            mainHandler.post {
                isRecordingVoice = false
                startAsForeground(recordingMic = false)
                if (!isGeneratingNow) {
                    setGlowActive(false)
                }
                if (!recognized.isNullOrBlank()) {
                    forceShowAssistantPanel = true
                    expandToCard(prefillText = recognized, focusKeyboard = true)
                    voiceBanner?.visibility = View.VISIBLE
                    voiceBanner?.text = "Распознано — проверьте и нажмите ↑"
                } else if (!errorMsg.isNullOrBlank()) {
                    forceShowAssistantPanel = true
                    expandToCard(prefillText = null, focusKeyboard = false)
                    voiceBanner?.visibility = View.VISIBLE
                    voiceBanner?.text = errorMsg
                } else if (visualState == IslandVisualState.VOICE_HOLD_PILL) {
                    collapseToIdlePill()
                }
                renderPriorityState()
            }
        }
    }

    private fun stopVoiceHold() {
        if (!isRecordingVoice) return
        JarvisApplication.instance.voiceEngine.stopRecording()
    }

    private fun morphToVoiceHoldPill() {
        visualState = IslandVisualState.VOICE_HOLD_PILL
        val screenW = resources.displayMetrics.widthPixels
        val targetW = dpToPx(276).coerceAtMost(screenW - dpToPx(24))
        val targetH = dpToPx(52)
        val params = layoutParams ?: return
        params.x = ((screenW - targetW) / 2).coerceAtLeast(dpToPx(12))
        glowDrawable.isExpandedSurface = false
        glowDrawable.setCornerRadiusPx(dpToPx(26).toFloat())
        animateShellSize(targetW, targetH)
        runCatching { windowManager?.updateViewLayout(rootView, params) }
    }

    private fun expandToCard(prefillText: String?, focusKeyboard: Boolean) {
        val params = layoutParams ?: return
        visualState = IslandVisualState.EXPANDED_CARD

        val screenW = resources.displayMetrics.widthPixels
        val targetW = dpToPx(348).coerceAtMost(screenW - dpToPx(20))

        params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        @Suppress("DEPRECATION")
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        params.x = ((screenW - targetW) / 2).coerceAtLeast(dpToPx(10))

        glowDrawable.isExpandedSurface = true
        glowDrawable.setCornerRadiusPx(dpToPx(26).toFloat())

        collapseBtn?.visibility = View.VISIBLE
        expandedPanel?.visibility = View.VISIBLE

        val shell = shellContainer
        if (shell != null) {
            shell.animate().cancel()
            morphAnimator?.cancel()
            val lp = shell.layoutParams
            lp.width = targetW
            lp.height = LinearLayout.LayoutParams.WRAP_CONTENT
            shell.layoutParams = lp
            shell.pivotX = targetW / 2f
            shell.pivotY = 0f
            shell.scaleX = 0.92f
            shell.scaleY = 0.90f
            shell.alpha = 0.86f
            shell.animate()
                .scaleX(1f)
                .scaleY(1f)
                .alpha(1f)
                .setDuration(280L)
                .setInterpolator(SMOOTH_SPRING)
                .start()
        }

        if (!prefillText.isNullOrBlank()) {
            inputEdit?.setText(prefillText)
            inputEdit?.setSelection(prefillText.length)
        }
        if (lastIslandAnswer.isNotBlank() && JarvisApplication.instance.prefs.islandShowAnswerInside) {
            answerScroll?.visibility = View.VISIBLE
            answerText?.text = RichTextFormatter.format(this, lastIslandAnswer)
        }

        runCatching { windowManager?.updateViewLayout(rootView, params) }

        if (focusKeyboard) {
            inputEdit?.requestFocus()
            mainHandler.postDelayed({
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.showSoftInput(inputEdit, InputMethodManager.SHOW_IMPLICIT)
            }, 140L)
        }
    }

    private fun collapseToIdlePill() {
        val params = layoutParams ?: return
        visualState = IslandVisualState.COLLAPSED_IDLE
        forceShowAssistantPanel = false
        autoExpandedForCall = false
        showTopBarDuringCall = false
        notifReplyRow?.visibility = View.GONE
        pillContainer?.visibility = View.VISIBLE

        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        inputEdit?.windowToken?.let { imm?.hideSoftInputFromWindow(it, 0) }

        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        expandedPanel?.visibility = View.GONE
        voiceBanner?.visibility = View.GONE
        collapseBtn?.visibility = View.GONE
        applyVisualSettingsAndGeometry(animate = true)
        renderPriorityState()
    }

    private fun submitIslandMessage() {
        val text = inputEdit?.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return
        val app = JarvisApplication.instance
        inputEdit?.setText("")
        voiceBanner?.visibility = View.GONE

        val showInside = app.prefs.islandShowAnswerInside
        if (showInside) {
            answerScroll?.visibility = View.VISIBLE
            answerText?.text = "Думаю…"
        } else {
            collapseToIdlePill()
            openMainActivity()
        }

        serviceScope.launch {
            val saved = app.chatCoordinator.sendMessage(
                rawUserText = text,
                imagePath = null,
                config = app.prefs.buildGenerationConfig(
                    profileId = app.prefs.activeProfileId,
                    source = RequestSource.DYNAMIC_ISLAND
                )
            )
            lastIslandAnswer = saved.text
            if (showInside && visualState == IslandVisualState.EXPANDED_CARD) {
                answerScroll?.visibility = View.VISIBLE
                answerText?.text = RichTextFormatter.format(this@IslandForegroundService, saved.text)
            }
        }
    }

    private fun showTransientStatus(text: String) {
        centerStatusText?.text = text
        setGlowActive(true)
        mainHandler.postDelayed({
            if (!isRecordingVoice && !isGeneratingNow) {
                setGlowActive(false)
                renderPriorityState()
            }
        }, 2500L)
    }

    private fun observeAppFlows() {
        val app = JarvisApplication.instance
        stateJobs.forEach { it.cancel() }
        stateJobs.clear()

        // 1) Calls (Priority #1 — immediately expand into compact iPhone Call capsule!)
        callManager?.let { cm ->
            stateJobs += serviceScope.launch {
                cm.activeCall.collectLatest { call ->
                    val enabled = app.prefs.islandCallsEnabled
                    val prevCall = currentSnapshot.activeCall
                    currentSnapshot = priorityEngine.setCall(if (enabled) call else null, app.prefs.assistantName)
                    if (enabled && call != null) {
                        if (visualState == IslandVisualState.COLLAPSED_IDLE) {
                            forceShowAssistantPanel = false
                            showTopBarDuringCall = false
                            autoExpandedForCall = true
                            expandToCard(prefillText = null, focusKeyboard = false)
                        }
                    } else if (prevCall != null && autoExpandedForCall && !forceShowAssistantPanel) {
                        autoExpandedForCall = false
                        showTopBarDuringCall = false
                        if (visualState == IslandVisualState.EXPANDED_CARD) {
                            collapseToIdlePill()
                        }
                    }
                    renderPriorityState()
                }
            }
        }
        stateJobs += serviceScope.launch {
            JarvisNotificationListenerService.currentCallNotification.collectLatest { notifCall ->
                callManager?.onCallNotificationChanged(notifCall)
            }
        }

        // 2) Live Notifications (Priority #2, NO history)
        stateJobs += serviceScope.launch {
            JarvisNotificationListenerService.currentNotification.collectLatest { notif ->
                val enabled = app.prefs.islandNotificationsEnabled
                currentSnapshot = priorityEngine.setNotification(if (enabled) notif else null, app.prefs.assistantName)
                notifAutoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
                if (enabled && notif != null && currentSnapshot.activeMode == IslandPriorityMode.NOTIFICATION) {
                    val r = Runnable {
                        if (visualState == IslandVisualState.COLLAPSED_IDLE) {
                            currentSnapshot = priorityEngine.dismissNotificationByKey(notif.key, app.prefs.assistantName)
                            renderPriorityState()
                        }
                    }
                    notifAutoDismissRunnable = r
                    mainHandler.postDelayed(r, 9_000L)
                }
                renderPriorityState()
            }
        }

        // 3) Live Music + Visualizer FFT (Priority #3)
        mediaController?.let { mc ->
            stateJobs += serviceScope.launch {
                mc.musicInfo.collectLatest { music ->
                    val enabled = app.prefs.islandMusicEnabled
                    currentSnapshot = priorityEngine.setMusic(if (enabled) music else null, app.prefs.assistantName)
                    renderPriorityState()
                }
            }
            stateJobs += serviceScope.launch {
                mc.artworkBitmap.collectLatest { bmp ->
                    if (bmp != null) musicCoverImg?.setImageBitmap(bmp)
                    renderPriorityState()
                }
            }
            stateJobs += serviceScope.launch {
                mc.audioBands.collectLatest { bands ->
                    waveformView?.setAudioBands(bands)
                    musicEqView?.setAudioBands(bands)
                }
            }
        }

        // 4) Chat & Thinking state
        stateJobs += serviceScope.launch {
            app.chatCoordinator.uiState.collectLatest { chatState ->
                isGeneratingNow = chatState.isGenerating
                sendBtn?.setImageResource(if (chatState.isGenerating) R.drawable.ic_stop_square else R.drawable.ic_arrow_up)

                if (chatState.isGenerating) {
                    val kurumi = app.prefs.kurumiThemeEnabled
                    glowDrawable.kurumiPalette = kurumi
                    setGlowActive(true)
                    waveformView?.setMode(IslandWaveformView.Mode.GENERATING)
                    val thinkText = chatState.statusBannerRu ?: if (kurumi) "Зафкиэль…" else "Думаю…"
                    centerStatusText?.text = thinkText
                    avatarImage?.setThinking(true)

                    thinkingRow?.visibility = View.VISIBLE
                    thinkingTitle?.text = app.prefs.assistantName
                    thinkingTitle?.setTextColor(if (kurumi) Color.parseColor("#FFD54F") else Color.WHITE)
                    thinkingSubtitle?.text = chatState.statusBannerRu ?: if (kurumi) "Сверяется с часами Зафкиэля…" else "Думает над ответом…"
                    thinkingAvatar?.setThinking(true)

                    if (app.prefs.islandShowAnswerInside && visualState == IslandVisualState.EXPANDED_CARD &&
                        chatState.liveStreamingText.isNotBlank()
                    ) {
                        lastIslandAnswer = chatState.liveStreamingText
                        answerScroll?.visibility = View.VISIBLE
                        answerText?.text = RichTextFormatter.format(this@IslandForegroundService, chatState.liveStreamingText)
                        answerScroll?.post { answerScroll?.fullScroll(View.FOCUS_DOWN) }
                    }
                    if (app.avatarManager.getThinkingGifFile() == null) {
                        startVideoAvatarPlayback()
                    }
                } else {
                    stopVideoAvatarPlayback()
                    avatarImage?.setThinking(false)
                    thinkingAvatar?.setThinking(false)
                    thinkingRow?.visibility = View.GONE
                    if (!isRecordingVoice) {
                        setGlowActive(false)
                        renderPriorityState()
                    }
                }
            }
        }

        // 5) Voice STT live state
        stateJobs += serviceScope.launch {
            app.voiceEngine.state.collectLatest { vState ->
                when (vState) {
                    is VoiceState.Recording -> {
                        val live = if (vState.partialText.isBlank()) "Слушаю…" else vState.partialText
                        centerStatusText?.text = live
                        voiceBanner?.visibility = View.VISIBLE
                        voiceBanner?.text = live
                    }
                    is VoiceState.Transcribing -> {
                        waveformView?.setMode(IslandWaveformView.Mode.GENERATING)
                        centerStatusText?.text = "Распознаю…"
                        voiceBanner?.visibility = View.VISIBLE
                        voiceBanner?.text = vState.statusRu
                    }
                    else -> Unit
                }
            }
        }
    }

    /**
     * Renders the strict priority state (CALL > NOTIFICATION > MUSIC > IDLE) in both compact capsule
     * and expanded card, plus B5 left button «Открыть «{assistantName}»» when occupied!
     */
    private fun renderPriorityState() {
        val prefs = JarvisApplication.instance.prefs
        currentSnapshot = priorityEngine.resolve(prefs.assistantName)
        val snap = currentSnapshot

        // B5: Left «Открыть «{assistantName}»» button whenever occupied by Call, Notification, or Music
        if (snap.isOccupiedByLiveContent) {
            quickOpenAssistantBtn?.visibility = View.VISIBLE
            quickOpenAssistantBtn?.text = snap.assistantQuickOpenLabel
        } else {
            quickOpenAssistantBtn?.visibility = View.GONE
        }

        // Update top capsule visuals unless actively recording or generating
        if (!isRecordingVoice && !isGeneratingNow) {
            when (snap.activeMode) {
                IslandPriorityMode.CALL -> {
                    val c = snap.activeCall
                    liveMediaIcon?.visibility = View.GONE
                    avatarImage?.visibility = View.VISIBLE
                    val timer = if (c != null && !c.isIncoming && c.connectedAtMs > 0L) {
                        " • ${IslandPriorityEngine.formatCallTimer(c.connectedAtMs)}"
                    } else ""
                    centerStatusText?.text = if (c?.isIncoming == true) "Звонок: ${c.callerName}" else "${c?.callerName ?: "Звонок"}$timer"
                    waveformView?.setMode(IslandWaveformView.Mode.LISTENING)
                    setGlowActive(true)
                }
                IslandPriorityMode.NOTIFICATION -> {
                    val n = snap.activeNotification
                    val icon = JarvisNotificationListenerService.currentNotificationIcon.value
                    if (icon != null) {
                        liveMediaIcon?.setImageBitmap(icon)
                        liveMediaIcon?.visibility = View.VISIBLE
                        avatarImage?.visibility = View.GONE
                    } else {
                        liveMediaIcon?.visibility = View.GONE
                        avatarImage?.visibility = View.VISIBLE
                    }
                    centerStatusText?.text = "${n?.appLabel}: ${n?.title}".take(34)
                    waveformView?.setMode(IslandWaveformView.Mode.IDLE)
                    setGlowActive(false)
                }
                IslandPriorityMode.MUSIC -> {
                    val m = snap.activeMusic
                    val art = mediaController?.artworkBitmap?.value
                    if (art != null) {
                        liveMediaIcon?.setImageBitmap(art)
                        liveMediaIcon?.visibility = View.VISIBLE
                        avatarImage?.visibility = View.GONE
                    } else {
                        liveMediaIcon?.visibility = View.GONE
                        avatarImage?.visibility = View.VISIBLE
                    }
                    centerStatusText?.text = m?.title?.take(26).orEmpty()
                    waveformView?.setMode(
                        if (m?.isPlaying == true) IslandWaveformView.Mode.MUSIC_REACTIVE
                        else IslandWaveformView.Mode.IDLE
                    )
                    setGlowActive(false)
                }
                IslandPriorityMode.IDLE -> {
                    liveMediaIcon?.visibility = View.GONE
                    avatarImage?.visibility = View.VISIBLE
                    centerStatusText?.text = if (visualState == IslandVisualState.EXPANDED_CARD) prefs.assistantName else ""
                    waveformView?.setMode(IslandWaveformView.Mode.IDLE)
                    setGlowActive(false)
                }
            }
        }

        // Adapt collapsed capsule width cleanly when occupied so left button + icon + title + EQ fit nicely
        if (visualState == IslandVisualState.COLLAPSED_IDLE) {
            val screenW = resources.displayMetrics.widthPixels
            val baseW = dpToPx(prefs.islandWidthDp)
            val desiredW = if (snap.isOccupiedByLiveContent) {
                maxOf(baseW, dpToPx(296)).coerceAtMost(screenW - dpToPx(16))
            } else baseW
            val desiredH = dpToPx(prefs.islandHeightDp)
            val lp = shellContainer?.layoutParams
            if (lp != null && lp.width != desiredW) {
                lp.width = desiredW
                lp.height = desiredH
                shellContainer?.layoutParams = lp
                layoutParams?.let { p ->
                    if (prefs.islandPosX < 0 || snap.isOccupiedByLiveContent) {
                        p.x = ((screenW - desiredW) / 2).coerceAtLeast(dpToPx(8))
                        runCatching { windowManager?.updateViewLayout(rootView, p) }
                    }
                }
            }
        }

        // Expanded panels: show top-priority live card + assistant section when requested or IDLE
        val showCall = snap.activeMode == IslandPriorityMode.CALL && snap.activeCall != null
        val showNotif = snap.activeMode == IslandPriorityMode.NOTIFICATION && snap.activeNotification != null
        val showMusic = snap.activeMode == IslandPriorityMode.MUSIC && snap.activeMusic != null

        // Compact iPhone call capsule hides the redundant top bar unless user tapped call info or opened assistant
        val hideTopBarForCompactCall = visualState == IslandVisualState.EXPANDED_CARD &&
            showCall && !forceShowAssistantPanel && !showTopBarDuringCall
        pillContainer?.visibility = if (hideTopBarForCompactCall) View.GONE else View.VISIBLE

        callPanel?.visibility = if (showCall) View.VISIBLE else View.GONE
        notifPanel?.visibility = if (showNotif) View.VISIBLE else View.GONE
        musicPanel?.visibility = if (showMusic) View.VISIBLE else View.GONE
        assistantSection?.visibility = if (!snap.isOccupiedByLiveContent || forceShowAssistantPanel) View.VISIBLE else View.GONE

        if (showCall) {
            val c = snap.activeCall!!
            callCallerName?.text = c.callerName
            if (c.isIncoming) {
                callStatusLabel?.text = "Входящий звонок"
                callStatusLabel?.setTextColor(Color.parseColor("#30D158"))
                callPrimaryBtn?.setBackgroundResource(R.drawable.bg_ios_circle_green)
                callPrimaryBtn?.setImageResource(R.drawable.ic_ios_call_accept)
                callPrimaryBtn?.imageTintList = ColorStateList.valueOf(Color.WHITE)
                callPrimaryBtn?.contentDescription = "Принять звонок"
            } else {
                val liveTimer = if (c.connectedAtMs > 0L) {
                    IslandPriorityEngine.formatCallTimer(c.connectedAtMs)
                } else "00:00"
                callStatusLabel?.text = liveTimer
                callStatusLabel?.setTextColor(Color.parseColor("#30D158"))
                callPrimaryBtn?.setImageResource(R.drawable.ic_ios_speaker)
                if (c.isSpeakerOn) {
                    callPrimaryBtn?.setBackgroundResource(R.drawable.bg_ios_circle_white)
                    callPrimaryBtn?.imageTintList = ColorStateList.valueOf(Color.parseColor("#111111"))
                } else {
                    callPrimaryBtn?.setBackgroundResource(R.drawable.bg_ios_circle_glass)
                    callPrimaryBtn?.imageTintList = ColorStateList.valueOf(Color.WHITE)
                }
                callPrimaryBtn?.contentDescription = if (c.isSpeakerOn) "Выключить громкую связь" else "Включить громкую связь"
            }
        }

        if (showNotif) {
            val n = snap.activeNotification!!
            notifAppLabel?.text = n.appLabel
            notifTitleTv?.text = n.title
            notifBodyTv?.text = n.text
            renderRealNotificationActions(n)
        }

        if (showMusic) {
            val m = snap.activeMusic!!
            musicSourceTv?.text = m.appLabel.ifBlank { "Музыка" }
            musicTitleTv?.text = m.title
            musicArtistTv?.text = m.artist.ifBlank { m.appLabel.ifBlank { "Аудиоплеер" } }
            musicPlayBtn?.setImageResource(
                if (m.isPlaying) R.drawable.ic_ios_media_pause else R.drawable.ic_ios_media_play
            )
            musicEqView?.setMode(
                if (m.isPlaying) IslandWaveformView.Mode.MUSIC_REACTIVE
                else IslandWaveformView.Mode.IDLE
            )
            mediaController?.artworkBitmap?.value?.let { musicCoverImg?.setImageBitmap(it) }
            updateLiveMusicProgressAndVolume(m)
        }

        syncLiveTicker(
            needTicker = (showCall && snap.activeCall?.isIncoming == false) ||
                (showMusic && visualState == IslandVisualState.EXPANDED_CARD)
        )
    }

    private fun syncLiveTicker(needTicker: Boolean) {
        if (needTicker && !liveTickerRunning) {
            liveTickerRunning = true
            mainHandler.removeCallbacks(liveTickerRunnable)
            mainHandler.postDelayed(liveTickerRunnable, 1000L)
        } else if (!needTicker && liveTickerRunning) {
            liveTickerRunning = false
            mainHandler.removeCallbacks(liveTickerRunnable)
        }
    }

    private fun updateLiveTimersAndProgress() {
        val snap = currentSnapshot
        if (snap.activeMode == IslandPriorityMode.CALL && snap.activeCall != null) {
            val c = snap.activeCall
            if (!c.isIncoming && c.connectedAtMs > 0L) {
                val timerStr = IslandPriorityEngine.formatCallTimer(c.connectedAtMs)
                callStatusLabel?.text = timerStr
                if (visualState == IslandVisualState.COLLAPSED_IDLE && !isRecordingVoice && !isGeneratingNow) {
                    centerStatusText?.text = "${c.callerName} • $timerStr"
                }
            }
        } else if (snap.activeMode == IslandPriorityMode.MUSIC &&
            snap.activeMusic != null &&
            visualState == IslandVisualState.EXPANDED_CARD
        ) {
            updateLiveMusicProgressAndVolume(snap.activeMusic)
        } else {
            syncLiveTicker(false)
        }
    }

    private fun updateLiveMusicProgressAndVolume(music: IslandMusicInfo) {
        val mc = mediaController ?: return
        if (!isUserSeekingTrack) {
            val dur = music.durationMs
            val pos = mc.getInterpolatedPositionMs()
            musicElapsedTv?.text = IslandPriorityEngine.formatMediaDuration(pos)
            musicRemainingTv?.text = IslandPriorityEngine.formatMediaRemaining(pos, dur)
            if (dur > 0L) {
                musicSeekBar?.isEnabled = true
                musicSeekBar?.progress = ((pos * 1000L) / dur).toInt().coerceIn(0, 1000)
            } else {
                musicSeekBar?.isEnabled = false
                musicSeekBar?.progress = 0
            }
        }
        if (!isUserAdjustingVolume) {
            musicVolumeSeekBar?.progress = mc.getMediaVolumePercent()
        }
    }

    /** B1: Renders ONLY real system Notification.Action buttons (zero fake actions!). */
    private fun renderRealNotificationActions(notif: IslandNotificationInfo) {
        val row = notifActionsRow ?: return
        row.removeAllViews()
        if (notif.actions.isEmpty()) {
            row.visibility = View.GONE
            return
        }
        row.visibility = View.VISIBLE
        val d = resources.displayMetrics.density
        for (act in notif.actions.take(3)) {
            val btn = TextView(this).apply {
                text = act.title
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#93C5FD"))
                background = getDrawable(R.drawable.bg_glass_pill)
                textSize = 11.5f
                setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = (6 * d).toInt()
                }
                setOnClickListener {
                    if (act.hasRemoteInput) {
                        pendingReplyActionKey = notif.key
                        pendingReplyActionIdx = act.index
                        notifReplyEdit?.hint = act.remoteInputHint ?: "Быстрый ответ…"
                        notifReplyRow?.visibility = View.VISIBLE
                        notifReplyEdit?.requestFocus()
                        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                        imm?.showSoftInput(notifReplyEdit, InputMethodManager.SHOW_IMPLICIT)
                    } else {
                        val ok = JarvisNotificationListenerService.instance?.executeRealAction(notif.key, act.index) == true
                        if (ok) {
                            currentSnapshot = priorityEngine.dismissNotificationByKey(
                                notif.key,
                                JarvisApplication.instance.prefs.assistantName
                            )
                            renderPriorityState()
                        }
                    }
                }
            }
            row.addView(btn)
        }
    }

    private fun setGlowActive(active: Boolean) {
        if (!::glowDrawable.isInitialized) return
        glowDrawable.glowActive = active
        if (active) {
            if (glowAnimator?.isRunning != true) {
                glowAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
                    duration = 2800L
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { glowDrawable.glowAngleDeg = it.animatedValue as Float }
                    start()
                }
            }
        } else {
            glowAnimator?.cancel()
            glowAnimator = null
        }
    }

    private fun applyVisualSettingsAndGeometry(animate: Boolean) {
        val app = JarvisApplication.instance
        val prefs = app.prefs
        touchController?.dragLocked = prefs.islandLockDrag
        inputEdit?.hint = "Спросить ${prefs.assistantName}…"

        glowDrawable.kurumiPalette = prefs.kurumiThemeEnabled
        val staticImg = app.avatarManager.getStaticImageFile()
        val thinkingGif = app.avatarManager.getThinkingGifFile()
        avatarImage?.bindMedia(staticImg, thinkingGif, prefs.kurumiThemeEnabled)
        thinkingAvatar?.bindMedia(staticImg, thinkingGif, prefs.kurumiThemeEnabled)

        if (visualState != IslandVisualState.COLLAPSED_IDLE) return

        val screenW = resources.displayMetrics.widthPixels
        val baseW = dpToPx(prefs.islandWidthDp)
        val targetW = if (currentSnapshot.isOccupiedByLiveContent) {
            maxOf(baseW, dpToPx(296)).coerceAtMost(screenW - dpToPx(16))
        } else baseW
        val targetH = dpToPx(prefs.islandHeightDp)
        val avatarSize = (targetH - dpToPx(6)).coerceIn(dpToPx(24), dpToPx(48))

        pillContainer?.layoutParams = (pillContainer?.layoutParams as? LinearLayout.LayoutParams)?.apply {
            height = targetH
        }
        avatarFrame?.layoutParams = (avatarFrame?.layoutParams as? LinearLayout.LayoutParams)?.apply {
            width = avatarSize
            height = avatarSize
        }

        glowDrawable.isExpandedSurface = false
        glowDrawable.setCornerRadiusPx(dpToPx(prefs.islandCornerRadiusDp).toFloat())

        val params = layoutParams
        if (params != null) {
            params.x = if (prefs.islandPosX < 0 || currentSnapshot.isOccupiedByLiveContent) {
                ((screenW - targetW) / 2).coerceAtLeast(dpToPx(8))
            } else {
                prefs.islandPosX.coerceIn(0, (screenW - dpToPx(60)).coerceAtLeast(0))
            }
            params.y = prefs.islandPosY.coerceAtLeast(0)
            runCatching { windowManager?.updateViewLayout(rootView, params) }
        }

        if (animate) {
            animateShellSize(targetW, targetH)
        } else {
            shellContainer?.layoutParams = (shellContainer?.layoutParams as? FrameLayout.LayoutParams)?.apply {
                width = targetW
                height = targetH
            }
            shellContainer?.requestLayout()
        }
    }

    private fun animateShellSize(targetW: Int, targetH: Int) {
        val shell = shellContainer ?: return
        val lp = shell.layoutParams ?: return
        val startW = if (shell.width > 0) shell.width else targetW
        val startH = if (shell.height > 0) shell.height else targetH
        morphAnimator?.cancel()
        morphAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280L
            interpolator = SMOOTH_SPRING
            addUpdateListener { anim ->
                val f = anim.animatedValue as Float
                lp.width = (startW + (targetW - startW) * f).roundToInt().coerceAtLeast(dpToPx(80))
                lp.height = (startH + (targetH - startH) * f).roundToInt().coerceAtLeast(dpToPx(26))
                shell.layoutParams = lp
            }
            start()
        }
    }

    private fun startVideoAvatarPlayback() {
        val videoFile: File = JarvisApplication.instance.avatarManager.getVideoAvatarFile() ?: return
        val tv = avatarVideo ?: return
        tv.visibility = View.VISIBLE
        avatarImage?.visibility = View.INVISIBLE

        val surface = videoSurface ?: return
        releaseVideoAvatar()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(videoFile.absolutePath)
            mp.setSurface(surface)
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            mp.setOnPreparedListener { player ->
                if (isGeneratingNow) player.start() else stopVideoAvatarPlayback()
            }
            mp.setOnErrorListener { _, _, _ ->
                stopVideoAvatarPlayback()
                true
            }
            mp.prepareAsync()
            mediaPlayer = mp
        } catch (_: Throwable) {
            stopVideoAvatarPlayback()
        }
    }

    private fun stopVideoAvatarPlayback() {
        releaseVideoAvatar()
        avatarVideo?.visibility = View.GONE
        if (liveMediaIcon?.visibility != View.VISIBLE) {
            avatarImage?.visibility = View.VISIBLE
        }
    }

    private fun releaseVideoAvatar() {
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.reset()
            mediaPlayer?.release()
        }
        mediaPlayer = null
    }

    private fun openMainActivity() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID,
                "Jarvis Dynamic Island",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Постоянное уведомление Dynamic Island"
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(recordingMic: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, IslandForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val name = JarvisApplication.instance.prefs.assistantName
        val title = if (recordingMic) "$name: запись микрофона" else "$name Dynamic Island активен"
        val body = if (recordingMic) "Запись речи активна." else "Тап — раскрыть • Удержание — голос • Уведомления, музыка, звонки."

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_jarvis_status)
            .setContentTitle(title)
            .setContentText(body)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openIntent)
            .addAction(0, "Скрыть", stopIntent)
            .build()
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        JarvisApplication.instance.agentToolExecutor.onBeforeScreenInteraction = null
        JarvisInCallService.onCallUpdated = null
        JarvisNotificationListenerService.onListenerStateChanged = null
        mediaController?.stop()
        callManager?.stop()
        syncLiveTicker(false)
        notifAutoDismissRunnable?.let { mainHandler.removeCallbacks(it) }
        cancelLongPressTimer()
        glowAnimator?.cancel()
        morphAnimator?.cancel()
        if (isRecordingVoice) {
            JarvisApplication.instance.voiceEngine.stopRecording()
            isRecordingVoice = false
        }
        releaseVideoAvatar()
        videoSurface?.release()
        videoSurface = null
        stateJobs.forEach { it.cancel() }
        stateJobs.clear()
        serviceScope.cancel()
        rootView?.let { v -> runCatching { windowManager?.removeViewImmediate(v) } }
        rootView = null
    }

    companion object {
        private val SMOOTH_SPRING = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        private const val CHANNEL_ID = "jarvis_dynamic_island_channel"
        private const val NOTIFICATION_ID = 4102
        const val ACTION_START = "ru.jarvis.assistant.island.START"
        const val ACTION_STOP = "ru.jarvis.assistant.island.STOP"
        const val ACTION_REFRESH = "ru.jarvis.assistant.island.REFRESH"
        const val ACTION_STATUS_FLASH = "ru.jarvis.assistant.island.STATUS_FLASH"
        const val EXTRA_STATUS_TEXT = "extra_status_text"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            startSafe(context)
        }

        /** A1: Crash-safe ForegroundService starter for Android 10–14 (including boot & background resume). */
        fun startSafe(context: Context): Boolean {
            if (!Settings.canDrawOverlays(context)) return false
            return try {
                val intent = Intent(context, IslandForegroundService::class.java).setAction(ACTION_START)
                ContextCompat.startForegroundService(context, intent)
                true
            } catch (_: Throwable) {
                false
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, IslandForegroundService::class.java))
        }

        fun refresh(context: Context) {
            if (!isRunning) return
            runCatching {
                val intent = Intent(context, IslandForegroundService::class.java).setAction(ACTION_REFRESH)
                context.startService(intent)
            }
        }

        fun flashStatus(context: Context, statusText: String) {
            if (!isRunning) return
            runCatching {
                val intent = Intent(context, IslandForegroundService::class.java)
                    .setAction(ACTION_STATUS_FLASH)
                    .putExtra(EXTRA_STATUS_TEXT, statusText)
                context.startService(intent)
            }
        }
    }
}
