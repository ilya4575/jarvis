package ru.jarvis.assistant.feature.accessibility

enum class RiskLevel {
    SAFE_PREVIEW_REQUIRED,
    HIGH_RISK_DOUBLE_CONFIRM,
    HARD_BLOCKED_SENSITIVE
}

enum class ActionStepType {
    LAUNCH_APP,
    FIND_AND_CLICK_TEXT,
    INPUT_TEXT_IN_FOCUSED
}

data class PlannedActionStep(
    val type: ActionStepType,
    val targetLabel: String,
    val payload: String? = null,
    val descriptionRu: String
)

data class ActionPlan(
    val originalCommand: String,
    val targetAppName: String?,
    val targetPackageName: String?,
    val steps: List<PlannedActionStep>,
    val riskLevel: RiskLevel,
    val riskReasonRu: String?
)

data class ScreenSafetyInspection(
    val isSensitiveBlocked: Boolean,
    val reasonRu: String? = null
)

/**
 * Enforces strict safety boundaries for Android Accessibility automation:
 * 1. Hard-blocks automation on password, PIN, MFA/OTP, payment/card, CAPTCHA, and biometric/security screens.
 * 2. Requires separate explicit high-warning confirmation for messaging, deleting, modifying, publishing, or purchases.
 * 3. Never invents raw blind screen coordinates — builds transparent text/node-verified step plans.
 */
object AccessibilitySafetyGuard {

    private val BLOCKED_KEYWORDS = listOf(
        "парол", "password", "passcode", "pin-код", "пин-код", "пин код", "enter pin",
        "код подтвержден", "одноразов", "otp", "mfa", "2fa", "смс-код", "sms code", "двухфактор",
        "номер карты", "cvv", "cvc", "срок действия карты", "card number", "банковск", "реквизит",
        "captcha", "капча", "я не робот", "i am not a robot", "recaptcha",
        "биометр", "отпечаток", "face id", "fingerprint", "biometric", "разблокиров", "подтвердите личность"
    )

    private val SENSITIVE_PACKAGE_HINTS = listOf(
        "biometric", "keyguard", "lockscreen", "password", "keepass", "bitwarden", "1password", "lastpass",
        "authenticator", "google.android.apps.authenticator", "com.android.systemui"
    )

    private val HIGH_RISK_COMMAND_KEYWORDS = listOf(
        "отправ", "напиш", "перешл", "send", "удал", "стер", "очист", "delete", "remove",
        "опублик", "вылож", "пост", "publish", "купи", "оплат", "перевед", "закаж", "buy", "pay", "purchase",
        "измен", "сохран", "сброс"
    )

    fun inspectScreen(
        packageName: String?,
        visibleTexts: List<String>,
        hasPasswordField: Boolean
    ): ScreenSafetyInspection {
        if (hasPasswordField) {
            return ScreenSafetyInspection(
                isSensitiveBlocked = true,
                reasonRu = "Обнаружено поле ввода пароля/PIN — автоматизация остановлена. Продолжите вручную."
            )
        }
        val pkgLower = packageName?.lowercase().orEmpty()
        if (SENSITIVE_PACKAGE_HINTS.any { pkgLower.contains(it) }) {
            return ScreenSafetyInspection(
                isSensitiveBlocked = true,
                reasonRu = "Защищённый экран системы/безопасности ($packageName) — управление передано человеку."
            )
        }
        val combined = visibleTexts.joinToString(" ").lowercase()
        val matched = BLOCKED_KEYWORDS.firstOrNull { combined.contains(it) }
        if (matched != null) {
            return ScreenSafetyInspection(
                isSensitiveBlocked = true,
                reasonRu = "Обнаружен защищённый/чувствительный экран (триггер: «$matched»). Автоматизация запрещена — выполните действие вручную."
            )
        }
        return ScreenSafetyInspection(isSensitiveBlocked = false)
    }

    fun classifyCommandRisk(command: String): Pair<RiskLevel, String?> {
        val lower = command.lowercase()
        val blocked = BLOCKED_KEYWORDS.firstOrNull { lower.contains(it) }
        if (blocked != null) {
            return RiskLevel.HARD_BLOCKED_SENSITIVE to
                "Команда затрагивает запрещённую категорию («$blocked»: пароли, PIN, MFA, оплата, CAPTCHA или биометрия). Автоматизация таких действий отключена."
        }
        val highRisk = HIGH_RISK_COMMAND_KEYWORDS.firstOrNull { lower.contains(it) }
        if (highRisk != null) {
            return RiskLevel.HIGH_RISK_DOUBLE_CONFIRM to
                "Команда может отправить сообщение, удалить/изменить данные, опубликовать контент или инициировать оплату («$highRisk»). Требуется отдельное подтверждение."
        }
        return RiskLevel.SAFE_PREVIEW_REQUIRED to null
    }

    /**
     * Parses a user command into a transparent step-by-step ActionPlan.
     * Examples:
     * - "Открой Настройки" -> [LAUNCH_APP]
     * - "Открой Калькулятор и нажми 5" -> [LAUNCH_APP, FIND_AND_CLICK_TEXT("5")]
     * - "Нажми Поиск" -> [FIND_AND_CLICK_TEXT("Поиск")]
     */
    fun buildPlan(
        command: String,
        appResolver: (String) -> Pair<String, String>? // query -> (displayName, packageName)
    ): ActionPlan {
        val trimmed = command.trim()
        val (risk, riskReason) = classifyCommandRisk(trimmed)
        if (risk == RiskLevel.HARD_BLOCKED_SENSITIVE) {
            return ActionPlan(
                originalCommand = trimmed,
                targetAppName = null,
                targetPackageName = null,
                steps = emptyList(),
                riskLevel = risk,
                riskReasonRu = riskReason
            )
        }

        val steps = mutableListOf<PlannedActionStep>()
        var resolvedAppName: String? = null
        var resolvedPkg: String? = null

        val openRegex = Regex("""(?:открой|запусти|open|launch)\s+([^,.;]+?)(?=\s+(?:и\s+нажми|и\s+введи|и\s+кликни|$))""", RegexOption.IGNORE_CASE)
        openRegex.find(trimmed)?.let { m ->
            val appQuery = m.groupValues[1].trim()
            val resolved = appResolver(appQuery)
            if (resolved != null) {
                resolvedAppName = resolved.first
                resolvedPkg = resolved.second
                steps.add(
                    PlannedActionStep(
                        type = ActionStepType.LAUNCH_APP,
                        targetLabel = resolved.first,
                        payload = resolved.second,
                        descriptionRu = "Запустить приложение «${resolved.first}» (${resolved.second})"
                    )
                )
            } else {
                steps.add(
                    PlannedActionStep(
                        type = ActionStepType.LAUNCH_APP,
                        targetLabel = appQuery,
                        payload = null,
                        descriptionRu = "Приложение «$appQuery» не найдено среди установленных"
                    )
                )
            }
        }

        val clickRegex = Regex("""(?:нажми|кликни|выбери|tap|click)\s+[«"']?([^»"'.,;]+)[»"']?""", RegexOption.IGNORE_CASE)
        clickRegex.findAll(trimmed).forEach { m ->
            val target = m.groupValues[1].trim()
            if (target.isNotEmpty()) {
                steps.add(
                    PlannedActionStep(
                        type = ActionStepType.FIND_AND_CLICK_TEXT,
                        targetLabel = target,
                        descriptionRu = "Найти видимый элемент «$target» через AccessibilityService и нажать (с проверкой результата)"
                    )
                )
            }
        }

        val inputRegex = Regex("""(?:введи|напечатай)\s+[«"']([^»"']+)[»"']""", RegexOption.IGNORE_CASE)
        inputRegex.find(trimmed)?.let { m ->
            val textVal = m.groupValues[1]
            steps.add(
                PlannedActionStep(
                    type = ActionStepType.INPUT_TEXT_IN_FOCUSED,
                    targetLabel = "Активное текстовое поле",
                    payload = textVal,
                    descriptionRu = "Вставить текст в активное непарольное поле (с проверкой отсутствия пароля/PIN)"
                )
            )
        }

        // Fallback: try interpreting entire command as an app name to launch
        if (steps.isEmpty()) {
            val resolved = appResolver(trimmed)
            if (resolved != null) {
                resolvedAppName = resolved.first
                resolvedPkg = resolved.second
                steps.add(
                    PlannedActionStep(
                        type = ActionStepType.LAUNCH_APP,
                        targetLabel = resolved.first,
                        payload = resolved.second,
                        descriptionRu = "Запустить приложение «${resolved.first}» (${resolved.second})"
                    )
                )
            }
        }

        return ActionPlan(
            originalCommand = trimmed,
            targetAppName = resolvedAppName,
            targetPackageName = resolvedPkg,
            steps = steps,
            riskLevel = risk,
            riskReasonRu = riskReason
        )
    }
}
