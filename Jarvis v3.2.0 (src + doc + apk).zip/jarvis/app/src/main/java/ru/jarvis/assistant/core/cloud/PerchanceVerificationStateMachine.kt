package ru.jarvis.assistant.core.cloud

/**
 * Pure-Kotlin state machine for Perchance Cloudflare/WebView verification reliability (A2 + C3).
 * Unit-testable on JVM without Android framework dependencies.
 */
class PerchanceVerificationStateMachine(
    private val debounceWindowMs: Long = 2_500L,
    private val notificationCooldownMs: Long = 60_000L
) {
    data class Snapshot(
        val status: PerchanceVerifyStatus = PerchanceVerifyStatus.IDLE,
        val statusMessageRu: String = "Проверка не выполнена",
        val currentUrl: String = DEFAULT_URL,
        val networkGeneration: Int = 0,
        val lastVerifiedAtMs: Long = 0L,
        val lastCheckStartedAtMs: Long = 0L,
        val lastManualNotifyAtMs: Long = 0L
    ) {
        val isVerified: Boolean get() = status == PerchanceVerifyStatus.VERIFIED
    }

    var state: Snapshot = Snapshot()
        private set

    private var lastNetworkEventAtMs: Long = 0L
    private var lastNetworkSignature: String = ""

    fun isVerified(): Boolean = state.isVerified

    /**
     * Evaluates a network transition event (e.g. Wi-Fi <-> LTE / validated network change).
     * Returns true if auto-recheck should be triggered (respecting debounce and avoiding duplicate triggers).
     */
    fun onNetworkChanged(networkSignature: String, nowMs: Long, enabled: Boolean): Boolean {
        if (!enabled) return false
        if (networkSignature.isBlank()) return false
        val changed = networkSignature != lastNetworkSignature
        val withinDebounce = (nowMs - lastNetworkEventAtMs) < debounceWindowMs && !changed
        lastNetworkEventAtMs = nowMs
        if (withinDebounce) return false
        if (!changed && state.isVerified) return false
        lastNetworkSignature = networkSignature
        state = state.copy(
            status = PerchanceVerifyStatus.CHECKING,
            statusMessageRu = "Смена сети — автоматическая перепроверка Perchance…",
            networkGeneration = state.networkGeneration + 1,
            lastCheckStartedAtMs = nowMs
        )
        return true
    }

    fun onNetworkLost() {
        lastNetworkSignature = ""
        state = state.copy(
            status = PerchanceVerifyStatus.ERROR,
            statusMessageRu = "Нет подключения к интернету"
        )
    }

    /** Called when the user edits the Perchance URL — immediately resets verification and triggers recheck. */
    fun onUrlChanged(newUrl: String, nowMs: Long): Boolean {
        val normalized = newUrl.trim().ifBlank { DEFAULT_URL }
        if (normalized == state.currentUrl) return false
        state = state.copy(
            currentUrl = normalized,
            status = PerchanceVerifyStatus.CHECKING,
            statusMessageRu = "URL изменён — запуск перепроверки…",
            lastVerifiedAtMs = 0L,
            lastCheckStartedAtMs = nowMs
        )
        return true
    }

    fun onCheckStarted(nowMs: Long, reasonRu: String = "Проверка Perchance…") {
        state = state.copy(
            status = PerchanceVerifyStatus.CHECKING,
            statusMessageRu = reasonRu,
            lastCheckStartedAtMs = nowMs
        )
    }

    fun onVerified(nowMs: Long) {
        state = state.copy(
            status = PerchanceVerifyStatus.VERIFIED,
            statusMessageRu = "Проверка пройдена",
            lastVerifiedAtMs = nowMs
        )
    }

    fun onNeedsManualVerification(reasonRu: String = "Нужна проверка Cloudflare — нажмите «Проверить»") {
        state = state.copy(
            status = PerchanceVerifyStatus.NEEDS_VERIFICATION,
            statusMessageRu = reasonRu,
            lastVerifiedAtMs = 0L
        )
    }

    fun onError(reasonRu: String) {
        state = state.copy(
            status = PerchanceVerifyStatus.ERROR,
            statusMessageRu = reasonRu,
            lastVerifiedAtMs = 0L
        )
    }

    /**
     * Closing the verification dialog via the mandatory "×" button MUST NOT mark the provider verified.
     */
    fun onDialogClosedWithX() {
        if (state.status != PerchanceVerifyStatus.VERIFIED) {
            state = state.copy(
                status = PerchanceVerifyStatus.NEEDS_VERIFICATION,
                statusMessageRu = "Проверка отменена — нужна проверка перед использованием Perchance"
            )
        }
    }

    fun onSessionInvalidated(reasonRu: String = "Сессия истекла — требуется повторная проверка") {
        state = state.copy(
            status = PerchanceVerifyStatus.NEEDS_VERIFICATION,
            statusMessageRu = reasonRu,
            lastVerifiedAtMs = 0L
        )
    }

    /** Rate-limited notification gate so failed auto-checks never spam the notification shade. */
    fun shouldPostManualActionNotification(nowMs: Long): Boolean {
        if (state.status == PerchanceVerifyStatus.VERIFIED) return false
        if (nowMs - state.lastManualNotifyAtMs < notificationCooldownMs) return false
        state = state.copy(lastManualNotifyAtMs = nowMs)
        return true
    }

    companion object {
        const val DEFAULT_URL = "https://text-generation.perchance.org/embed"
    }
}
