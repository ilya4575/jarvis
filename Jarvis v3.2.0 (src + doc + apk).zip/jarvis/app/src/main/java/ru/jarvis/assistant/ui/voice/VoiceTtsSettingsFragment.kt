package ru.jarvis.assistant.ui.voice

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.models.ModelCatalog
import ru.jarvis.assistant.feature.avatar.ZafkielClockAvatarView
import ru.jarvis.assistant.feature.overlay.IslandForegroundService
import ru.jarvis.assistant.feature.voice.NeuralVoicePreset
import ru.jarvis.assistant.feature.voice.TtsEngineMode
import ru.jarvis.assistant.ui.MainActivity

class VoiceTtsSettingsFragment : Fragment() {

    private lateinit var kurumiBadgeAvatar: ZafkielClockAvatarView
    private lateinit var presetsContainer: LinearLayout
    private lateinit var playbackStatusTv: TextView
    private lateinit var rateLabel: TextView
    private lateinit var rateSeek: SeekBar
    private lateinit var pitchLabel: TextView
    private lateinit var pitchSeek: SeekBar
    private lateinit var autoSpeakSwitch: Switch
    private lateinit var engineSpinner: Spinner
    private lateinit var engineSubtitleTv: TextView
    private lateinit var testSelectedBtn: Button

    private lateinit var sampleStatusTv: TextView
    private lateinit var playSampleBtn: MaterialButton
    private lateinit var clearSampleBtn: MaterialButton
    private lateinit var sampleTextEdit: EditText

    private lateinit var fishGroup: LinearLayout
    private lateinit var fishKeyEdit: EditText
    private lateinit var fishIdEdit: EditText
    private lateinit var fishModelEdit: EditText

    private lateinit var elevenGroup: LinearLayout
    private lateinit var elevenKeyEdit: EditText
    private lateinit var elevenIdEdit: EditText

    private lateinit var puterTtsGroup: LinearLayout
    private lateinit var puterProviderEdit: EditText
    private lateinit var puterVoiceEdit: EditText
    private lateinit var puterModelEdit: EditText

    private lateinit var customUrlGroup: LinearLayout
    private lateinit var customUrlEdit: EditText
    private lateinit var customKeyEdit: EditText
    private lateinit var customModelEdit: EditText
    private lateinit var customVoiceEdit: EditText

    private val pickVoiceSampleLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) saveVoiceSample(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_voice_tts, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance
        val prefs = app.prefs

        kurumiBadgeAvatar = view.findViewById(R.id.voice_kurumi_badge_avatar)
        presetsContainer = view.findViewById(R.id.voice_presets_container)
        playbackStatusTv = view.findViewById(R.id.voice_playback_status)
        rateLabel = view.findViewById(R.id.voice_rate_label)
        rateSeek = view.findViewById(R.id.voice_rate_seek)
        pitchLabel = view.findViewById(R.id.voice_pitch_label)
        pitchSeek = view.findViewById(R.id.voice_pitch_seek)
        autoSpeakSwitch = view.findViewById(R.id.voice_autospeak_switch)
        engineSpinner = view.findViewById(R.id.voice_engine_spinner)
        engineSubtitleTv = view.findViewById(R.id.voice_engine_subtitle)
        testSelectedBtn = view.findViewById(R.id.voice_test_selected_btn)

        sampleStatusTv = view.findViewById(R.id.voice_sample_status)
        playSampleBtn = view.findViewById(R.id.voice_play_sample_btn)
        clearSampleBtn = view.findViewById(R.id.voice_clear_sample_btn)
        sampleTextEdit = view.findViewById(R.id.voice_sample_text_edit)

        fishGroup = view.findViewById(R.id.voice_fish_group)
        fishKeyEdit = view.findViewById(R.id.voice_fish_key_edit)
        fishIdEdit = view.findViewById(R.id.voice_fish_id_edit)
        fishModelEdit = view.findViewById(R.id.voice_fish_model_edit)

        elevenGroup = view.findViewById(R.id.voice_eleven_group)
        elevenKeyEdit = view.findViewById(R.id.voice_eleven_key_edit)
        elevenIdEdit = view.findViewById(R.id.voice_eleven_id_edit)

        puterTtsGroup = view.findViewById(R.id.voice_puter_tts_group)
        puterProviderEdit = view.findViewById(R.id.voice_puter_provider_edit)
        puterVoiceEdit = view.findViewById(R.id.voice_puter_voice_edit)
        puterModelEdit = view.findViewById(R.id.voice_puter_model_edit)

        customUrlGroup = view.findViewById(R.id.voice_custom_url_group)
        customUrlEdit = view.findViewById(R.id.voice_custom_url_edit)
        customKeyEdit = view.findViewById(R.id.voice_custom_key_edit)
        customModelEdit = view.findViewById(R.id.voice_custom_model_edit)
        customVoiceEdit = view.findViewById(R.id.voice_custom_voice_edit)

        kurumiBadgeAvatar.bindMedia(null, null, kurumiThemeEnabled = true)

        view.findViewById<View>(R.id.voice_back_btn).setOnClickListener {
            saveCloneFields()
            app.ttsSpeaker.stop()
            (activity as? MainActivity)?.popToChat()
        }

        // 1-Tap Kurumi Preset Activation
        view.findViewById<MaterialButton>(R.id.voice_activate_kurumi_btn).setOnClickListener {
            prefs.applyKurumiPreset()
            kurumiBadgeAvatar.setThinking(true)
            kurumiBadgeAvatar.postDelayed({
                if (isAdded) kurumiBadgeAvatar.setThinking(false)
            }, 3600L)
            (activity as? MainActivity)?.updateToolbarTitle()
            IslandForegroundService.refresh(requireContext())
            renderVoiceCards()
            Toast.makeText(
                requireContext(),
                "Образ Куруми Токисаки включён! Часы Зафкиэля активны в чате и Dynamic Island.",
                Toast.LENGTH_LONG
            ).show()
        }

        // Hydrate voice cloning fields
        sampleTextEdit.setText(prefs.customVoiceSampleText)
        fishKeyEdit.setText(prefs.fishAudioApiKey)
        fishIdEdit.setText(prefs.fishAudioVoiceId)
        fishModelEdit.setText(prefs.fishAudioModel)
        elevenKeyEdit.setText(prefs.elevenLabsApiKey)
        elevenIdEdit.setText(prefs.elevenLabsVoiceId)
        puterProviderEdit.setText(prefs.puterTtsProvider)
        puterVoiceEdit.setText(prefs.puterTtsVoice)
        puterModelEdit.setText(prefs.puterTtsModel)
        customUrlEdit.setText(prefs.customCloneTtsUrl)
        customKeyEdit.setText(prefs.customTtsApiKey)
        customModelEdit.setText(prefs.customTtsModel)
        customVoiceEdit.setText(prefs.customTtsVoice)

        view.findViewById<MaterialButton>(R.id.voice_pick_sample_btn).setOnClickListener {
            pickVoiceSampleLauncher.launch(arrayOf("audio/*"))
        }
        playSampleBtn.setOnClickListener {
            val f = app.voiceSampleManager.getVoiceSampleFile()
            if (f != null) {
                app.ttsSpeaker.playLocalSampleFile(f) { err ->
                    if (isAdded) Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show()
                }
            }
        }
        clearSampleBtn.setOnClickListener {
            app.voiceSampleManager.clearVoiceSample()
            refreshSampleStatus()
            Toast.makeText(requireContext(), "Сэмпл удалён", Toast.LENGTH_SHORT).show()
        }

        // Engine selector
        val modes = TtsEngineMode.entries
        engineSpinner.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            modes.map { it.labelRu }
        )
        engineSpinner.setSelection(modes.indexOf(prefs.ttsEngineMode).coerceAtLeast(0))
        updateEngineGroups(prefs.ttsEngineMode)
        engineSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val chosen = modes[position]
                prefs.ttsEngineMode = chosen
                updateEngineGroups(chosen)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Rate slider (-30..+45)
        val savedRate = prefs.ttsRateOffsetPct
        rateSeek.progress = (savedRate + 30).coerceIn(0, 75)
        updateRateLabel(savedRate)
        rateSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val pct = progress - 30
                updateRateLabel(pct)
                if (fromUser) prefs.ttsRateOffsetPct = pct
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Pitch slider (-20..+25)
        val savedPitch = prefs.ttsPitchOffsetHz
        pitchSeek.progress = (savedPitch + 20).coerceIn(0, 45)
        updatePitchLabel(savedPitch)
        pitchSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val hz = progress - 20
                updatePitchLabel(hz)
                if (fromUser) prefs.ttsPitchOffsetHz = hz
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        autoSpeakSwitch.isChecked = prefs.ttsAutoSpeakReplies
        autoSpeakSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.ttsAutoSpeakReplies = checked
        }

        testSelectedBtn.setOnClickListener {
            saveCloneFields()
            val selected = prefs.ttsVoicePreset
            val name = prefs.assistantName
            val line = if (prefs.kurumiThemeEnabled) {
                "Ара-ара… Привет! Я $name. Моё время в твоём распоряжении."
            } else {
                "Привет! Я $name. Голос ${selected.titleRu} звучит чисто и естественно на русском языке."
            }
            app.ttsSpeaker.previewVoice(
                voice = selected,
                sampleText = line,
                onError = { err ->
                    if (isAdded) Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show()
                }
            )
        }

        refreshSampleStatus()
        renderVoiceCards()

        viewLifecycleOwner.lifecycleScope.launch {
            app.ttsSpeaker.playbackState.collectLatest { st ->
                if (st.statusRu.isNotBlank()) {
                    playbackStatusTv.visibility = View.VISIBLE
                    playbackStatusTv.text = st.statusRu
                } else {
                    playbackStatusTv.visibility = View.GONE
                }
                renderVoiceCards(activePlayingVoiceId = if (st.active) st.activeVoiceId else null)
            }
        }
    }

    private fun saveCloneFields() {
        val prefs = JarvisApplication.instance.prefs
        prefs.customVoiceSampleText = sampleTextEdit.text.toString().trim()
        prefs.fishAudioApiKey = fishKeyEdit.text.toString().trim()
        prefs.fishAudioVoiceId = fishIdEdit.text.toString().trim()
        prefs.fishAudioModel = fishModelEdit.text.toString().trim()
        prefs.elevenLabsApiKey = elevenKeyEdit.text.toString().trim()
        prefs.elevenLabsVoiceId = elevenIdEdit.text.toString().trim()
        prefs.puterTtsProvider = puterProviderEdit.text.toString().trim()
        prefs.puterTtsVoice = puterVoiceEdit.text.toString().trim()
        prefs.puterTtsModel = puterModelEdit.text.toString().trim()
        prefs.customCloneTtsUrl = customUrlEdit.text.toString().trim()
        prefs.customTtsApiKey = customKeyEdit.text.toString().trim()
        prefs.customTtsModel = customModelEdit.text.toString().trim()
        prefs.customTtsVoice = customVoiceEdit.text.toString().trim()
    }

    private fun updateEngineGroups(mode: TtsEngineMode) {
        engineSubtitleTv.text = mode.subtitleRu
        fishGroup.visibility = if (mode == TtsEngineMode.FISH_AUDIO_CLONE) View.VISIBLE else View.GONE
        elevenGroup.visibility = if (mode == TtsEngineMode.ELEVENLABS_CLONE) View.VISIBLE else View.GONE
        puterTtsGroup.visibility = if (mode == TtsEngineMode.PUTER_TTS) View.VISIBLE else View.GONE
        customUrlGroup.visibility = if (mode == TtsEngineMode.CUSTOM_CLONE_URL) View.VISIBLE else View.GONE
    }

    private fun saveVoiceSample(uri: Uri) {
        val app = JarvisApplication.instance
        viewLifecycleOwner.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) { app.voiceSampleManager.saveVoiceSample(uri) }
            res.onSuccess { saved ->
                refreshSampleStatus()
                val note = saved.warningRu ?: "Сэмпл «${saved.displayName}» (${saved.durationSec} с) сохранён! Выберите Fish Audio или Свой сервер выше."
                Toast.makeText(requireContext(), note, Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                Toast.makeText(requireContext(), err.message ?: "Ошибка сохранения сэмпла", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshSampleStatus() {
        val app = JarvisApplication.instance
        val file = app.voiceSampleManager.getVoiceSampleFile()
        if (file != null) {
            val label = app.prefs.customVoiceSampleName.ifBlank { file.name }
            sampleStatusTv.text = "Загружен: $label (${ModelCatalog.formatBytes(file.length())})"
            sampleStatusTv.setTextColor(android.graphics.Color.parseColor("#5EF2A5"))
            playSampleBtn.visibility = View.VISIBLE
            clearSampleBtn.visibility = View.VISIBLE
        } else {
            sampleStatusTv.text = "Сэмпл не выбран (подойдёт 10–20 сек чистой речи Куруми в MP3/WAV)"
            sampleStatusTv.setTextColor(requireContext().getColor(R.color.jarvis_text_muted))
            playSampleBtn.visibility = View.GONE
            clearSampleBtn.visibility = View.GONE
        }
    }

    private fun updateRateLabel(pct: Int) {
        val sign = if (pct > 0) "+" else ""
        rateLabel.text = "Скорость речи: $sign$pct%"
    }

    private fun updatePitchLabel(hz: Int) {
        val sign = if (hz > 0) "+" else ""
        pitchLabel.text = "Высота голоса: $sign$hz Гц"
    }

    private fun renderVoiceCards(activePlayingVoiceId: String? = null) {
        if (!isAdded) return
        val app = JarvisApplication.instance
        val selected = app.prefs.ttsVoicePreset
        val d = resources.displayMetrics.density
        presetsContainer.removeAllViews()

        for (preset in NeuralVoicePreset.entries) {
            val isSelected = preset == selected
            val isPlaying = preset.id == activePlayingVoiceId

            val card = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = requireContext().getDrawable(
                    if (isSelected) R.drawable.bg_chip_selected else R.drawable.bg_glass_card
                )
                setPadding((14 * d).toInt(), (12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (8 * d).toInt() }
                setOnClickListener {
                    app.prefs.ttsVoicePreset = preset
                    if (app.prefs.ttsEngineMode == TtsEngineMode.SYSTEM_ANDROID) {
                        app.prefs.ttsEngineMode = TtsEngineMode.EDGE_NEURAL
                        engineSpinner.setSelection(0)
                    }
                    renderVoiceCards(activePlayingVoiceId)
                }
            }

            val statusIcon = ImageView(requireContext()).apply {
                setImageResource(if (isSelected) R.drawable.ic_status_check else R.drawable.ic_nav_voice)
                val sz = (22 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (12 * d).toInt() }
            }
            card.addView(statusIcon)

            val textCol = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val titleRow = TextView(requireContext()).apply {
                text = "${preset.titleRu}  •  ${preset.genderRu}"
                setTextColor(
                    if (isSelected) android.graphics.Color.BLACK
                    else requireContext().getColor(R.color.jarvis_text_primary)
                )
                textSize = 14.5f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            val descTv = TextView(requireContext()).apply {
                text = preset.descriptionRu
                setTextColor(
                    if (isSelected) android.graphics.Color.parseColor("#222222")
                    else requireContext().getColor(R.color.jarvis_text_secondary)
                )
                textSize = 12.2f
            }
            textCol.addView(titleRow)
            textCol.addView(descTv)
            card.addView(textCol)

            val playBtn = ImageButton(requireContext()).apply {
                setImageResource(if (isPlaying) R.drawable.ic_stop_square else R.drawable.ic_play_circle)
                background = requireContext().getDrawable(R.drawable.bg_glass_circle)
                contentDescription = if (isPlaying) "Стоп" else "Прослушать ${preset.titleRu}"
                val sz = (38 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (8 * d).toInt() }
                setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
                setOnClickListener {
                    saveCloneFields()
                    val name = app.prefs.assistantName
                    val line = if (preset == NeuralVoicePreset.KURUMI_STYLE) {
                        "Ара-ара… Привет! Я Куруми. Чем займёмся сегодня?"
                    } else {
                        "Привет! Я $name. Это голос ${preset.titleRu}. Чем могу помочь?"
                    }
                    app.ttsSpeaker.previewVoice(
                        voice = preset,
                        sampleText = line,
                        forceMode = TtsEngineMode.EDGE_NEURAL,
                        onError = { err ->
                            if (isAdded) Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show()
                        }
                    )
                }
            }
            card.addView(playBtn)

            presetsContainer.addView(card)
        }
    }

    override fun onPause() {
        super.onPause()
        saveCloneFields()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (::kurumiBadgeAvatar.isInitialized) kurumiBadgeAvatar.setThinking(false)
        JarvisApplication.instance.ttsSpeaker.stop()
    }
}
