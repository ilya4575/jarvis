package ru.jarvis.assistant.feature.accessibility

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.core.agent.AppCandidate
import ru.jarvis.assistant.core.agent.AppFuzzyMatcher

data class InstalledAppEntry(
    val displayName: String,
    val packageName: String
)

data class PlanExecutionReport(
    val allSucceeded: Boolean,
    val stepLogsRu: List<String>
)

/**
 * Resolves launchable installed apps, builds previewable action plans using AccessibilitySafetyGuard,
 * and executes user-confirmed steps with per-step verification.
 */
class AppActionPlanner(private val context: Context) {

    fun listLaunchableApps(): List<InstalledAppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolved.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
            if (label.isEmpty()) return@mapNotNull null
            InstalledAppEntry(displayName = label, packageName = pkg)
        }.distinctBy { it.packageName }.sortedBy { it.displayName.lowercase() }
    }

    fun resolveApp(query: String): Pair<String, String>? {
        val apps = listLaunchableApps().map { AppCandidate(it.displayName, it.packageName) }
        val best = AppFuzzyMatcher.resolveBestMatch(apps, query) ?: return null
        return best.displayName to best.packageName
    }

    fun searchApps(query: String, limit: Int = 20): List<InstalledAppEntry> {
        val apps = listLaunchableApps()
        if (query.isBlank()) return apps.take(limit)
        val candidates = apps.map { AppCandidate(it.displayName, it.packageName) }
        return AppFuzzyMatcher.searchApps(candidates, query, limit)
            .map { InstalledAppEntry(it.displayName, it.packageName) }
    }

    fun buildPreviewPlan(command: String): ActionPlan {
        return AccessibilitySafetyGuard.buildPlan(command) { query -> resolveApp(query) }
    }

    fun launchAppDirectly(packageName: String): Result<Unit> {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?: return Result.failure(IllegalStateException("Приложение не поддерживает прямой запуск ($packageName)."))
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun executeConfirmedPlan(plan: ActionPlan): PlanExecutionReport = withContext(Dispatchers.Main) {
        if (plan.riskLevel == RiskLevel.HARD_BLOCKED_SENSITIVE) {
            return@withContext PlanExecutionReport(
                allSucceeded = false,
                stepLogsRu = listOf("Остановлено защитой: ${plan.riskReasonRu}")
            )
        }
        if (plan.steps.isEmpty()) {
            return@withContext PlanExecutionReport(
                allSucceeded = false,
                stepLogsRu = listOf("План пуст — не удалось распознать целевое приложение или действие.")
            )
        }

        val logs = mutableListOf<String>()
        var allOk = true

        for ((idx, step) in plan.steps.withIndex()) {
            val prefix = "Шаг ${idx + 1}: "
            when (step.type) {
                ActionStepType.LAUNCH_APP -> {
                    val pkg = step.payload
                    if (pkg.isNullOrBlank()) {
                        logs.add("${prefix}Ошибка — приложение «${step.targetLabel}» не найдено на устройстве.")
                        allOk = false
                        break
                    }
                    val res = launchAppDirectly(pkg)
                    if (res.isSuccess) {
                        logs.add("${prefix}Запущено «${step.targetLabel}» ($pkg).")
                        if (idx + 1 < plan.steps.size) {
                            delay(1400L) // allow target app window to appear before next Accessibility step
                        }
                    } else {
                        logs.add("${prefix}Не удалось запустить «${step.targetLabel}»: ${res.exceptionOrNull()?.message}")
                        allOk = false
                        break
                    }
                }
                ActionStepType.FIND_AND_CLICK_TEXT -> {
                    val svc = JarvisAccessibilityService.activeInstance
                    if (svc == null) {
                        logs.add("${prefix}AccessibilityService не включён в настройках Android — шаг пропущен.")
                        allOk = false
                        break
                    }
                    val outcome = svc.executeTapText(step.targetLabel)
                    logs.add("${prefix}${outcome.messageRu}")
                    if (!outcome.success) {
                        allOk = false
                        break
                    }
                    delay(500L)
                }
                ActionStepType.INPUT_TEXT_IN_FOCUSED -> {
                    val svc = JarvisAccessibilityService.activeInstance
                    if (svc == null) {
                        logs.add("${prefix}AccessibilityService не включён в настройках Android.")
                        allOk = false
                        break
                    }
                    val outcome = svc.executeInputText(step.payload.orEmpty())
                    logs.add("${prefix}${outcome.messageRu}")
                    if (!outcome.success) {
                        allOk = false
                        break
                    }
                    delay(400L)
                }
            }
        }

        PlanExecutionReport(allSucceeded = allOk, stepLogsRu = logs)
    }
}
