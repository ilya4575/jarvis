package ru.jarvis.assistant.feature.overlay

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Animated vertical audio equalizer waveform for the Dynamic Island:
 * - IDLE: subtle static capsule bars
 * - LISTENING / GENERATING: smooth voice / thinking waves
 * - MUSIC_REACTIVE (B2): driven by real Android Visualizer FFT bands when available,
 *   with smooth synthetic equalizer fallback when Visualizer is unavailable.
 */
class IslandWaveformView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Mode {
        IDLE,
        LISTENING,
        GENERATING,
        MUSIC_REACTIVE
    }

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private var mode: Mode = Mode.IDLE
    private var phase: Float = 0f
    private var animator: ValueAnimator? = null

    private val barCount = 5
    private val idleRatios = floatArrayOf(0.32f, 0.62f, 0.90f, 0.56f, 0.34f)
    private val phaseOffsets = floatArrayOf(0.0f, 1.15f, 2.3f, 3.45f, 4.6f)

    private var externalBands: FloatArray? = null
    private val smoothedBands = floatArrayOf(0.3f, 0.5f, 0.7f, 0.5f, 0.3f)

    fun setMode(newMode: Mode) {
        if (mode == newMode && (newMode == Mode.IDLE || animator?.isRunning == true)) return
        mode = newMode
        if (newMode != Mode.MUSIC_REACTIVE) {
            externalBands = null
        }
        updateShader(width, height)
        if (newMode == Mode.IDLE) {
            stopAnimation()
            invalidate()
        } else {
            startAnimation()
        }
    }

    /** Updates equalizer bars from real audio Visualizer FFT output (5 normalized bands 0..1). */
    fun setAudioBands(bands: FloatArray?) {
        externalBands = bands
        if (bands != null && mode == Mode.MUSIC_REACTIVE) {
            for (i in 0 until minOf(barCount, bands.size)) {
                smoothedBands[i] = smoothedBands[i] * 0.45f + bands[i].coerceIn(0.16f, 1f) * 0.55f
            }
            postInvalidateOnAnimation()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateShader(w, h)
    }

    private fun updateShader(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        val colors = when (mode) {
            Mode.IDLE -> intArrayOf(
                Color.parseColor("#B8A5E8"),
                Color.parseColor("#E3A7D2")
            )
            Mode.LISTENING -> intArrayOf(
                Color.parseColor("#FB7185"),
                Color.parseColor("#F59E0B"),
                Color.parseColor("#A855F7")
            )
            Mode.GENERATING -> intArrayOf(
                Color.parseColor("#F59E0B"),
                Color.parseColor("#EC4899"),
                Color.parseColor("#6366F1")
            )
            Mode.MUSIC_REACTIVE -> intArrayOf(
                Color.parseColor("#34D399"),
                Color.parseColor("#38BDF8"),
                Color.parseColor("#A78BFA")
            )
        }
        barPaint.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            colors, null, Shader.TileMode.CLAMP
        )
        barPaint.alpha = if (mode == Mode.IDLE) 205 else 255
    }

    private fun startAnimation() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, (2.0 * PI).toFloat()).apply {
            duration = when (mode) {
                Mode.LISTENING -> 720L
                Mode.MUSIC_REACTIVE -> 860L
                else -> 1100L
            }
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimation() {
        animator?.cancel()
        animator = null
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val padX = w * 0.08f
        val usableW = w - padX * 2f
        val barW = (usableW / (barCount * 1.9f)).coerceAtLeast(2f)
        val gap = if (barCount > 1) (usableW - barW * barCount) / (barCount - 1) else 0f
        val centerY = h / 2f
        val maxBarH = h * 0.80f
        val minBarH = h * 0.18f

        for (i in 0 until barCount) {
            val ratio = when (mode) {
                Mode.IDLE -> idleRatios[i]
                Mode.LISTENING -> {
                    val wave = 0.5f + 0.5f * sin((phase * 1.8f + phaseOffsets[i]).toDouble()).toFloat()
                    0.22f + 0.78f * wave
                }
                Mode.GENERATING -> {
                    val wave = 0.5f + 0.5f * sin((phase + phaseOffsets[i]).toDouble()).toFloat()
                    0.28f + 0.64f * wave
                }
                Mode.MUSIC_REACTIVE -> {
                    if (externalBands != null) {
                        smoothedBands[i]
                    } else {
                        // Graceful rhythmic equalizer fallback when Visualizer is unavailable
                        val w1 = 0.5f + 0.5f * sin((phase * 1.6f + phaseOffsets[i]).toDouble()).toFloat()
                        val w2 = 0.5f + 0.5f * sin((phase * 2.7f + i * 1.9f).toDouble()).toFloat()
                        0.20f + 0.76f * (w1 * 0.6f + w2 * 0.4f)
                    }
                }
            }
            val barH = (minBarH + (maxBarH - minBarH) * ratio).coerceIn(minBarH, maxBarH)
            val left = padX + i * (barW + gap)
            val top = centerY - barH / 2f
            val r = barW / 2f
            canvas.drawRoundRect(left, top, left + barW, top + barH, r, r, barPaint)
        }
    }
}
