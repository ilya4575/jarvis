package ru.jarvis.assistant.feature.overlay

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import ru.jarvis.assistant.ui.MainActivity

/**
 * A1: Safely restores Dynamic Island after device reboot or app update without crashing on
 * Android 12–14 background ForegroundServiceStartNotAllowedException restrictions.
 */
class IslandBootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action !in SUPPORTED_ACTIONS) return

        val prefs = runCatching { JarvisPreferences(context.applicationContext) }.getOrNull() ?: return
        val decision = IslandPriorityEngine.evaluateAutoRestore(
            islandToggleEnabled = prefs.islandEnabled,
            hasOverlayPermission = Settings.canDrawOverlays(context)
        )
        if (decision != IslandRestoreDecision.START_NOW) {
            return
        }

        val started = IslandForegroundService.startSafe(context.applicationContext)
        if (!started) {
            // Android 12-14 background FGS restriction prevented immediate start:
            // mark pending restore and offer a 1-tap notification to restore the island cleanly!
            prefs.islandPendingRestore = true
            postRestoreNotification(context.applicationContext, prefs.assistantName)
        } else {
            prefs.islandPendingRestore = false
        }
    }

    private fun postRestoreNotification(context: Context, assistantName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(
                    RESTORE_CHANNEL_ID,
                    "Восстановление Dynamic Island",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
        val openIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_RESTORE_ISLAND, true)
        }
        val pi = PendingIntent.getActivity(
            context,
            4109,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, RESTORE_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_jarvis_status)
            .setContentTitle("$assistantName Dynamic Island")
            .setContentText("Нажмите, чтобы восстановить Dynamic Island после перезагрузки.")
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(4109, notif)
    }

    companion object {
        private const val RESTORE_CHANNEL_ID = "jarvis_island_restore_channel"
        private val SUPPORTED_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON"
        )
    }
}
