package ru.jarvis.assistant.feature.avatar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

data class AvatarSaveResult(
    val savedFile: File,
    val warningRu: String? = null
)

/**
 * Manages local user avatar photo & optional MP4 video avatar inside app-private storage (`filesDir/avatar`).
 * Supports HEIC/HEIF/WebP/PNG/JPEG via ImageDecoder and saves a clean normalized avatar JPEG.
 */
class AvatarManager(
    private val context: Context,
    private val prefs: JarvisPreferences
) {
    private val avatarDir: File = File(context.filesDir, "avatar").apply { mkdirs() }

    fun saveStaticImage(uri: Uri): Result<File> {
        return try {
            val dest = File(avatarDir, "avatar_static.jpg")
            val temp = File(avatarDir, "avatar_static.tmp")

            val decoded: Bitmap? = try {
                val src = ImageDecoder.createSource(context.contentResolver, uri)
                ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val longest = max(info.size.width, info.size.height)
                    if (longest > 512) {
                        val scale = 512f / longest
                        decoder.setTargetSize(
                            (info.size.width * scale).roundToInt().coerceAtLeast(1),
                            (info.size.height * scale).roundToInt().coerceAtLeast(1)
                        )
                    }
                }
            } catch (_: Throwable) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }

            if (decoded != null) {
                val sw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                    decoded.config == Bitmap.Config.HARDWARE
                ) {
                    val c = decoded.copy(Bitmap.Config.ARGB_8888, false)
                    decoded.recycle()
                    c
                } else decoded
                FileOutputStream(temp).use { fos ->
                    sw.compress(Bitmap.CompressFormat.JPEG, 92, fos)
                }
                sw.recycle()
            } else {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(temp).use { output ->
                        val copied = input.copyTo(output)
                        if (copied <= 0L) throw IllegalArgumentException("Пустой файл изображения")
                        if (copied > 25L * 1024L * 1024L) {
                            throw IllegalArgumentException("Изображение слишком велико (лимит 25 МиБ)")
                        }
                    }
                } ?: return Result.failure(IllegalArgumentException("Не удалось открыть изображение"))
            }

            if (dest.exists()) dest.delete()
            temp.renameTo(dest)
            prefs.avatarImagePath = dest.absolutePath
            Result.success(dest)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun saveVideoAvatar(uri: Uri): Result<AvatarSaveResult> {
        return try {
            val mime = context.contentResolver.getType(uri)
            val (displayName, queriedSize) = queryDisplayNameAndSize(uri)

            var durationMs: Long
            var hasVideo: Boolean
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
                val hasVideoMeta = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
                hasVideo = hasVideoMeta.equals("yes", ignoreCase = true) ||
                    (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0) > 0
            } finally {
                runCatching { retriever.release() }
            }

            val temp = File(avatarDir, "avatar_video.tmp")
            var actualSize = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val r = input.read(buf)
                        if (r <= 0) break
                        actualSize += r
                        if (actualSize > VideoAvatarValidator.MAX_SIZE_BYTES) {
                            break
                        }
                        output.write(buf, 0, r)
                    }
                }
            } ?: return Result.failure(IllegalArgumentException("Не удалось открыть видеофайл"))

            val finalSize = if (actualSize > VideoAvatarValidator.MAX_SIZE_BYTES) actualSize
            else if (queriedSize > 0L) queriedSize else actualSize

            val validation = VideoAvatarValidator.validate(
                VideoAvatarMetadata(
                    mimeType = mime,
                    fileName = displayName,
                    sizeBytes = finalSize,
                    durationMs = durationMs,
                    hasVideoTrack = hasVideo
                )
            )

            when (validation) {
                is VideoAvatarValidationResult.Invalid -> {
                    temp.delete()
                    Result.failure(IllegalArgumentException(validation.reasonRu))
                }
                is VideoAvatarValidationResult.Valid -> {
                    val dest = File(avatarDir, "avatar_loop.mp4")
                    if (dest.exists()) dest.delete()
                    temp.renameTo(dest)
                    prefs.avatarVideoPath = dest.absolutePath
                    Result.success(AvatarSaveResult(dest, validation.warningRu))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun saveThinkingGif(uri: Uri): Result<File> {
        return try {
            val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
            val (displayName, _) = queryDisplayNameAndSize(uri)
            val ext = when {
                mime.contains("webp") || displayName?.endsWith(".webp", ignoreCase = true) == true -> "webp"
                else -> "gif"
            }
            val temp = File(avatarDir, "avatar_thinking.tmp")
            var copied = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val r = input.read(buf)
                        if (r <= 0) break
                        copied += r
                        if (copied > 25L * 1024L * 1024L) {
                            temp.delete()
                            return Result.failure(IllegalArgumentException("GIF/WebP слишком большой (лимит 25 МБ)."))
                        }
                        output.write(buf, 0, r)
                    }
                }
            } ?: return Result.failure(IllegalArgumentException("Не удалось открыть GIF/WebP файл."))

            if (copied < 128L) {
                temp.delete()
                return Result.failure(IllegalArgumentException("Файл пустой или повреждён."))
            }

            File(avatarDir, "avatar_thinking.gif").delete()
            File(avatarDir, "avatar_thinking.webp").delete()
            val dest = File(avatarDir, "avatar_thinking.$ext")
            temp.renameTo(dest)
            prefs.avatarThinkingGifPath = dest.absolutePath
            Result.success(dest)
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    fun getThinkingGifFile(): File? =
        prefs.avatarThinkingGifPath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }

    fun clearThinkingGif() {
        getThinkingGifFile()?.delete()
        prefs.avatarThinkingGifPath = null
    }

    fun getStaticImageFile(): File? =
        prefs.avatarImagePath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }

    fun getVideoAvatarFile(): File? =
        prefs.avatarVideoPath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }

    fun clearStaticImage() {
        getStaticImageFile()?.delete()
        prefs.avatarImagePath = null
    }

    fun clearVideoAvatar() {
        getVideoAvatarFile()?.delete()
        prefs.avatarVideoPath = null
    }

    private fun queryDisplayNameAndSize(uri: Uri): Pair<String?, Long> {
        var name: String? = null
        var size = -1L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) {
                    val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = c.getString(nameIdx)
                    if (sizeIdx >= 0 && !c.isNull(sizeIdx)) size = c.getLong(sizeIdx)
                }
            }
        return name to size
    }
}
