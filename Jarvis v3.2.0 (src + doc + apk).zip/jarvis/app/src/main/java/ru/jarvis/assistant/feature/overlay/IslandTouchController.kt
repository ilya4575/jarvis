package ru.jarvis.assistant.feature.overlay

import kotlin.math.hypot

/**
 * Pure, deterministic gesture state machine for the floating Dynamic Island overlay.
 * Cleanly separates:
 * - Dragging (moving beyond touchSlopPx when dragLocked == false) -> moves island, NEVER starts voice recording
 * - Short tap (release before longPressThresholdMs without dragging) -> expands/collapses island card
 * - Long press (hold >= longPressThresholdMs without dragging) -> expands voice pill & starts offline voice recording
 * - Release / Cancel after long press -> stops voice recording immediately
 */
class IslandTouchController(
    private val touchSlopPx: Float = 18f,
    private val longPressThresholdMs: Long = 340L,
    var dragLocked: Boolean = false
) {
    enum class GestureMode {
        IDLE,
        PRESSED,
        DRAGGING,
        HOLD_RECORDING
    }

    sealed class GestureEvent {
        data object None : GestureEvent()
        data class DragMove(val newX: Int, val newY: Int) : GestureEvent()
        data class DragEnd(val finalX: Int, val finalY: Int) : GestureEvent()
        data object ShortTap : GestureEvent()
        data object StartVoiceRecording : GestureEvent()
        data object StopVoiceRecording : GestureEvent()
    }

    var mode: GestureMode = GestureMode.IDLE
        private set

    private var initialWindowX = 0
    private var initialWindowY = 0
    private var downRawX = 0f
    private var downRawY = 0f
    private var downTimeMs = 0L

    fun onDown(windowX: Int, windowY: Int, rawX: Float, rawY: Float, nowMs: Long): GestureEvent {
        initialWindowX = windowX
        initialWindowY = windowY
        downRawX = rawX
        downRawY = rawY
        downTimeMs = nowMs
        mode = GestureMode.PRESSED
        return GestureEvent.None
    }

    fun onLongPressTimerFired(nowMs: Long): GestureEvent {
        if (mode == GestureMode.PRESSED && (nowMs - downTimeMs) >= longPressThresholdMs) {
            mode = GestureMode.HOLD_RECORDING
            return GestureEvent.StartVoiceRecording
        }
        return GestureEvent.None
    }

    fun onMove(rawX: Float, rawY: Float): GestureEvent {
        if (dragLocked) return GestureEvent.None

        val dx = rawX - downRawX
        val dy = rawY - downRawY
        val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()

        return when (mode) {
            GestureMode.PRESSED -> {
                if (dist > touchSlopPx) {
                    mode = GestureMode.DRAGGING
                    GestureEvent.DragMove(
                        newX = initialWindowX + dx.toInt(),
                        newY = initialWindowY + dy.toInt()
                    )
                } else {
                    GestureEvent.None
                }
            }
            GestureMode.DRAGGING -> {
                GestureEvent.DragMove(
                    newX = initialWindowX + dx.toInt(),
                    newY = initialWindowY + dy.toInt()
                )
            }
            GestureMode.HOLD_RECORDING, GestureMode.IDLE -> GestureEvent.None
        }
    }

    fun onUp(rawX: Float, rawY: Float, nowMs: Long): GestureEvent {
        val prevMode = mode
        mode = GestureMode.IDLE
        return when (prevMode) {
            GestureMode.HOLD_RECORDING -> GestureEvent.StopVoiceRecording
            GestureMode.DRAGGING -> GestureEvent.DragEnd(
                finalX = initialWindowX + (rawX - downRawX).toInt(),
                finalY = initialWindowY + (rawY - downRawY).toInt()
            )
            GestureMode.PRESSED -> {
                if ((nowMs - downTimeMs) < longPressThresholdMs) {
                    GestureEvent.ShortTap
                } else {
                    GestureEvent.None
                }
            }
            GestureMode.IDLE -> GestureEvent.None
        }
    }

    fun onCancel(): GestureEvent {
        val prevMode = mode
        mode = GestureMode.IDLE
        return if (prevMode == GestureMode.HOLD_RECORDING) {
            GestureEvent.StopVoiceRecording
        } else {
            GestureEvent.None
        }
    }
}
