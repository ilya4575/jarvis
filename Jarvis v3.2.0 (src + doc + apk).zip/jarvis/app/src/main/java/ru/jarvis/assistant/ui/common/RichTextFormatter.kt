package ru.jarvis.assistant.ui.common

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ImageSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import ru.jarvis.assistant.R

/**
 * Renders lightweight markdown (**bold**, *italic*, `inline code`, ### headings) AND
 * replaces structured [[ACTION]] / [[WARN]] / [[OK]] markers with crisp vector SVG ImageSpans
 * so there are zero raw emojis in chat bubbles or Dynamic Island answers.
 */
object RichTextFormatter {

    fun format(context: Context, raw: String): CharSequence {
        if (raw.isEmpty()) return ""
        val sb = SpannableStringBuilder()
        val lines = raw.split('\n')
        for ((idx, line) in lines.withIndex()) {
            if (idx > 0) sb.append('\n')
            val trimmed = line.trimStart()
            when {
                trimmed.startsWith("[[ACTION]]") -> {
                    appendIconToken(context, sb, R.drawable.ic_action_bolt, 16)
                    sb.append(' ')
                    val start = sb.length
                    appendInlineMarkdown(sb, trimmed.removePrefix("[[ACTION]]").trim())
                    sb.setSpan(ForegroundColorSpan(Color.parseColor("#C4B5FD")), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(0.92f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("[[WARN]]") -> {
                    appendIconToken(context, sb, R.drawable.ic_status_warn, 16)
                    sb.append(' ')
                    val start = sb.length
                    appendInlineMarkdown(sb, trimmed.removePrefix("[[WARN]]").trim())
                    sb.setSpan(ForegroundColorSpan(Color.parseColor("#FDBA74")), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(0.92f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("[[OK]]") -> {
                    appendIconToken(context, sb, R.drawable.ic_status_check, 16)
                    sb.append(' ')
                    val start = sb.length
                    appendInlineMarkdown(sb, trimmed.removePrefix("[[OK]]").trim())
                    sb.setSpan(ForegroundColorSpan(Color.parseColor("#6EE7B7")), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(0.92f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("### ") -> {
                    val start = sb.length
                    appendInlineMarkdown(sb, trimmed.removePrefix("### "))
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(1.06f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("## ") -> {
                    val start = sb.length
                    appendInlineMarkdown(sb, trimmed.removePrefix("## "))
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(1.12f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("# ") -> {
                    val start = sb.length
                    appendInlineMarkdown(sb, trimmed.removePrefix("# "))
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(1.18f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    sb.append("• ")
                    appendInlineMarkdown(sb, trimmed.substring(2))
                }
                else -> appendInlineMarkdown(sb, line)
            }
        }
        return sb
    }

    fun badgeWithIcon(context: Context, @DrawableRes iconRes: Int, text: String, iconSizeDp: Int = 15): CharSequence {
        val sb = SpannableStringBuilder()
        appendIconToken(context, sb, iconRes, iconSizeDp)
        sb.append(' ')
        sb.append(text)
        return sb
    }

    private fun appendIconToken(context: Context, sb: SpannableStringBuilder, @DrawableRes iconRes: Int, sizeDp: Int) {
        val d = ContextCompat.getDrawable(context, iconRes)?.mutate() ?: return
        val px = (sizeDp * context.resources.displayMetrics.density).toInt().coerceAtLeast(16)
        d.setBounds(0, 0, px, px)
        val start = sb.length
        sb.append(" ")
        sb.setSpan(ImageSpan(d, ImageSpan.ALIGN_CENTER), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun appendInlineMarkdown(sb: SpannableStringBuilder, line: String) {
        var i = 0
        val n = line.length
        while (i < n) {
            if (line[i] == '`') {
                val end = line.indexOf('`', i + 1)
                if (end > i + 1) {
                    val start = sb.length
                    sb.append(line, i + 1, end)
                    sb.setSpan(TypefaceSpan("monospace"), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(BackgroundColorSpan(Color.parseColor("#24FFFFFF")), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = end + 1
                    continue
                }
            }
            if (i + 1 < n && line[i] == '*' && line[i + 1] == '*') {
                val end = line.indexOf("**", i + 2)
                if (end > i + 2) {
                    val start = sb.length
                    sb.append(line, i + 2, end)
                    sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = end + 2
                    continue
                }
            }
            if (line[i] == '*' && (i + 1 < n && line[i + 1] != ' ')) {
                val end = line.indexOf('*', i + 1)
                if (end > i + 1 && line[end - 1] != ' ') {
                    val start = sb.length
                    sb.append(line, i + 1, end)
                    sb.setSpan(StyleSpan(Typeface.ITALIC), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = end + 1
                    continue
                }
            }
            sb.append(line[i])
            i++
        }
    }
}
