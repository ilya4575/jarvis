package ru.jarvis.assistant.core.cloud

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import ru.jarvis.assistant.core.chat.ChatContextManager
import ru.jarvis.assistant.core.inference.ChatTurn
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.GenerationResult
import ru.jarvis.assistant.core.inference.LlamaInferenceEngine
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Hardened streaming HTTP client for the 4 core API providers (A3):
 * - Google Gemini (AI Studio + Vertex AI Express v1/v1beta1 auto-failover + thought parts)
 * - Groq (Llama + Vision + TPM-aware 20..50 context window)
 * - OpenRouter (curated :free retry cascade + reasoning_content extraction)
 * - Custom Providers (up to 10 user-defined OpenAI-compatible or Anthropic-compatible endpoints with custom headers)
 */
class CloudLlmClient(
    private val geminiAiStudioBaseUrl: String = DEFAULT_GEMINI_AI_STUDIO_BASE,
    private val geminiVertexBaseUrl: String = DEFAULT_GEMINI_VERTEX_BASE,
    private val groqBaseUrl: String = DEFAULT_GROQ_BASE,
    private val openRouterBaseUrl: String = DEFAULT_OPENROUTER_BASE
) {
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(95, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    private val activeCall = AtomicReference<Call?>(null)
    private val cancelled = AtomicBoolean(false)

    fun cancelActive() {
        cancelled.set(true)
        activeCall.getAndSet(null)?.cancel()
    }

    suspend fun streamGemini(
        apiKey: String,
        model: String,
        endpointMode: GeminiEndpointMode,
        cachedUseVertex: Boolean,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit,
        onDetectedVertexChanged: ((Boolean) -> Unit)? = null
    ): GenerationResult = withContext(Dispatchers.IO) {
        cancelled.set(false)
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) {
            return@withContext GenerationResult.Failed("Ключ Gemini не указан.")
        }

        val modelsToTry = buildList {
            val primary = model.trim().ifEmpty { DEFAULT_GEMINI_MODEL }
            add(primary)
            for (fb in GEMINI_FALLBACK_MODELS) {
                if (!contains(fb)) add(fb)
            }
        }

        val endpointsToTry: List<Pair<String, Boolean>> = buildGeminiEndpoints(endpointMode, cachedUseVertex)
        val payloadJson = buildGeminiPayload(history, userPrompt, imagePath, config)
        var lastError = "Неизвестная ошибка Gemini"

        for ((baseUrl, isVertex) in endpointsToTry) {
            var shouldTryNextEndpoint = false
            for (modelId in modelsToTry) {
                if (cancelled.get()) return@withContext GenerationResult.Cancelled("")
                val startMs = System.currentTimeMillis()
                val url = "${baseUrl.trimEnd('/')}/models/$modelId:streamGenerateContent?alt=sse"
                val req = Request.Builder()
                    .url(url)
                    .header("x-goog-api-key", cleanKey)
                    .header("Content-Type", "application/json")
                    .header("Accept", "text/event-stream")
                    .post(payloadJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                    .build()

                val outcome = executeGeminiSseRequest(req, startMs, onToken, config.onThought)
                when (outcome) {
                    is HttpStreamOutcome.Success -> {
                        if (endpointMode == GeminiEndpointMode.AUTO && isVertex != cachedUseVertex) {
                            onDetectedVertexChanged?.invoke(isVertex)
                        }
                        return@withContext outcome.result
                    }
                    is HttpStreamOutcome.Cancelled -> {
                        return@withContext GenerationResult.Cancelled(outcome.partial)
                    }
                    is HttpStreamOutcome.HttpError -> {
                        val friendly = diagnoseGeminiError(outcome.code, outcome.shortMsg)
                        lastError = "Gemini ($modelId, HTTP ${outcome.code}): $friendly"
                        if (outcome.code == 400 || outcome.code == 401 || outcome.code == 403) {
                            shouldTryNextEndpoint = true
                            break
                        }
                        if (outcome.code == 404 || outcome.code == 429 || outcome.code >= 500) {
                            continue
                        }
                        return@withContext GenerationResult.Failed(lastError)
                    }
                    is HttpStreamOutcome.NetworkError -> {
                        lastError = "Gemini сеть: ${outcome.msg}"
                        return@withContext GenerationResult.Failed(lastError)
                    }
                }
            }
            if (!shouldTryNextEndpoint && endpointMode != GeminiEndpointMode.AUTO) break
        }
        GenerationResult.Failed(lastError)
    }

    suspend fun streamOpenRouter(
        apiKey: String,
        model: String,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) {
            return GenerationResult.Failed("Ключ OpenRouter не указан.")
        }
        val primary = model.trim().ifEmpty { DEFAULT_OPENROUTER_MODEL }
        val modelsToTry = buildList {
            add(primary)
            if (primary == DEFAULT_OPENROUTER_MODEL || primary.endsWith(":free")) {
                for (fb in OPENROUTER_FREE_FALLBACKS) {
                    if (!contains(fb)) add(fb)
                }
            }
            if (!contains(DEFAULT_OPENROUTER_MODEL)) add(DEFAULT_OPENROUTER_MODEL)
        }.take(4)

        var lastError = "Ошибка OpenRouter"
        for ((attemptIdx, modelId) in modelsToTry.withIndex()) {
            if (cancelled.get()) return GenerationResult.Cancelled("")
            if (attemptIdx > 0) delay(300)
            val streamedAny = booleanArrayOf(false)
            val res = streamOpenAiCompatible(
                providerName = "OpenRouter",
                endpointUrl = "${openRouterBaseUrl.trimEnd('/')}/chat/completions",
                apiKey = cleanKey,
                model = modelId,
                extraHeaders = mapOf(
                    "HTTP-Referer" to "https://github.com/ilya4575/jarvis",
                    "X-Title" to "Jarvis Android"
                ),
                history = history,
                userPrompt = userPrompt,
                imagePath = imagePath,
                config = config,
                onToken = { tok ->
                    if (tok.isNotEmpty()) streamedAny[0] = true
                    onToken(tok)
                }
            )
            when (res) {
                is GenerationResult.Completed -> return res
                is GenerationResult.Cancelled -> return res
                is GenerationResult.Failed -> {
                    lastError = res.reasonRu
                    if (streamedAny[0]) return res
                    if (res.reasonRu.contains("HTTP 401") || res.reasonRu.contains("HTTP 402")) {
                        return res
                    }
                }
            }
        }
        return GenerationResult.Failed(lastError)
    }

    suspend fun streamGroq(
        apiKey: String,
        model: String,
        visionModel: String,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) {
            return GenerationResult.Failed("Ключ Groq не указан.")
        }
        // Keep full configured 20..50 turn memory while staying inside Groq's token budget via smart per-turn trim
        val window = ChatContextManager.clampWindowSize(config.contextWindowSize)
        val compactHistory = compactHistoryForBudget(history, maxTurns = window, maxTotalChars = 16_000)
        val hasImage = !imagePath.isNullOrBlank() && File(imagePath).exists()
        val modelsToTry = if (hasImage) {
            listOf(visionModel.trim().ifEmpty { DEFAULT_GROQ_VISION_MODEL })
        } else {
            buildList {
                val primary = model.trim().ifEmpty { DEFAULT_GROQ_LLM_MODEL }
                add(primary)
                for (fb in GROQ_FALLBACK_MODELS) {
                    if (!contains(fb)) add(fb)
                }
            }
        }

        var lastError = "Ошибка Groq"
        for ((idx, chosenModel) in modelsToTry.withIndex()) {
            if (cancelled.get()) return GenerationResult.Cancelled("")
            if (idx > 0) delay(250)
            val streamedAny = booleanArrayOf(false)
            val res = streamOpenAiCompatible(
                providerName = "Groq",
                endpointUrl = "${groqBaseUrl.trimEnd('/')}/chat/completions",
                apiKey = cleanKey,
                model = chosenModel,
                extraHeaders = emptyMap(),
                history = compactHistory,
                userPrompt = userPrompt,
                imagePath = imagePath,
                config = config,
                onToken = { tok ->
                    if (tok.isNotEmpty()) streamedAny[0] = true
                    onToken(tok)
                }
            )
            when (res) {
                is GenerationResult.Completed -> return res
                is GenerationResult.Cancelled -> return res
                is GenerationResult.Failed -> {
                    lastError = res.reasonRu
                    if (streamedAny[0]) return res
                    if (res.reasonRu.contains("HTTP 401")) return res
                }
            }
        }
        return GenerationResult.Failed(lastError)
    }

    suspend fun streamCustomProvider(
        providerConfig: CustomProviderConfig,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult {
        val extraObj = providerConfig.parseExtraParams()
        val tempOverride = extraObj?.takeIf { it.has("temperature") }?.optDouble("temperature")?.toFloat()
        val maxTokOverride = extraObj?.takeIf { it.has("max_tokens") }?.optInt("max_tokens")?.takeIf { it > 0 }
        val effectiveConfig = config.copy(
            temperature = tempOverride ?: config.temperature,
            maxTokens = maxTokOverride ?: config.maxTokens
        )
        return streamCustomApi(
            apiKey = providerConfig.apiKey,
            compatibility = providerConfig.compatibility,
            optionalBaseUrl = providerConfig.baseUrl,
            optionalModel = providerConfig.effectiveModel(),
            extraHeaders = providerConfig.parsedExtraHeaders(),
            providerLabel = providerConfig.name.ifBlank { "Custom API" },
            history = history,
            userPrompt = userPrompt,
            imagePath = imagePath,
            config = effectiveConfig,
            onToken = onToken
        )
    }

    suspend fun streamCustomApi(
        apiKey: String,
        compatibility: CustomApiCompatibility,
        optionalBaseUrl: String,
        optionalModel: String,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit,
        extraHeaders: Map<String, String> = emptyMap(),
        providerLabel: String = "Custom API"
    ): GenerationResult {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank() && optionalBaseUrl.isBlank()) {
            return GenerationResult.Failed("Укажите URL и API-ключ для $providerLabel.")
        }
        val resolved = CustomApiResolver.resolve(
            rawKey = cleanKey,
            compatibility = compatibility,
            optionalBaseUrl = optionalBaseUrl,
            optionalModel = optionalModel
        )
        return when (resolved.compatibility) {
            CustomApiCompatibility.ANTHROPIC_COMPATIBLE -> streamAnthropicCompatible(
                endpointUrl = resolveAnthropicMessagesEndpoint(resolved.baseUrl),
                apiKey = cleanKey,
                model = resolved.model,
                extraHeaders = extraHeaders,
                history = history,
                userPrompt = userPrompt,
                imagePath = imagePath,
                config = config,
                onToken = onToken
            )
            CustomApiCompatibility.OPENAI_COMPATIBLE -> streamOpenAiCompatible(
                providerName = providerLabel,
                endpointUrl = resolveChatCompletionsEndpoint(resolved.baseUrl),
                apiKey = cleanKey,
                model = resolved.model,
                extraHeaders = extraHeaders,
                history = history,
                userPrompt = userPrompt,
                imagePath = imagePath,
                config = config,
                onToken = onToken
            )
        }
    }

    private suspend fun streamAnthropicCompatible(
        endpointUrl: String,
        apiKey: String,
        model: String,
        extraHeaders: Map<String, String>,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult = withContext(Dispatchers.IO) {
        cancelled.set(false)
        val startMs = System.currentTimeMillis()
        val payload = buildAnthropicPayload(model, history, userPrompt, imagePath, config)
        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .header("anthropic-version", ANTHROPIC_API_VERSION)
            .header("Content-Type", "application/json")
            .header("Accept", "text/event-stream")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
        if (apiKey.isNotBlank()) {
            reqBuilder.header("x-api-key", apiKey)
        }
        for ((k, v) in extraHeaders) {
            reqBuilder.header(k, v)
        }

        val call = httpClient.newCall(reqBuilder.build())
        activeCall.set(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val errText = resp.body?.string().orEmpty()
                    return@withContext GenerationResult.Failed(
                        "Anthropic API ($model, HTTP ${resp.code}): ${extractErrorMessage(errText)}"
                    )
                }
                val body = resp.body ?: return@withContext GenerationResult.Failed("Anthropic API: пустой ответ сервера.")
                val collected = StringBuilder()
                val reader = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8))
                while (true) {
                    if (cancelled.get()) {
                        return@withContext GenerationResult.Cancelled(collected.toString())
                    }
                    val line = reader.readLine() ?: break
                    val trimmed = line.trim()
                    if (!trimmed.startsWith("data:")) continue
                    val dataStr = trimmed.removePrefix("data:").trim()
                    if (dataStr.isEmpty() || dataStr == "[DONE]") continue
                    val (textChunk, thoughtChunk) = parseAnthropicSse(dataStr)
                    if (thoughtChunk.isNotEmpty()) {
                        config.onThought?.invoke(thoughtChunk)
                    }
                    if (textChunk.isNotEmpty()) {
                        collected.append(textChunk)
                        onToken(textChunk)
                    }
                }
                val finalText = collected.toString().trim()
                if (finalText.isEmpty()) {
                    return@withContext GenerationResult.Failed("Anthropic API ($model): сервер вернул пустой ответ.")
                }
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                GenerationResult.Completed(text = finalText, elapsedMs = elapsed)
            }
        } catch (e: IOException) {
            if (cancelled.get()) GenerationResult.Cancelled("")
            else GenerationResult.Failed("Anthropic API сеть: ${e.message ?: "нет соединения"}")
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    private suspend fun streamOpenAiCompatible(
        providerName: String,
        endpointUrl: String,
        apiKey: String,
        model: String,
        extraHeaders: Map<String, String>,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult = withContext(Dispatchers.IO) {
        cancelled.set(false)
        val startMs = System.currentTimeMillis()
        val payload = buildOpenAiPayload(model, history, userPrompt, imagePath, config)
        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .header("Content-Type", "application/json")
            .header("Accept", "text/event-stream")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
        if (apiKey.isNotBlank()) {
            reqBuilder.header("Authorization", "Bearer $apiKey")
        }
        for ((k, v) in extraHeaders) {
            reqBuilder.header(k, v)
        }

        val call = httpClient.newCall(reqBuilder.build())
        activeCall.set(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val errText = resp.body?.string().orEmpty()
                    return@withContext GenerationResult.Failed(
                        "$providerName ($model, HTTP ${resp.code}): ${extractErrorMessage(errText)}"
                    )
                }
                val body = resp.body ?: return@withContext GenerationResult.Failed("$providerName: пустой ответ сервера.")
                val collected = StringBuilder()
                val reader = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8))
                while (true) {
                    if (cancelled.get()) {
                        return@withContext GenerationResult.Cancelled(collected.toString())
                    }
                    val line = reader.readLine() ?: break
                    val trimmed = line.trim()
                    if (trimmed.isEmpty() || trimmed.startsWith(":")) continue
                    if (!trimmed.startsWith("data:")) continue
                    val dataStr = trimmed.removePrefix("data:").trim()
                    if (dataStr == "[DONE]") break
                    val (textChunk, thoughtChunk) = parseOpenAiDelta(dataStr)
                    if (thoughtChunk.isNotEmpty()) {
                        config.onThought?.invoke(thoughtChunk)
                    }
                    if (textChunk.isNotEmpty()) {
                        collected.append(textChunk)
                        onToken(textChunk)
                    }
                }
                val finalText = collected.toString().trim()
                if (finalText.isEmpty()) {
                    return@withContext GenerationResult.Failed("$providerName ($model): сервер вернул пустой ответ.")
                }
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                GenerationResult.Completed(text = finalText, elapsedMs = elapsed)
            }
        } catch (e: IOException) {
            if (cancelled.get()) {
                GenerationResult.Cancelled("")
            } else {
                GenerationResult.Failed("$providerName сеть: ${e.message ?: "нет соединения"}")
            }
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    // --- Connection test helpers ---

    suspend fun testGeminiKey(
        apiKey: String,
        model: String,
        endpointMode: GeminiEndpointMode
    ): CloudTestResult = withContext(Dispatchers.IO) {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) {
            return@withContext CloudTestResult(CloudProvider.GEMINI, false, "Ключ не указан")
        }
        val modelsToTry = buildList {
            add(model.trim().ifEmpty { DEFAULT_GEMINI_MODEL })
            for (fb in GEMINI_FALLBACK_MODELS) if (!contains(fb)) add(fb)
        }
        val endpoints = buildGeminiEndpoints(endpointMode, cachedUseVertex = false)
        val payload = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", "Ответь одним словом: ОК")))
                    }
                )
            )
            put("generationConfig", JSONObject().put("maxOutputTokens", 16))
        }

        var lastReason = "Нет ответа от Gemini"
        for ((baseUrl, isVertex) in endpoints) {
            var switchEndpoint = false
            for (modelId in modelsToTry) {
                val url = "${baseUrl.trimEnd('/')}/models/$modelId:generateContent"
                val req = Request.Builder()
                    .url(url)
                    .header("x-goog-api-key", cleanKey)
                    .header("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                    .build()
                try {
                    httpClient.newCall(req).execute().use { resp ->
                        val bodyStr = resp.body?.string().orEmpty()
                        if (resp.isSuccessful) {
                            val label = if (isVertex) "Vertex Express" else "AI Studio"
                            return@withContext CloudTestResult(
                                provider = CloudProvider.GEMINI,
                                ok = true,
                                summaryRu = "Подключено ($label • $modelId)",
                                detectedVertex = isVertex
                            )
                        }
                        val friendly = diagnoseGeminiError(resp.code, extractErrorMessage(bodyStr))
                        lastReason = "HTTP ${resp.code}: $friendly"
                        if (resp.code == 400 || resp.code == 401 || resp.code == 403) {
                            switchEndpoint = true
                        }
                    }
                } catch (e: Exception) {
                    lastReason = "Сеть: ${e.message}"
                }
                if (switchEndpoint) break
            }
        }
        CloudTestResult(CloudProvider.GEMINI, false, lastReason)
    }

    suspend fun testGroqKey(apiKey: String): CloudTestResult = withContext(Dispatchers.IO) {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) return@withContext CloudTestResult(CloudProvider.GROQ, false, "Ключ не указан")
        val req = Request.Builder()
            .url("${groqBaseUrl.trimEnd('/')}/models")
            .header("Authorization", "Bearer $cleanKey")
            .get()
            .build()
        try {
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val hasWhisper = body.contains("whisper-large-v3", ignoreCase = true)
                    val note = if (hasWhisper) "Whisper + Llama доступны" else "ключ активен"
                    CloudTestResult(CloudProvider.GROQ, true, "Подключено ($note)")
                } else {
                    CloudTestResult(CloudProvider.GROQ, false, "HTTP ${resp.code}: ${extractErrorMessage(body)}")
                }
            }
        } catch (e: Exception) {
            CloudTestResult(CloudProvider.GROQ, false, "Сеть: ${e.message}")
        }
    }

    suspend fun testOpenRouterKey(apiKey: String): CloudTestResult = withContext(Dispatchers.IO) {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) return@withContext CloudTestResult(CloudProvider.OPENROUTER, false, "Ключ не указан")
        val req = Request.Builder()
            .url("${openRouterBaseUrl.trimEnd('/')}/key")
            .header("Authorization", "Bearer $cleanKey")
            .header("HTTP-Referer", "https://github.com/ilya4575/jarvis")
            .header("X-Title", "Jarvis Android")
            .get()
            .build()
        try {
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    CloudTestResult(CloudProvider.OPENROUTER, true, "Подключено (OpenRouter готов)")
                } else {
                    CloudTestResult(CloudProvider.OPENROUTER, false, "HTTP ${resp.code}: ${extractErrorMessage(body)}")
                }
            }
        } catch (e: Exception) {
            CloudTestResult(CloudProvider.OPENROUTER, false, "Сеть: ${e.message}")
        }
    }

    suspend fun testCustomProvider(cfg: CustomProviderConfig): CloudTestResult =
        testCustomApi(
            apiKey = cfg.apiKey,
            compatibility = cfg.compatibility,
            optionalBaseUrl = cfg.baseUrl,
            optionalModel = cfg.effectiveModel(),
            extraHeaders = cfg.parsedExtraHeaders()
        )

    suspend fun testCustomApi(
        apiKey: String,
        compatibility: CustomApiCompatibility,
        optionalBaseUrl: String,
        optionalModel: String,
        extraHeaders: Map<String, String> = emptyMap()
    ): CloudTestResult = withContext(Dispatchers.IO) {
        val cleanKey = sanitizeApiKey(apiKey)
        if (cleanKey.isBlank() && optionalBaseUrl.isBlank()) {
            return@withContext CloudTestResult(CloudProvider.CUSTOM_API, false, "Укажите URL и API-ключ")
        }
        val resolved = CustomApiResolver.resolve(
            rawKey = cleanKey,
            compatibility = compatibility,
            optionalBaseUrl = optionalBaseUrl,
            optionalModel = optionalModel
        )
        if (resolved.compatibility == CustomApiCompatibility.ANTHROPIC_COMPATIBLE) {
            val endpoint = resolveAnthropicMessagesEndpoint(resolved.baseUrl)
            val payload = JSONObject().apply {
                put("model", resolved.model)
                put("max_tokens", 16)
                put(
                    "messages",
                    JSONArray().put(JSONObject().put("role", "user").put("content", "Ответь одним словом: ОК"))
                )
            }
            val rb = Request.Builder()
                .url(endpoint)
                .header("anthropic-version", ANTHROPIC_API_VERSION)
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            if (cleanKey.isNotBlank()) rb.header("x-api-key", cleanKey)
            for ((k, v) in extraHeaders) rb.header(k, v)
            try {
                httpClient.newCall(rb.build()).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        CloudTestResult(CloudProvider.CUSTOM_API, true, "Подключено (Anthropic • ${resolved.model})")
                    } else {
                        CloudTestResult(CloudProvider.CUSTOM_API, false, "HTTP ${resp.code}: ${extractErrorMessage(body)}")
                    }
                }
            } catch (e: Exception) {
                CloudTestResult(CloudProvider.CUSTOM_API, false, "Сеть: ${e.message}")
            }
        } else {
            testOpenAiKey(
                provider = CloudProvider.CUSTOM_API,
                baseUrl = resolved.baseUrl,
                apiKey = cleanKey,
                model = resolved.model,
                extraHeaders = extraHeaders
            )
        }
    }

    suspend fun testOpenAiKey(
        provider: CloudProvider,
        baseUrl: String,
        apiKey: String,
        model: String,
        extraHeaders: Map<String, String> = emptyMap()
    ): CloudTestResult = withContext(Dispatchers.IO) {
        val cleanKey = sanitizeApiKey(apiKey)
        val cleanBase = baseUrl.trim().trimEnd('/')
        if (cleanBase.isBlank()) {
            return@withContext CloudTestResult(provider, false, "Укажите URL")
        }
        val endpoint = resolveChatCompletionsEndpoint(cleanBase)
        val payload = JSONObject().apply {
            put("model", model.trim())
            put("max_tokens", 12)
            put("stream", false)
            put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", "Ответь одним словом: ОК"))
            )
        }
        val rb = Request.Builder()
            .url(endpoint)
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
        if (cleanKey.isNotBlank()) rb.header("Authorization", "Bearer $cleanKey")
        for ((k, v) in extraHeaders) rb.header(k, v)
        try {
            httpClient.newCall(rb.build()).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    CloudTestResult(provider, true, "Подключено ($model)")
                } else {
                    CloudTestResult(provider, false, "HTTP ${resp.code}: ${extractErrorMessage(body)}")
                }
            }
        } catch (e: Exception) {
            CloudTestResult(provider, false, "Сеть: ${e.message}")
        }
    }

    suspend fun fetchOpenRouterFreeModels(apiKey: String): Result<List<OpenRouterFreeModel>> =
        withContext(Dispatchers.IO) {
            val reqBuilder = Request.Builder()
                .url("${openRouterBaseUrl.trimEnd('/')}/models")
                .header("HTTP-Referer", "https://github.com/ilya4575/jarvis")
                .header("X-Title", "Jarvis Android")
                .get()
            val cleanKey = sanitizeApiKey(apiKey)
            if (cleanKey.isNotBlank()) {
                reqBuilder.header("Authorization", "Bearer $cleanKey")
            }
            try {
                httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext Result.failure(
                            IllegalStateException("HTTP ${resp.code}: ${extractErrorMessage(body)}")
                        )
                    }
                    val root = JSONObject(body)
                    val data = root.optJSONArray("data") ?: JSONArray()
                    val result = mutableListOf(
                        OpenRouterFreeModel(
                            id = DEFAULT_OPENROUTER_MODEL,
                            name = "Авто-выбор бесплатной модели (openrouter/free)",
                            contextLength = 128_000,
                            supportsVision = true
                        )
                    )
                    for (i in 0 until data.length()) {
                        val obj = data.optJSONObject(i) ?: continue
                        val id = obj.optString("id", "").trim()
                        if (id.isEmpty() || id == DEFAULT_OPENROUTER_MODEL) continue
                        val pricing = obj.optJSONObject("pricing")
                        val promptPrice = pricing?.optString("prompt", "1")?.toDoubleOrNull() ?: 1.0
                        val compPrice = pricing?.optString("completion", "1")?.toDoubleOrNull() ?: 1.0
                        val isFree = id.endsWith(":free") || (promptPrice == 0.0 && compPrice == 0.0)
                        if (!isFree) continue
                        val name = obj.optString("name", id).trim()
                        val ctx = obj.optInt("context_length", 32_768)
                        val arch = obj.optJSONObject("architecture")
                        val inMods = arch?.optJSONArray("input_modalities")
                        var vision = false
                        if (inMods != null) {
                            for (j in 0 until inMods.length()) {
                                if (inMods.optString(j) == "image") vision = true
                            }
                        }
                        result.add(OpenRouterFreeModel(id, name, ctx, vision))
                    }
                    Result.success(result)
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // --- Internal SSE & Payload Helpers ---

    private fun buildGeminiEndpoints(
        mode: GeminiEndpointMode,
        cachedUseVertex: Boolean
    ): List<Pair<String, Boolean>> = when (mode) {
        GeminiEndpointMode.AI_STUDIO -> listOf(geminiAiStudioBaseUrl to false)
        GeminiEndpointMode.VERTEX_EXPRESS -> buildList {
            add(geminiVertexBaseUrl to true)
            if (geminiVertexBaseUrl == DEFAULT_GEMINI_VERTEX_BASE) {
                add(DEFAULT_GEMINI_VERTEX_BETA_BASE to true)
            }
        }
        GeminiEndpointMode.AUTO -> buildList {
            if (cachedUseVertex) {
                add(geminiVertexBaseUrl to true)
                if (geminiVertexBaseUrl == DEFAULT_GEMINI_VERTEX_BASE) {
                    add(DEFAULT_GEMINI_VERTEX_BETA_BASE to true)
                }
                add(geminiAiStudioBaseUrl to false)
            } else {
                add(geminiAiStudioBaseUrl to false)
                add(geminiVertexBaseUrl to true)
                if (geminiVertexBaseUrl == DEFAULT_GEMINI_VERTEX_BASE) {
                    add(DEFAULT_GEMINI_VERTEX_BETA_BASE to true)
                }
            }
        }
    }

    private sealed class HttpStreamOutcome {
        data class Success(val result: GenerationResult.Completed) : HttpStreamOutcome()
        data class Cancelled(val partial: String) : HttpStreamOutcome()
        data class HttpError(val code: Int, val shortMsg: String) : HttpStreamOutcome()
        data class NetworkError(val msg: String) : HttpStreamOutcome()
    }

    private fun executeGeminiSseRequest(
        req: Request,
        startMs: Long,
        onToken: (String) -> Unit,
        onThought: ((String) -> Unit)?
    ): HttpStreamOutcome {
        val call = httpClient.newCall(req)
        activeCall.set(call)
        return try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val errText = resp.body?.string().orEmpty()
                    return HttpStreamOutcome.HttpError(resp.code, extractErrorMessage(errText))
                }
                val body = resp.body ?: return HttpStreamOutcome.HttpError(502, "Пустой поток ответа")
                val collected = StringBuilder()
                val reader = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8))
                while (true) {
                    if (cancelled.get()) {
                        return HttpStreamOutcome.Cancelled(collected.toString())
                    }
                    val line = reader.readLine() ?: break
                    val trimmed = line.trim()
                    if (!trimmed.startsWith("data:")) continue
                    val dataStr = trimmed.removePrefix("data:").trim()
                    if (dataStr.isEmpty() || dataStr == "[DONE]") continue
                    val (textChunk, thoughtChunk) = parseGeminiSse(dataStr)
                    if (thoughtChunk.isNotEmpty()) onThought?.invoke(thoughtChunk)
                    if (textChunk.isNotEmpty()) {
                        collected.append(textChunk)
                        onToken(textChunk)
                    }
                }
                val finalText = collected.toString().trim()
                if (finalText.isEmpty()) {
                    return HttpStreamOutcome.HttpError(502, "Gemini вернул пустой ответ")
                }
                val elapsed = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                HttpStreamOutcome.Success(
                    GenerationResult.Completed(text = finalText, elapsedMs = elapsed)
                )
            }
        } catch (e: IOException) {
            if (cancelled.get()) HttpStreamOutcome.Cancelled("")
            else HttpStreamOutcome.NetworkError(e.message ?: "нет соединения")
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    private fun buildGeminiPayload(
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig
    ): JSONObject {
        val systemText = LlamaInferenceEngine.buildSystemInstruction(config)
        val window = ChatContextManager.clampWindowSize(config.contextWindowSize)
        val contents = JSONArray()
        for (turn in history.takeLast(window)) {
            val cleaned = turn.content.trim()
            if (cleaned.isEmpty()) continue
            val role = if (turn.role == "user") "user" else "model"
            contents.put(
                JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", cleaned)))
                }
            )
        }
        val userParts = JSONArray()
        val encoded = encodeImageFile(imagePath)
        if (encoded != null) {
            userParts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject()
                        .put("mimeType", encoded.first)
                        .put("data", encoded.second)
                )
            )
        }
        val promptText = userPrompt.trim().ifEmpty { "Опиши это изображение подробно на русском языке." }
        userParts.put(JSONObject().put("text", promptText))
        contents.put(
            JSONObject().apply {
                put("role", "user")
                put("parts", userParts)
            }
        )

        return JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().apply {
                    put("role", "system")
                    put("parts", JSONArray().put(JSONObject().put("text", systemText)))
                }
            )
            put("contents", contents)
            put(
                "generationConfig",
                JSONObject().apply {
                    put("temperature", config.temperature.toDouble().coerceIn(0.0, 2.0))
                    put("maxOutputTokens", config.maxTokens.coerceIn(128, 4096))
                }
            )
        }
    }

    private fun buildOpenAiPayload(
        model: String,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig
    ): JSONObject {
        val systemText = LlamaInferenceEngine.buildSystemInstruction(config)
        val window = ChatContextManager.clampWindowSize(config.contextWindowSize)
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemText))
        for (turn in history.takeLast(window)) {
            val cleaned = turn.content.trim()
            if (cleaned.isEmpty()) continue
            messages.put(
                JSONObject()
                    .put("role", if (turn.role == "user") "user" else "assistant")
                    .put("content", cleaned)
            )
        }
        val encoded = encodeImageFile(imagePath)
        val promptText = userPrompt.trim().ifEmpty { "Опиши это изображение подробно на русском языке." }
        if (encoded != null) {
            val contentArr = JSONArray()
                .put(JSONObject().put("type", "text").put("text", promptText))
                .put(
                    JSONObject()
                        .put("type", "image_url")
                        .put("image_url", JSONObject().put("url", "data:${encoded.first};base64,${encoded.second}"))
                )
            messages.put(JSONObject().put("role", "user").put("content", contentArr))
        } else {
            messages.put(JSONObject().put("role", "user").put("content", promptText))
        }

        return JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", config.temperature.toDouble().coerceIn(0.0, 2.0))
            put("max_tokens", config.maxTokens.coerceIn(128, 4096))
            put("stream", true)
        }
    }

    private fun compactHistoryForBudget(
        history: List<ChatTurn>,
        maxTurns: Int,
        maxTotalChars: Int
    ): List<ChatTurn> {
        val slice = history.takeLast(maxTurns)
        if (slice.isEmpty()) return emptyList()
        val perTurnBudget = (maxTotalChars / slice.size).coerceIn(320, 1400)
        return slice.map { turn ->
            if (turn.content.length > perTurnBudget) {
                turn.copy(content = turn.content.take(perTurnBudget) + "…")
            } else turn
        }
    }

    private fun encodeImageFile(path: String?): Pair<String, String>? {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return null
        return runCatching {
            val bytes = file.readBytes()
            val mime = when (file.extension.lowercase()) {
                "png" -> "image/png"
                "webp" -> "image/webp"
                else -> "image/jpeg"
            }
            val b64 = try {
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            } catch (_: Throwable) {
                java.util.Base64.getEncoder().encodeToString(bytes)
            }
            mime to b64
        }.getOrNull()
    }

    private fun parseGeminiSse(jsonStr: String): Pair<String, String> {
        return runCatching {
            val root = JSONObject(jsonStr)
            val candidates = root.optJSONArray("candidates") ?: return "" to ""
            val textSb = StringBuilder()
            val thoughtSb = StringBuilder()
            for (i in 0 until candidates.length()) {
                val cand = candidates.optJSONObject(i) ?: continue
                val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (j in 0 until parts.length()) {
                    val part = parts.optJSONObject(j) ?: continue
                    val t = part.optString("text", "")
                    if (t.isEmpty()) continue
                    if (part.optBoolean("thought", false)) {
                        thoughtSb.append(t)
                    } else {
                        textSb.append(t)
                    }
                }
            }
            textSb.toString() to thoughtSb.toString()
        }.getOrDefault("" to "")
    }

    private fun parseOpenAiDelta(jsonStr: String): Pair<String, String> {
        return runCatching {
            val root = JSONObject(jsonStr)
            val choices = root.optJSONArray("choices") ?: return "" to ""
            val first = choices.optJSONObject(0) ?: return "" to ""
            val delta = first.optJSONObject("delta")
            val thought = delta?.optString("reasoning_content", "")?.ifEmpty {
                delta.optString("reasoning", "")
            }.orEmpty()
            val content = delta?.optString("content", "") ?: ""
            if (content.isNotEmpty() || thought.isNotEmpty()) return content to thought
            val msgContent = first.optJSONObject("message")?.optString("content", "") ?: ""
            msgContent to ""
        }.getOrDefault("" to "")
    }

    private fun buildAnthropicPayload(
        model: String,
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig
    ): JSONObject {
        val systemText = LlamaInferenceEngine.buildSystemInstruction(config)
        val window = ChatContextManager.clampWindowSize(config.contextWindowSize)
        val messages = JSONArray()
        var lastRole: String? = null
        for (turn in history.takeLast(window)) {
            val cleaned = turn.content.trim()
            if (cleaned.isEmpty()) continue
            val role = if (turn.role == "user") "user" else "assistant"
            if (messages.length() == 0 && role != "user") continue
            if (role == lastRole && messages.length() > 0) {
                val prev = messages.getJSONObject(messages.length() - 1)
                prev.put("content", prev.optString("content") + "\n" + cleaned)
                continue
            }
            messages.put(JSONObject().put("role", role).put("content", cleaned))
            lastRole = role
        }
        val encoded = encodeImageFile(imagePath)
        val promptText = userPrompt.trim().ifEmpty { "Опиши это изображение подробно на русском языке." }
        if (lastRole == "user" && encoded == null && messages.length() > 0) {
            val prev = messages.getJSONObject(messages.length() - 1)
            prev.put("content", prev.optString("content") + "\n" + promptText)
        } else if (encoded != null) {
            val contentBlocks = JSONArray()
                .put(
                    JSONObject()
                        .put("type", "image")
                        .put(
                            "source",
                            JSONObject()
                                .put("type", "base64")
                                .put("media_type", encoded.first)
                                .put("data", encoded.second)
                        )
                )
                .put(JSONObject().put("type", "text").put("text", promptText))
            messages.put(JSONObject().put("role", "user").put("content", contentBlocks))
        } else {
            messages.put(JSONObject().put("role", "user").put("content", promptText))
        }

        return JSONObject().apply {
            put("model", model)
            put("system", systemText)
            put("messages", messages)
            put("max_tokens", config.maxTokens.coerceIn(128, 4096))
            put("temperature", config.temperature.toDouble().coerceIn(0.0, 1.0))
            put("stream", true)
        }
    }

    private fun parseAnthropicSse(jsonStr: String): Pair<String, String> {
        return runCatching {
            val root = JSONObject(jsonStr)
            when (root.optString("type")) {
                "content_block_delta" -> {
                    val delta = root.optJSONObject("delta")
                    when (delta?.optString("type")) {
                        "text_delta" -> delta.optString("text", "") to ""
                        "thinking_delta" -> "" to delta.optString("thinking", "")
                        else -> "" to ""
                    }
                }
                "content_block_start" -> {
                    val cb = root.optJSONObject("content_block")
                    if (cb?.optString("type") == "text") cb.optString("text", "") to "" else "" to ""
                }
                else -> "" to ""
            }
        }.getOrDefault("" to "")
    }

    companion object {
        const val ANTHROPIC_API_VERSION = "2023-06-01"
        const val DEFAULT_GEMINI_AI_STUDIO_BASE = "https://generativelanguage.googleapis.com/v1beta"
        const val DEFAULT_GEMINI_VERTEX_BASE = "https://aiplatform.googleapis.com/v1/publishers/google"
        const val DEFAULT_GEMINI_VERTEX_BETA_BASE = "https://aiplatform.googleapis.com/v1beta1/publishers/google"
        const val DEFAULT_GROQ_BASE = "https://api.groq.com/openai/v1"
        const val DEFAULT_OPENROUTER_BASE = "https://openrouter.ai/api/v1"

        const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
        const val FALLBACK_GEMINI_MODEL = "gemini-2.5-flash-lite"
        private val GEMINI_FALLBACK_MODELS = listOf("gemini-2.5-flash-lite", "gemini-2.0-flash")

        const val DEFAULT_GROQ_LLM_MODEL = "llama-3.3-70b-versatile"
        const val DEFAULT_GROQ_VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"
        private val GROQ_FALLBACK_MODELS = listOf(
            "llama-3.1-8b-instant",
            "meta-llama/llama-4-scout-17b-16e-instruct"
        )

        const val DEFAULT_OPENROUTER_MODEL = "openrouter/free"
        private val OPENROUTER_FREE_FALLBACKS = listOf(
            "google/gemma-3-27b-it:free",
            "meta-llama/llama-3.3-70b-instruct:free",
            "qwen/qwen3-next-80b-a3b-instruct:free"
        )

        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        fun sanitizeApiKey(raw: String): String {
            return raw
                .replace("\u200B", "")
                .replace("\uFEFF", "")
                .trim()
                .trim('"', '\'', '`')
                .trim()
                .removePrefix("Bearer ")
                .removePrefix("bearer ")
                .trim()
                .trim('"', '\'', '`')
                .trim()
        }

        fun resolveChatCompletionsEndpoint(baseUrl: String): String {
            val clean = baseUrl.trim().trimEnd('/')
            return if (clean.endsWith("/chat/completions")) clean else "$clean/chat/completions"
        }

        fun resolveAnthropicMessagesEndpoint(baseUrl: String): String {
            val clean = baseUrl.trim().trimEnd('/')
            return when {
                clean.endsWith("/messages") -> clean
                clean.endsWith("/v1") -> "$clean/messages"
                else -> "$clean/v1/messages"
            }
        }

        fun diagnoseGeminiError(@Suppress("UNUSED_PARAMETER") httpCode: Int, rawMsg: String): String {
            val lower = rawMsg.lowercase()
            return when {
                lower.contains("location is not supported") ->
                    "Регион VPN не поддерживается Google Gemini — смените страну VPN на США/Германию/Нидерланды или выберите OpenRouter / Groq / Custom."
                lower.contains("api_key_invalid") || lower.contains("api key not valid") ->
                    "Ключ не принят этой точкой Google (проверьте, что ключ свежий и без лишних символов, или пересоздайте его в aistudio.google.com)."
                else -> rawMsg
            }
        }

        fun extractErrorMessage(raw: String): String {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) return "пустой ответ ошибки"
            return runCatching {
                val root = JSONObject(trimmed)
                val errObj = root.optJSONObject("error")
                val msg = errObj?.optString("message")?.takeIf { it.isNotBlank() }
                    ?: root.optString("message").takeIf { it.isNotBlank() }
                    ?: trimmed
                msg.take(220)
            }.getOrDefault(trimmed.take(220))
        }
    }
}
