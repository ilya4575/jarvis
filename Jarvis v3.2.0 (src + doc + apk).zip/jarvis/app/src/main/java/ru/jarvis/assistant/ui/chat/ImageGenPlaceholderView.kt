package ru.jarvis.assistant.ui.chat

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * A4: Smooth 60-FPS animated placeholder with orbiting glowing circles and drifting particles
 * displayed inside the chat message while Perchance generates an image.
 */
class ImageGenPlaceholderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var phase = 0f
    private var animator: ValueAnimator? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E5E7EB")
        textAlign = Paint.Align.CENTER
    }

    private val particleSeeds = FloatArray(18) { i -> (i * 0.37f) % 1f }

    fun startAnimating() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, (2.0 * PI).toFloat()).apply {
            duration = 3200L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stopAnimating() {
        animator?.cancel()
        animator = null
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (visibility == VISIBLE) startAnimating()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) startAnimating() else stopAnimating()
    }

    override fun onDetachedFromWindow() {
        stopAnimating()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.44f
        val baseR = minOf(w, h) * 0.22f
        val d = resources.displayMetrics.density

        // Soft ambient radial glow background
        bgPaint.shader = RadialGradient(
            cx, cy, maxOf(w, h) * 0.65f,
            intArrayOf(Color.parseColor("#2A1B3D"), Color.parseColor("#13151F"), Color.parseColor("#0D0F16")),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(0f, 0f, w, h, 16f * d, 16f * d, bgPaint)

        // Concentric pulsing rings
        ringPaint.strokeWidth = 2.2f * d
        for (i in 0..2) {
            val pulse = 0.85f + 0.25f * sin((phase + i * 1.4f).toDouble()).toFloat()
            ringPaint.color = when (i) {
                0 -> Color.argb(120, 147, 197, 253)
                1 -> Color.argb(95, 216, 180, 254)
                else -> Color.argb(70, 251, 191, 36)
            }
            canvas.drawCircle(cx, cy, baseR * (0.65f + i * 0.38f) * pulse, ringPaint)
        }

        // 5 Orbiting luminous circles
        val orbitColors = intArrayOf(
            Color.parseColor("#60A5FA"),
            Color.parseColor("#A78BFA"),
            Color.parseColor("#F472B6"),
            Color.parseColor("#FBBF24"),
            Color.parseColor("#34D399")
        )
        for (i in 0 until 5) {
            val angle = phase * (if (i % 2 == 0) 1f else -1.3f) + i * (2f * PI.toFloat() / 5f)
            val orbitR = baseR * (0.72f + (i % 3) * 0.26f)
            val ox = cx + cos(angle.toDouble()).toFloat() * orbitR
            val oy = cy + sin(angle.toDouble()).toFloat() * orbitR
            val dotR = (4.5f + 2.2f * sin((phase * 2f + i).toDouble()).toFloat()) * d
            circlePaint.color = orbitColors[i]
            circlePaint.alpha = 230
            canvas.drawCircle(ox, oy, dotR, circlePaint)
        }

        // 18 Drifting sparkling particles
        for (i in particleSeeds.indices) {
            val seed = particleSeeds[i]
            val pAngle = seed * 2f * PI.toFloat() + phase * (0.4f + (i % 4) * 0.15f)
            val radialFrac = 0.35f + ((seed + phase / (2f * PI.toFloat())) % 1f) * 1.25f
            val px = cx + cos(pAngle.toDouble()).toFloat() * baseR * radialFrac * 1.4f
            val py = cy + sin(pAngle.toDouble()).toFloat() * baseR * radialFrac * 1.15f
            val alpha = ((1f - (radialFrac - 0.35f) / 1.25f).coerceIn(0f, 1f) * 215).toInt()
            particlePaint.color = orbitColors[i % orbitColors.size]
            particlePaint.alpha = alpha
            canvas.drawCircle(px, py, (1.6f + (i % 3) * 0.8f) * d, particlePaint)
        }

        // Caption at bottom
        labelPaint.textSize = 12.5f * d
        canvas.drawText("Генерация изображения (Perchance)…", cx, h - 18f * d, labelPaint)
    }
}
