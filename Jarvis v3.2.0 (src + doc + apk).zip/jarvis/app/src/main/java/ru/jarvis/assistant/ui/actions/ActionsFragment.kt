package ru.jarvis.assistant.ui.actions

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.feature.accessibility.ActionPlan
import ru.jarvis.assistant.feature.accessibility.JarvisAccessibilityService
import ru.jarvis.assistant.feature.accessibility.RiskLevel
import ru.jarvis.assistant.feature.commands.CommandStepType
import ru.jarvis.assistant.feature.commands.CoordinateRecorderOverlay
import ru.jarvis.assistant.feature.commands.CustomCommand
import ru.jarvis.assistant.feature.commands.CustomCommandStep
import java.util.UUID

class ActionsFragment : Fragment() {

    private lateinit var serviceStatusText: TextView
    private lateinit var agentToolsSwitch: SwitchMaterial
    private lateinit var masterSwitch: SwitchMaterial
    private lateinit var agentLimitLabel: TextView
    private lateinit var agentLimitSeek: SeekBar
    private lateinit var openA11ySettingsBtn: MaterialButton
    private lateinit var howToDisableBtn: MaterialButton

    private lateinit var addCustomCmdBtn: MaterialButton
    private lateinit var customCmdsContainer: LinearLayout

    private lateinit var commandEditText: EditText
    private lateinit var previewPlanBtn: MaterialButton
    private lateinit var exampleSettingsBtn: MaterialButton
    private lateinit var exampleCalcBtn: MaterialButton
    private lateinit var planCard: MaterialCardView
    private lateinit var planDetailsText: TextView
    private lateinit var confirmExecuteBtn: MaterialButton
    private lateinit var executionLogText: TextView

    private var currentPlan: ActionPlan? = null
    private var recorderOverlay: CoordinateRecorderOverlay? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_actions, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance

        view.findViewById<android.widget.ImageButton>(R.id.actions_back_btn).setOnClickListener {
            (activity as? ru.jarvis.assistant.ui.MainActivity)?.popToChat()
        }

        serviceStatusText = view.findViewById(R.id.actions_service_status)
        agentToolsSwitch = view.findViewById(R.id.actions_agent_tools_switch)
        masterSwitch = view.findViewById(R.id.actions_master_switch)
        agentLimitLabel = view.findViewById(R.id.actions_agent_limit_label)
        agentLimitSeek = view.findViewById(R.id.actions_agent_limit_seek)
        openA11ySettingsBtn = view.findViewById(R.id.actions_open_settings_btn)
        howToDisableBtn = view.findViewById(R.id.actions_disable_guide_btn)

        addCustomCmdBtn = view.findViewById(R.id.actions_add_custom_cmd_btn)
        customCmdsContainer = view.findViewById(R.id.actions_custom_cmds_container)

        commandEditText = view.findViewById(R.id.actions_command_edit)
        previewPlanBtn = view.findViewById(R.id.actions_preview_btn)
        exampleSettingsBtn = view.findViewById(R.id.actions_example_settings)
        exampleCalcBtn = view.findViewById(R.id.actions_example_calc)
        planCard = view.findViewById(R.id.actions_plan_card)
        planDetailsText = view.findViewById(R.id.actions_plan_details)
        confirmExecuteBtn = view.findViewById(R.id.actions_confirm_exec_btn)
        executionLogText = view.findViewById(R.id.actions_exec_log)

        agentToolsSwitch.isChecked = app.prefs.agentToolsEnabled
        agentToolsSwitch.setOnCheckedChangeListener { _, checked ->
            app.prefs.agentToolsEnabled = checked
            refreshServiceStatus()
        }

        masterSwitch.isChecked = app.prefs.accessibilityMasterSwitch
        masterSwitch.setOnCheckedChangeListener { _, checked ->
            app.prefs.accessibilityMasterSwitch = checked
            app.prefs.accessibilityUserDisabled = !checked
            refreshServiceStatus()
        }

        // A8: 5..50 step limit slider
        val curLimit = app.prefs.agentMaxSteps.coerceIn(5, 50)
        agentLimitSeek.max = 45
        agentLimitSeek.progress = curLimit - 5
        agentLimitLabel.text = "Лимит действий агента за задачу: $curLimit (диапазон 5–50)"
        agentLimitSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val limit = (5 + progress).coerceIn(5, 50)
                app.prefs.agentMaxSteps = limit
                agentLimitLabel.text = "Лимит действий агента за задачу: $limit (диапазон 5–50)"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // A7: Custom Commands CRUD
        addCustomCmdBtn.setOnClickListener {
            showCommandEditorDialog(existing = null)
        }

        openA11ySettingsBtn.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Включение AccessibilityService вручную")
                .setMessage(
                    "Сервис Спецвозможностей позволяет выполнять нажатия и свайпы внутри других приложений.\n\n" +
                        "В настройках Android найдите «Jarvis» в разделе «Установленные приложения» и включите вручную."
                )
                .setPositiveButton("Открыть настройки Android") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        howToDisableBtn.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Как полностью отключить AccessibilityService")
                .setMessage(
                    "1. Выключите переключатель Спецвозможностей на этом экране.\n" +
                        "2. Откройте Настройки Android → Специальные возможности → Установленные приложения → Jarvis → Выключить."
                )
                .setPositiveButton("Открыть настройки") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Закрыть", null)
                .show()
        }

        exampleSettingsBtn.setOnClickListener {
            commandEditText.setText("Открой Настройки")
            buildAndShowPreview()
        }
        exampleCalcBtn.setOnClickListener {
            commandEditText.setText("Открой Калькулятор")
            buildAndShowPreview()
        }
        previewPlanBtn.setOnClickListener { buildAndShowPreview() }

        confirmExecuteBtn.setOnClickListener {
            val plan = currentPlan ?: return@setOnClickListener
            when (plan.riskLevel) {
                RiskLevel.HARD_BLOCKED_SENSITIVE -> {
                    Toast.makeText(requireContext(), "Действие заблокировано политикой безопасности.", Toast.LENGTH_LONG).show()
                }
                RiskLevel.HIGH_RISK_DOUBLE_CONFIRM -> {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Подтверждение чувствительного действия")
                        .setMessage("${plan.riskReasonRu}\n\nВыполнить этот план?")
                        .setPositiveButton("Да, выполнить") { _, _ -> runPlan(plan) }
                        .setNegativeButton("Отмена", null)
                        .show()
                }
                RiskLevel.SAFE_PREVIEW_REQUIRED -> runPlan(plan)
            }
        }

        refreshServiceStatus()
        renderCustomCommandsList()
    }

    override fun onResume() {
        super.onResume()
        refreshServiceStatus()
        renderCustomCommandsList()
    }

    override fun onDestroyView() {
        recorderOverlay?.dismiss()
        recorderOverlay = null
        super.onDestroyView()
    }

    // -------------------------------------------------------------------------
    // A7: Custom Commands List & Editor (Manual + Crosshair X&Y + AI Generator)
    // -------------------------------------------------------------------------

    private fun renderCustomCommandsList() {
        val repo = JarvisApplication.instance.customCommandRepository
        val commands = repo.listCommands()
        customCmdsContainer.removeAllViews()
        val d = resources.displayMetrics.density

        if (commands.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = "Пока нет пользовательских команд. Нажмите «+ Добавить команду»."
                setTextColor(Color.parseColor("#9CA3AF"))
                textSize = 12.5f
                setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
            }
            customCmdsContainer.addView(empty)
            return
        }

        for (cmd in commands) {
            val card = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                background = requireContext().getDrawable(R.drawable.bg_glass_pill)
                setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (8 * d).toInt() }
            }

            val titleTv = TextView(requireContext()).apply {
                text = cmd.name
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            card.addView(titleTv)

            val subTv = TextView(requireContext()).apply {
                val trig = if (cmd.triggerPhrase.isNotBlank()) "Триггер: «${cmd.triggerPhrase}»  •  " else ""
                text = "${trig}Шагов: ${cmd.steps.size}"
                setTextColor(Color.parseColor("#9CA3AF"))
                textSize = 12f
            }
            card.addView(subTv)

            val btnRow = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (8 * d).toInt() }
            }

            fun makeChip(label: String, colorHex: String, onClick: () -> Unit): TextView =
                TextView(requireContext()).apply {
                    text = label
                    setTextColor(Color.parseColor(colorHex))
                    textSize = 12f
                    gravity = Gravity.CENTER
                    background = requireContext().getDrawable(R.drawable.bg_glass_card)
                    setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = (6 * d).toInt()
                    }
                    setOnClickListener { onClick() }
                }

            btnRow.addView(makeChip("Запустить", "#5EF2A5") { runCustomCommand(cmd) })
            btnRow.addView(makeChip("Изменить", "#93C5FD") { showCommandEditorDialog(cmd) })
            btnRow.addView(makeChip("Удалить", "#FCA5A5") {
                AlertDialog.Builder(requireContext())
                    .setTitle("Удалить команду?")
                    .setMessage("Удалить «${cmd.name}»?")
                    .setPositiveButton("Удалить") { _, _ ->
                        repo.deleteCommand(cmd.id)
                        renderCustomCommandsList()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            })
            card.addView(btnRow)
            customCmdsContainer.addView(card)
        }
    }

    private fun runCustomCommand(cmd: CustomCommand) {
        viewLifecycleOwner.lifecycleScope.launch {
            executionLogText.visibility = View.VISIBLE
            executionLogText.text = "Запуск команды «${cmd.name}»…"
            val rep = JarvisApplication.instance.customCommandRepository.executeCommand(cmd)
            executionLogText.text = buildString {
                append(if (rep.succeeded) "Команда выполнена (${rep.completedSteps}/${rep.totalSteps}):\n" else "Команда остановлена:\n")
                rep.logsRu.forEach { append("• ").append(it).append('\n') }
            }.trim()
        }
    }

    private fun showCommandEditorDialog(existing: CustomCommand?) {
        val d = resources.displayMetrics.density
        val stepsList = existing?.steps?.toMutableList() ?: mutableListOf()

        val scroll = ScrollView(requireContext())
        val root = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
        }
        scroll.addView(root)

        // AI Command Generator block
        val aiHeader = TextView(requireContext()).apply {
            text = "Сгенерировать шаги с помощью ИИ"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.parseColor("#93C5FD"))
        }
        root.addView(aiHeader)

        val aiPromptEdit = EditText(requireContext()).apply {
            hint = "Например: Открой Telegram, подожди 2 сек и открой https://t.me/durov"
            minLines = 2
            maxLines = 3
        }
        root.addView(aiPromptEdit)

        val aiBtn = MaterialButton(requireContext()).apply { text = "Сгенерировать (ИИ)" }
        val aiStatus = TextView(requireContext()).apply {
            textSize = 11.5f
            setTextColor(Color.parseColor("#FDE68A"))
            visibility = View.GONE
        }
        root.addView(aiBtn)
        root.addView(aiStatus)

        val nameEdit = EditText(requireContext()).apply {
            hint = "Название команды (обязательно)"
            setText(existing?.name.orEmpty())
        }
        val triggerEdit = EditText(requireContext()).apply {
            hint = "Фраза-триггер в чате (опционально)"
            setText(existing?.triggerPhrase.orEmpty())
        }
        root.addView(nameEdit)
        root.addView(triggerEdit)

        val stepsTitle = TextView(requireContext()).apply {
            text = "Шаги команды:"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, (10 * d).toInt(), 0, (4 * d).toInt())
        }
        root.addView(stepsTitle)

        val stepsContainer = LinearLayout(requireContext()).apply { orientation = LinearLayout.VERTICAL }
        root.addView(stepsContainer)

        lateinit var renderSteps: () -> Unit
        renderSteps = {
            stepsContainer.removeAllViews()
            if (stepsList.isEmpty()) {
                stepsContainer.addView(TextView(requireContext()).apply {
                    text = "Нет шагов — добавьте вручную или сгенерируйте через ИИ."
                    textSize = 12f
                    setTextColor(Color.parseColor("#9CA3AF"))
                })
            } else {
                stepsList.forEachIndexed { idx, step ->
                    val row = LinearLayout(requireContext()).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
                    }
                    val tv = TextView(requireContext()).apply {
                        text = "${idx + 1}. ${step.summaryRu()}"
                        textSize = 12.5f
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    row.addView(tv)

                    val upBtn = TextView(requireContext()).apply {
                        text = "↑"
                        setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                        setOnClickListener {
                            if (idx > 0) {
                                val tmp = stepsList[idx - 1]
                                stepsList[idx - 1] = stepsList[idx]
                                stepsList[idx] = tmp
                                renderSteps()
                            }
                        }
                    }
                    val downBtn = TextView(requireContext()).apply {
                        text = "↓"
                        setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                        setOnClickListener {
                            if (idx < stepsList.lastIndex) {
                                val tmp = stepsList[idx + 1]
                                stepsList[idx + 1] = stepsList[idx]
                                stepsList[idx] = tmp
                                renderSteps()
                            }
                        }
                    }
                    val delBtn = TextView(requireContext()).apply {
                        text = "×"
                        setTextColor(Color.parseColor("#FCA5A5"))
                        setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                        setOnClickListener {
                            stepsList.removeAt(idx)
                            renderSteps()
                        }
                    }
                    row.addView(upBtn)
                    row.addView(downBtn)
                    row.addView(delBtn)
                    stepsContainer.addView(row)
                }
            }
        }
        renderSteps()

        val addStepRow = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, (8 * d).toInt(), 0, 0)
        }
        val addManualStepBtn = MaterialButton(requireContext()).apply {
            text = "+ Добавить шаг"
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = (6 * d).toInt()
            }
            setOnClickListener {
                showAddStepDialog { newStep ->
                    stepsList.add(newStep)
                    renderSteps()
                }
            }
        }
        val pickCoordsBtn = MaterialButton(requireContext()).apply {
            text = "Прицел X&Y"
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                launchCrosshairRecorder { x, y ->
                    stepsList.add(
                        CustomCommandStep(
                            type = CommandStepType.TAP_XY,
                            params = mapOf("x" to x.toString(), "y" to y.toString())
                        )
                    )
                    renderSteps()
                    Toast.makeText(requireContext(), "Добавлен шаг: тап ($x, $y)", Toast.LENGTH_SHORT).show()
                }
            }
        }
        addStepRow.addView(addManualStepBtn)
        addStepRow.addView(pickCoordsBtn)
        root.addView(addStepRow)

        aiBtn.setOnClickListener {
            val prompt = aiPromptEdit.text.toString().trim()
            if (prompt.isEmpty()) {
                Toast.makeText(requireContext(), "Опишите команду для генерации.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            aiBtn.isEnabled = false
            aiStatus.visibility = View.VISIBLE
            aiStatus.text = "Генерирую шаги через активный ИИ…"
            viewLifecycleOwner.lifecycleScope.launch {
                val app = JarvisApplication.instance
                val res = app.customCommandRepository.generateWithAi(
                    engine = app.inferenceEngine,
                    baseConfig = app.prefs.buildGenerationConfig(),
                    taskDescription = prompt
                )
                aiBtn.isEnabled = true
                res.onSuccess { gen ->
                    if (nameEdit.text.isNullOrBlank()) nameEdit.setText(gen.name)
                    if (triggerEdit.text.isNullOrBlank()) triggerEdit.setText(gen.triggerPhrase)
                    stepsList.clear()
                    stepsList.addAll(gen.steps)
                    renderSteps()
                    aiStatus.text = if (gen.warningsRu.isEmpty()) {
                        "Готово! Сгенерировано шагов: ${stepsList.size}. Проверьте и сохраните."
                    } else {
                        "Сгенерировано шагов: ${stepsList.size}. Уточните:\n" + gen.warningsRu.joinToString("\n")
                    }
                }.onFailure { err ->
                    aiStatus.text = "Ошибка генерации: ${err.message}"
                }
            }
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle(if (existing == null) "Новая команда" else "Редактировать команду")
            .setView(scroll)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameEdit.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(requireContext(), "Введите название команды.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (stepsList.isEmpty()) {
                    Toast.makeText(requireContext(), "Добавьте хотя бы один шаг.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val saved = CustomCommand(
                    id = existing?.id ?: UUID.randomUUID().toString(),
                    name = name,
                    triggerPhrase = triggerEdit.text.toString().trim(),
                    steps = stepsList.toList()
                )
                val v = JarvisApplication.instance.customCommandRepository.saveCommand(saved)
                if (!v.valid) {
                    Toast.makeText(requireContext(), v.errorsRu.joinToString("; "), Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                renderCustomCommandsList()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun showAddStepDialog(onAdded: (CustomCommandStep) -> Unit) {
        val d = resources.displayMetrics.density
        val types = CommandStepType.entries
        val labels = types.map { it.titleRu }

        val box = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
        }
        val spinner = Spinner(requireContext()).apply {
            adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, labels)
        }
        val arg1 = EditText(requireContext()).apply { hint = "URL / приложение / текст / мс / направление (down|up)" }
        val arg2 = EditText(requireContext()).apply { hint = "Координата X (для TAP_XY)" }
        val arg3 = EditText(requireContext()).apply { hint = "Координата Y (для TAP_XY)" }
        val pickBtn = MaterialButton(requireContext()).apply {
            text = "Записать X&Y прицелом поверх экрана"
            setOnClickListener {
                launchCrosshairRecorder { x, y ->
                    arg2.setText(x.toString())
                    arg3.setText(y.toString())
                    spinner.setSelection(types.indexOf(CommandStepType.TAP_XY))
                }
            }
        }

        box.addView(spinner)
        box.addView(arg1)
        box.addView(arg2)
        box.addView(arg3)
        box.addView(pickBtn)

        AlertDialog.Builder(requireContext())
            .setTitle("Добавить шаг")
            .setView(box)
            .setPositiveButton("Добавить") { _, _ ->
                val t = types[spinner.selectedItemPosition]
                val a1 = arg1.text.toString().trim()
                val xVal = arg2.text.toString().trim().toIntOrNull()
                val yVal = arg3.text.toString().trim().toIntOrNull()
                val params: Map<String, String> = when (t) {
                    CommandStepType.OPEN_URL -> mapOf("url" to a1)
                    CommandStepType.OPEN_APP -> mapOf("app" to a1)
                    CommandStepType.TAP_XY -> mapOf("x" to (xVal ?: 540).toString(), "y" to (yVal ?: 1200).toString())
                    CommandStepType.WAIT -> mapOf("ms" to (a1.toLongOrNull() ?: 1000L).toString())
                    CommandStepType.TYPE_TEXT -> mapOf("text" to a1)
                    CommandStepType.TAP_TEXT -> mapOf("text" to a1)
                    CommandStepType.SWIPE -> mapOf("direction" to a1.ifBlank { "down" })
                    CommandStepType.CHECK_SCREEN_TEXT -> mapOf("text" to a1)
                    CommandStepType.SHOW_MESSAGE -> mapOf("message" to a1)
                    CommandStepType.PRESS_BACK, CommandStepType.PRESS_HOME, CommandStepType.OPEN_NOTIFICATIONS -> emptyMap()
                }
                onAdded(CustomCommandStep(type = t, params = params))
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun launchCrosshairRecorder(onCaptured: (Int, Int) -> Unit) {
        val ctx = requireContext()
        if (!Settings.canDrawOverlays(ctx)) {
            AlertDialog.Builder(ctx)
                .setTitle("Нужно разрешение «Поверх окон»")
                .setMessage("Чтобы показать прицел выбора координат X&Y поверх любого приложения, разрешите показ поверх окон.")
                .setPositiveButton("Открыть настройки") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }
        recorderOverlay?.dismiss()
        val overlay = CoordinateRecorderOverlay(
            context = ctx.applicationContext,
            onRecorded = { x, y, _, _ ->
                recorderOverlay = null
                onCaptured(x, y)
            },
            onCancelled = {
                recorderOverlay = null
            }
        )
        recorderOverlay = overlay
        overlay.show()
    }

    private fun refreshServiceStatus() {
        val prefs = JarvisApplication.instance.prefs
        val connected = JarvisAccessibilityService.isSystemServiceConnected()
        val masterOn = prefs.accessibilityMasterSwitch
        val agentOn = prefs.agentToolsEnabled
        val appCount = runCatching { JarvisApplication.instance.actionPlanner.listLaunchableApps().size }.getOrDefault(0)
        if (masterSwitch.isChecked != masterOn) masterSwitch.isChecked = masterOn
        if (agentToolsSwitch.isChecked != agentOn) agentToolsSwitch.isChecked = agentOn
        serviceStatusText.text = buildString {
            append("ИИ-агент: ").append(if (agentOn) "Включён (видит $appCount прилож.)" else "Выключен").append('\n')
            append("Спецвозможности Android: ").append(
                if (connected && masterOn) "Готовы к работе"
                else if (connected) "Выключены тумблером ниже"
                else "Не включены в Android"
            )
        }
    }

    private fun buildAndShowPreview() {
        val cmd = commandEditText.text.toString().trim()
        if (cmd.isEmpty()) {
            Toast.makeText(requireContext(), "Введите команду.", Toast.LENGTH_SHORT).show()
            return
        }
        val plan = JarvisApplication.instance.actionPlanner.buildPreviewPlan(cmd)
        currentPlan = plan
        planCard.visibility = View.VISIBLE
        planDetailsText.text = buildString {
            append("Команда: «${plan.originalCommand}»\n\n")
            if (plan.steps.isEmpty()) append("Не удалось подобрать шаги.")
            else plan.steps.forEachIndexed { idx, s -> append("${idx + 1}. ${s.descriptionRu}\n") }
        }.trim()
        confirmExecuteBtn.isEnabled = plan.riskLevel != RiskLevel.HARD_BLOCKED_SENSITIVE && plan.steps.isNotEmpty()
    }

    private fun runPlan(plan: ActionPlan) {
        viewLifecycleOwner.lifecycleScope.launch {
            executionLogText.visibility = View.VISIBLE
            executionLogText.text = "Выполняю план…"
            val report = JarvisApplication.instance.actionPlanner.executeConfirmedPlan(plan)
            executionLogText.text = report.stepLogsRu.joinToString("\n") { "• $it" }
        }
    }
}
