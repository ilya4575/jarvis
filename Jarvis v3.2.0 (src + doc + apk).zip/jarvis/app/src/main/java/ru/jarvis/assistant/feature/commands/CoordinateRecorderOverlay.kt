package ru.jarvis.assistant.feature.commands

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.feature.accessibility.JarvisAccessibilityService

/**
 * A7: 1-Tap X & Y Coordinate Recorder with visual crosshair/reticle overlay.
 * - Uses TYPE_APPLICATION_OVERLAY (SYSTEM_ALERT_WINDOW) so the user can even navigate over
 *   the real target app screen, then tap 1 point to record exact (X, Y) screen coordinates.
 * - Shows orientation/scale warning, live crosshair pin, Confirm / Re-record / Safe Test Tap / Cancel.
 */
class CoordinateRecorderOverlay(
    private val context: Context,
    private val onRecorded: (x: Int, y: Int, screenW: Int, screenH: Int) -> Unit,
    private val onCancelled: () -> Unit = {}
) {
    private val appContext = context.applicationContext
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var rootView: View? = null

    private var recordedX: Int = -1
    private var recordedY: Int = -1

    fun canShowSystemOverlay(): Boolean = Settings.canDrawOverlays(appContext)

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (!canShowSystemOverlay()) {
            Toast.makeText(
                appContext,
                "Для записи точки поверх приложений нужно разрешение «Поверх других приложений».",
                Toast.LENGTH_LONG
            ).show()
            onCancelled()
            return
        }
        dismiss()

        val dm = appContext.resources.displayMetrics
        val d = dm.density

        val container = FrameLayout(appContext).apply {
            setBackgroundColor(Color.argb(115, 8, 10, 18))
        }

        val reticleView = CrosshairCanvasView(appContext)
        container.addView(
            reticleView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )

        // Top instructional & confirmation HUD
        val hud = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(235, 17, 19, 28))
            setPadding((14 * d).toInt(), (14 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
        }

        val titleTv = TextView(appContext).apply {
            text = "Рекордер нажатия X & Y (1 касание)"
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val coordTv = TextView(appContext).apply {
            text = "Коснитесь любой точки экрана ниже, чтобы поставить прицел."
            setTextColor(Color.parseColor("#64D2FF"))
            textSize = 13f
            setPadding(0, (4 * d).toInt(), 0, 0)
        }
        val warnTv = TextView(appContext).apply {
            text = "Внимание: координаты X/Y зависят от разрешения (${dm.widthPixels}×${dm.heightPixels}), ориентации и масштаба экрана."
            setTextColor(Color.parseColor("#FDE68A"))
            textSize = 11.5f
            setPadding(0, (4 * d).toInt(), 0, (8 * d).toInt())
        }

        val btnRow = LinearLayout(appContext).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val confirmBtn = TextView(appContext).apply {
            text = "Подтвердить"
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#5EF2A5"))
            setPadding((12 * d).toInt(), (9 * d).toInt(), (12 * d).toInt(), (9 * d).toInt())
            textSize = 12.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            isEnabled = false
            alpha = 0.45f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = (6 * d).toInt()
            }
        }

        val retryBtn = TextView(appContext).apply {
            text = "Сбросить"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#2B3042"))
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
            textSize = 12.5f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f).apply {
                marginEnd = (6 * d).toInt()
            }
        }

        val testBtn = TextView(appContext).apply {
            text = "Тест"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#93C5FD"))
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
            textSize = 12.5f
            isEnabled = false
            alpha = 0.45f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f).apply {
                marginEnd = (6 * d).toInt()
            }
        }

        val cancelBtn = TextView(appContext).apply {
            text = "Отмена"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#FCA5A5"))
            setBackgroundColor(Color.parseColor("#2A1B20"))
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
            textSize = 12.5f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
        }

        btnRow.addView(confirmBtn)
        btnRow.addView(retryBtn)
        btnRow.addView(testBtn)
        btnRow.addView(cancelBtn)

        hud.addView(titleTv)
        hud.addView(coordTv)
        hud.addView(warnTv)
        hud.addView(btnRow)

        val hudLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP
            topMargin = (28 * d).toInt()
            marginStart = (10 * d).toInt()
            marginEnd = (10 * d).toInt()
        }
        container.addView(hud, hudLp)

        reticleView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    recordedX = ev.rawX.toInt().coerceIn(0, dm.widthPixels)
                    recordedY = ev.rawY.toInt().coerceIn(0, dm.heightPixels)
                    reticleView.setCrosshair(ev.x, ev.y)
                    coordTv.text = "Записана точка: X = $recordedX, Y = $recordedY (нажмите «Подтвердить» или тапните другую точку)"
                    confirmBtn.isEnabled = true
                    confirmBtn.alpha = 1f
                    testBtn.isEnabled = true
                    testBtn.alpha = 1f
                    true
                }
                else -> false
            }
        }

        confirmBtn.setOnClickListener {
            if (recordedX >= 0 && recordedY >= 0) {
                val fx = recordedX
                val fy = recordedY
                dismiss()
                onRecorded(fx, fy, dm.widthPixels, dm.heightPixels)
            }
        }

        retryBtn.setOnClickListener {
            recordedX = -1
            recordedY = -1
            reticleView.clearCrosshair()
            coordTv.text = "Точка сброшена. Коснитесь нужного места экрана."
            confirmBtn.isEnabled = false
            confirmBtn.alpha = 0.45f
            testBtn.isEnabled = false
            testBtn.alpha = 0.45f
        }

        testBtn.setOnClickListener {
            if (recordedX < 0 || recordedY < 0) return@setOnClickListener
            val svc = JarvisAccessibilityService.activeInstance
            if (svc == null || !JarvisApplication.instance.prefs.accessibilityMasterSwitch) {
                Toast.makeText(
                    appContext,
                    "Тест нажатия требует включённых Спецвозможностей Android.",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            val tx = recordedX
            val ty = recordedY
            // Temporarily hide overlay so the gesture hits the real screen underneath
            container.visibility = View.INVISIBLE
            CoroutineScope(Dispatchers.Main).launch {
                val res = svc.executeTapCoordinates(tx, ty)
                Toast.makeText(appContext, res.messageRu, Toast.LENGTH_SHORT).show()
                if (rootView === container) container.visibility = View.VISIBLE
            }
        }

        cancelBtn.setOnClickListener {
            dismiss()
            onCancelled()
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        rootView = container
        wm.addView(container, params)
    }

    fun dismiss() {
        rootView?.let { v -> runCatching { wm.removeViewImmediate(v) } }
        rootView = null
    }

    private class CrosshairCanvasView(context: Context) : View(context) {
        private var cx = -1f
        private var cy = -1f

        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(180, 100, 210, 255)
            strokeWidth = 2f * resources.displayMetrics.density
        }
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#5EF2A5")
            style = Paint.Style.STROKE
            strokeWidth = 3f * resources.displayMetrics.density
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FF4D6D")
            style = Paint.Style.FILL
        }

        fun setCrosshair(x: Float, y: Float) {
            cx = x
            cy = y
            invalidate()
        }

        fun clearCrosshair() {
            cx = -1f
            cy = -1f
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (cx < 0f || cy < 0f) return
            val d = resources.displayMetrics.density
            // Full horizontal + vertical crosshair guide lines
            canvas.drawLine(0f, cy, width.toFloat(), cy, linePaint)
            canvas.drawLine(cx, 0f, cx, height.toFloat(), linePaint)
            // Outer reticle ring + center precision dot
            canvas.drawCircle(cx, cy, 24f * d, ringPaint)
            canvas.drawCircle(cx, cy, 5f * d, dotPaint)
        }
    }
}
