package ru.jarvis.assistant.feature.voice

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import ru.jarvis.assistant.core.cloud.CloudLlmClient
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Direct xAI/Grok Text-to-Speech client. The key is user-provided and never bundled. */
class GrokTtsClient(private val ttsEndpoint: String = DEFAULT_TTS_ENDPOINT) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    private val activeCall = AtomicReference<Call?>(null)

    fun cancelActive() { activeCall.getAndSet(null)?.cancel() }

    companion object {
        const val DEFAULT_TTS_ENDPOINT = "https://api.x.ai/v1/tts"
    }

    suspend fun synthesizeToMp3File(
        apiKey: String,
        voiceId: String,
        text: String,
        speed: Float,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val key = CloudLlmClient.sanitizeApiKey(apiKey)
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Для Grok TTS укажите API-ключ xAI в «Провайдеры и API-ключи»."))
        val payload = JSONObject()
            .put("text", text.trim().take(60000))
            .put("voice_id", voiceId.trim().ifBlank { "eve" })
            .put("language", "ru")
            .put("speed", speed.coerceIn(0.7f, 1.5f).toDouble())
        val request = Request.Builder()
            .url(ttsEndpoint)
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        val call = client.newCall(request)
        activeCall.set(call)
        try {
            call.execute().use { response ->
                val bytes = response.body?.bytes() ?: ByteArray(0)
                if (!response.isSuccessful) {
                    val body = runCatching { String(bytes).take(500) }.getOrDefault("")
                    return@withContext Result.failure(IllegalStateException("Grok TTS HTTP ${response.code}: ${body.ifBlank { response.message }}"))
                }
                if (bytes.isEmpty()) return@withContext Result.failure(IllegalStateException("Grok TTS вернул пустой аудиофайл."))
                outputFile.parentFile?.mkdirs()
                outputFile.writeBytes(bytes)
                Result.success(outputFile)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }
}
