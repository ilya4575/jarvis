package ru.jarvis.assistant.core.math

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class MathEvalResult(
    val expression: String,
    val formattedAnswer: String,
    val stepsRu: List<String>
)

/**
 * Deterministic, auditable local mathematical evaluator and linear/quadratic equation solver.
 * Used to verify arithmetic and equations so small local LLMs never hallucinate math results.
 */
object MathEvaluator {

    private val EQUATION_REGEX = Regex("""([0-9a-zA-Zа-яА-Я.,+\-*/^()\s]+)=([0-9a-zA-Zа-яА-Я.,+\-*/^()\s]+)""")

    /**
     * Attempts to extract and deterministically evaluate an arithmetic expression or linear/quadratic
     * equation in variable `x` (Latin `x` or Cyrillic `х`). Returns null if the message is not a math expression.
     */
    fun tryEvaluateFromMessage(userMessage: String): MathEvalResult? {
        val cleaned = normalizeText(userMessage)

        // 1. Check simple equation in x (e.g., "2x + 5 = 15" or "x^2 - 5x + 6 = 0")
        val eqMatch = EQUATION_REGEX.find(cleaned)
        if (eqMatch != null) {
            val lhs = eqMatch.groupValues[1].trim()
            val rhs = eqMatch.groupValues[2].trim()
            if (lhs.contains('x') || rhs.contains('x')) {
                val solved = trySolvePolynomialEquation(lhs, rhs)
                if (solved != null) return solved
            }
        }

        // 2. Try evaluating direct expression or extracting arithmetic candidate
        val candidate = extractArithmeticCandidate(cleaned) ?: return null
        val value = evaluateExpression(candidate) ?: return null
        if (value.isNaN() || value.isInfinite()) return null

        val formatted = formatNumber(value)
        return MathEvalResult(
            expression = candidate,
            formattedAnswer = formatted,
            stepsRu = listOf(
                "Выражение: $candidate",
                "Точный детерминированный расчёт: $formatted"
            )
        )
    }

    /** Evaluates a pure arithmetic expression string; returns null on parse or domain error. */
    fun evaluateExpression(raw: String): Double? {
        val expr = normalizeExpression(raw)
        if (expr.isBlank()) return null
        return try {
            val parser = RecursiveDescentParser(expr)
            val result = parser.parse()
            if (parser.isAtEnd()) result else null
        } catch (_: Exception) {
            null
        }
    }

    private fun normalizeText(text: String): String {
        return text
            .replace('×', '*')
            .replace('·', '*')
            .replace('÷', '/')
            .replace('−', '-')
            .replace('–', '-')
            .replace("²", "^2")
            .replace("³", "^3")
            .replace("√", "sqrt")
            .replace(Regex("(?<=\\d),(?=\\d)"), ".")
            .replace('х', 'x')
            .replace('Х', 'x')
            .replace('X', 'x')
    }

    private fun normalizeExpression(raw: String): String {
        var s = normalizeText(raw).trim()
        // Support Russian "20% от 150" -> "(20/100)*150"
        s = s.replace(Regex("""(\d+(?:\.\d+)?)\s*%\s*от\s*(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)) {
            "(${it.groupValues[1]}/100)*${it.groupValues[2]}"
        }
        // Replace trailing "%" as /100
        s = s.replace(Regex("""(\d+(?:\.\d+)?)\s*%""")) { "(${it.groupValues[1]}/100)" }
        // Strip leading Russian math prompts
        s = s.replace(Regex("""^(посчитай|вычисли|сколько будет|реши|найди|чему равно|=)\s*:?\s*""", RegexOption.IGNORE_CASE), "")
        s = s.trimEnd('?', '.', '!', ' ', '=')
        return s.trim()
    }

    private fun extractArithmeticCandidate(text: String): String? {
        val direct = normalizeExpression(text)
        val hasOperatorOrFunc = direct.any { it in "+-*/^" } ||
            Regex("""\b(sqrt|sin|cos|tan|log|ln|abs)\s*\(""").containsMatchIn(direct)
        if (hasOperatorOrFunc && isPureMathChars(direct) && direct.any { it.isDigit() }) {
            return direct
        }
        // Try extracting a math substring inside a Russian sentence (e.g. "Сколько будет (12 + 8) * 3?")
        val subRegex = Regex("""(?<![a-zA-Zа-яА-Я])((?:sqrt|sin|cos|tan|log|ln|abs)?\s*\(?\s*-?\d+(?:\.\d+)?(?:\s*[+\-*/^]\s*(?:(?:sqrt|sin|cos|tan|log|ln|abs)\s*)?\(?\s*-?\d+(?:\.\d+)?\s*\)?)+\s*\)?)""")
        val found = subRegex.find(text)?.groupValues?.get(1)?.trim()
        if (!found.isNullOrBlank() && found.any { it in "+-*/^" }) {
            return found
        }
        return null
    }

    private fun isPureMathChars(s: String): Boolean {
        val stripped = s.replace(Regex("""\b(sqrt|sin|cos|tan|log|ln|abs|pi|e)\b""", RegexOption.IGNORE_CASE), "")
        return stripped.all { it.isDigit() || it in "+-*/^().% " }
    }

    /**
     * Solves linear (bx + c = 0) and quadratic (ax^2 + bx + c = 0) equations deterministically
     * using numerical coefficient extraction on `(lhs) - (rhs)` (verified at 3 points + check at 4th point).
     */
    private fun trySolvePolynomialEquation(rawLhs: String, rawRhs: String): MathEvalResult? {
        val lhs = insertImplicitMultiplication(rawLhs)
        val rhs = insertImplicitMultiplication(rawRhs)
        if (!isValidEquationSide(lhs) || !isValidEquationSide(rhs)) return null

        fun f(xVal: Double): Double? {
            val l = evaluateAtX(lhs, xVal) ?: return null
            val r = evaluateAtX(rhs, xVal) ?: return null
            return l - r
        }

        val y0 = f(0.0) ?: return null
        val y1 = f(1.0) ?: return null
        val ym1 = f(-1.0) ?: return null
        val y2 = f(2.0) ?: return null

        // For ax^2 + bx + c:
        // c = y0
        // a + b + c = y1
        // a - b + c = ym1
        val c = y0
        val a = (y1 + ym1 - 2.0 * c) / 2.0
        val b = (y1 - ym1) / 2.0

        // Verify degree <= 2 using 4th point x=2
        val predictedY2 = a * 4.0 + b * 2.0 + c
        if (abs(predictedY2 - y2) > 1e-6) return null

        val eqLabel = "${rawLhs.trim()} = ${rawRhs.trim()}"
        val eps = 1e-9

        if (abs(a) < eps) {
            // Linear: bx + c = 0
            if (abs(b) < eps) {
                val msg = if (abs(c) < eps) "Бесконечно много решений (тождество)" else "Решений нет"
                return MathEvalResult(eqLabel, msg, listOf("Уравнение: $eqLabel", msg))
            }
            val x = -c / b
            val fx = formatNumber(x)
            return MathEvalResult(
                expression = eqLabel,
                formattedAnswer = "x = $fx",
                stepsRu = listOf(
                    "Линейное уравнение: ${formatNumber(b)}·x + (${formatNumber(c)}) = 0",
                    "x = -(${formatNumber(c)}) / (${formatNumber(b)}) = $fx"
                )
            )
        } else {
            // Quadratic: ax^2 + bx + c = 0
            val disc = b * b - 4.0 * a * c
            val steps = mutableListOf(
                "Квадратное уравнение: a = ${formatNumber(a)}, b = ${formatNumber(b)}, c = ${formatNumber(c)}",
                "Дискриминант D = b² - 4ac = ${formatNumber(disc)}"
            )
            return when {
                disc < -eps -> {
                    steps.add("D < 0 → действительных корней нет")
                    MathEvalResult(eqLabel, "Действительных корней нет (D = ${formatNumber(disc)})", steps)
                }
                abs(disc) <= eps -> {
                    val x = -b / (2.0 * a)
                    val fx = formatNumber(x)
                    steps.add("D = 0 → единственный корень x = $fx")
                    MathEvalResult(eqLabel, "x = $fx", steps)
                }
                else -> {
                    val sqrtD = sqrt(disc)
                    val x1 = (-b - sqrtD) / (2.0 * a)
                    val x2 = (-b + sqrtD) / (2.0 * a)
                    val fx1 = formatNumber(x1)
                    val fx2 = formatNumber(x2)
                    steps.add("√D = ${formatNumber(sqrtD)}")
                    steps.add("x₁ = $fx1, x₂ = $fx2")
                    MathEvalResult(eqLabel, "x₁ = $fx1; x₂ = $fx2", steps)
                }
            }
        }
    }

    private fun insertImplicitMultiplication(s: String): String {
        var res = s.replace(" ", "")
        res = res.replace(Regex("""(\d)(x)"""), "$1*$2")
        res = res.replace(Regex("""(\d)(\()"""), "$1*$2")
        res = res.replace(Regex("""(\))(x|\d|\()"""), "$1*$2")
        res = res.replace(Regex("""(x)(\()"""), "$1*$2")
        return res
    }

    private fun isValidEquationSide(s: String): Boolean {
        return s.isNotBlank() && s.all { it.isDigit() || it in "x+-*/^(). " }
    }

    private fun evaluateAtX(expr: String, xVal: Double): Double? {
        val substituted = expr.replace("x", "(${BigDecimal.valueOf(xVal).toPlainString()})")
        return evaluateExpression(substituted)
    }

    fun formatNumber(value: Double): String {
        if (abs(value) < 1e-12) return "0"
        val roundedInt = kotlin.math.round(value)
        if (abs(value - roundedInt) < 1e-9 && abs(roundedInt) < 1e15) {
            return roundedInt.toLong().toString()
        }
        return BigDecimal.valueOf(value)
            .round(MathContext(10, RoundingMode.HALF_UP))
            .stripTrailingZeros()
            .toPlainString()
    }

    private class RecursiveDescentParser(private val input: String) {
        private var pos = 0

        fun isAtEnd(): Boolean {
            skipSpaces()
            return pos >= input.length
        }

        fun parse(): Double = parseAddSub()

        private fun skipSpaces() {
            while (pos < input.length && input[pos].isWhitespace()) pos++
        }

        private fun parseAddSub(): Double {
            var left = parseMulDiv()
            while (true) {
                skipSpaces()
                if (pos >= input.length) break
                when (input[pos]) {
                    '+' -> { pos++; left += parseMulDiv() }
                    '-' -> { pos++; left -= parseMulDiv() }
                    else -> break
                }
            }
            return left
        }

        private fun parseMulDiv(): Double {
            var left = parseUnary()
            while (true) {
                skipSpaces()
                if (pos >= input.length) break
                when (input[pos]) {
                    '*' -> { pos++; left *= parseUnary() }
                    '/' -> {
                        pos++
                        val right = parseUnary()
                        if (abs(right) < 1e-15) throw ArithmeticException("Division by zero")
                        left /= right
                    }
                    else -> break
                }
            }
            return left
        }

        private fun parseUnary(): Double {
            skipSpaces()
            if (pos < input.length && input[pos] == '+') {
                pos++
                return parseUnary()
            }
            if (pos < input.length && input[pos] == '-') {
                pos++
                return -parseUnary()
            }
            return parsePower()
        }

        private fun parsePower(): Double {
            val base = parsePrimary()
            skipSpaces()
            if (pos < input.length && input[pos] == '^') {
                pos++
                val exp = parseUnary()
                return base.pow(exp)
            }
            return base
        }

        private fun parsePrimary(): Double {
            skipSpaces()
            if (pos >= input.length) throw IllegalArgumentException("Unexpected end")

            if (input[pos] == '(') {
                pos++
                val v = parseAddSub()
                skipSpaces()
                if (pos >= input.length || input[pos] != ')') {
                    throw IllegalArgumentException("Missing closing parenthesis")
                }
                pos++
                return v
            }

            if (input[pos].isLetter()) {
                val start = pos
                while (pos < input.length && input[pos].isLetter()) pos++
                val ident = input.substring(start, pos).lowercase()
                skipSpaces()
                return when (ident) {
                    "pi" -> PI
                    "e" -> kotlin.math.E
                    else -> {
                        if (pos >= input.length || input[pos] != '(') {
                            throw IllegalArgumentException("Expected '(' after $ident")
                        }
                        pos++
                        val arg = parseAddSub()
                        skipSpaces()
                        if (pos >= input.length || input[pos] != ')') {
                            throw IllegalArgumentException("Missing ')' after $ident")
                        }
                        pos++
                        when (ident) {
                            "sqrt" -> {
                                if (arg < 0) throw ArithmeticException("sqrt of negative")
                                sqrt(arg)
                            }
                            "abs" -> abs(arg)
                            "sin" -> sin(arg)
                            "cos" -> cos(arg)
                            "tan" -> tan(arg)
                            "ln" -> {
                                if (arg <= 0) throw ArithmeticException("ln domain")
                                ln(arg)
                            }
                            "log" -> {
                                if (arg <= 0) throw ArithmeticException("log domain")
                                log10(arg)
                            }
                            else -> throw IllegalArgumentException("Unknown function $ident")
                        }
                    }
                }
            }

            val start = pos
            var hasDot = false
            while (pos < input.length && (input[pos].isDigit() || (input[pos] == '.' && !hasDot))) {
                if (input[pos] == '.') hasDot = true
                pos++
            }
            if (start == pos) throw IllegalArgumentException("Expected number at $pos")
            return input.substring(start, pos).toDouble()
        }
    }
}
