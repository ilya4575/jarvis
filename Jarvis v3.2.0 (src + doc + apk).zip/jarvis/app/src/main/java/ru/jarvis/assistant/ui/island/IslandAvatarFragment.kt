package ru.jarvis.assistant.ui.island

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.models.ModelCatalog
import ru.jarvis.assistant.feature.avatar.ZafkielClockAvatarView
import ru.jarvis.assistant.feature.overlay.IslandCallManager
import ru.jarvis.assistant.feature.overlay.IslandForegroundService
import ru.jarvis.assistant.feature.overlay.IslandNotifFilterPolicy
import ru.jarvis.assistant.feature.overlay.JarvisNotificationListenerService
import ru.jarvis.assistant.ui.MainActivity
import kotlin.math.roundToInt

class IslandAvatarFragment : Fragment() {

    private lateinit var overlayStatusText: TextView
    private lateinit var overlayPermBtn: MaterialButton
    private lateinit var islandSwitch: SwitchMaterial
    private lateinit var lockDragSwitch: SwitchMaterial
    private lateinit var answerInsideSwitch: SwitchMaterial
    private lateinit var micPermBtn: MaterialButton

    private lateinit var livePermStatusText: TextView
    private lateinit var liveNotificationsSwitch: SwitchMaterial
    private lateinit var notifAppsFilterBtn: MaterialButton
    private lateinit var liveMusicSwitch: SwitchMaterial
    private lateinit var liveCallsSwitch: SwitchMaterial
    private lateinit var notifAccessBtn: MaterialButton
    private lateinit var callPermBtn: MaterialButton
    private lateinit var dialerRoleBtn: MaterialButton

    private lateinit var labelX: TextView
    private lateinit var sliderX: SeekBar
    private lateinit var labelY: TextView
    private lateinit var sliderY: SeekBar
    private lateinit var labelW: TextView
    private lateinit var sliderW: SeekBar
    private lateinit var labelH: TextView
    private lateinit var sliderH: SeekBar
    private lateinit var labelR: TextView
    private lateinit var sliderR: SeekBar
    private lateinit var centerXBtn: MaterialButton
    private lateinit var resetPosBtn: MaterialButton

    private lateinit var nameEditText: EditText
    private lateinit var saveNameBtn: MaterialButton
    private lateinit var kurumiThemeSwitch: SwitchMaterial
    private lateinit var kurumiPresetBtn: MaterialButton
    private lateinit var testThinkingBtn: MaterialButton
    private lateinit var avatarPreviewImage: ZafkielClockAvatarView
    private lateinit var pickImageBtn: MaterialButton
    private lateinit var clearImageBtn: MaterialButton
    private lateinit var gifStatusText: TextView
    private lateinit var pickGifBtn: MaterialButton
    private lateinit var clearGifBtn: MaterialButton
    private lateinit var videoStatusText: TextView
    private lateinit var pickVideoBtn: MaterialButton
    private lateinit var clearVideoBtn: MaterialButton
    private var previewThinkingActive: Boolean = false

    private val pickAvatarImageLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) saveStaticAvatar(uri) }

    private val pickAvatarGifLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) saveThinkingGif(uri) }

    private val pickAvatarVideoLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) saveVideoAvatar(uri) }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(requireContext(), if (granted) "Доступ к микрофону выдан." else "Микрофон не разрешён.", Toast.LENGTH_SHORT).show()
        refreshStatusLabels()
    }

    private val callPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        IslandForegroundService.refresh(requireContext())
        refreshStatusLabels()
    }

    private val dialerRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        refreshStatusLabels()
    }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> tryEnableIsland() }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_island_avatar, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance
        val prefs = app.prefs

        view.findViewById<ImageButton>(R.id.island_back_btn).setOnClickListener {
            (activity as? MainActivity)?.popToChat()
        }

        overlayStatusText = view.findViewById(R.id.island_perm_status)
        overlayPermBtn = view.findViewById(R.id.island_overlay_perm_btn)
        islandSwitch = view.findViewById(R.id.island_enable_switch)
        lockDragSwitch = view.findViewById(R.id.island_lock_drag_switch)
        answerInsideSwitch = view.findViewById(R.id.island_answer_inside_switch)
        micPermBtn = view.findViewById(R.id.island_mic_perm_btn)

        livePermStatusText = view.findViewById(R.id.island_live_perm_status)
        liveNotificationsSwitch = view.findViewById(R.id.island_live_notifications_switch)
        notifAppsFilterBtn = view.findViewById(R.id.island_notif_apps_btn)
        liveMusicSwitch = view.findViewById(R.id.island_live_music_switch)
        liveCallsSwitch = view.findViewById(R.id.island_live_calls_switch)
        notifAccessBtn = view.findViewById(R.id.island_notif_access_btn)
        callPermBtn = view.findViewById(R.id.island_call_perm_btn)
        dialerRoleBtn = view.findViewById(R.id.island_dialer_role_btn)

        labelX = view.findViewById(R.id.island_slider_x_label)
        sliderX = view.findViewById(R.id.island_slider_x)
        labelY = view.findViewById(R.id.island_slider_y_label)
        sliderY = view.findViewById(R.id.island_slider_y)
        labelW = view.findViewById(R.id.island_slider_w_label)
        sliderW = view.findViewById(R.id.island_slider_w)
        labelH = view.findViewById(R.id.island_slider_h_label)
        sliderH = view.findViewById(R.id.island_slider_h)
        labelR = view.findViewById(R.id.island_slider_r_label)
        sliderR = view.findViewById(R.id.island_slider_r)
        centerXBtn = view.findViewById(R.id.island_center_x_btn)
        resetPosBtn = view.findViewById(R.id.island_reset_pos_btn)

        nameEditText = view.findViewById(R.id.avatar_name_edit)
        saveNameBtn = view.findViewById(R.id.avatar_save_name_btn)
        kurumiThemeSwitch = view.findViewById(R.id.avatar_kurumi_theme_switch)
        kurumiPresetBtn = view.findViewById(R.id.avatar_kurumi_preset_btn)
        testThinkingBtn = view.findViewById(R.id.avatar_test_thinking_btn)
        avatarPreviewImage = view.findViewById(R.id.avatar_preview_image)
        pickImageBtn = view.findViewById(R.id.avatar_pick_image_btn)
        clearImageBtn = view.findViewById(R.id.avatar_clear_image_btn)
        gifStatusText = view.findViewById(R.id.avatar_gif_status)
        pickGifBtn = view.findViewById(R.id.avatar_pick_gif_btn)
        clearGifBtn = view.findViewById(R.id.avatar_clear_gif_btn)
        videoStatusText = view.findViewById(R.id.avatar_video_status)
        pickVideoBtn = view.findViewById(R.id.avatar_pick_video_btn)
        clearVideoBtn = view.findViewById(R.id.avatar_clear_video_btn)

        overlayPermBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${requireContext().packageName}")))
        }

        // B1 / B2 / B3 live toggles
        liveNotificationsSwitch.isChecked = prefs.islandNotificationsEnabled
        liveNotificationsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.islandNotificationsEnabled = checked
            IslandForegroundService.refresh(requireContext())
            if (checked && !JarvisNotificationListenerService.isPermissionGranted(requireContext())) {
                Toast.makeText(requireContext(), "Выдайте «Доступ к уведомлениям» кнопкой ниже.", Toast.LENGTH_LONG).show()
            }
        }

        notifAppsFilterBtn.setOnClickListener {
            IslandNotifAppFilterDialog.show(requireContext(), viewLifecycleOwner) {
                refreshStatusLabels()
            }
        }

        liveMusicSwitch.isChecked = prefs.islandMusicEnabled
        liveMusicSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.islandMusicEnabled = checked
            IslandForegroundService.refresh(requireContext())
        }

        liveCallsSwitch.isChecked = prefs.islandCallsEnabled
        liveCallsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.islandCallsEnabled = checked
            IslandForegroundService.refresh(requireContext())
            if (checked && !IslandCallManager.hasCallPermissions(requireContext())) {
                requestCallPermissions()
            }
        }

        notifAccessBtn.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Доступ к уведомлениям Android")
                .setMessage(
                    "Нужен, чтобы Dynamic Island показывал живые уведомления с кнопками ответа " +
                        "и управлял текущим музыкальным плеером.\n\n" +
                        "История уведомлений не сохраняется и никуда не отправляется."
                )
                .setPositiveButton("Открыть настройки") { _, _ ->
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        callPermBtn.setOnClickListener { requestCallPermissions() }

        dialerRoleBtn.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = requireContext().getSystemService(Context.ROLE_SERVICE) as? RoleManager
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                    if (rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                        Toast.makeText(requireContext(), "Роль системной звонилки уже активна.", Toast.LENGTH_SHORT).show()
                    } else {
                        AlertDialog.Builder(requireContext())
                            .setTitle("Опциональный режим системной звонилки")
                            .setMessage(
                                "Без этой роли Dynamic Island уже умеет принимать/сбрасывать звонки и переключать громкую связь.\n\n" +
                                    "Если вы хотите дополнительно включать/выключать микрофон (Mute) прямо во время активного разговора " +
                                    "через системный InCallService, подтвердите запрос Android."
                            )
                            .setPositiveButton("Запросить") { _, _ ->
                                dialerRoleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                            }
                            .setNegativeButton("Не сейчас", null)
                            .show()
                    }
                } else {
                    Toast.makeText(requireContext(), "ROLE_DIALER недоступна на этом устройстве.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Требуется Android 10+.", Toast.LENGTH_SHORT).show()
            }
        }

        kurumiThemeSwitch.isChecked = prefs.kurumiThemeEnabled
        kurumiThemeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.kurumiThemeEnabled = checked
            refreshAvatarPreview()
            (activity as? MainActivity)?.updateToolbarTitle()
            IslandForegroundService.refresh(requireContext())
        }

        kurumiPresetBtn.setOnClickListener {
            prefs.applyKurumiPreset()
            nameEditText.setText(prefs.assistantName)
            kurumiThemeSwitch.isChecked = true
            previewThinkingActive = true
            refreshAvatarPreview()
            avatarPreviewImage.setThinking(true)
            testThinkingBtn.text = "Стоп тест"
            (activity as? MainActivity)?.updateToolbarTitle()
            IslandForegroundService.refresh(requireContext())
            Toast.makeText(requireContext(), "Образ Куруми Токисаки активирован!", Toast.LENGTH_SHORT).show()
        }

        testThinkingBtn.setOnClickListener {
            previewThinkingActive = !previewThinkingActive
            avatarPreviewImage.setThinking(previewThinkingActive)
            testThinkingBtn.text = if (previewThinkingActive) "Стоп тест" else "Тест анимации"
        }

        nameEditText.setText(prefs.assistantName)
        lockDragSwitch.isChecked = prefs.islandLockDrag
        answerInsideSwitch.isChecked = prefs.islandShowAnswerInside

        lockDragSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.islandLockDrag = checked
            IslandForegroundService.refresh(requireContext())
        }

        answerInsideSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.islandShowAnswerInside = checked
        }

        micPermBtn.setOnClickListener {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setupGeometrySliders()

        centerXBtn.setOnClickListener {
            prefs.islandPosX = -1
            syncGeometrySlidersFromPrefs()
            IslandForegroundService.refresh(requireContext())
        }

        resetPosBtn.setOnClickListener {
            prefs.resetIslandGeometry()
            syncGeometrySlidersFromPrefs()
            IslandForegroundService.refresh(requireContext())
            Toast.makeText(requireContext(), "Геометрия островка сброшена", Toast.LENGTH_SHORT).show()
        }

        saveNameBtn.setOnClickListener {
            val newName = nameEditText.text.toString().trim()
            if (newName.isBlank()) {
                Toast.makeText(requireContext(), "Введите имя помощника.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.assistantName = newName
            (activity as? MainActivity)?.updateToolbarTitle()
            IslandForegroundService.refresh(requireContext())
            Toast.makeText(requireContext(), "Имя обновлено: $newName", Toast.LENGTH_SHORT).show()
        }

        pickImageBtn.setOnClickListener {
            pickAvatarImageLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        clearImageBtn.setOnClickListener {
            app.avatarManager.clearStaticImage()
            IslandForegroundService.refresh(requireContext())
            (activity as? MainActivity)?.updateToolbarTitle()
            refreshAvatarPreview()
        }
        pickGifBtn.setOnClickListener { pickAvatarGifLauncher.launch(arrayOf("image/gif", "image/webp")) }
        clearGifBtn.setOnClickListener {
            app.avatarManager.clearThinkingGif()
            IslandForegroundService.refresh(requireContext())
            refreshAvatarPreview()
        }
        pickVideoBtn.setOnClickListener { pickAvatarVideoLauncher.launch(arrayOf("video/mp4")) }
        clearVideoBtn.setOnClickListener {
            app.avatarManager.clearVideoAvatar()
            IslandForegroundService.refresh(requireContext())
            refreshAvatarPreview()
        }

        refreshStatusLabels()
        refreshAvatarPreview()
    }

    private fun requestCallPermissions() {
        val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            perms += Manifest.permission.ANSWER_PHONE_CALLS
        }
        callPermissionsLauncher.launch(perms.toTypedArray())
    }

    private fun setupGeometrySliders() {
        val prefs = JarvisApplication.instance.prefs
        val screenW = resources.displayMetrics.widthPixels
        sliderX.max = (screenW - 80).coerceAtLeast(300)
        sliderY.max = 600
        sliderW.max = 320 - 104
        sliderH.max = 76 - 28
        sliderR.max = 40 - 10

        syncGeometrySlidersFromPrefs()

        sliderX.setOnSeekBarChangeListener(simpleSeekListener { p, fromUser ->
            if (!fromUser) return@simpleSeekListener
            prefs.islandPosX = p
            labelX.text = "Позиция X: $p px"
            IslandForegroundService.refresh(requireContext())
        })
        sliderY.setOnSeekBarChangeListener(simpleSeekListener { p, fromUser ->
            if (!fromUser) return@simpleSeekListener
            prefs.islandPosY = p
            labelY.text = "Позиция Y (вкл. статус-бар): $p px"
            IslandForegroundService.refresh(requireContext())
        })
        sliderW.setOnSeekBarChangeListener(simpleSeekListener { p, fromUser ->
            if (!fromUser) return@simpleSeekListener
            val wDp = 104 + p
            prefs.islandWidthDp = wDp
            labelW.text = "Ширина: $wDp dp"
            IslandForegroundService.refresh(requireContext())
        })
        sliderH.setOnSeekBarChangeListener(simpleSeekListener { p, fromUser ->
            if (!fromUser) return@simpleSeekListener
            val hDp = 28 + p
            prefs.islandHeightDp = hDp
            labelH.text = "Высота: $hDp dp"
            IslandForegroundService.refresh(requireContext())
        })
        sliderR.setOnSeekBarChangeListener(simpleSeekListener { p, fromUser ->
            if (!fromUser) return@simpleSeekListener
            val rDp = 10 + p
            prefs.islandCornerRadiusDp = rDp
            labelR.text = "Скругление углов: $rDp dp"
            IslandForegroundService.refresh(requireContext())
        })
    }

    private fun syncGeometrySlidersFromPrefs() {
        val prefs = JarvisApplication.instance.prefs
        val screenW = resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val currentWpx = (prefs.islandWidthDp * density).roundToInt()
        val effectiveX = if (prefs.islandPosX < 0) ((screenW - currentWpx) / 2).coerceAtLeast(0) else prefs.islandPosX

        sliderX.progress = effectiveX.coerceIn(0, sliderX.max)
        labelX.text = if (prefs.islandPosX < 0) "Позиция X: по центру ($effectiveX px)" else "Позиция X: $effectiveX px"
        sliderY.progress = prefs.islandPosY.coerceIn(0, sliderY.max)
        labelY.text = "Позиция Y (вкл. статус-бар): ${prefs.islandPosY} px"
        sliderW.progress = (prefs.islandWidthDp - 104).coerceIn(0, sliderW.max)
        labelW.text = "Ширина: ${prefs.islandWidthDp} dp"
        sliderH.progress = (prefs.islandHeightDp - 28).coerceIn(0, sliderH.max)
        labelH.text = "Высота: ${prefs.islandHeightDp} dp"
        sliderR.progress = (prefs.islandCornerRadiusDp - 10).coerceIn(0, sliderR.max)
        labelR.text = "Скругление углов: ${prefs.islandCornerRadiusDp} dp"
    }

    private fun simpleSeekListener(onChange: (Int, Boolean) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onChange(progress, fromUser)
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    override fun onResume() {
        super.onResume()
        refreshStatusLabels()
        syncGeometrySlidersFromPrefs()
    }

    private fun requestPermissionsAndStartIsland() {
        val ctx = requireContext()
        if (!Settings.canDrawOverlays(ctx)) {
            islandSwitch.isChecked = false
            AlertDialog.Builder(ctx)
                .setTitle("Разрешение «Поверх других приложений»")
                .setMessage("Чтобы показать Dynamic Island поверх приложений и в области камеры, нужно разрешение SYSTEM_ALERT_WINDOW.\n\nОткрыть настройки?")
                .setPositiveButton("Открыть") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }

        tryEnableIsland()
    }

    private fun tryEnableIsland() {
        JarvisApplication.instance.prefs.islandEnabled = true
        IslandForegroundService.startSafe(requireContext())
        refreshStatusLabels()
    }

    private fun saveStaticAvatar(uri: Uri) {
        val app = JarvisApplication.instance
        viewLifecycleOwner.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) { app.avatarManager.saveStaticImage(uri) }
            res.onSuccess {
                refreshAvatarPreview()
                IslandForegroundService.refresh(requireContext())
                Toast.makeText(requireContext(), "Фото аватара сохранено.", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(requireContext(), err.message ?: "Ошибка сохранения изображения", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveThinkingGif(uri: Uri) {
        val app = JarvisApplication.instance
        viewLifecycleOwner.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) { app.avatarManager.saveThinkingGif(uri) }
            res.onSuccess {
                refreshAvatarPreview()
                previewThinkingActive = true
                avatarPreviewImage.setThinking(true)
                testThinkingBtn.text = "Стоп тест"
                IslandForegroundService.refresh(requireContext())
                Toast.makeText(requireContext(), "GIF/WebP анимация сохранена!", Toast.LENGTH_SHORT).show()
            }.onFailure { err ->
                Toast.makeText(requireContext(), err.message ?: "Ошибка сохранения GIF/WebP", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun saveVideoAvatar(uri: Uri) {
        val app = JarvisApplication.instance
        Toast.makeText(requireContext(), "Проверяю MP4 (<= 30 с, <= 100 МиБ)…", Toast.LENGTH_SHORT).show()
        viewLifecycleOwner.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) { app.avatarManager.saveVideoAvatar(uri) }
            res.onSuccess { saved ->
                refreshAvatarPreview()
                IslandForegroundService.refresh(requireContext())
                if (!saved.warningRu.isNullOrBlank()) {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Видеоаватар сохранён")
                        .setMessage(saved.warningRu)
                        .setPositiveButton("Понятно", null)
                        .show()
                } else {
                    Toast.makeText(requireContext(), "Видеоаватар MP4 сохранён.", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { err ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Видео не подходит")
                    .setMessage(err.message ?: "Ошибка проверки MP4")
                    .setPositiveButton("Закрыть", null)
                    .show()
            }
        }
    }

    private fun refreshStatusLabels() {
        val ctx = requireContext()
        val prefs = JarvisApplication.instance.prefs
        notifAppsFilterBtn.text = IslandNotifFilterPolicy.summaryLabelRu(prefs.islandBlockedNotifPackages.size)
        val overlayOk = Settings.canDrawOverlays(ctx)
        val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val running = IslandForegroundService.isRunning

        overlayPermBtn.visibility = if (overlayOk) View.GONE else View.VISIBLE

        islandSwitch.setOnCheckedChangeListener(null)
        islandSwitch.isChecked = prefs.islandEnabled && (running || !overlayOk)
        islandSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) requestPermissionsAndStartIsland()
            else {
                prefs.islandEnabled = false
                prefs.islandPendingRestore = false
                IslandForegroundService.stop(requireContext())
                refreshStatusLabels()
            }
        }

        overlayStatusText.text = buildString {
            append("Поверх окон: ").append(if (overlayOk) "Разрешено" else "Нет (требуется для показа)").append("  •  ")
            append("Микрофон: ").append(if (micOk) "Разрешён" else "Нет").append('\n')
            append("Статус: ").append(
                when {
                    running -> "Активен поверх экрана"
                    prefs.islandEnabled && !overlayOk -> "Включён в настройках, но отозвано разрешение «Поверх окон»"
                    else -> "Выключен"
                }
            )
        }

        val notifGranted = JarvisNotificationListenerService.isPermissionGranted(ctx)
        val callGranted = IslandCallManager.hasCallPermissions(ctx)
        val isDialer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = ctx.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            rm?.isRoleHeld(RoleManager.ROLE_DIALER) == true
        } else false

        livePermStatusText.text = buildString {
            append("Уведомления и музыка: ").append(if (notifGranted) "Доступ выдан" else "Нужен доступ к уведомлениям").append('\n')
            append("Звонки (приём/сброс/громкая): ").append(if (callGranted) "Разрешено" else "Не разрешено").append('\n')
            append("Доп. InCallService (ROLE_DIALER): ").append(if (isDialer) "Активен" else "Не выбран (опционально)")
        }
    }

    private fun refreshAvatarPreview() {
        val app = JarvisApplication.instance
        val mgr = app.avatarManager
        val img = mgr.getStaticImageFile()
        val gif = mgr.getThinkingGifFile()
        val kurumi = app.prefs.kurumiThemeEnabled

        avatarPreviewImage.bindMedia(img, gif, kurumi)
        clearImageBtn.visibility = if (img != null) View.VISIBLE else View.GONE

        gifStatusText.text = if (gif != null && gif.exists()) {
            "GIF/WebP размышления: установлен (${ModelCatalog.formatBytes(gif.length())})."
        } else if (kurumi) {
            "GIF не выбран — работает встроенная анимация золотых часов Зафкиэля."
        } else {
            "GIF/WebP анимация размышления не выбрана."
        }
        clearGifBtn.visibility = if (gif != null && gif.exists()) View.VISIBLE else View.GONE

        val vid = mgr.getVideoAvatarFile()
        videoStatusText.text = if (vid != null && vid.exists()) {
            "Видеоаватар MP4: установлен (${ModelCatalog.formatBytes(vid.length())})."
        } else {
            "Видеоаватар MP4 не выбран (до 30 с и до 100 МиБ)."
        }
        clearVideoBtn.visibility = if (vid != null && vid.exists()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        if (::avatarPreviewImage.isInitialized) avatarPreviewImage.setThinking(false)
        super.onDestroyView()
    }
}
