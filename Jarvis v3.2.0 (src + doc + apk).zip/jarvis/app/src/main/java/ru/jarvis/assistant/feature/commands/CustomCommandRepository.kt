package ru.jarvis.assistant.feature.commands

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.core.agent.AgentToolCall
import ru.jarvis.assistant.core.agent.AgentToolExecutor
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.GenerationResult
import ru.jarvis.assistant.core.inference.InferenceEngine
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

data class CommandRunReport(
    val succeeded: Boolean,
    val completedSteps: Int,
    val totalSteps: Int,
    val logsRu: List<String>
)

/**
 * Local file-backed repository + executor + AI generator for user Custom Commands (A7).
 */
class CustomCommandRepository(
    private val context: Context,
    private val toolExecutor: AgentToolExecutor
) {
    private val storageFile: File
        get() = File(context.filesDir, "custom_commands_v1.json")

    private val cancelRun = AtomicBoolean(false)

    fun listCommands(): List<CustomCommand> {
        val f = storageFile
        if (!f.exists()) return emptyList()
        return runCatching { CustomCommandCodec.deserializeList(f.readText()) }.getOrDefault(emptyList())
    }

    fun saveCommand(command: CustomCommand): CommandValidationResult {
        val validation = CustomCommandCodec.validateCommand(command)
        if (!validation.valid) return validation
        val all = listCommands().toMutableList()
        val idx = all.indexOfFirst { it.id == command.id }
        val updated = command.copy(updatedAtMs = System.currentTimeMillis())
        if (idx >= 0) all[idx] = updated else all.add(0, updated)
        persist(all)
        return CommandValidationResult(valid = true)
    }

    fun deleteCommand(commandId: String) {
        val remaining = listCommands().filterNot { it.id == commandId }
        persist(remaining)
    }

    fun findMatchingTrigger(userText: String): CustomCommand? {
        val norm = userText.trim().lowercase()
        if (norm.isEmpty()) return null
        return listCommands().firstOrNull { cmd ->
            val trig = cmd.triggerPhrase.trim().lowercase()
            val name = cmd.name.trim().lowercase()
            (trig.isNotEmpty() && (norm == trig || norm.startsWith(trig))) ||
                (name.length >= 4 && norm == name)
        }
    }

    private fun persist(list: List<CustomCommand>) {
        runCatching {
            storageFile.parentFile?.mkdirs()
            storageFile.writeText(CustomCommandCodec.serializeList(list))
        }
    }

    fun cancelRunningCommand() {
        cancelRun.set(true)
    }

    /**
     * Generates a structured editable [AiGeneratedCommandDraft] using the user's active LLM provider.
     */
    suspend fun generateWithAi(
        engine: InferenceEngine,
        baseConfig: GenerationConfig,
        taskDescription: String
    ): Result<AiGeneratedCommandDraft> {
        val trimmed = taskDescription.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Опишите задачу текстом, чтобы ИИ собрал шаги команды."))
        }
        val apps = runCatching { toolExecutor.captureContextSnapshot().installedAppNames }.getOrDefault(emptyList())
        val prompt = CustomCommandCodec.buildAiGenerationPrompt(trimmed, apps)
        val genCfg = baseConfig.copy(
            agentToolsEnabled = false,
            temperature = 0.2f,
            maxTokens = 1400,
            customSystemPrompt = "Ты — генератор структурированных сценариев автоматизации Android. Отвечай строго одним валидным JSON-объектом по заданной схеме без markdown-пояснений."
        )

        val result = engine.generate(
            history = emptyList(),
            userPrompt = prompt,
            imagePath = null,
            config = genCfg,
            onToken = {}
        )

        return when (result) {
            is GenerationResult.Completed -> CustomCommandCodec.parseAiGeneratedResponse(result.text)
            is GenerationResult.Cancelled -> Result.failure(IllegalStateException("Генерация отменена."))
            is GenerationResult.Failed -> Result.failure(IllegalStateException(result.reasonRu))
        }
    }

    /**
     * Executes a saved [CustomCommand] sequentially with per-step verification, safety checks,
     * error handling, and live progress callbacks.
     */
    suspend fun executeCommand(
        command: CustomCommand,
        onStepProgress: (stepIndex: Int, totalSteps: Int, statusRu: String) -> Unit = { _, _, _ -> }
    ): CommandRunReport {
        cancelRun.set(false)
        val logs = mutableListOf<String>()
        val total = command.steps.size
        var done = 0

        for ((idx, step) in command.steps.withIndex()) {
            if (cancelRun.get()) {
                logs.add("Остановлено пользователем на шаге ${idx + 1}/$total.")
                return CommandRunReport(false, done, total, logs)
            }
            val label = "Шаг ${idx + 1}/$total: ${step.summaryRu()}"
            onStepProgress(idx + 1, total, label)

            val outcome = executeSingleStep(step)
            if (outcome.first) {
                done++
                logs.add("✓ Шаг ${idx + 1}: ${outcome.second}")
            } else {
                logs.add("✗ Шаг ${idx + 1} (${step.type.titleRu}): ${outcome.second}")
                return CommandRunReport(false, done, total, logs)
            }
        }

        return CommandRunReport(true, done, total, logs)
    }

    private suspend fun executeSingleStep(step: CustomCommandStep): Pair<Boolean, String> {
        return when (step.type) {
            CommandStepType.OPEN_URL -> {
                val res = toolExecutor.execute(AgentToolCall("open_url", mapOf("url" to step.params["url"].orEmpty())))
                res.success to res.summaryRu
            }
            CommandStepType.OPEN_APP -> {
                val res = toolExecutor.execute(AgentToolCall("open_app", mapOf("app" to step.params["app"].orEmpty())))
                res.success to res.summaryRu
            }
            CommandStepType.TAP_XY -> {
                val x = step.params["x"].orEmpty()
                val y = step.params["y"].orEmpty()
                val res = toolExecutor.execute(AgentToolCall("tap_xy", mapOf("x" to x, "y" to y)))
                res.success to res.summaryRu
            }
            CommandStepType.WAIT -> {
                val ms = (step.params["ms"]?.toLongOrNull() ?: 1000L).coerceIn(100L, 60_000L)
                delay(ms)
                true to "Ожидание $ms мс завершено"
            }
            CommandStepType.TYPE_TEXT -> {
                val res = toolExecutor.execute(
                    AgentToolCall(
                        "type_text",
                        mapOf(
                            "text" to step.params["text"].orEmpty(),
                            "submit" to (step.params["submit"] ?: "false")
                        )
                    )
                )
                res.success to res.summaryRu
            }
            CommandStepType.TAP_TEXT -> {
                val res = toolExecutor.execute(AgentToolCall("tap_text", mapOf("text" to step.params["text"].orEmpty())))
                res.success to res.summaryRu
            }
            CommandStepType.SWIPE -> {
                val dir = step.params["direction"] ?: "down"
                val res = toolExecutor.execute(AgentToolCall("scroll", mapOf("direction" to dir)))
                res.success to res.summaryRu
            }
            CommandStepType.PRESS_BACK -> {
                val res = toolExecutor.execute(AgentToolCall("press_key", mapOf("key" to "back")))
                res.success to res.summaryRu
            }
            CommandStepType.PRESS_HOME -> {
                val res = toolExecutor.execute(AgentToolCall("press_key", mapOf("key" to "home")))
                res.success to res.summaryRu
            }
            CommandStepType.OPEN_NOTIFICATIONS -> {
                val res = toolExecutor.execute(AgentToolCall("press_key", mapOf("key" to "notifications")))
                res.success to res.summaryRu
            }
            CommandStepType.CHECK_SCREEN_TEXT -> {
                val needle = step.params["text"]?.trim().orEmpty()
                if (needle.isEmpty()) return false to "Не указан текст для проверки"
                val screenRes = toolExecutor.execute(AgentToolCall("get_screen"))
                if (!screenRes.success) return false to screenRes.summaryRu
                val found = screenRes.outputForModel.contains(needle, ignoreCase = true)
                if (found) true to "Текст «$needle» найден на экране"
                else false to "Условие не выполнено: текст «$needle» не найден на экране"
            }
            CommandStepType.SHOW_MESSAGE -> {
                val msg = step.params["message"]?.trim().orEmpty().ifBlank { "Шаг выполнен" }
                withContext(Dispatchers.Main) {
                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(context.applicationContext, msg, Toast.LENGTH_LONG).show()
                    }
                }
                true to "Показано сообщение: «$msg»"
            }
        }
    }
}
