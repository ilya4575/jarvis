package ru.jarvis.assistant.core.prefs

import android.content.Context
import android.content.SharedPreferences
import ru.jarvis.assistant.core.chat.ChatContextManager
import ru.jarvis.assistant.core.cloud.CloudLlmClient
import ru.jarvis.assistant.core.cloud.CloudProvider
import ru.jarvis.assistant.core.cloud.CustomApiCompatibility
import ru.jarvis.assistant.core.cloud.CustomApiResolver
import ru.jarvis.assistant.core.cloud.CustomProviderConfig
import ru.jarvis.assistant.core.cloud.CustomProviderManager
import ru.jarvis.assistant.core.cloud.GeminiEndpointMode
import ru.jarvis.assistant.core.cloud.ImageQualityMode
import ru.jarvis.assistant.core.cloud.PerchanceWebViewBridge
import ru.jarvis.assistant.core.cloud.PuterApiClient
import ru.jarvis.assistant.core.cloud.RequestSource
import ru.jarvis.assistant.core.cloud.ResolvedCustomApi
import ru.jarvis.assistant.core.cloud.VoiceSttMode
import ru.jarvis.assistant.core.inference.AssistantTone
import ru.jarvis.assistant.core.inference.ChatMode
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.ResponseLength
import ru.jarvis.assistant.core.models.ModelProfileId
import ru.jarvis.assistant.feature.voice.NeuralVoicePreset
import ru.jarvis.assistant.feature.voice.TtsEngineMode

class JarvisPreferences(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val secureKeys = SecureKeyStorage(appContext)

    init {
        migrateLegacySecretsAndProviders()
    }

    private fun migrateLegacySecretsAndProviders() {
        val secretKeys = listOf(
            KEY_GEMINI_API_KEY,
            KEY_GROQ_API_KEY,
            KEY_OPENROUTER_API_KEY,
            KEY_CUSTOM_API_KEY,
            KEY_PUTER_AUTH_TOKEN,
            KEY_FISH_AUDIO_API_KEY,
            KEY_ELEVENLABS_API_KEY,
            KEY_CUSTOM_TTS_API_KEY,
            KEY_GROK_TTS_API_KEY
        )
        for (k in secretKeys) {
            secureKeys.migrateFromLegacyPlaintext(prefs, k)
        }
        // Purge removed Cerebras/Mistral secrets if any existed in older installs
        if (prefs.contains("cloud_cerebras_key") || prefs.contains("cloud_mistral_key")) {
            prefs.edit()
                .remove("cloud_cerebras_key")
                .remove("cloud_cerebras_model")
                .remove("cloud_mistral_key")
                .remove("cloud_mistral_model")
                .apply()
        }
        // Migrate legacy single Custom API into multi-custom list once
        if (!prefs.getBoolean(KEY_CUSTOM_MIGRATED_V3, false)) {
            val legacyKey = secureKeys.getSecret(KEY_CUSTOM_API_KEY)
            val legacyUrl = prefs.getString(KEY_CUSTOM_API_BASE_URL, "").orEmpty().trim()
            val legacyModel = prefs.getString(KEY_CUSTOM_API_MODEL, "").orEmpty().trim()
            if (legacyKey.isNotBlank() || legacyUrl.isNotBlank()) {
                val resolved = CustomApiResolver.resolve(
                    rawKey = legacyKey,
                    compatibility = runCatching {
                        CustomApiCompatibility.valueOf(prefs.getString(KEY_CUSTOM_API_COMPAT, "").orEmpty())
                    }.getOrDefault(CustomApiCompatibility.OPENAI_COMPATIBLE),
                    optionalBaseUrl = legacyUrl,
                    optionalModel = legacyModel
                )
                val migrated = CustomProviderConfig(
                    id = "custom_migrated_1",
                    baseUrl = resolved.baseUrl,
                    apiKey = legacyKey,
                    name = resolved.detectedLabelRu.take(28),
                    model = legacyModel.ifBlank { resolved.model },
                    compatibility = resolved.compatibility,
                    enabled = true
                )
                saveCustomProviders(listOf(migrated), activeId = migrated.id)
            }
            prefs.edit().putBoolean(KEY_CUSTOM_MIGRATED_V3, true).apply()
        }
    }

    var activeProfileId: ModelProfileId
        get() = runCatching {
            ModelProfileId.valueOf(prefs.getString(KEY_ACTIVE_PROFILE, ModelProfileId.BALANCED.name).orEmpty())
        }.getOrDefault(ModelProfileId.BALANCED)
        set(value) = prefs.edit().putString(KEY_ACTIVE_PROFILE, value.name).apply()

    var assistantName: String
        get() = prefs.getString(KEY_ASSISTANT_NAME, "Jarvis") ?: "Jarvis"
        set(value) = prefs.edit().putString(KEY_ASSISTANT_NAME, value.trim().ifEmpty { "Jarvis" }).apply()

    var personaStyle: String
        get() = prefs.getString(KEY_PERSONA_STYLE, DEFAULT_PERSONA) ?: DEFAULT_PERSONA
        set(value) = prefs.edit().putString(KEY_PERSONA_STYLE, value.trim().ifEmpty { DEFAULT_PERSONA }).apply()

    var customSystemPrompt: String
        get() = prefs.getString(KEY_SYSTEM_PROMPT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SYSTEM_PROMPT, value.trim()).apply()

    var temperature: Float
        get() = prefs.getFloat(KEY_TEMPERATURE, 0.45f).coerceIn(0.05f, 1.4f)
        set(value) = prefs.edit().putFloat(KEY_TEMPERATURE, value.coerceIn(0.05f, 1.4f)).apply()

    var maxTokens: Int
        get() = prefs.getInt(KEY_MAX_TOKENS, 768).coerceIn(64, 4096)
        set(value) = prefs.edit().putInt(KEY_MAX_TOKENS, value.coerceIn(64, 4096)).apply()

    var showThinking: Boolean
        get() = prefs.getBoolean(KEY_SHOW_THINKING, false)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_THINKING, value).apply()

    var enableThinking: Boolean
        get() = showThinking
        set(value) { showThinking = value }

    var responseLength: ResponseLength
        get() = runCatching {
            ResponseLength.valueOf(prefs.getString(KEY_RESPONSE_LENGTH, ResponseLength.MEDIUM.name).orEmpty())
        }.getOrDefault(ResponseLength.MEDIUM)
        set(value) = prefs.edit().putString(KEY_RESPONSE_LENGTH, value.name).apply()

    var assistantTone: AssistantTone
        get() = runCatching {
            AssistantTone.valueOf(prefs.getString(KEY_ASSISTANT_TONE, AssistantTone.FRIENDLY.name).orEmpty())
        }.getOrDefault(AssistantTone.FRIENDLY)
        set(value) = prefs.edit().putString(KEY_ASSISTANT_TONE, value.name).apply()

    // --- Context Window (A6: 20..50 messages, default 36) ---
    var contextWindowMessages: Int
        get() = ChatContextManager.clampWindowSize(
            prefs.getInt(KEY_CONTEXT_WINDOW_MESSAGES, ChatContextManager.DEFAULT_CONTEXT_MESSAGES)
        )
        set(value) = prefs.edit()
            .putInt(KEY_CONTEXT_WINDOW_MESSAGES, ChatContextManager.clampWindowSize(value))
            .apply()

    // --- Autonomous Agent Step Limit (A8: 5..50, default 50) ---
    var agentMaxSteps: Int
        get() = prefs.getInt(KEY_AGENT_MAX_STEPS, 50).coerceIn(5, 50)
        set(value) = prefs.edit().putInt(KEY_AGENT_MAX_STEPS, value.coerceIn(5, 50)).apply()

    // --- Dynamic Island persistence (A1 + B1..B5) ---
    var islandEnabled: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_ENABLED, false)
        set(value) {
            prefs.edit().putBoolean(KEY_ISLAND_ENABLED, value).commit()
        }

    var islandPendingRestore: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_PENDING_RESTORE, false)
        set(value) = prefs.edit().putBoolean(KEY_ISLAND_PENDING_RESTORE, value).apply()

    var islandNotificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_NOTIFICATIONS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ISLAND_NOTIFICATIONS_ENABLED, value).apply()

    /** Blacklist of package names whose notifications are hidden from Dynamic Island (all allowed by default). */
    var islandBlockedNotifPackages: Set<String>
        get() = prefs.getStringSet(KEY_ISLAND_BLOCKED_NOTIF_PKGS, emptySet())?.toSet().orEmpty()
        set(value) = prefs.edit().putStringSet(KEY_ISLAND_BLOCKED_NOTIF_PKGS, value.toSet()).apply()

    fun isAppAllowedInIslandNotifications(packageName: String): Boolean {
        val pkg = packageName.trim()
        if (pkg.isEmpty()) return false
        return pkg !in islandBlockedNotifPackages
    }

    fun setAppAllowedInIslandNotifications(packageName: String, allowed: Boolean) {
        val pkg = packageName.trim()
        if (pkg.isEmpty()) return
        val updated = islandBlockedNotifPackages.toMutableSet()
        if (allowed) updated.remove(pkg) else updated.add(pkg)
        islandBlockedNotifPackages = updated
    }

    var islandMusicEnabled: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_MUSIC_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ISLAND_MUSIC_ENABLED, value).apply()

    var islandCallsEnabled: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_CALLS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ISLAND_CALLS_ENABLED, value).apply()

    var islandPosX: Int
        get() = prefs.getInt(KEY_ISLAND_X, -1)
        set(value) = prefs.edit().putInt(KEY_ISLAND_X, value).apply()

    var islandPosY: Int
        get() = prefs.getInt(KEY_ISLAND_Y, 18)
        set(value) = prefs.edit().putInt(KEY_ISLAND_Y, value).apply()

    var islandWidthDp: Int
        get() = prefs.getInt(KEY_ISLAND_WIDTH_DP, 172).coerceIn(112, 300)
        set(value) = prefs.edit().putInt(KEY_ISLAND_WIDTH_DP, value.coerceIn(112, 300)).apply()

    var islandHeightDp: Int
        get() = prefs.getInt(KEY_ISLAND_HEIGHT_DP, 38).coerceIn(28, 64)
        set(value) = prefs.edit().putInt(KEY_ISLAND_HEIGHT_DP, value.coerceIn(28, 64)).apply()

    var islandCornerRadiusDp: Int
        get() = prefs.getInt(KEY_ISLAND_RADIUS_DP, 22).coerceIn(10, 34)
        set(value) = prefs.edit().putInt(KEY_ISLAND_RADIUS_DP, value.coerceIn(10, 34)).apply()

    var islandLockDrag: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_LOCK_DRAG, false)
        set(value) = prefs.edit().putBoolean(KEY_ISLAND_LOCK_DRAG, value).apply()

    var islandShowAnswerInside: Boolean
        get() = prefs.getBoolean(KEY_ISLAND_SHOW_ANSWER, true)
        set(value) = prefs.edit().putBoolean(KEY_ISLAND_SHOW_ANSWER, value).apply()

    var islandSizeDp: Int
        get() = islandHeightDp
        set(value) {
            islandHeightDp = value
        }

    fun resetIslandGeometry() {
        islandPosX = -1
        islandPosY = 18
        islandWidthDp = 172
        islandHeightDp = 38
        islandCornerRadiusDp = 22
    }

    var avatarStaticPath: String?
        get() = prefs.getString(KEY_AVATAR_STATIC, null)
        set(value) = prefs.edit().putString(KEY_AVATAR_STATIC, value).apply()

    var avatarImagePath: String?
        get() = avatarStaticPath
        set(value) { avatarStaticPath = value }

    var avatarVideoPath: String?
        get() = prefs.getString(KEY_AVATAR_VIDEO, null)
        set(value) = prefs.edit().putString(KEY_AVATAR_VIDEO, value).apply()

    var avatarThinkingGifPath: String?
        get() = prefs.getString(KEY_AVATAR_THINKING_GIF, null)
        set(value) = prefs.edit().putString(KEY_AVATAR_THINKING_GIF, value).apply()

    var pendingCameraFilePath: String?
        get() = prefs.getString(KEY_PENDING_CAMERA_FILE, null)
        set(value) = prefs.edit().putString(KEY_PENDING_CAMERA_FILE, value).apply()

    var kurumiThemeEnabled: Boolean
        get() = prefs.getBoolean(KEY_KURUMI_THEME, false)
        set(value) = prefs.edit().putBoolean(KEY_KURUMI_THEME, value).apply()

    // --- Neural Voice TTS & Voice Cloning + Puter TTS + Custom TTS ---
    // Defaults to native Android TextToSpeech so voice never burns cloud/Puter quota unless opted in.
    var ttsEngineMode: TtsEngineMode
        get() = runCatching {
            TtsEngineMode.valueOf(prefs.getString(KEY_TTS_ENGINE_MODE, TtsEngineMode.SYSTEM_ANDROID.name).orEmpty())
        }.getOrDefault(TtsEngineMode.SYSTEM_ANDROID)
        set(value) = prefs.edit().putString(KEY_TTS_ENGINE_MODE, value.name).apply()

    var ttsVoicePreset: NeuralVoicePreset
        get() = NeuralVoicePreset.fromId(prefs.getString(KEY_TTS_VOICE_PRESET, NeuralVoicePreset.SVETLANA.id))
        set(value) = prefs.edit().putString(KEY_TTS_VOICE_PRESET, value.id).apply()

    var ttsRateOffsetPct: Int
        get() = prefs.getInt(KEY_TTS_RATE_PCT, 0).coerceIn(-30, 45)
        set(value) = prefs.edit().putInt(KEY_TTS_RATE_PCT, value.coerceIn(-30, 45)).apply()

    var ttsPitchOffsetHz: Int
        get() = prefs.getInt(KEY_TTS_PITCH_HZ, 0).coerceIn(-20, 25)
        set(value) = prefs.edit().putInt(KEY_TTS_PITCH_HZ, value.coerceIn(-20, 25)).apply()

    var ttsAutoSpeakReplies: Boolean
        get() = prefs.getBoolean(KEY_TTS_AUTO_SPEAK, false)
        set(value) = prefs.edit().putBoolean(KEY_TTS_AUTO_SPEAK, value).apply()

    // Puter TTS preferences
    var puterTtsProvider: String
        get() = prefs.getString(KEY_PUTER_TTS_PROVIDER, "openai").orEmpty().ifBlank { "openai" }
        set(value) = prefs.edit().putString(KEY_PUTER_TTS_PROVIDER, value.trim().ifBlank { "openai" }).apply()

    var puterTtsVoice: String
        get() = prefs.getString(KEY_PUTER_TTS_VOICE, "nova").orEmpty().ifBlank { "nova" }
        set(value) = prefs.edit().putString(KEY_PUTER_TTS_VOICE, value.trim().ifBlank { "nova" }).apply()

    var puterTtsModel: String
        get() = prefs.getString(KEY_PUTER_TTS_MODEL, "gpt-4o-mini-tts").orEmpty().ifBlank { "gpt-4o-mini-tts" }
        set(value) = prefs.edit().putString(KEY_PUTER_TTS_MODEL, value.trim()).apply()

    // xAI / Grok Text-to-Speech credentials and voice selection
    var grokTtsApiKey: String
        get() = secureKeys.getSecret(KEY_GROK_TTS_API_KEY)
        set(value) = secureKeys.putSecret(KEY_GROK_TTS_API_KEY, value.trim())

    var grokTtsVoiceId: String
        get() = prefs.getString(KEY_GROK_TTS_VOICE_ID, "eve").orEmpty().trim().ifBlank { "eve" }
        set(value) = prefs.edit().putString(KEY_GROK_TTS_VOICE_ID, value.trim().ifBlank { "eve" }).apply()

    // Voice Cloning / Custom TTS preferences
    var customVoiceSamplePath: String?
        get() = prefs.getString(KEY_VOICE_SAMPLE_PATH, null)
        set(value) = prefs.edit().putString(KEY_VOICE_SAMPLE_PATH, value).apply()

    var customVoiceSampleName: String
        get() = prefs.getString(KEY_VOICE_SAMPLE_NAME, "").orEmpty()
        set(value) = prefs.edit().putString(KEY_VOICE_SAMPLE_NAME, value).apply()

    var customVoiceSampleText: String
        get() = prefs.getString(KEY_VOICE_SAMPLE_TEXT, "").orEmpty()
        set(value) = prefs.edit().putString(KEY_VOICE_SAMPLE_TEXT, value.trim()).apply()

    var fishAudioApiKey: String
        get() = secureKeys.getSecret(KEY_FISH_AUDIO_API_KEY)
        set(value) = secureKeys.putSecret(KEY_FISH_AUDIO_API_KEY, value.trim())

    var fishAudioVoiceId: String
        get() = prefs.getString(KEY_FISH_AUDIO_VOICE_ID, "").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_FISH_AUDIO_VOICE_ID, value.trim()).apply()

    var fishAudioModel: String
        get() = prefs.getString(KEY_FISH_AUDIO_MODEL, "s2.1-pro-free").orEmpty().ifBlank { "s2.1-pro-free" }
        set(value) = prefs.edit().putString(KEY_FISH_AUDIO_MODEL, value.trim().ifBlank { "s2.1-pro-free" }).apply()

    var elevenLabsApiKey: String
        get() = secureKeys.getSecret(KEY_ELEVENLABS_API_KEY)
        set(value) = secureKeys.putSecret(KEY_ELEVENLABS_API_KEY, value.trim())

    var elevenLabsVoiceId: String
        get() = prefs.getString(KEY_ELEVENLABS_VOICE_ID, "").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_ELEVENLABS_VOICE_ID, value.trim()).apply()

    var customCloneTtsUrl: String
        get() = prefs.getString(KEY_CUSTOM_CLONE_TTS_URL, "").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_CUSTOM_CLONE_TTS_URL, value.trim()).apply()

    var customTtsApiKey: String
        get() = secureKeys.getSecret(KEY_CUSTOM_TTS_API_KEY)
        set(value) = secureKeys.putSecret(KEY_CUSTOM_TTS_API_KEY, value.trim())

    var customTtsModel: String
        get() = prefs.getString(KEY_CUSTOM_TTS_MODEL, "tts-1").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_CUSTOM_TTS_MODEL, value.trim()).apply()

    var customTtsVoice: String
        get() = prefs.getString(KEY_CUSTOM_TTS_VOICE, "nova").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_CUSTOM_TTS_VOICE, value.trim()).apply()

    fun applyKurumiPreset() {
        assistantName = "Куруми"
        personaStyle = KURUMI_PERSONA
        ttsVoicePreset = NeuralVoicePreset.KURUMI_STYLE
        kurumiThemeEnabled = true
    }

    var accessibilityMasterSwitch: Boolean
        get() = prefs.getBoolean(KEY_ACCESSIBILITY_MASTER, false)
        set(value) = prefs.edit().putBoolean(KEY_ACCESSIBILITY_MASTER, value).apply()

    var accessibilityUserDisabled: Boolean
        get() = prefs.getBoolean(KEY_ACCESSIBILITY_USER_DISABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_ACCESSIBILITY_USER_DISABLED, value).apply()

    var agentToolsEnabled: Boolean
        get() = prefs.getBoolean(KEY_AGENT_TOOLS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_AGENT_TOOLS_ENABLED, value).apply()

    // --- Cloud API Keys (encrypted in AndroidKeyStore) ---
    var geminiApiKey: String
        get() = secureKeys.getSecret(KEY_GEMINI_API_KEY)
        set(value) = secureKeys.putSecret(KEY_GEMINI_API_KEY, value.trim())

    var geminiModel: String
        get() = prefs.getString(KEY_GEMINI_MODEL, CloudLlmClient.DEFAULT_GEMINI_MODEL)
            .orEmpty().ifBlank { CloudLlmClient.DEFAULT_GEMINI_MODEL }
        set(value) = prefs.edit().putString(KEY_GEMINI_MODEL, value.trim().ifBlank { CloudLlmClient.DEFAULT_GEMINI_MODEL }).apply()

    var geminiEndpointMode: GeminiEndpointMode
        get() = runCatching {
            GeminiEndpointMode.valueOf(prefs.getString(KEY_GEMINI_ENDPOINT_MODE, GeminiEndpointMode.AUTO.name).orEmpty())
        }.getOrDefault(GeminiEndpointMode.AUTO)
        set(value) = prefs.edit().putString(KEY_GEMINI_ENDPOINT_MODE, value.name).apply()

    var geminiDetectedVertex: Boolean
        get() = prefs.getBoolean(KEY_GEMINI_DETECTED_VERTEX, false)
        set(value) = prefs.edit().putBoolean(KEY_GEMINI_DETECTED_VERTEX, value).apply()

    var groqApiKey: String
        get() = secureKeys.getSecret(KEY_GROQ_API_KEY)
        set(value) = secureKeys.putSecret(KEY_GROQ_API_KEY, value.trim())

    var groqLlmModel: String
        get() = prefs.getString(KEY_GROQ_LLM_MODEL, CloudLlmClient.DEFAULT_GROQ_LLM_MODEL)
            .orEmpty().ifBlank { CloudLlmClient.DEFAULT_GROQ_LLM_MODEL }
        set(value) = prefs.edit().putString(KEY_GROQ_LLM_MODEL, value.trim().ifBlank { CloudLlmClient.DEFAULT_GROQ_LLM_MODEL }).apply()

    var groqSttModel: String
        get() = prefs.getString(KEY_GROQ_STT_MODEL, "whisper-large-v3-turbo")
            .orEmpty().ifBlank { "whisper-large-v3-turbo" }
        set(value) = prefs.edit().putString(KEY_GROQ_STT_MODEL, value.trim().ifBlank { "whisper-large-v3-turbo" }).apply()

    var openRouterApiKey: String
        get() = secureKeys.getSecret(KEY_OPENROUTER_API_KEY)
        set(value) = secureKeys.putSecret(KEY_OPENROUTER_API_KEY, value.trim())

    var openRouterModel: String
        get() = prefs.getString(KEY_OPENROUTER_MODEL, CloudLlmClient.DEFAULT_OPENROUTER_MODEL)
            .orEmpty().ifBlank { CloudLlmClient.DEFAULT_OPENROUTER_MODEL }
        set(value) = prefs.edit().putString(KEY_OPENROUTER_MODEL, value.trim().ifBlank { CloudLlmClient.DEFAULT_OPENROUTER_MODEL }).apply()

    // --- Perchance (editable default URL for text & image generation) ---
    var perchanceEnabled: Boolean
        get() = prefs.getBoolean(KEY_PERCHANCE_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_PERCHANCE_ENABLED, value).apply()

    var perchanceVerifyUrl: String
        get() = prefs.getString(KEY_PERCHANCE_VERIFY_URL, PerchanceWebViewBridge.DEFAULT_TEXT_EMBED_URL)
            .orEmpty().trim().ifBlank { PerchanceWebViewBridge.DEFAULT_TEXT_EMBED_URL }
        set(value) = prefs.edit()
            .putString(KEY_PERCHANCE_VERIFY_URL, value.trim().ifBlank { PerchanceWebViewBridge.DEFAULT_TEXT_EMBED_URL })
            .apply()

    var perchanceImageUrl: String
        get() {
            val raw = prefs.getString(KEY_PERCHANCE_IMAGE_URL, PerchanceWebViewBridge.DEFAULT_IMAGE_API_URL)
                .orEmpty().trim()
            // Auto-migrate broken/legacy perchance-ai-api URL to modern image-generation.perchance.org/embed
            return if (raw.isBlank() || raw.contains("perchance-ai-api", ignoreCase = true)) {
                PerchanceWebViewBridge.DEFAULT_IMAGE_API_URL
            } else raw
        }
        set(value) = prefs.edit()
            .putString(KEY_PERCHANCE_IMAGE_URL, value.trim().ifBlank { PerchanceWebViewBridge.DEFAULT_IMAGE_API_URL })
            .apply()

    // --- Image Generation Preferences (perchance.org/api-gen + scene memory) ---
    var imageGenQualityMode: ImageQualityMode
        get() = ImageQualityMode.fromStored(prefs.getString(KEY_IMAGE_GEN_QUALITY_MODE, ImageQualityMode.FAST.name))
        set(value) = prefs.edit().putString(KEY_IMAGE_GEN_QUALITY_MODE, value.name).apply()

    var imageGenStyle: String
        get() = prefs.getString(KEY_IMAGE_GEN_STYLE, "").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_IMAGE_GEN_STYLE, value.trim()).apply()

    var imageGenResolution: String
        get() = prefs.getString(KEY_IMAGE_GEN_RESOLUTION, "768x768").orEmpty().ifBlank { "768x768" }
        set(value) = prefs.edit().putString(KEY_IMAGE_GEN_RESOLUTION, value.trim().ifBlank { "768x768" }).apply()

    // --- Puter API (next to Perchance, Bearer token encrypted in AndroidKeyStore, NO hardcoded tokens!) ---
    var puterAuthToken: String
        get() = secureKeys.getSecret(KEY_PUTER_AUTH_TOKEN)
        set(value) = secureKeys.putSecret(KEY_PUTER_AUTH_TOKEN, value.trim())

    var puterModel: String
        get() = prefs.getString(KEY_PUTER_MODEL, PuterApiClient.DEFAULT_ECON_MODEL)
            .orEmpty().trim().ifBlank { PuterApiClient.DEFAULT_ECON_MODEL }
        set(value) = prefs.edit()
            .putString(KEY_PUTER_MODEL, value.trim().ifBlank { PuterApiClient.DEFAULT_ECON_MODEL })
            .apply()

    var puterSmartMode: Boolean
        get() = prefs.getBoolean(KEY_PUTER_SMART_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_PUTER_SMART_MODE, value).apply()

    var puterSmartModel: String
        get() = prefs.getString(KEY_PUTER_SMART_MODEL, PuterApiClient.DEFAULT_SMART_MODEL)
            .orEmpty().trim().ifBlank { PuterApiClient.DEFAULT_SMART_MODEL }
        set(value) = prefs.edit()
            .putString(KEY_PUTER_SMART_MODEL, value.trim().ifBlank { PuterApiClient.DEFAULT_SMART_MODEL })
            .apply()

    var puterManualModelId: String
        get() = prefs.getString(KEY_PUTER_MANUAL_MODEL, "").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_PUTER_MANUAL_MODEL, value.trim()).apply()

    var puterLastUsageLabelRu: String
        get() = prefs.getString(KEY_PUTER_LAST_USAGE_RU, "").orEmpty().trim()
        set(value) = prefs.edit().putString(KEY_PUTER_LAST_USAGE_RU, value.trim()).apply()

    fun effectivePuterModel(): String =
        puterManualModelId.ifBlank { if (puterSmartMode) puterSmartModel else puterModel }

    // --- Multi-Custom Providers (1..10) ---
    fun getCustomProviders(): List<CustomProviderConfig> {
        val raw = prefs.getString(KEY_CUSTOM_PROVIDERS_JSON, null)
        return CustomProviderManager.deserializeMetadataList(raw) { id ->
            secureKeys.getSecret("$KEY_CUSTOM_PROVIDER_SECRET_PREFIX$id")
        }
    }

    var activeCustomProviderId: String
        get() = prefs.getString(KEY_ACTIVE_CUSTOM_PROVIDER_ID, "").orEmpty()
        set(value) = prefs.edit().putString(KEY_ACTIVE_CUSTOM_PROVIDER_ID, value).apply()

    fun getActiveCustomProvider(): CustomProviderConfig? {
        val all = getCustomProviders().filter { it.enabled && it.baseUrl.isNotBlank() }
        if (all.isEmpty()) return null
        return all.firstOrNull { it.id == activeCustomProviderId } ?: all.first()
    }

    fun saveCustomProviders(providers: List<CustomProviderConfig>, activeId: String? = null) {
        val trimmed = providers.take(CustomProviderManager.MAX_PROVIDERS)
        val oldIds = getCustomProviders().map { it.id }.toSet()
        val newIds = trimmed.map { it.id }.toSet()
        for (removed in oldIds - newIds) {
            secureKeys.putSecret("$KEY_CUSTOM_PROVIDER_SECRET_PREFIX$removed", "")
        }
        for (p in trimmed) {
            secureKeys.putSecret("$KEY_CUSTOM_PROVIDER_SECRET_PREFIX${p.id}", p.apiKey.trim())
        }
        val metaJson = CustomProviderManager.serializeMetadataList(trimmed)
        val effectiveActive = activeId ?: activeCustomProviderId.takeIf { id -> trimmed.any { it.id == id } }
            ?: trimmed.firstOrNull { it.enabled }?.id.orEmpty()
        prefs.edit()
            .putString(KEY_CUSTOM_PROVIDERS_JSON, metaJson)
            .putString(KEY_ACTIVE_CUSTOM_PROVIDER_ID, effectiveActive)
            .apply()
    }

    fun upsertCustomProvider(config: CustomProviderConfig, setAsActive: Boolean = false) {
        val current = getCustomProviders().toMutableList()
        val idx = current.indexOfFirst { it.id == config.id }
        val normalized = config.copy(baseUrl = CustomProviderManager.normalizeUrl(config.baseUrl))
        if (idx >= 0) current[idx] = normalized else current.add(normalized)
        saveCustomProviders(current, activeId = if (setAsActive) normalized.id else null)
    }

    fun deleteCustomProvider(id: String) {
        val remaining = getCustomProviders().filterNot { it.id == id }
        saveCustomProviders(remaining)
    }

    var customApiKey: String
        get() = getActiveCustomProvider()?.apiKey ?: secureKeys.getSecret(KEY_CUSTOM_API_KEY)
        set(value) {
            val active = getActiveCustomProvider()
            if (active != null) upsertCustomProvider(active.copy(apiKey = value.trim()))
            else secureKeys.putSecret(KEY_CUSTOM_API_KEY, value.trim())
        }

    var customApiBaseUrl: String
        get() = getActiveCustomProvider()?.baseUrl ?: prefs.getString(KEY_CUSTOM_API_BASE_URL, "").orEmpty().trim()
        set(value) {
            val active = getActiveCustomProvider()
            if (active != null) upsertCustomProvider(active.copy(baseUrl = value.trim()))
            else prefs.edit().putString(KEY_CUSTOM_API_BASE_URL, value.trim()).apply()
        }

    var customApiModel: String
        get() = getActiveCustomProvider()?.model ?: prefs.getString(KEY_CUSTOM_API_MODEL, "").orEmpty().trim()
        set(value) {
            val active = getActiveCustomProvider()
            if (active != null) upsertCustomProvider(active.copy(model = value.trim()))
            else prefs.edit().putString(KEY_CUSTOM_API_MODEL, value.trim()).apply()
        }

    var customApiCompat: CustomApiCompatibility
        get() = getActiveCustomProvider()?.compatibility ?: CustomApiCompatibility.OPENAI_COMPATIBLE
        set(value) {
            val active = getActiveCustomProvider()
            if (active != null) upsertCustomProvider(active.copy(compatibility = value))
            else prefs.edit().putString(KEY_CUSTOM_API_COMPAT, value.name).apply()
        }

    fun resolvedCustomApi(): ResolvedCustomApi {
        val active = getActiveCustomProvider()
        if (active != null) {
            return ResolvedCustomApi(
                baseUrl = active.baseUrl,
                model = active.effectiveModel(),
                compatibility = active.compatibility,
                detectedLabelRu = active.displayTitle()
            )
        }
        return CustomApiResolver.resolve(
            rawKey = customApiKey,
            compatibility = customApiCompat,
            optionalBaseUrl = customApiBaseUrl,
            optionalModel = customApiModel
        )
    }

    fun hasAnyCustomProviderReady(): Boolean =
        getCustomProviders().any { it.enabled && it.baseUrl.isNotBlank() }

    var chatPrimaryProvider: CloudProvider
        get() = CloudProvider.fromStoredNameSafe(
            prefs.getString(KEY_CHAT_PRIMARY_PROVIDER, CloudProvider.GEMINI.name),
            fallback = CloudProvider.GEMINI
        )
        set(value) = prefs.edit().putString(KEY_CHAT_PRIMARY_PROVIDER, value.name).apply()

    var islandPrimaryProvider: CloudProvider
        get() = CloudProvider.fromStoredNameSafe(
            prefs.getString(KEY_ISLAND_PRIMARY_PROVIDER, CloudProvider.GROQ.name),
            fallback = CloudProvider.GROQ
        )
        set(value) = prefs.edit().putString(KEY_ISLAND_PRIMARY_PROVIDER, value.name).apply()

    var autoFallbackEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_FALLBACK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_FALLBACK, value).apply()

    var voiceSttMode: VoiceSttMode
        get() = runCatching {
            VoiceSttMode.valueOf(prefs.getString(KEY_VOICE_STT_MODE, VoiceSttMode.ANDROID_NATIVE.name).orEmpty())
        }.getOrDefault(VoiceSttMode.ANDROID_NATIVE)
        set(value) = prefs.edit().putString(KEY_VOICE_STT_MODE, value.name).apply()

    fun hasAnyCloudKey(): Boolean =
        geminiApiKey.isNotBlank() ||
            groqApiKey.isNotBlank() ||
            openRouterApiKey.isNotBlank() ||
            hasAnyCustomProviderReady() ||
            perchanceEnabled ||
            puterAuthToken.isNotBlank()

    fun buildGenerationConfig(
        profileId: ModelProfileId = activeProfileId,
        source: RequestSource = RequestSource.CHAT,
        chatMode: ChatMode = ChatMode.NORMAL,
        contextSummary: String = ""
    ): GenerationConfig = GenerationConfig(
        assistantName = assistantName,
        maxTokens = maxOf(maxTokens, responseLength.maxTokens),
        temperature = chatMode.temperatureHint ?: temperature,
        enableThinking = showThinking,
        responseLength = responseLength,
        tone = assistantTone,
        customSystemPrompt = buildString {
            if (personaStyle.isNotBlank()) append(personaStyle.trim())
            if (customSystemPrompt.isNotBlank()) {
                if (isNotEmpty()) append("\n\n")
                append(customSystemPrompt.trim())
            }
        },
        chatMode = chatMode,
        contextSummary = contextSummary,
        contextWindowSize = contextWindowMessages,
        promptFormat = profileId.promptFormat,
        requestSource = source,
        agentToolsEnabled = agentToolsEnabled
    )

    companion object {
        private const val PREFS_NAME = "jarvis_preferences"
        private const val KEY_ACTIVE_PROFILE = "active_profile"
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_PERSONA_STYLE = "persona_style"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val KEY_TEMPERATURE = "temperature"
        private const val KEY_MAX_TOKENS = "max_tokens"
        private const val KEY_SHOW_THINKING = "show_thinking"
        private const val KEY_RESPONSE_LENGTH = "response_length"
        private const val KEY_ASSISTANT_TONE = "assistant_tone"
        private const val KEY_ACCESSIBILITY_USER_DISABLED = "accessibility_user_disabled"
        private const val KEY_PUTER_MANUAL_MODEL = "puter_manual_model"
        private const val KEY_PUTER_LAST_USAGE_RU = "puter_last_usage_ru"
        private const val KEY_CONTEXT_WINDOW_MESSAGES = "context_window_messages"
        private const val KEY_AGENT_MAX_STEPS = "agent_max_steps"

        private const val KEY_ISLAND_ENABLED = "island_enabled"
        private const val KEY_ISLAND_PENDING_RESTORE = "island_pending_restore"
        private const val KEY_ISLAND_NOTIFICATIONS_ENABLED = "island_notifications_enabled"
        private const val KEY_ISLAND_BLOCKED_NOTIF_PKGS = "island_blocked_notif_packages"
        private const val KEY_ISLAND_MUSIC_ENABLED = "island_music_enabled"
        private const val KEY_ISLAND_CALLS_ENABLED = "island_calls_enabled"
        private const val KEY_ISLAND_X = "island_x"
        private const val KEY_ISLAND_Y = "island_y"
        private const val KEY_ISLAND_WIDTH_DP = "island_width_dp"
        private const val KEY_ISLAND_HEIGHT_DP = "island_height_dp"
        private const val KEY_ISLAND_RADIUS_DP = "island_radius_dp"
        private const val KEY_ISLAND_LOCK_DRAG = "island_lock_drag"
        private const val KEY_ISLAND_SHOW_ANSWER = "island_show_answer"

        private const val KEY_AVATAR_STATIC = "avatar_static_path"
        private const val KEY_AVATAR_VIDEO = "avatar_video_path"
        private const val KEY_AVATAR_THINKING_GIF = "avatar_thinking_gif_path"
        private const val KEY_PENDING_CAMERA_FILE = "pending_camera_file_path"
        private const val KEY_KURUMI_THEME = "kurumi_theme_enabled"

        private const val KEY_TTS_ENGINE_MODE = "tts_engine_mode"
        private const val KEY_TTS_VOICE_PRESET = "tts_voice_preset"
        private const val KEY_TTS_RATE_PCT = "tts_rate_pct"
        private const val KEY_TTS_PITCH_HZ = "tts_pitch_hz"
        private const val KEY_TTS_AUTO_SPEAK = "tts_auto_speak"

        private const val KEY_PUTER_TTS_PROVIDER = "puter_tts_provider"
        private const val KEY_PUTER_TTS_VOICE = "puter_tts_voice"
        private const val KEY_PUTER_TTS_MODEL = "puter_tts_model"

        private const val KEY_VOICE_SAMPLE_PATH = "voice_sample_path"
        private const val KEY_VOICE_SAMPLE_NAME = "voice_sample_name"
        private const val KEY_VOICE_SAMPLE_TEXT = "voice_sample_text"
        private const val KEY_FISH_AUDIO_API_KEY = "fish_audio_api_key"
        private const val KEY_FISH_AUDIO_VOICE_ID = "fish_audio_voice_id"
        private const val KEY_FISH_AUDIO_MODEL = "fish_audio_model"
        private const val KEY_ELEVENLABS_API_KEY = "elevenlabs_api_key"
        private const val KEY_ELEVENLABS_VOICE_ID = "elevenlabs_voice_id"
        private const val KEY_CUSTOM_CLONE_TTS_URL = "custom_clone_tts_url"
        private const val KEY_CUSTOM_TTS_API_KEY = "custom_tts_api_key"
        private const val KEY_CUSTOM_TTS_MODEL = "custom_tts_model"
        private const val KEY_CUSTOM_TTS_VOICE = "custom_tts_voice"
        private const val KEY_GROK_TTS_API_KEY = "grok_tts_api_key"
        private const val KEY_GROK_TTS_VOICE_ID = "grok_tts_voice_id"

        private const val KEY_ACCESSIBILITY_MASTER = "accessibility_master_switch"
        private const val KEY_AGENT_TOOLS_ENABLED = "agent_tools_enabled"

        private const val KEY_GEMINI_API_KEY = "cloud_gemini_key"
        private const val KEY_GEMINI_MODEL = "cloud_gemini_model"
        private const val KEY_GEMINI_ENDPOINT_MODE = "cloud_gemini_endpoint_mode"
        private const val KEY_GEMINI_DETECTED_VERTEX = "cloud_gemini_detected_vertex"
        private const val KEY_GROQ_API_KEY = "cloud_groq_key"
        private const val KEY_GROQ_LLM_MODEL = "cloud_groq_llm_model"
        private const val KEY_GROQ_STT_MODEL = "cloud_groq_stt_model"
        private const val KEY_OPENROUTER_API_KEY = "cloud_openrouter_key"
        private const val KEY_OPENROUTER_MODEL = "cloud_openrouter_model"

        private const val KEY_PERCHANCE_ENABLED = "cloud_perchance_enabled"
        private const val KEY_PERCHANCE_VERIFY_URL = "cloud_perchance_verify_url"
        private const val KEY_PERCHANCE_IMAGE_URL = "cloud_perchance_image_url"
        private const val KEY_IMAGE_GEN_QUALITY_MODE = "image_gen_quality_mode"
        private const val KEY_IMAGE_GEN_STYLE = "image_gen_style"
        private const val KEY_IMAGE_GEN_RESOLUTION = "image_gen_resolution"

        private const val KEY_PUTER_AUTH_TOKEN = "cloud_puter_auth_token"
        private const val KEY_PUTER_MODEL = "cloud_puter_model"
        private const val KEY_PUTER_SMART_MODE = "cloud_puter_smart_mode"
        private const val KEY_PUTER_SMART_MODEL = "cloud_puter_smart_model"

        private const val KEY_CUSTOM_PROVIDERS_JSON = "cloud_custom_providers_v3_json"
        private const val KEY_ACTIVE_CUSTOM_PROVIDER_ID = "cloud_active_custom_provider_id"
        private const val KEY_CUSTOM_PROVIDER_SECRET_PREFIX = "cloud_custom_secret_"
        private const val KEY_CUSTOM_MIGRATED_V3 = "cloud_custom_migrated_v3"

        private const val KEY_CUSTOM_API_KEY = "cloud_custom_key"
        private const val KEY_CUSTOM_API_BASE_URL = "cloud_custom_base_url"
        private const val KEY_CUSTOM_API_MODEL = "cloud_custom_model"
        private const val KEY_CUSTOM_API_COMPAT = "cloud_custom_compat"

        private const val KEY_CHAT_PRIMARY_PROVIDER = "cloud_chat_primary_provider"
        private const val KEY_ISLAND_PRIMARY_PROVIDER = "cloud_island_primary_provider"
        private const val KEY_AUTO_FALLBACK = "cloud_auto_fallback"
        private const val KEY_VOICE_STT_MODE = "cloud_voice_stt_mode"

        const val DEFAULT_PERSONA = "дружелюбный, точный, лаконичный помощник, отвечает по делу на русском языке"
        const val KURUMI_PERSONA =
            "элегантная, загадочная и слегка игривая помощница в стиле Куруми Токисаки (из Date A Live): " +
                "вежливая, остроумная, иногда использует лёгкое «ара-ара», но всегда остаётся точной, заботливой и реально полезной."
    }
}
