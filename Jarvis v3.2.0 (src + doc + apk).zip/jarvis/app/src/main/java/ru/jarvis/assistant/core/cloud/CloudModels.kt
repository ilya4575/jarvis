package ru.jarvis.assistant.core.cloud

import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.util.UUID

/**
 * Online API providers (strictly curated in v3.0):
 *  1. GEMINI      — Google Gemini (AI Studio & Vertex Express)
 *  2. GROQ        — Groq Cloud (fast Llama + Whisper STT)
 *  3. OPENROUTER  — OpenRouter (multi-model gateway)
 *  4. CUSTOM_API  — 1..10 user-configured OpenAI/Anthropic compatible endpoints
 * Plus:
 *  5. PERCHANCE   — Free WebView bridge (chat + image generation, isolated Cloudflare verify)
 *  6. PUTER       — Puter OpenAI-compatible API (Bearer Auth Token, presets, metering, tools, TTS)
 *  7. LOCAL       — Optional offline GGUF (only if explicitly loaded by the user in «Локальные модели»)
 */
enum class CloudProvider(val shortLabelRu: String, val fullLabelRu: String) {
    GEMINI("Gemini", "Google Gemini (AI Studio / Vertex)"),
    GROQ("Groq", "Groq Cloud (LLM + Whisper STT)"),
    OPENROUTER("OpenRouter", "OpenRouter"),
    CUSTOM_API("Custom", "Custom API (до 10 провайдеров)"),
    PERCHANCE("Perchance", "Perchance (чат и картинки, без ключа)"),
    PUTER("Puter", "Puter API (GPT-5 / Claude / Gemini по Auth Token)"),
    LOCAL("Локальная", "Локальная GGUF (офлайн)");

    companion object {
        val ONLINE_SELECTABLE: List<CloudProvider> = listOf(
            GEMINI, GROQ, OPENROUTER, CUSTOM_API, PERCHANCE, PUTER
        )

        fun fromStoredNameSafe(raw: String?, fallback: CloudProvider = GEMINI): CloudProvider {
            if (raw.isNullOrBlank()) return fallback
            // Safely migrate removed legacy providers (CEREBRAS / MISTRAL) without crashing
            if (raw.equals("CEREBRAS", ignoreCase = true) || raw.equals("MISTRAL", ignoreCase = true)) {
                return fallback
            }
            return entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: fallback
        }
    }
}

enum class VoiceSttMode(val labelRu: String) {
    ANDROID_NATIVE("Android SpeechRecognizer (бесплатно; зависит от службы распознавания)"),
    GROQ_FIRST("Groq Whisper STT (нужен Groq API key; резерв: Android/Vosk)"),
    VOSK_ONLY("Vosk STT офлайн (нужна скачанная модель)")
}

enum class RequestSource {
    CHAT,
    DYNAMIC_ISLAND
}

enum class GeminiEndpointMode(val labelRu: String) {
    AUTO("Авто (AI Studio → Vertex)"),
    AI_STUDIO("Google AI Studio (generativelanguage)"),
    VERTEX_EXPRESS("Google Cloud Vertex Express (aiplatform)")
}

enum class CustomApiCompatibility(val labelRu: String) {
    OPENAI_COMPATIBLE("OpenAI-совместимый (/chat/completions)"),
    ANTHROPIC_COMPATIBLE("Anthropic Messages (/v1/messages)")
}

/**
 * Single user-configured Custom API provider (up to 10 supported in v3.0).
 * UI field order: Base URL -> API Key -> Optional settings (compatibility, name, model, extra headers/overrides).
 */
data class CustomProviderConfig(
    val id: String = UUID.randomUUID().toString().take(12),
    val baseUrl: String = "",
    val apiKey: String = "",
    val name: String = "",
    val model: String = "",
    val compatibility: CustomApiCompatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
    val extraHeadersJson: String = "",
    val extraParamsJson: String = "",
    val enabled: Boolean = true
) {
    fun displayTitle(): String =
        name.trim().ifBlank {
            runCatching { URI(baseUrl.trim()).host }.getOrNull()?.takeIf { !it.isNullOrBlank() }
                ?: "Custom API"
        }

    fun effectiveModel(): String = model.trim().ifBlank {
        when (compatibility) {
            CustomApiCompatibility.OPENAI_COMPATIBLE -> "gpt-4o-mini"
            CustomApiCompatibility.ANTHROPIC_COMPATIBLE -> "claude-3-5-sonnet-latest"
        }
    }

    fun parsedExtraHeaders(): Map<String, String> = parseExtraHeaders()

    fun parseExtraHeaders(): Map<String, String> {
        if (extraHeadersJson.isBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(extraHeadersJson)
            val map = linkedMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next().trim()
                val v = obj.optString(k, "").trim()
                if (k.isNotEmpty() && v.isNotEmpty()) map[k] = v
            }
            map
        }.getOrDefault(emptyMap())
    }

    fun parseExtraParams(): JSONObject? {
        if (extraParamsJson.isBlank()) return null
        return runCatching { JSONObject(extraParamsJson) }.getOrNull()
    }
}

data class CustomProviderValidationResult(
    val valid: Boolean,
    val errorRu: String? = null
)

/**
 * Pure-Kotlin CRUD & validation helper for 1..10 Custom API providers (unit-testable on JVM).
 */
object CustomProviderManager {
    const val MAX_PROVIDERS = 10

    fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        val withScheme = if (!trimmed.contains("://")) {
            "https://$trimmed"
        } else {
            trimmed
        }
        return withScheme.trimEnd('/')
    }

    fun validate(
        candidate: CustomProviderConfig,
        existingList: List<CustomProviderConfig>
    ): CustomProviderValidationResult {
        val url = normalizeUrl(candidate.baseUrl)
        if (url.isEmpty()) {
            return CustomProviderValidationResult(false, "Укажите URL API-провайдера.")
        }
        val parsed = runCatching { URI(url) }.getOrNull()
        if (parsed == null || parsed.scheme !in setOf("http", "https") || parsed.host.isNullOrBlank()) {
            return CustomProviderValidationResult(false, "Некорректный URL (пример: https://api.openai.com/v1).")
        }
        val isEditing = existingList.any { it.id == candidate.id }
        if (!isEditing && existingList.size >= MAX_PROVIDERS) {
            return CustomProviderValidationResult(false, "Достигнут лимит: максимум $MAX_PROVIDERS Custom-провайдеров.")
        }
        val dupName = candidate.name.trim()
        if (dupName.isNotEmpty() && existingList.any {
                it.id != candidate.id && it.name.trim().equals(dupName, ignoreCase = true)
            }
        ) {
            return CustomProviderValidationResult(false, "Провайдер с именем «$dupName» уже существует.")
        }
        if (existingList.any {
                it.id != candidate.id &&
                    normalizeUrl(it.baseUrl).equals(url, ignoreCase = true) &&
                    it.effectiveModel().equals(candidate.effectiveModel(), ignoreCase = true)
            }
        ) {
            return CustomProviderValidationResult(false, "Дубликат: этот URL и модель уже добавлены.")
        }
        if (candidate.extraHeadersJson.isNotBlank()) {
            val ok = runCatching { JSONObject(candidate.extraHeadersJson) }.isSuccess
            if (!ok) return CustomProviderValidationResult(false, "Доп. заголовки должны быть валидным JSON-объектом.")
        }
        if (candidate.extraParamsJson.isNotBlank()) {
            val ok = runCatching { JSONObject(candidate.extraParamsJson) }.isSuccess
            if (!ok) return CustomProviderValidationResult(false, "Доп. параметры должны быть валидным JSON-объектом.")
        }
        return CustomProviderValidationResult(true)
    }

    fun serializeMetadataList(providers: List<CustomProviderConfig>): String {
        val arr = JSONArray()
        for (p in providers.take(MAX_PROVIDERS)) {
            arr.put(
                JSONObject().apply {
                    put("id", p.id)
                    put("baseUrl", normalizeUrl(p.baseUrl))
                    put("name", p.name.trim())
                    put("model", p.model.trim())
                    put("compatibility", p.compatibility.name)
                    put("extraHeadersJson", p.extraHeadersJson.trim())
                    put("extraParamsJson", p.extraParamsJson.trim())
                    put("enabled", p.enabled)
                }
            )
        }
        return arr.toString()
    }

    fun deserializeMetadataList(rawJson: String?, keyLookup: (String) -> String): List<CustomProviderConfig> {
        if (rawJson.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(rawJson)
            val result = mutableListOf<CustomProviderConfig>()
            for (i in 0 until minOf(arr.length(), MAX_PROVIDERS)) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id", "").ifBlank { UUID.randomUUID().toString().take(12) }
                val compat = runCatching {
                    CustomApiCompatibility.valueOf(obj.optString("compatibility", "OPENAI_COMPATIBLE"))
                }.getOrDefault(CustomApiCompatibility.OPENAI_COMPATIBLE)
                result.add(
                    CustomProviderConfig(
                        id = id,
                        baseUrl = obj.optString("baseUrl", ""),
                        apiKey = keyLookup(id),
                        name = obj.optString("name", ""),
                        model = obj.optString("model", ""),
                        compatibility = compat,
                        extraHeadersJson = obj.optString("extraHeadersJson", ""),
                        extraParamsJson = obj.optString("extraParamsJson", ""),
                        enabled = obj.optBoolean("enabled", true)
                    )
                )
            }
            result
        }.getOrDefault(emptyList())
    }
}

data class ResolvedCustomApi(
    val baseUrl: String,
    val model: String,
    val compatibility: CustomApiCompatibility,
    val detectedLabelRu: String,
    val autoDetectedUrl: Boolean = false
)

typealias ResolvedCustomApiConfig = ResolvedCustomApi

data class OpenRouterFreeModel(
    val id: String,
    val name: String,
    val contextLength: Int = 32_768,
    val supportsVision: Boolean = false
)

data class CloudTestResult(
    val provider: CloudProvider,
    val ok: Boolean,
    val summaryRu: String,
    val detectedVertex: Boolean = false
)

enum class PerchanceVerifyStatus(val labelRu: String) {
    IDLE("Ожидает"),
    CHECKING("Проверка…"),
    VERIFIED("Пройдена"),
    NEEDS_VERIFICATION("Нужна проверка"),
    ERROR("Ошибка")
}

enum class ImageQualityMode(
    val apiModelId: String,
    val labelRu: String,
    val shortRu: String
) {
    FAST("sir-image-fast", "Быстрый (~10–15 сек)", "Быстрый"),
    FULL("sir-image-full", "Макс. качество (перевод + контроль 8/10)", "Качество");

    companion object {
        fun fromStored(raw: String?): ImageQualityMode =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) || it.apiModelId.equals(raw, ignoreCase = true) }
                ?: FAST
    }
}

data class ImageGenRequest(
    val prompt: String,
    val resolution: String = "768x768",
    val qualityMode: ImageQualityMode = ImageQualityMode.FAST,
    val style: String? = null,
    val negativePrompt: String = "",
    val seed: Long? = null,
    val useSceneMemory: Boolean = true
)

data class PerchanceImageResult(
    val ok: Boolean,
    val localFilePath: String? = null,
    val remoteUrl: String? = null,
    val seed: Long? = null,
    val errorRu: String? = null,
    val needsVerification: Boolean = false,
    val engineUsed: String = "",
    val modelUsed: String = "",
    val styleUsed: String? = null,
    val effectivePrompt: String = "",
    val fallbackNotes: List<String> = emptyList()
)

/**
 * Parsed result of GET https://api.puter.com/metering/usage
 * Per Puter docs: 1_000_000 microcents = $0.01 (100_000_000 microcents = $1.00).
 */
data class PuterUsageInfo(
    val remainingRaw: Double,
    val monthAllowanceRaw: Double,
    val unit: String = "microcents",
    val remainingFormatted: String,
    val allowanceFormatted: String,
    val percentRemaining: Int
) {
    fun summaryRu(): String = "Остаток Puter: $remainingFormatted из $allowanceFormatted ($percentRemaining%)"
}
