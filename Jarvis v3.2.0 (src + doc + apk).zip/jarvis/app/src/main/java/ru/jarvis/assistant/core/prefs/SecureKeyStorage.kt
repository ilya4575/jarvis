package ru.jarvis.assistant.core.prefs

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Local hardware-backed AES-256-GCM encrypted storage for API keys and tokens using AndroidKeyStore.
 * - Never logs secrets or transmits keys anywhere outside explicit user-configured API requests.
 * - Transparently migrates legacy plaintext keys from jarvis_local_prefs on first read.
 */
class SecureKeyStorage(context: Context) {

    private val encPrefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val legacyPrefs: SharedPreferences =
        context.getSharedPreferences("jarvis_local_prefs", Context.MODE_PRIVATE)

    fun getSecret(key: String, legacyKey: String? = null): String {
        val stored = encPrefs.getString(key, null)
        if (stored != null) {
            return decrypt(stored)
        }
        // Transparent one-time migration from legacy SharedPreferences
        val fallbackKey = legacyKey ?: key
        val legacyVal = legacyPrefs.getString(fallbackKey, null)
        if (!legacyVal.isNullOrEmpty()) {
            putSecret(key, legacyVal)
            legacyPrefs.edit().remove(fallbackKey).apply()
            return legacyVal
        }
        return ""
    }

    fun putSecret(key: String, value: String) {
        if (value.isEmpty()) {
            encPrefs.edit().remove(key).apply()
            legacyPrefs.edit().remove(key).apply()
            return
        }
        val encrypted = encrypt(value)
        encPrefs.edit().putString(key, encrypted).apply()
        // Ensure no plaintext copy remains in legacy prefs
        if (legacyPrefs.contains(key)) {
            legacyPrefs.edit().remove(key).apply()
        }
    }

    fun removeSecret(key: String) {
        encPrefs.edit().remove(key).apply()
        legacyPrefs.edit().remove(key).apply()
    }

    fun migrateFromLegacyPlaintext(sourcePrefs: SharedPreferences, key: String) {
        if (encPrefs.contains(key)) {
            if (sourcePrefs.contains(key)) sourcePrefs.edit().remove(key).apply()
            return
        }
        val legacy = sourcePrefs.getString(key, null)
        if (!legacy.isNullOrEmpty()) {
            putSecret(key, legacy)
            sourcePrefs.edit().remove(key).apply()
        }
    }

    private fun getOrCreateKey(): SecretKey? = runCatching {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return@runCatching existing

        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        gen.init(spec)
        gen.generateKey()
    }.getOrNull()

    private fun encrypt(plain: String): String {
        val key = getOrCreateKey() ?: return PREFIX_RAW + Base64.encodeToString(plain.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        return runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val iv = cipher.iv
            val cipherBytes = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(1 + iv.size + cipherBytes.size)
            combined[0] = iv.size.toByte()
            System.arraycopy(iv, 0, combined, 1, iv.size)
            System.arraycopy(cipherBytes, 0, combined, 1 + iv.size, cipherBytes.size)
            PREFIX_GCM + Base64.encodeToString(combined, Base64.NO_WRAP)
        }.getOrElse {
            PREFIX_RAW + Base64.encodeToString(plain.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    private fun decrypt(encoded: String): String {
        if (encoded.startsWith(PREFIX_RAW)) {
            return runCatching {
                String(Base64.decode(encoded.removePrefix(PREFIX_RAW), Base64.NO_WRAP), Charsets.UTF_8)
            }.getOrDefault("")
        }
        if (!encoded.startsWith(PREFIX_GCM)) {
            return encoded
        }
        val key = getOrCreateKey() ?: return ""
        return runCatching {
            val combined = Base64.decode(encoded.removePrefix(PREFIX_GCM), Base64.NO_WRAP)
            if (combined.size < 2) return@runCatching ""
            val ivLen = combined[0].toInt() and 0xFF
            if (ivLen <= 0 || combined.size <= 1 + ivLen) return@runCatching ""
            val iv = combined.copyOfRange(1, 1 + ivLen)
            val cipherBytes = combined.copyOfRange(1 + ivLen, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
        }.getOrDefault("")
    }

    companion object {
        private const val PREFS_NAME = "jarvis_secure_keys"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "jarvis_aes256_gcm_keys_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val PREFIX_GCM = "gcm1:"
        private const val PREFIX_RAW = "b64:"
    }
}
