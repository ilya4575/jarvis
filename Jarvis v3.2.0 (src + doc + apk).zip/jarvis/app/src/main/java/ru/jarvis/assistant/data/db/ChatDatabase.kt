package ru.jarvis.assistant.data.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import ru.jarvis.assistant.core.inference.ChatMode

data class ChatSessionEntity(
    val id: Long,
    val title: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis(),
    val mode: ChatMode = ChatMode.NORMAL,
    val contextSummary: String = "",
    val summaryUpToMsgId: Long = 0L,
    val imageSceneMemory: String = ""
)

data class ChatMessageEntity(
    val id: Long,
    val role: String, // "user" | "assistant" | "system"
    val text: String,
    val imagePath: String? = null,
    val mathVerifiedNote: String? = null,
    val timestampMs: Long = System.currentTimeMillis(),
    val sessionId: Long = 1L,
    val thinkingLog: String? = null,
    val generatedImagePath: String? = null,
    val imagePrompt: String? = null,
    val isImageGenerating: Boolean = false
)

interface ChatHistoryStore {
    fun listSessions(): List<ChatSessionEntity>
    fun createSession(title: String = "Новый чат", mode: ChatMode = ChatMode.NORMAL): ChatSessionEntity
    fun renameSession(sessionId: Long, newTitle: String)
    fun updateSessionMode(sessionId: Long, mode: ChatMode) {}
    fun updateSessionSummary(sessionId: Long, summary: String, upToMessageId: Long) {}
    fun updateSessionImageSceneMemory(sessionId: Long, sceneMemoryJson: String) {}
    fun deleteSession(sessionId: Long)

    fun getMessages(sessionId: Long): List<ChatMessageEntity>
    fun getAllMessages(): List<ChatMessageEntity>

    fun insertMessage(
        role: String,
        text: String,
        imagePath: String? = null,
        mathVerifiedNote: String? = null,
        timestampMs: Long = System.currentTimeMillis(),
        sessionId: Long = 1L,
        thinkingLog: String? = null,
        generatedImagePath: String? = null,
        imagePrompt: String? = null
    ): ChatMessageEntity

    fun updateMessageText(id: Long, newText: String)
    fun updateMessageThinking(id: Long, thinkingLog: String?) {}
    fun updateMessageGeneratedImage(id: Long, generatedImagePath: String?, newText: String? = null) {}
    fun updateMessageImagePrompt(id: Long, imagePrompt: String?) {}
    fun deleteMessagesFrom(sessionId: Long, fromIdInclusive: Long)
    fun clearSession(sessionId: Long)
    fun clearHistory()
}

/**
 * Strictly local on-device SQLite chat history store with:
 * - Multi-chat sessions + per-chat ChatMode (NORMAL / CODER / ADULT_ROLEPLAY)
 * - Persistent rolling context summary (for 20..50+ long chats)
 * - Persistent «Думает…» thinking logs on every assistant message
 * - Generated Perchance images & retry prompts
 * Safe backwards-compatible DB migration v1 -> v2 -> v3.
 */
class ChatDatabase(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION),
    ChatHistoryStore {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE_SESSIONS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITLE TEXT NOT NULL,
                $COL_CREATED_AT INTEGER NOT NULL,
                $COL_UPDATED_AT INTEGER NOT NULL,
                $COL_MODE TEXT NOT NULL DEFAULT 'NORMAL',
                $COL_CONTEXT_SUMMARY TEXT,
                $COL_SUMMARY_UPTO_ID INTEGER NOT NULL DEFAULT 0,
                $COL_IMAGE_SCENE_MEMORY TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE $TABLE_MESSAGES (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_SESSION_ID INTEGER NOT NULL DEFAULT 1,
                $COL_ROLE TEXT NOT NULL,
                $COL_TEXT TEXT NOT NULL,
                $COL_IMAGE_PATH TEXT,
                $COL_MATH_NOTE TEXT,
                $COL_TIMESTAMP INTEGER NOT NULL,
                $COL_THINKING_LOG TEXT,
                $COL_GENERATED_IMAGE_PATH TEXT,
                $COL_IMAGE_PROMPT TEXT
            )
            """.trimIndent()
        )
        val now = System.currentTimeMillis()
        db.execSQL(
            "INSERT INTO $TABLE_SESSIONS ($COL_ID, $COL_TITLE, $COL_CREATED_AT, $COL_UPDATED_AT, $COL_MODE, $COL_CONTEXT_SUMMARY, $COL_SUMMARY_UPTO_ID, $COL_IMAGE_SCENE_MEMORY) VALUES (1, 'Новый чат', $now, $now, 'NORMAL', '', 0, '')"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS $TABLE_SESSIONS (
                    $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COL_TITLE TEXT NOT NULL,
                    $COL_CREATED_AT INTEGER NOT NULL,
                    $COL_UPDATED_AT INTEGER NOT NULL
                )
                """.trimIndent()
            )
            val now = System.currentTimeMillis()
            db.execSQL(
                "INSERT OR IGNORE INTO $TABLE_SESSIONS ($COL_ID, $COL_TITLE, $COL_CREATED_AT, $COL_UPDATED_AT) VALUES (1, 'Основной чат', $now, $now)"
            )
            runCatching {
                db.execSQL("ALTER TABLE $TABLE_MESSAGES ADD COLUMN $COL_SESSION_ID INTEGER NOT NULL DEFAULT 1")
            }
        }
        if (oldVersion < 3) {
            runCatching { db.execSQL("ALTER TABLE $TABLE_SESSIONS ADD COLUMN $COL_MODE TEXT NOT NULL DEFAULT 'NORMAL'") }
            runCatching { db.execSQL("ALTER TABLE $TABLE_SESSIONS ADD COLUMN $COL_CONTEXT_SUMMARY TEXT") }
            runCatching { db.execSQL("ALTER TABLE $TABLE_SESSIONS ADD COLUMN $COL_SUMMARY_UPTO_ID INTEGER NOT NULL DEFAULT 0") }
            runCatching { db.execSQL("ALTER TABLE $TABLE_MESSAGES ADD COLUMN $COL_THINKING_LOG TEXT") }
            runCatching { db.execSQL("ALTER TABLE $TABLE_MESSAGES ADD COLUMN $COL_GENERATED_IMAGE_PATH TEXT") }
            runCatching { db.execSQL("ALTER TABLE $TABLE_MESSAGES ADD COLUMN $COL_IMAGE_PROMPT TEXT") }
        }
        if (oldVersion < 4) {
            runCatching { db.execSQL("ALTER TABLE $TABLE_SESSIONS ADD COLUMN $COL_IMAGE_SCENE_MEMORY TEXT NOT NULL DEFAULT ''") }
        }
    }

    override fun listSessions(): List<ChatSessionEntity> {
        val list = mutableListOf<ChatSessionEntity>()
        readableDatabase.query(
            TABLE_SESSIONS,
            arrayOf(COL_ID, COL_TITLE, COL_CREATED_AT, COL_UPDATED_AT, COL_MODE, COL_CONTEXT_SUMMARY, COL_SUMMARY_UPTO_ID, COL_IMAGE_SCENE_MEMORY),
            null, null, null, null,
            "$COL_UPDATED_AT DESC, $COL_ID DESC"
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    ChatSessionEntity(
                        id = c.getLong(0),
                        title = c.getString(1),
                        createdAtMs = c.getLong(2),
                        updatedAtMs = c.getLong(3),
                        mode = ChatMode.fromStored(c.getString(4)),
                        contextSummary = c.getString(5).orEmpty(),
                        summaryUpToMsgId = c.getLong(6),
                        imageSceneMemory = c.getString(7).orEmpty()
                    )
                )
            }
        }
        if (list.isEmpty()) {
            list.add(createSession("Новый чат", ChatMode.NORMAL))
        }
        return list
    }

    override fun createSession(title: String, mode: ChatMode): ChatSessionEntity {
        val now = System.currentTimeMillis()
        val cleanTitle = title.trim().take(48).ifBlank { "Новый чат" }
        val values = ContentValues().apply {
            put(COL_TITLE, cleanTitle)
            put(COL_CREATED_AT, now)
            put(COL_UPDATED_AT, now)
            put(COL_MODE, mode.name)
            put(COL_CONTEXT_SUMMARY, "")
            put(COL_SUMMARY_UPTO_ID, 0L)
            put(COL_IMAGE_SCENE_MEMORY, "")
        }
        val id = writableDatabase.insert(TABLE_SESSIONS, null, values)
        return ChatSessionEntity(
            id = id,
            title = cleanTitle,
            createdAtMs = now,
            updatedAtMs = now,
            mode = mode,
            contextSummary = "",
            summaryUpToMsgId = 0L,
            imageSceneMemory = ""
        )
    }

    override fun renameSession(sessionId: Long, newTitle: String) {
        val clean = newTitle.trim().take(48).ifBlank { "Новый чат" }
        val values = ContentValues().apply {
            put(COL_TITLE, clean)
            put(COL_UPDATED_AT, System.currentTimeMillis())
        }
        writableDatabase.update(TABLE_SESSIONS, values, "$COL_ID = ?", arrayOf(sessionId.toString()))
    }

    override fun updateSessionMode(sessionId: Long, mode: ChatMode) {
        val values = ContentValues().apply {
            put(COL_MODE, mode.name)
            put(COL_UPDATED_AT, System.currentTimeMillis())
        }
        writableDatabase.update(TABLE_SESSIONS, values, "$COL_ID = ?", arrayOf(sessionId.toString()))
    }

    override fun updateSessionSummary(sessionId: Long, summary: String, upToMessageId: Long) {
        val values = ContentValues().apply {
            put(COL_CONTEXT_SUMMARY, summary.take(2000))
            put(COL_SUMMARY_UPTO_ID, upToMessageId)
        }
        writableDatabase.update(TABLE_SESSIONS, values, "$COL_ID = ?", arrayOf(sessionId.toString()))
    }

    override fun updateSessionImageSceneMemory(sessionId: Long, sceneMemoryJson: String) {
        val values = ContentValues().apply {
            put(COL_IMAGE_SCENE_MEMORY, sceneMemoryJson.take(4000))
        }
        writableDatabase.update(TABLE_SESSIONS, values, "$COL_ID = ?", arrayOf(sessionId.toString()))
    }

    override fun deleteSession(sessionId: Long) {
        writableDatabase.delete(TABLE_MESSAGES, "$COL_SESSION_ID = ?", arrayOf(sessionId.toString()))
        writableDatabase.delete(TABLE_SESSIONS, "$COL_ID = ?", arrayOf(sessionId.toString()))
    }

    override fun getMessages(sessionId: Long): List<ChatMessageEntity> {
        val list = mutableListOf<ChatMessageEntity>()
        readableDatabase.query(
            TABLE_MESSAGES,
            arrayOf(
                COL_ID, COL_ROLE, COL_TEXT, COL_IMAGE_PATH, COL_MATH_NOTE,
                COL_TIMESTAMP, COL_SESSION_ID, COL_THINKING_LOG,
                COL_GENERATED_IMAGE_PATH, COL_IMAGE_PROMPT
            ),
            "$COL_SESSION_ID = ?",
            arrayOf(sessionId.toString()),
            null, null,
            "$COL_ID ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(
                    ChatMessageEntity(
                        id = cursor.getLong(0),
                        role = cursor.getString(1),
                        text = cursor.getString(2),
                        imagePath = cursor.getString(3),
                        mathVerifiedNote = cursor.getString(4),
                        timestampMs = cursor.getLong(5),
                        sessionId = cursor.getLong(6),
                        thinkingLog = cursor.getString(7),
                        generatedImagePath = cursor.getString(8),
                        imagePrompt = cursor.getString(9)
                    )
                )
            }
        }
        return list
    }

    override fun getAllMessages(): List<ChatMessageEntity> {
        val sessions = listSessions()
        return getMessages(sessions.first().id)
    }

    override fun insertMessage(
        role: String,
        text: String,
        imagePath: String?,
        mathVerifiedNote: String?,
        timestampMs: Long,
        sessionId: Long,
        thinkingLog: String?,
        generatedImagePath: String?,
        imagePrompt: String?
    ): ChatMessageEntity {
        val values = ContentValues().apply {
            put(COL_SESSION_ID, sessionId)
            put(COL_ROLE, role)
            put(COL_TEXT, text)
            put(COL_IMAGE_PATH, imagePath)
            put(COL_MATH_NOTE, mathVerifiedNote)
            put(COL_TIMESTAMP, timestampMs)
            put(COL_THINKING_LOG, thinkingLog)
            put(COL_GENERATED_IMAGE_PATH, generatedImagePath)
            put(COL_IMAGE_PROMPT, imagePrompt)
        }
        val id = writableDatabase.insert(TABLE_MESSAGES, null, values)
        val touch = ContentValues().apply { put(COL_UPDATED_AT, timestampMs) }
        writableDatabase.update(TABLE_SESSIONS, touch, "$COL_ID = ?", arrayOf(sessionId.toString()))
        return ChatMessageEntity(
            id = id,
            role = role,
            text = text,
            imagePath = imagePath,
            mathVerifiedNote = mathVerifiedNote,
            timestampMs = timestampMs,
            sessionId = sessionId,
            thinkingLog = thinkingLog,
            generatedImagePath = generatedImagePath,
            imagePrompt = imagePrompt
        )
    }

    override fun updateMessageText(id: Long, newText: String) {
        val values = ContentValues().apply { put(COL_TEXT, newText) }
        writableDatabase.update(TABLE_MESSAGES, values, "$COL_ID = ?", arrayOf(id.toString()))
    }

    override fun updateMessageThinking(id: Long, thinkingLog: String?) {
        val values = ContentValues().apply { put(COL_THINKING_LOG, thinkingLog) }
        writableDatabase.update(TABLE_MESSAGES, values, "$COL_ID = ?", arrayOf(id.toString()))
    }

    override fun updateMessageGeneratedImage(id: Long, generatedImagePath: String?, newText: String?) {
        val values = ContentValues().apply {
            put(COL_GENERATED_IMAGE_PATH, generatedImagePath)
            if (newText != null) put(COL_TEXT, newText)
        }
        writableDatabase.update(TABLE_MESSAGES, values, "$COL_ID = ?", arrayOf(id.toString()))
    }

    override fun updateMessageImagePrompt(id: Long, imagePrompt: String?) {
        val values = ContentValues().apply { put(COL_IMAGE_PROMPT, imagePrompt) }
        writableDatabase.update(TABLE_MESSAGES, values, "$COL_ID = ?", arrayOf(id.toString()))
    }

    override fun deleteMessagesFrom(sessionId: Long, fromIdInclusive: Long) {
        writableDatabase.delete(
            TABLE_MESSAGES,
            "$COL_SESSION_ID = ? AND $COL_ID >= ?",
            arrayOf(sessionId.toString(), fromIdInclusive.toString())
        )
        // Reset summary if messages before summary cutoff were deleted
        updateSessionSummary(sessionId, "", 0L)
    }

    override fun clearSession(sessionId: Long) {
        writableDatabase.delete(TABLE_MESSAGES, "$COL_SESSION_ID = ?", arrayOf(sessionId.toString()))
        updateSessionSummary(sessionId, "", 0L)
        updateSessionImageSceneMemory(sessionId, "")
    }

    override fun clearHistory() {
        writableDatabase.delete(TABLE_MESSAGES, null, null)
        writableDatabase.delete(TABLE_SESSIONS, null, null)
        createSession("Новый чат", ChatMode.NORMAL)
    }

    companion object {
        private const val DB_NAME = "jarvis_local_chat.db"
        private const val DB_VERSION = 4
        private const val TABLE_SESSIONS = "chat_sessions"
        private const val TABLE_MESSAGES = "chat_messages"
        private const val COL_ID = "id"
        private const val COL_TITLE = "title"
        private const val COL_CREATED_AT = "created_at"
        private const val COL_UPDATED_AT = "updated_at"
        private const val COL_MODE = "mode"
        private const val COL_CONTEXT_SUMMARY = "context_summary"
        private const val COL_SUMMARY_UPTO_ID = "summary_upto_msg_id"
        private const val COL_IMAGE_SCENE_MEMORY = "image_scene_memory"
        private const val COL_SESSION_ID = "session_id"
        private const val COL_ROLE = "role"
        private const val COL_TEXT = "text"
        private const val COL_IMAGE_PATH = "image_path"
        private const val COL_MATH_NOTE = "math_note"
        private const val COL_TIMESTAMP = "timestamp_ms"
        private const val COL_THINKING_LOG = "thinking_log"
        private const val COL_GENERATED_IMAGE_PATH = "generated_image_path"
        private const val COL_IMAGE_PROMPT = "image_prompt"
    }
}
