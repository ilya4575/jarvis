package ru.jarvis.assistant.feature.overlay

/**
 * Pure-Kotlin priority state engine & auto-start policy for Dynamic Island (A1 + B1–B5).
 * Strict priority hierarchy: CALL > NOTIFICATION > MUSIC > IDLE.
 * Never retains notification history — only the currently active live notification.
 */
enum class IslandPriorityMode {
    CALL,
    NOTIFICATION,
    MUSIC,
    IDLE
}

data class IslandNotificationActionInfo(
    val index: Int,
    val title: String,
    val hasRemoteInput: Boolean = false,
    val remoteInputHint: String? = null
)

data class IslandNotificationInfo(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val postedAtMs: Long,
    val actions: List<IslandNotificationActionInfo> = emptyList()
)

data class IslandMusicInfo(
    val packageName: String,
    val title: String,
    val artist: String,
    val isPlaying: Boolean,
    val hasArtwork: Boolean = false,
    val appLabel: String = "",
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val positionUpdatedAtElapsedMs: Long = 0L,
    val playbackSpeed: Float = 1f
)

data class IslandCallInfo(
    val callId: String,
    val callerName: String,
    val callerNumber: String = "",
    val isIncoming: Boolean,
    val isActive: Boolean,
    val isSpeakerOn: Boolean = false,
    val fromInCallService: Boolean = false,
    val notificationKey: String? = null,
    val acceptActionIndex: Int? = null,
    val declineActionIndex: Int? = null,
    val connectedAtMs: Long = 0L,
    val isMuted: Boolean = false
)

data class IslandPrioritySnapshot(
    val activeMode: IslandPriorityMode = IslandPriorityMode.IDLE,
    val activeCall: IslandCallInfo? = null,
    val activeNotification: IslandNotificationInfo? = null,
    val activeMusic: IslandMusicInfo? = null,
    val assistantQuickOpenLabel: String = "",
    val isOccupiedByLiveContent: Boolean = false
)

enum class IslandRestoreDecision {
    START_NOW,
    SKIP_DISABLED,
    MISSING_OVERLAY_PERMISSION
}

class IslandPriorityEngine {

    private var activeCall: IslandCallInfo? = null
    private var activeNotification: IslandNotificationInfo? = null
    private var activeMusic: IslandMusicInfo? = null

    fun setCall(call: IslandCallInfo?, assistantName: String): IslandPrioritySnapshot {
        activeCall = call
        return resolve(assistantName)
    }

    fun setNotification(notif: IslandNotificationInfo?, assistantName: String): IslandPrioritySnapshot {
        activeNotification = notif
        return resolve(assistantName)
    }

    fun dismissNotificationByKey(key: String, assistantName: String): IslandPrioritySnapshot {
        if (activeNotification?.key == key) {
            activeNotification = null
        }
        return resolve(assistantName)
    }

    fun clearActiveNotification(assistantName: String): IslandPrioritySnapshot {
        activeNotification = null
        return resolve(assistantName)
    }

    fun setMusic(music: IslandMusicInfo?, assistantName: String): IslandPrioritySnapshot {
        activeMusic = music
        return resolve(assistantName)
    }

    /**
     * Resolves the highest-priority content currently active:
     * CALL > NOTIFICATION > MUSIC > IDLE.
     * Automatically falls back to the next active layer when the top one finishes.
     */
    fun resolve(assistantName: String): IslandPrioritySnapshot {
        val mode = when {
            activeCall != null -> IslandPriorityMode.CALL
            activeNotification != null -> IslandPriorityMode.NOTIFICATION
            activeMusic != null -> IslandPriorityMode.MUSIC
            else -> IslandPriorityMode.IDLE
        }
        val occupied = mode != IslandPriorityMode.IDLE
        val cleanName = assistantName.trim().ifBlank { "Jarvis" }
        val openLabel = if (occupied) "Открыть «$cleanName»" else ""
        return IslandPrioritySnapshot(
            activeMode = mode,
            activeCall = activeCall,
            activeNotification = activeNotification,
            activeMusic = activeMusic,
            assistantQuickOpenLabel = openLabel,
            isOccupiedByLiveContent = occupied
        )
    }

    companion object {
        /** A1: Evaluates whether Dynamic Island should auto-start on launch / resume / boot. */
        fun evaluateAutoRestore(
            islandToggleEnabled: Boolean,
            hasOverlayPermission: Boolean
        ): IslandRestoreDecision = when {
            !islandToggleEnabled -> IslandRestoreDecision.SKIP_DISABLED
            !hasOverlayPermission -> IslandRestoreDecision.MISSING_OVERLAY_PERMISSION
            else -> IslandRestoreDecision.START_NOW
        }

        /** Formats elapsed track time like iOS 16 Lock Screen: `0:05`, `2:49`, `1:02:10`. */
        fun formatMediaDuration(ms: Long): String {
            val totalSec = (ms.coerceAtLeast(0L) / 1000L)
            val h = totalSec / 3600L
            val m = (totalSec % 3600L) / 60L
            val s = totalSec % 60L
            return if (h > 0L) {
                String.format("%d:%02d:%02d", h, m, s)
            } else {
                String.format("%d:%02d", m, s)
            }
        }

        /** Formats remaining track time like iOS 16 Lock Screen: `-0:56`. */
        fun formatMediaRemaining(positionMs: Long, durationMs: Long): String {
            if (durationMs <= 0L) return "-0:00"
            val rem = (durationMs - positionMs).coerceAtLeast(0L)
            return "-${formatMediaDuration(rem)}"
        }

        /** Formats active call duration like iPhone Dynamic Island: `00:05`, `01:42`, `1:05:10`. */
        fun formatCallTimer(connectedAtMs: Long, nowMs: Long = System.currentTimeMillis()): String {
            if (connectedAtMs <= 0L) return "00:00"
            val totalSec = ((nowMs - connectedAtMs).coerceAtLeast(0L) / 1000L)
            val h = totalSec / 3600L
            val m = (totalSec % 3600L) / 60L
            val s = totalSec % 60L
            return if (h > 0L) {
                String.format("%d:%02d:%02d", h, m, s)
            } else {
                String.format("%02d:%02d", m, s)
            }
        }
    }
}
