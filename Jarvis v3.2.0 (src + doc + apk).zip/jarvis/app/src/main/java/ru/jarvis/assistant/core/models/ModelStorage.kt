package ru.jarvis.assistant.core.models

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

enum class LocalArtifactStatus {
    MISSING,
    PARTIAL,
    INSTALLED_VERIFIED,
    CORRUPT_HASH_MISMATCH
}

/**
 * Manages local storage of downloaded AI models under app-private storage (`filesDir/models`).
 * Provides strict SHA-256 verification gating, zip-slip-safe archive extraction, and cleanup.
 */
class ModelStorage(private val modelsRootDir: File) {

    init {
        if (!modelsRootDir.exists()) {
            modelsRootDir.mkdirs()
        }
    }

    fun rootDir(): File = modelsRootDir

    fun finalFileFor(artifact: ModelArtifact): File = File(modelsRootDir, artifact.fileName)

    fun partFileFor(artifact: ModelArtifact): File = File(modelsRootDir, "${artifact.fileName}.part")

    fun verifiedMarkerFor(artifact: ModelArtifact): File = File(modelsRootDir, "${artifact.id}.sha256")

    fun extractedDirFor(artifact: ModelArtifact): File? {
        val dirName = artifact.extractedDirName ?: return null
        return File(modelsRootDir, dirName)
    }

    /** Fast status inspection for UI rendering without hashing multi-GB files on UI thread. */
    fun inspectQuickStatus(artifact: ModelArtifact): LocalArtifactStatus {
        val marker = verifiedMarkerFor(artifact)
        if (artifact.isZipArchive) {
            val dir = extractedDirFor(artifact)
            if (dir != null && dir.exists() && dir.isDirectory && markerMatches(marker, artifact.sha256)) {
                val hasContents = dir.listFiles()?.isNotEmpty() == true
                if (hasContents) return LocalArtifactStatus.INSTALLED_VERIFIED
            }
            if (partFileFor(artifact).exists()) return LocalArtifactStatus.PARTIAL
            return LocalArtifactStatus.MISSING
        } else {
            val f = finalFileFor(artifact)
            if (f.exists() && f.isFile) {
                return if (f.length() == artifact.sizeBytes && markerMatches(marker, artifact.sha256)) {
                    LocalArtifactStatus.INSTALLED_VERIFIED
                } else {
                    LocalArtifactStatus.CORRUPT_HASH_MISMATCH
                }
            }
            if (partFileFor(artifact).exists()) return LocalArtifactStatus.PARTIAL
            return LocalArtifactStatus.MISSING
        }
    }

    /**
     * Full cryptographic SHA-256 verification gate before passing a model file to native llama.cpp.
     * Refuses to return a path if SHA-256 does not match the pinned manifest.
     */
    fun verifyAndGetModelFile(artifact: ModelArtifact): Result<File> {
        require(!artifact.isZipArchive) { "Use verifyAndGetExtractedDir for archive artifacts" }
        val file = finalFileFor(artifact)
        val check = Sha256Verifier.verifyFile(file, artifact.sha256)
        return if (check.matches) {
            writeVerifiedMarker(artifact)
            Result.success(file)
        } else {
            verifiedMarkerFor(artifact).delete()
            Result.failure(
                SecurityException(
                    "Отказ загрузки ${artifact.displayName}: ${check.error}. " +
                        "Ожидалось ${check.expectedSha256.take(16)}…, получено ${check.actualSha256?.take(16) ?: "нет"}."
                )
            )
        }
    }

    fun verifyAndGetExtractedDir(artifact: ModelArtifact): Result<File> {
        require(artifact.isZipArchive) { "Not an archive artifact: ${artifact.id}" }
        val dir = extractedDirFor(artifact)
            ?: return Result.failure(IllegalStateException("Не указана директория распаковки"))
        val marker = verifiedMarkerFor(artifact)
        if (!dir.exists() || !dir.isDirectory || dir.listFiles().isNullOrEmpty()) {
            return Result.failure(IllegalStateException("Модель ${artifact.displayName} не установлена"))
        }
        if (!markerMatches(marker, artifact.sha256)) {
            return Result.failure(SecurityException("Нет подтверждённого SHA-256 маркера для ${artifact.displayName}"))
        }
        return Result.success(dir)
    }

    fun writeVerifiedMarker(artifact: ModelArtifact) {
        verifiedMarkerFor(artifact).writeText(artifact.sha256.lowercase())
    }

    fun deleteArtifact(artifact: ModelArtifact): Boolean {
        var deletedAny = false
        if (finalFileFor(artifact).delete()) deletedAny = true
        if (partFileFor(artifact).delete()) deletedAny = true
        if (verifiedMarkerFor(artifact).delete()) deletedAny = true
        extractedDirFor(artifact)?.let { dir ->
            if (dir.exists() && dir.deleteRecursively()) deletedAny = true
        }
        return deletedAny
    }

    fun deleteProfileSpecificModels(profile: ModelProfile): Boolean {
        var deletedAny = false
        if (deleteArtifact(profile.llm)) deletedAny = true
        if (deleteArtifact(profile.visionProjector)) deletedAny = true
        return deletedAny
    }

    fun installedDiskUsageBytes(): Long {
        if (!modelsRootDir.exists()) return 0L
        return modelsRootDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    fun availableSpaceBytes(): Long = modelsRootDir.usableSpace

    /**
     * Extracts a verified zip archive safely with Zip-Slip path traversal protection.
     */
    fun extractZipSafely(zipFile: File, targetParentDir: File) {
        val canonicalParent = targetParentDir.canonicalFile
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val entry = zis.nextEntry ?: break
                val outFile = File(canonicalParent, entry.name)
                val canonicalOut = outFile.canonicalFile
                if (!canonicalOut.path.startsWith(canonicalParent.path + File.separator) &&
                    canonicalOut.path != canonicalParent.path
                ) {
                    throw SecurityException("Обнаружена небезопасная запись в архиве (Zip-Slip): ${entry.name}")
                }
                if (entry.isDirectory) {
                    canonicalOut.mkdirs()
                } else {
                    canonicalOut.parentFile?.mkdirs()
                    FileOutputStream(canonicalOut).use { fos ->
                        while (true) {
                            val r = zis.read(buf)
                            if (r <= 0) break
                            fos.write(buf, 0, r)
                        }
                    }
                }
                zis.closeEntry()
            }
        }
    }

    private fun markerMatches(marker: File, expectedSha256: String): Boolean {
        if (!marker.exists() || !marker.isFile) return false
        return try {
            marker.readText().trim().equals(expectedSha256.trim(), ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }
}
