package ru.jarvis.assistant.ui.chat

import android.graphics.BitmapFactory
import android.graphics.Outline
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.PathInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import ru.jarvis.assistant.R
import ru.jarvis.assistant.data.db.ChatMessageEntity
import ru.jarvis.assistant.ui.common.RichTextFormatter
import java.io.File

interface ChatMessageListener {
    fun onCopy(message: ChatMessageEntity)
    fun onRegenerate(message: ChatMessageEntity)
    fun onSpeakTts(message: ChatMessageEntity)
    fun onShowContextMenu(message: ChatMessageEntity)
    fun onOpenGeneratedImage(path: String) {}
    fun onSaveGeneratedImage(path: String) {}
    fun onShareGeneratedImage(path: String) {}
}

class ChatAdapter(
    private val listener: ChatMessageListener
) : RecyclerView.Adapter<ChatAdapter.MessageViewHolder>() {

    private val items = mutableListOf<ChatMessageEntity>()
    private val animatedIds = HashSet<Long>()
    private val expandedThinkingIds = HashSet<Long>()
    private var initialBatchLoaded = false

    fun submitList(newItems: List<ChatMessageEntity>) {
        if (!initialBatchLoaded) {
            initialBatchLoaded = true
            newItems.forEach { animatedIds.add(it.id) }
        }
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val msg = items[position]
        holder.bind(msg)
        if (animatedIds.add(msg.id)) {
            holder.animateSmoothEntry()
        } else {
            holder.itemView.alpha = 1f
            holder.itemView.translationY = 0f
        }
    }

    override fun getItemCount(): Int = items.size

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val userContainer: LinearLayout = itemView.findViewById(R.id.msg_user_container)
        private val userImage: ImageView = itemView.findViewById(R.id.msg_user_image)
        private val userText: TextView = itemView.findViewById(R.id.msg_user_text)

        private val assistantContainer: LinearLayout = itemView.findViewById(R.id.msg_assistant_container)
        private val thinkingBlock: LinearLayout = itemView.findViewById(R.id.msg_thinking_block)
        private val thinkingHeader: LinearLayout = itemView.findViewById(R.id.msg_thinking_header)
        private val thinkingTitle: TextView = itemView.findViewById(R.id.msg_thinking_title)
        private val thinkingChevron: TextView = itemView.findViewById(R.id.msg_thinking_chevron)
        private val thinkingBody: TextView = itemView.findViewById(R.id.msg_thinking_body)

        private val mathBadge: TextView = itemView.findViewById(R.id.msg_math_badge)
        private val imageGenPlaceholder: ImageGenPlaceholderView = itemView.findViewById(R.id.msg_image_gen_placeholder)
        private val generatedImageContainer: LinearLayout = itemView.findViewById(R.id.msg_generated_image_container)
        private val generatedImage: ImageView = itemView.findViewById(R.id.msg_generated_image)
        private val imgOpenBtn: TextView = itemView.findViewById(R.id.msg_img_open_btn)
        private val imgSaveBtn: TextView = itemView.findViewById(R.id.msg_img_save_btn)
        private val imgShareBtn: TextView = itemView.findViewById(R.id.msg_img_share_btn)

        private val assistantText: TextView = itemView.findViewById(R.id.msg_assistant_text)
        private val assistantActions: LinearLayout = itemView.findViewById(R.id.msg_assistant_actions)
        private val copyBtn: ImageButton = itemView.findViewById(R.id.msg_action_copy)
        private val regenBtn: ImageButton = itemView.findViewById(R.id.msg_action_regen)
        private val ttsBtn: ImageButton = itemView.findViewById(R.id.msg_action_tts)
        private val moreBtn: ImageButton = itemView.findViewById(R.id.msg_action_more)

        init {
            val radius = 16f * itemView.resources.displayMetrics.density
            val clipRound = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
            userImage.outlineProvider = clipRound
            userImage.clipToOutline = true
            generatedImage.outlineProvider = clipRound
            generatedImage.clipToOutline = true
        }

        fun animateSmoothEntry() {
            val dy = 14f * itemView.resources.displayMetrics.density
            itemView.animate().cancel()
            itemView.alpha = 0f
            itemView.translationY = dy
            itemView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(240L)
                .setInterpolator(SMOOTH_INTERPOLATOR)
                .start()
        }

        fun bind(msg: ChatMessageEntity) {
            val isUser = msg.role == "user"
            if (isUser) {
                userContainer.visibility = View.VISIBLE
                assistantContainer.visibility = View.GONE
                userText.text = msg.text

                val imgPath = msg.imagePath
                if (!imgPath.isNullOrBlank() && File(imgPath).exists()) {
                    userImage.visibility = View.VISIBLE
                    val bmp = runCatching { BitmapFactory.decodeFile(imgPath) }.getOrNull()
                    if (bmp != null) userImage.setImageBitmap(bmp)
                    else userImage.visibility = View.GONE
                } else {
                    userImage.visibility = View.GONE
                }

                userText.setOnLongClickListener { listener.onShowContextMenu(msg); true }
                userContainer.setOnLongClickListener { listener.onShowContextMenu(msg); true }
            } else {
                userContainer.visibility = View.GONE
                assistantContainer.visibility = View.VISIBLE

                // C1: Collapsible «Думает…» block persisted on every assistant message
                val trace = msg.thinkingLog?.trim().orEmpty()
                if (trace.isNotEmpty()) {
                    thinkingBlock.visibility = View.VISIBLE
                    val expanded = expandedThinkingIds.contains(msg.id)
                    val isLive = msg.text == "…" || msg.isImageGenerating
                    thinkingTitle.text = if (isLive) "Думает…" else "Думает… (шаги и рассуждение)"
                    thinkingChevron.text = if (expanded) "Свернуть" else "Развернуть"
                    thinkingBody.visibility = if (expanded) View.VISIBLE else View.GONE
                    thinkingBody.text = trace
                    thinkingHeader.setOnClickListener {
                        if (expandedThinkingIds.contains(msg.id)) expandedThinkingIds.remove(msg.id)
                        else expandedThinkingIds.add(msg.id)
                        val nowExp = expandedThinkingIds.contains(msg.id)
                        thinkingChevron.text = if (nowExp) "Свернуть" else "Развернуть"
                        thinkingBody.visibility = if (nowExp) View.VISIBLE else View.GONE
                    }
                } else {
                    thinkingBlock.visibility = View.GONE
                }

                // A4: Animated placeholder OR completed Perchance image
                if (msg.isImageGenerating) {
                    imageGenPlaceholder.visibility = View.VISIBLE
                    imageGenPlaceholder.startAnimating()
                    generatedImageContainer.visibility = View.GONE
                } else {
                    imageGenPlaceholder.stopAnimating()
                    imageGenPlaceholder.visibility = View.GONE
                    val genPath = msg.generatedImagePath
                    if (!genPath.isNullOrBlank() && File(genPath).exists()) {
                        generatedImageContainer.visibility = View.VISIBLE
                        val bmp = runCatching { BitmapFactory.decodeFile(genPath) }.getOrNull()
                        if (bmp != null) generatedImage.setImageBitmap(bmp)
                        generatedImage.setOnClickListener { listener.onOpenGeneratedImage(genPath) }
                        imgOpenBtn.setOnClickListener { listener.onOpenGeneratedImage(genPath) }
                        imgSaveBtn.setOnClickListener { listener.onSaveGeneratedImage(genPath) }
                        imgShareBtn.setOnClickListener { listener.onShareGeneratedImage(genPath) }
                    } else {
                        generatedImageContainer.visibility = View.GONE
                    }
                }

                assistantText.text = RichTextFormatter.format(itemView.context, msg.text)

                if (!msg.mathVerifiedNote.isNullOrBlank()) {
                    mathBadge.visibility = View.VISIBLE
                    mathBadge.text = RichTextFormatter.badgeWithIcon(
                        itemView.context,
                        R.drawable.ic_status_check,
                        msg.mathVerifiedNote,
                        14
                    )
                } else {
                    mathBadge.visibility = View.GONE
                }

                val isStreamingPlaceholder = msg.text == "…" || msg.isImageGenerating
                assistantActions.visibility = if (isStreamingPlaceholder) View.GONE else View.VISIBLE

                copyBtn.setOnClickListener { listener.onCopy(msg) }
                regenBtn.setOnClickListener { listener.onRegenerate(msg) }
                ttsBtn.setOnClickListener { listener.onSpeakTts(msg) }
                moreBtn.setOnClickListener { listener.onShowContextMenu(msg) }
                assistantText.setOnLongClickListener { listener.onShowContextMenu(msg); true }
            }
        }
    }

    companion object {
        private val SMOOTH_INTERPOLATOR = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    }
}
