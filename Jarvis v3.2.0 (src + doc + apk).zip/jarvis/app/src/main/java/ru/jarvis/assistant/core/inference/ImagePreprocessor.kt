package ru.jarvis.assistant.core.inference

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Prepares a clean standard Baseline JPEG local copy of a gallery or camera photo for on-device vision inference.
 * Uses Android ImageDecoder (API 29+) for full HEIC/HEIF/WebP/PNG/JPEG + automatic EXIF orientation support,
 * with a resilient temp-file BitmapFactory fallback so ContentResolver streams never fail.
 * Never modifies the original user image.
 */
object ImagePreprocessor {
    private const val MAX_LONG_SIDE_PX = 896
    private const val JPEG_QUALITY = 88

    fun prepareLocalCopyForVision(context: Context, sourceUri: Uri): Result<File> {
        return try {
            val cacheDir = File(context.cacheDir, "vision_work").apply { mkdirs() }
            cleanupOldCacheFiles(cacheDir)

            // 1. Primary path: Android ImageDecoder (handles HEIC/HEIF, WebP, PNG, JPEG & EXIF rotation natively on API 29+)
            val decodedBitmap: Bitmap? = decodeViaImageDecoder(context, sourceUri)
                ?: decodeViaTempCopyFallback(context, sourceUri, cacheDir)

            if (decodedBitmap == null) {
                return Result.failure(IllegalArgumentException("Не удалось декодировать изображение (проверьте формат файла)."))
            }

            // Ensure software ARGB_8888 bitmap for clean JPEG encoding compatible with libmtmd's stb_image
            val softwareBmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                decodedBitmap.config == Bitmap.Config.HARDWARE
            ) {
                val copy = decodedBitmap.copy(Bitmap.Config.ARGB_8888, false)
                decodedBitmap.recycle()
                copy
            } else {
                decodedBitmap
            }

            val scaled = scaleIfNeeded(softwareBmp, MAX_LONG_SIDE_PX)
            if (scaled !== softwareBmp) {
                softwareBmp.recycle()
            }

            val outFile = File(cacheDir, "vision_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { fos ->
                val ok = scaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, fos)
                fos.flush()
                if (!ok || !outFile.exists() || outFile.length() == 0L) {
                    throw IllegalStateException("Не удалось сохранить локальную копию фото.")
                }
            }
            scaled.recycle()

            Result.success(outFile)
        } catch (oom: OutOfMemoryError) {
            Result.failure(IllegalStateException("Недостаточно ОЗУ для обработки фото.", oom))
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Ошибка подготовки фото: ${e.message ?: e.javaClass.simpleName}", e))
        }
    }

    /** Also allows preparing a local file path directly (e.g. from camera FileProvider output). */
    fun prepareLocalFileForVision(context: Context, sourceFile: File): Result<File> {
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            return Result.failure(IllegalArgumentException("Файл снимка с камеры пуст или не найден."))
        }
        return prepareLocalCopyForVision(context, Uri.fromFile(sourceFile))
    }

    private fun decodeViaImageDecoder(context: Context, sourceUri: Uri): Bitmap? {
        return try {
            val source = if (sourceUri.scheme == "file" && sourceUri.path != null) {
                ImageDecoder.createSource(File(sourceUri.path!!))
            } else {
                ImageDecoder.createSource(context.contentResolver, sourceUri)
            }
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width
                val h = info.size.height
                val longest = max(w, h)
                if (longest > MAX_LONG_SIDE_PX) {
                    val scale = MAX_LONG_SIDE_PX.toFloat() / longest.toFloat()
                    decoder.setTargetSize(
                        (w * scale).roundToInt().coerceAtLeast(1),
                        (h * scale).roundToInt().coerceAtLeast(1)
                    )
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun decodeViaTempCopyFallback(context: Context, sourceUri: Uri, cacheDir: File): Bitmap? {
        val rawTemp = File(cacheDir, "raw_import_${System.currentTimeMillis()}.tmp")
        return try {
            val copied = context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(rawTemp).use { out -> input.copyTo(out) }
            } ?: return null
            if (copied <= 0L) return null

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(rawTemp.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val sampleSize = computeInSampleSize(bounds.outWidth, bounds.outHeight, MAX_LONG_SIDE_PX)
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bmp = BitmapFactory.decodeFile(rawTemp.absolutePath, opts) ?: return null
            val orientation = try {
                ExifInterface(rawTemp.absolutePath).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
            } catch (_: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val rotated = applyOrientation(bmp, orientation)
            if (rotated !== bmp) bmp.recycle()
            rotated
        } catch (_: Throwable) {
            null
        } finally {
            rawTemp.delete()
        }
    }

    private fun computeInSampleSize(width: Int, height: Int, maxLongSide: Int): Int {
        var inSampleSize = 1
        var longest = max(width, height)
        while (longest / 2 >= maxLongSide) {
            inSampleSize *= 2
            longest /= 2
        }
        return inSampleSize
    }

    private fun applyOrientation(src: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            else -> return src
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    private fun scaleIfNeeded(src: Bitmap, maxLongSide: Int): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxLongSide) return src
        val scale = maxLongSide.toFloat() / longest.toFloat()
        val nw = (src.width * scale).roundToInt().coerceAtLeast(1)
        val nh = (src.height * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, nw, nh, true)
    }

    private fun cleanupOldCacheFiles(dir: File) {
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        for (i in min(files.size, 12) until files.size) {
            files[i].delete()
        }
    }
}
