package ru.jarvis.assistant.feature.overlay

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.audiofx.Visualizer
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock
import android.util.LruCache
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * B2 + Phase 9: Live Music controller, SoundCloud-ready 4-tier artwork loader, seek/volume control,
 * and real audio-reactive Visualizer feed for Dynamic Island.
 *
 * 4-tier artwork resolution chain (fixes SoundCloud, Yandex Music, VK, Spotify, YouTube Music):
 *   1) Embedded MediaMetadata Bitmap (ALBUM_ART / ART / DISPLAY_ICON)
 *   2) Cached/live media notification LargeIcon (JarvisNotificationListenerService)
 *   3) Async URI fetch from METADATA_KEY_ALBUM_ART_URI / ART_URI / DISPLAY_ICON_URI (http(s):// or content://)
 *   4) Player app launcher icon fallback so cover art is never blank
 */
class IslandMediaController(private val context: Context) {

    private val appContext = context.applicationContext
    private val sessionManager = appContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var artworkFetchJob: Job? = null
    private val uriBitmapCache = LruCache<String, Bitmap>(20)
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private var activeController: MediaController? = null
    private var visualizer: Visualizer? = null
    private var started = false
    @Volatile
    private var currentTrackKey: String = ""

    private val _musicInfo = MutableStateFlow<IslandMusicInfo?>(null)
    val musicInfo: StateFlow<IslandMusicInfo?> = _musicInfo.asStateFlow()

    private val _artworkBitmap = MutableStateFlow<Bitmap?>(null)
    val artworkBitmap: StateFlow<Bitmap?> = _artworkBitmap.asStateFlow()

    private val _audioBands = MutableStateFlow<FloatArray?>(null)
    val audioBands: StateFlow<FloatArray?> = _audioBands.asStateFlow()

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
        bindBestController(controllers.orEmpty())
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            refreshStateFromController()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            refreshStateFromController()
        }

        override fun onSessionDestroyed() {
            detachActiveController()
            refreshActiveSessions()
        }
    }

    fun start() {
        JarvisNotificationListenerService.onMediaArtworkUpdated = { pkg, bmp ->
            val current = _musicInfo.value
            if (current != null && current.packageName == pkg && !bmp.isRecycled) {
                val scaled = scaleArtwork(bmp, 256)
                if (scaled != null) {
                    _artworkBitmap.value = scaled
                    _musicInfo.value = current.copy(hasArtwork = true)
                }
            }
        }
        if (started) {
            refreshActiveSessions()
            return
        }
        if (!JarvisNotificationListenerService.isPermissionGranted(appContext)) {
            _musicInfo.value = null
            _artworkBitmap.value = null
            return
        }
        val mgr = sessionManager ?: return
        val cn = JarvisNotificationListenerService.componentName(appContext)
        runCatching {
            mgr.addOnActiveSessionsChangedListener(sessionsListener, cn)
            started = true
            refreshActiveSessions()
        }
    }

    fun refreshActiveSessions() {
        if (!JarvisNotificationListenerService.isPermissionGranted(appContext)) return
        val mgr = sessionManager ?: return
        val cn = JarvisNotificationListenerService.componentName(appContext)
        runCatching {
            val sessions = mgr.getActiveSessions(cn)
            bindBestController(sessions)
        }
    }

    private fun bindBestController(controllers: List<MediaController>) {
        // Prefer currently playing controller, else paused/buffering controller with metadata
        val best = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.firstOrNull {
            val st = it.playbackState?.state
            st == PlaybackState.STATE_PAUSED || st == PlaybackState.STATE_BUFFERING
        }

        if (best == null) {
            detachActiveController()
            currentTrackKey = ""
            _musicInfo.value = null
            _artworkBitmap.value = null
            stopVisualizer()
            return
        }

        if (activeController?.sessionToken != best.sessionToken) {
            detachActiveController()
            activeController = best
            runCatching { best.registerCallback(controllerCallback) }
        }
        refreshStateFromController()
    }

    private fun detachActiveController() {
        activeController?.let { ctrl ->
            runCatching { ctrl.unregisterCallback(controllerCallback) }
        }
        activeController = null
    }

    private fun refreshStateFromController() {
        val ctrl = activeController
        if (ctrl == null) {
            currentTrackKey = ""
            _musicInfo.value = null
            _artworkBitmap.value = null
            stopVisualizer()
            return
        }
        val pb = ctrl.playbackState
        val pbState = pb?.state ?: PlaybackState.STATE_NONE
        val isPlaying = pbState == PlaybackState.STATE_PLAYING
        val isRelevant = isPlaying || pbState == PlaybackState.STATE_PAUSED || pbState == PlaybackState.STATE_BUFFERING
        if (!isRelevant) {
            currentTrackKey = ""
            _musicInfo.value = null
            _artworkBitmap.value = null
            stopVisualizer()
            return
        }

        val pkg = ctrl.packageName.orEmpty()
        val appLabel = resolveAppLabel(pkg)
        val meta = ctrl.metadata
        val title = (meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE))?.trim().orEmpty()
        val artist = (meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE))?.trim().orEmpty()
        val durationMs = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L) ?: 0L
        val posMs = pb?.position?.coerceAtLeast(0L) ?: 0L
        val updatedAtElapsed = pb?.lastPositionUpdateTime?.takeIf { it > 0L } ?: SystemClock.elapsedRealtime()
        val speed = pb?.playbackSpeed?.takeIf { it > 0f } ?: if (isPlaying) 1f else 0f

        val trackKey = "$pkg|$title|$artist|$durationMs"
        currentTrackKey = trackKey

        // Tier 1: Embedded MediaMetadata Bitmap
        val embeddedArt = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        // Tier 3 URI candidate (SoundCloud puts https://i1.sndcdn.com/... or content:// here!)
        val artUri = (meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ART_URI)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI))?.trim().orEmpty()

        val immediateBmp: Bitmap? = when {
            embeddedArt != null && !embeddedArt.isRecycled -> scaleArtwork(embeddedArt, 256)
            artUri.isNotEmpty() && uriBitmapCache.get(artUri) != null -> uriBitmapCache.get(artUri)
            else -> JarvisNotificationListenerService.getCachedMediaArtwork(pkg)?.let { scaleArtwork(it, 256) }
        }

        // Tier 4 immediate placeholder (app icon) while URI downloads if nothing else is cached yet
        val resolvedArt = immediateBmp ?: loadAppIconBitmap(pkg)
        _artworkBitmap.value = resolvedArt

        _musicInfo.value = IslandMusicInfo(
            packageName = pkg,
            title = title.ifBlank { "Музыка" },
            artist = artist,
            isPlaying = isPlaying,
            hasArtwork = resolvedArt != null,
            appLabel = appLabel,
            durationMs = durationMs,
            positionMs = posMs,
            positionUpdatedAtElapsedMs = updatedAtElapsed,
            playbackSpeed = speed
        )

        // If no embedded bitmap AND we have an art URI not yet cached, fetch it asynchronously!
        if (embeddedArt == null && artUri.isNotEmpty() && uriBitmapCache.get(artUri) == null) {
            fetchArtworkFromUriAsync(artUri, trackKey)
        }

        if (isPlaying) {
            startVisualizerSafely()
        } else {
            stopVisualizer()
        }
    }

    private fun fetchArtworkFromUriAsync(uriStr: String, expectedTrackKey: String) {
        artworkFetchJob?.cancel()
        artworkFetchJob = ioScope.launch {
            val fetched = runCatching { loadBitmapFromUri(uriStr) }.getOrNull() ?: return@launch
            val scaled = scaleArtwork(fetched, 256) ?: return@launch
            uriBitmapCache.put(uriStr, scaled)
            if (currentTrackKey == expectedTrackKey) {
                _artworkBitmap.value = scaled
                _musicInfo.value = _musicInfo.value?.copy(hasArtwork = true)
            }
        }
    }

    private fun loadBitmapFromUri(uriStr: String): Bitmap? {
        return when {
            uriStr.startsWith("http://", ignoreCase = true) || uriStr.startsWith("https://", ignoreCase = true) -> {
                // Upgrade http -> https for SoundCloud / CDN because AndroidManifest blocks cleartext HTTP
                val secureUrl = if (uriStr.startsWith("http://", ignoreCase = true)) {
                    "https://" + uriStr.removePrefix("http://")
                } else uriStr
                val req = Request.Builder()
                    .url(secureUrl)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36")
                    .get()
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return null
                    val bytes = resp.body?.bytes() ?: return null
                    if (bytes.size < 128) return null
                    decodeSampledBitmap(bytes, 256)
                }
            }
            uriStr.startsWith("content://", ignoreCase = true) || uriStr.startsWith("file://", ignoreCase = true) -> {
                appContext.contentResolver.openInputStream(Uri.parse(uriStr))?.use { input ->
                    val bytes = input.readBytes()
                    decodeSampledBitmap(bytes, 256)
                }
            }
            else -> null
        }
    }

    private fun decodeSampledBitmap(bytes: ByteArray, maxDim: Int): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
        var sample = 1
        while (opts.outWidth / sample > maxDim * 2 || opts.outHeight / sample > maxDim * 2) {
            sample *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)
    }

    private fun scaleArtwork(src: Bitmap, maxDim: Int): Bitmap? = runCatching {
        if (src.isRecycled) return@runCatching null
        val w = src.width.coerceAtLeast(1)
        val h = src.height.coerceAtLeast(1)
        if (w <= maxDim && h <= maxDim) return@runCatching src
        val ratio = maxDim.toFloat() / maxOf(w, h).toFloat()
        Bitmap.createScaledBitmap(
            src,
            (w * ratio).roundToInt().coerceAtLeast(1),
            (h * ratio).roundToInt().coerceAtLeast(1),
            true
        )
    }.getOrNull()

    private fun resolveAppLabel(pkg: String): String {
        if (pkg.isBlank()) return "Музыка"
        return runCatching {
            val ai = appContext.packageManager.getApplicationInfo(pkg, 0)
            appContext.packageManager.getApplicationLabel(ai).toString().trim().ifBlank { pkg }
        }.getOrDefault(pkg)
    }

    private fun loadAppIconBitmap(pkg: String): Bitmap? {
        if (pkg.isBlank()) return null
        return runCatching {
            val d: Drawable = appContext.packageManager.getApplicationIcon(pkg)
            if (d is BitmapDrawable && d.bitmap != null && !d.bitmap.isRecycled) {
                scaleArtwork(d.bitmap, 128)
            } else {
                val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                d.setBounds(0, 0, 128, 128)
                d.draw(c)
                bmp
            }
        }.getOrNull()
    }

    /** Computes smoothly interpolated current playback position (ms) for the iOS seek bar. */
    fun getInterpolatedPositionMs(): Long {
        val info = _musicInfo.value ?: return 0L
        val base = info.positionMs.coerceAtLeast(0L)
        if (!info.isPlaying || info.positionUpdatedAtElapsedMs <= 0L) {
            return if (info.durationMs > 0L) base.coerceAtMost(info.durationMs) else base
        }
        val delta = (SystemClock.elapsedRealtime() - info.positionUpdatedAtElapsedMs).coerceAtLeast(0L)
        val computed = base + (delta * info.playbackSpeed).toLong()
        return if (info.durationMs > 0L) computed.coerceIn(0L, info.durationMs) else computed.coerceAtLeast(0L)
    }

    fun seekTo(positionMs: Long) {
        val clamped = positionMs.coerceAtLeast(0L)
        runCatching { activeController?.transportControls?.seekTo(clamped) }
        _musicInfo.value = _musicInfo.value?.copy(
            positionMs = clamped,
            positionUpdatedAtElapsedMs = SystemClock.elapsedRealtime()
        )
    }

    fun getMediaVolumePercent(): Int {
        val am = audioManager ?: return 50
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC).coerceIn(0, max)
        return ((cur * 100f) / max).roundToInt().coerceIn(0, 100)
    }

    fun setMediaVolumePercent(percent: Int) {
        val am = audioManager ?: return
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val target = ((percent.coerceIn(0, 100) * max) / 100f).roundToInt().coerceIn(0, max)
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0) }
    }

    fun togglePlayPause() {
        val ctrl = activeController ?: return
        val tc = ctrl.transportControls
        val isPlaying = ctrl.playbackState?.state == PlaybackState.STATE_PLAYING
        runCatching {
            if (isPlaying) tc.pause() else tc.play()
        }
    }

    fun skipToNext() {
        runCatching { activeController?.transportControls?.skipToNext() }
    }

    fun skipToPrevious() {
        runCatching { activeController?.transportControls?.skipToPrevious() }
    }

    fun openPlayerApp() {
        val pkg = activeController?.packageName ?: _musicInfo.value?.packageName ?: return
        if (pkg.isBlank()) return
        runCatching {
            val intent = appContext.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                appContext.startActivity(intent)
            }
        }
    }

    /**
     * Real audio-reactive FFT capture via Android Visualizer(0).
     * Strictly guarded: never crashes if RECORD_AUDIO is absent or if OEM blocks mix-0 Visualizer.
     */
    private fun startVisualizerSafely() {
        if (visualizer != null) return
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            _audioBands.value = null
            return
        }
        try {
            val vis = Visualizer(0)
            val captureSize = Visualizer.getCaptureSizeRange().firstOrNull()?.coerceAtLeast(128) ?: 128
            vis.captureSize = captureSize
            vis.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) = Unit

                    override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        if (fft == null || fft.size < 16) return
                        val bands = FloatArray(5)
                        val binsPerBand = ((fft.size / 2) / 5).coerceAtLeast(1)
                        for (b in 0 until 5) {
                            var energy = 0.0
                            val start = 2 + b * binsPerBand * 2
                            val end = (start + binsPerBand * 2).coerceAtMost(fft.size - 1)
                            var idx = start
                            while (idx + 1 < end) {
                                val re = fft[idx].toDouble()
                                val im = fft[idx + 1].toDouble()
                                energy += hypot(re, im)
                                idx += 2
                            }
                            val avg = energy / binsPerBand.coerceAtLeast(1)
                            bands[b] = (avg / 48.0).toFloat().coerceIn(0.18f, 1.0f)
                        }
                        _audioBands.value = bands
                    }
                },
                Visualizer.getMaxCaptureRate() / 2,
                false,
                true
            )
            vis.enabled = true
            visualizer = vis
        } catch (_: Throwable) {
            // Gracefully fall back to synthetic music animation inside IslandWaveformView
            stopVisualizer()
        }
    }

    private fun stopVisualizer() {
        visualizer?.let { v ->
            runCatching { v.enabled = false }
            runCatching { v.release() }
        }
        visualizer = null
        _audioBands.value = null
    }

    fun stop() {
        JarvisNotificationListenerService.onMediaArtworkUpdated = null
        artworkFetchJob?.cancel()
        ioScope.cancel()
        stopVisualizer()
        detachActiveController()
        if (started) {
            runCatching { sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener) }
            started = false
        }
        _musicInfo.value = null
        _artworkBitmap.value = null
    }
}
