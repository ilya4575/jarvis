package ru.jarvis.assistant.feature.voice

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import java.io.File
import java.io.FileOutputStream

data class VoiceSampleSaveResult(
    val file: File,
    val displayName: String,
    val durationSec: Int,
    val warningRu: String? = null
)

/**
 * Manages a local reference voice sample (MP3/WAV/M4A/OGG, 5–30s recommended) saved privately
 * on-device for zero-shot voice cloning (e.g. Kurumi Tokisaki via Fish Audio or custom TTS server).
 */
class VoiceSampleManager(
    private val context: Context,
    private val prefs: JarvisPreferences
) {
    private val sampleDir: File = File(context.filesDir, "voice_samples").apply { mkdirs() }

    fun saveVoiceSample(uri: Uri): Result<VoiceSampleSaveResult> {
        return try {
            val (rawName, _) = queryNameAndSize(uri)
            val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
            val ext = resolveExtension(rawName, mime)
            val displayName = rawName?.takeIf { it.isNotBlank() } ?: "voice_sample.$ext"

            val temp = File(sampleDir, "sample_tmp.$ext")
            var totalBytes = 0L
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val r = input.read(buf)
                        if (r <= 0) break
                        totalBytes += r
                        if (totalBytes > MAX_SAMPLE_BYTES) {
                            temp.delete()
                            return Result.failure(
                                IllegalArgumentException("Аудиофайл слишком большой (максимум 15 МБ). Оптимально 10–20 секунд голоса.")
                            )
                        }
                        output.write(buf, 0, r)
                    }
                }
            } ?: return Result.failure(IllegalArgumentException("Не удалось открыть выбранный аудиофайл."))

            if (totalBytes < 1024L) {
                temp.delete()
                return Result.failure(IllegalArgumentException("Аудиофайл пустой или повреждён."))
            }

            var durationMs = 0L
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(temp.absolutePath)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
            } catch (_: Throwable) {
                // Keep going even if container metadata wasn't parsed
            } finally {
                runCatching { retriever.release() }
            }

            // Clean older samples so only 1 active sample resides on disk
            sampleDir.listFiles()?.forEach { old ->
                if (old.absolutePath != temp.absolutePath) old.delete()
            }
            val dest = File(sampleDir, "custom_voice_sample.$ext")
            if (dest.exists()) dest.delete()
            temp.renameTo(dest)

            prefs.customVoiceSamplePath = dest.absolutePath
            prefs.customVoiceSampleName = displayName

            val sec = (durationMs / 1000L).toInt()
            val warning = when {
                sec in 1..4 -> "Сэмпл короче 5 сек — для лучшего сходства голоса лучше 10–20 сек чистой речи без музыки."
                sec > 45 -> "Сэмпл длиннее 45 сек ($sec с) — для быстрого клонирования лучше обрезать до 10–25 сек."
                else -> null
            }

            Result.success(
                VoiceSampleSaveResult(
                    file = dest,
                    displayName = displayName,
                    durationSec = sec,
                    warningRu = warning
                )
            )
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    fun getVoiceSampleFile(): File? =
        prefs.customVoiceSamplePath?.let { File(it) }?.takeIf { it.exists() && it.length() > 0L }

    fun clearVoiceSample() {
        getVoiceSampleFile()?.delete()
        prefs.customVoiceSamplePath = null
        prefs.customVoiceSampleName = ""
    }

    private fun resolveExtension(name: String?, mime: String): String {
        val fromName = name?.substringAfterLast('.', "")?.lowercase().orEmpty()
        if (fromName in setOf("mp3", "wav", "m4a", "ogg", "opus", "flac")) return fromName
        return when {
            mime.contains("wav") -> "wav"
            mime.contains("ogg") || mime.contains("opus") -> "ogg"
            mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac") -> "m4a"
            mime.contains("flac") -> "flac"
            else -> "mp3"
        }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String?, Long> {
        var name: String? = null
        var size = -1L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        return name to size
    }

    companion object {
        const val MAX_SAMPLE_BYTES = 15L * 1024L * 1024L
    }
}
