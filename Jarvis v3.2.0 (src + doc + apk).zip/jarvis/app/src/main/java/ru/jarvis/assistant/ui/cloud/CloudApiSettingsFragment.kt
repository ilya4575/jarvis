package ru.jarvis.assistant.ui.cloud

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.cloud.CloudProvider
import ru.jarvis.assistant.core.cloud.CustomApiCompatibility
import ru.jarvis.assistant.core.cloud.CustomProviderConfig
import ru.jarvis.assistant.core.cloud.CustomProviderManager
import ru.jarvis.assistant.core.cloud.PuterApiClient
import ru.jarvis.assistant.core.cloud.VoiceSttMode
import ru.jarvis.assistant.feature.voice.TtsEngineMode
import ru.jarvis.assistant.ui.MainActivity
import java.util.UUID

class CloudApiSettingsFragment : Fragment() {

    private lateinit var chatProviderSpinner: Spinner
    private lateinit var islandProviderSpinner: Spinner
    private lateinit var sttModeSpinner: Spinner
    private lateinit var ttsModeSpinner: Spinner
    private lateinit var grokTtsKeyEdit: EditText
    private lateinit var grokTtsVoiceEdit: EditText
    private lateinit var autoFallbackSwitch: SwitchMaterial
    private lateinit var contextLimitLabel: TextView
    private lateinit var contextLimitSeek: SeekBar

    // Puter API UI
    private lateinit var puterOpenDashboardBtn: MaterialButton
    private lateinit var puterTokenEdit: EditText
    private lateinit var puterSmartSwitch: SwitchMaterial
    private lateinit var puterEconModelEdit: EditText
    private lateinit var puterSmartModelEdit: EditText
    private lateinit var puterManualModelEdit: EditText
    private lateinit var puterUsageStatus: TextView
    private lateinit var puterSaveBtn: MaterialButton
    private lateinit var puterTestBtn: MaterialButton

    // Perchance UI
    private lateinit var perchanceStatus: TextView
    private lateinit var perchanceEnableSwitch: SwitchMaterial
    private lateinit var perchanceTextUrlEdit: EditText
    private lateinit var perchanceImageUrlEdit: EditText
    private lateinit var perchanceSaveUrlsBtn: MaterialButton
    private lateinit var perchanceVerifyBtn: MaterialButton
    private lateinit var perchanceRecheckBtn: MaterialButton
    private lateinit var perchanceResetBtn: MaterialButton

    // Gemini / Groq / OpenRouter
    private lateinit var geminiKeyEdit: EditText
    private lateinit var geminiModelEdit: EditText
    private lateinit var geminiTestBtn: MaterialButton
    private lateinit var groqKeyEdit: EditText
    private lateinit var groqModelEdit: EditText
    private lateinit var groqTestBtn: MaterialButton
    private lateinit var openRouterKeyEdit: EditText
    private lateinit var openRouterModelEdit: EditText
    private lateinit var openRouterTestBtn: MaterialButton

    // Custom 1..10
    private lateinit var customHeader: TextView
    private lateinit var customAddBtn: MaterialButton
    private lateinit var customListContainer: LinearLayout
    private lateinit var testOutput: TextView

    private val providerOptions = listOf(
        CloudProvider.GEMINI,
        CloudProvider.GROQ,
        CloudProvider.OPENROUTER,
        CloudProvider.CUSTOM_API,
        CloudProvider.PERCHANCE,
        CloudProvider.PUTER,
        CloudProvider.LOCAL
    )

    private val sttOptions = listOf(
        VoiceSttMode.ANDROID_NATIVE,
        VoiceSttMode.GROQ_FIRST,
        VoiceSttMode.VOSK_ONLY
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_cloud_api, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = JarvisApplication.instance

        view.findViewById<ImageButton>(R.id.cloud_back_btn).setOnClickListener {
            (activity as? MainActivity)?.popToChat()
        }

        chatProviderSpinner = view.findViewById(R.id.cloud_chat_provider_spinner)
        islandProviderSpinner = view.findViewById(R.id.cloud_island_provider_spinner)
        sttModeSpinner = view.findViewById(R.id.cloud_stt_mode_spinner)
        ttsModeSpinner = view.findViewById(R.id.cloud_tts_mode_spinner)
        grokTtsKeyEdit = view.findViewById(R.id.cloud_grok_tts_key_edit)
        grokTtsVoiceEdit = view.findViewById(R.id.cloud_grok_tts_voice_edit)
        autoFallbackSwitch = view.findViewById(R.id.cloud_auto_fallback_switch)
        contextLimitLabel = view.findViewById(R.id.cloud_context_limit_label)
        contextLimitSeek = view.findViewById(R.id.cloud_context_limit_seek)

        puterOpenDashboardBtn = view.findViewById(R.id.cloud_puter_open_dashboard_btn)
        puterTokenEdit = view.findViewById(R.id.cloud_puter_token_edit)
        puterSmartSwitch = view.findViewById(R.id.cloud_puter_smart_switch)
        puterEconModelEdit = view.findViewById(R.id.cloud_puter_econ_model_edit)
        puterSmartModelEdit = view.findViewById(R.id.cloud_puter_smart_model_edit)
        puterManualModelEdit = view.findViewById(R.id.cloud_puter_manual_model_edit)
        puterUsageStatus = view.findViewById(R.id.cloud_puter_usage_status)
        puterSaveBtn = view.findViewById(R.id.cloud_puter_save_btn)
        puterTestBtn = view.findViewById(R.id.cloud_puter_test_btn)

        perchanceStatus = view.findViewById(R.id.cloud_perchance_status)
        perchanceEnableSwitch = view.findViewById(R.id.cloud_perchance_enable_switch)
        perchanceTextUrlEdit = view.findViewById(R.id.cloud_perchance_text_url_edit)
        perchanceImageUrlEdit = view.findViewById(R.id.cloud_perchance_image_url_edit)
        perchanceSaveUrlsBtn = view.findViewById(R.id.cloud_perchance_save_urls_btn)
        perchanceVerifyBtn = view.findViewById(R.id.cloud_perchance_verify_btn)
        perchanceRecheckBtn = view.findViewById(R.id.cloud_perchance_recheck_btn)
        perchanceResetBtn = view.findViewById(R.id.cloud_perchance_reset_btn)

        geminiKeyEdit = view.findViewById(R.id.cloud_gemini_key_edit)
        geminiModelEdit = view.findViewById(R.id.cloud_gemini_model_edit)
        geminiTestBtn = view.findViewById(R.id.cloud_gemini_test_btn)
        groqKeyEdit = view.findViewById(R.id.cloud_groq_key_edit)
        groqModelEdit = view.findViewById(R.id.cloud_groq_model_edit)
        groqTestBtn = view.findViewById(R.id.cloud_groq_test_btn)
        openRouterKeyEdit = view.findViewById(R.id.cloud_openrouter_key_edit)
        openRouterModelEdit = view.findViewById(R.id.cloud_openrouter_model_edit)
        openRouterTestBtn = view.findViewById(R.id.cloud_openrouter_test_btn)

        customHeader = view.findViewById(R.id.cloud_custom_header)
        customAddBtn = view.findViewById(R.id.cloud_custom_add_btn)
        customListContainer = view.findViewById(R.id.cloud_custom_list_container)
        testOutput = view.findViewById(R.id.cloud_test_output)

        setupMainSpinnersAndContext(view)
        setupPuterSection(view)
        setupPerchanceSection()
        setupCoreProviders()
        setupCustomProvidersSection()

        viewLifecycleOwner.lifecycleScope.launch {
            app.perchanceBridge.bridgeState.collectLatest { st ->
                perchanceStatus.text = "Статус: ${st.verifyStatus.labelRu} — ${st.statusRu}"
            }
        }
    }

    private fun setupMainSpinnersAndContext(view: View) {
        val app = JarvisApplication.instance
        val prefs = app.prefs

        val provLabels = providerOptions.map { it.fullLabelRu }
        val provAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, provLabels)
        chatProviderSpinner.adapter = provAdapter
        islandProviderSpinner.adapter = provAdapter

        chatProviderSpinner.setSelection(providerOptions.indexOf(prefs.chatPrimaryProvider).coerceAtLeast(0))
        islandProviderSpinner.setSelection(providerOptions.indexOf(prefs.islandPrimaryProvider).coerceAtLeast(0))

        chatProviderSpinner.onItemSelectedListener = simpleSelectListener { pos ->
            prefs.chatPrimaryProvider = providerOptions[pos]
            app.inferenceEngine.refreshEffectiveState()
        }
        islandProviderSpinner.onItemSelectedListener = simpleSelectListener { pos ->
            prefs.islandPrimaryProvider = providerOptions[pos]
            app.inferenceEngine.refreshEffectiveState()
        }

        val sttLabels = sttOptions.map { it.labelRu }
        sttModeSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, sttLabels)
        sttModeSpinner.setSelection(sttOptions.indexOf(prefs.voiceSttMode).coerceAtLeast(0))
        sttModeSpinner.onItemSelectedListener = simpleSelectListener { pos ->
            prefs.voiceSttMode = sttOptions[pos]
        }

        // Compact API-page selector requested by the user: device-local TTS or xAI/Grok TTS.
        val ttsOptions = listOf(TtsEngineMode.SYSTEM_ANDROID, TtsEngineMode.GROK_TTS)
        ttsModeSpinner.adapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_dropdown_item,
            listOf("Локально на телефоне (без API)", "Grok TTS / xAI (по API-ключу)")
        )
        ttsModeSpinner.setSelection(if (prefs.ttsEngineMode == TtsEngineMode.GROK_TTS) 1 else 0)
        var ttsModeTouchedByUser = false
        ttsModeSpinner.setOnTouchListener { _, event ->
            if (event.actionMasked == android.view.MotionEvent.ACTION_DOWN) ttsModeTouchedByUser = true
            false
        }
        ttsModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, child: View?, position: Int, id: Long) {
                if (ttsModeTouchedByUser) {
                    prefs.ttsEngineMode = ttsOptions[position]
                    ttsModeTouchedByUser = false
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        grokTtsKeyEdit.setText(prefs.grokTtsApiKey)
        grokTtsVoiceEdit.setText(prefs.grokTtsVoiceId)
        view.findViewById<MaterialButton>(R.id.cloud_grok_tts_save_btn).setOnClickListener {
            prefs.grokTtsApiKey = grokTtsKeyEdit.text.toString().trim()
            prefs.grokTtsVoiceId = grokTtsVoiceEdit.text.toString().trim().ifBlank { "eve" }
            Toast.makeText(requireContext(), "Настройки Grok TTS сохранены в зашифрованном хранилище.", Toast.LENGTH_SHORT).show()
        }

        autoFallbackSwitch.isChecked = prefs.autoFallbackEnabled
        autoFallbackSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.autoFallbackEnabled = checked
        }

        val curCtx = prefs.contextWindowMessages.coerceIn(20, 50)
        contextLimitSeek.max = 30
        contextLimitSeek.progress = curCtx - 20
        contextLimitLabel.text = "Глубина контекста чата: $curCtx сообщений (диапазон 20–50)"
        contextLimitSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val n = (20 + progress).coerceIn(20, 50)
                prefs.contextWindowMessages = n
                contextLimitLabel.text = "Глубина контекста чата: $n сообщений (диапазон 20–50)"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun setupPuterSection(view: View) {
        val app = JarvisApplication.instance
        val prefs = app.prefs

        puterTokenEdit.setText(prefs.puterAuthToken)
        puterSmartSwitch.isChecked = prefs.puterSmartMode
        puterEconModelEdit.setText(prefs.puterModel)
        puterSmartModelEdit.setText(prefs.puterSmartModel)
        puterManualModelEdit.setText(prefs.puterManualModelId)

        val cachedUsage = prefs.puterLastUsageLabelRu
        if (cachedUsage.isNotBlank()) puterUsageStatus.text = cachedUsage

        puterOpenDashboardBtn.setOnClickListener {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PuterApiClient.DASHBOARD_ACCOUNT_URL)))
            }.onFailure {
                Toast.makeText(requireContext(), "Откройте вручную: ${PuterApiClient.DASHBOARD_ACCOUNT_URL}", Toast.LENGTH_LONG).show()
            }
        }

        puterSmartSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.puterSmartMode = checked
            app.inferenceEngine.refreshEffectiveState()
        }

        view.findViewById<View>(R.id.cloud_puter_preset_nano54).setOnClickListener {
            puterEconModelEdit.setText(PuterApiClient.DEFAULT_ECON_MODEL)
            puterManualModelEdit.setText("")
            puterSmartSwitch.isChecked = false
            savePuterFields()
            Toast.makeText(requireContext(), "Выбрана эконом-модель: ${PuterApiClient.DEFAULT_ECON_MODEL}", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<View>(R.id.cloud_puter_preset_nano5).setOnClickListener {
            puterEconModelEdit.setText(PuterApiClient.ALT_ECON_MODEL)
            puterManualModelEdit.setText("")
            puterSmartSwitch.isChecked = false
            savePuterFields()
            Toast.makeText(requireContext(), "Выбрана эконом-модель: ${PuterApiClient.ALT_ECON_MODEL}", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<View>(R.id.cloud_puter_preset_claude).setOnClickListener {
            puterSmartModelEdit.setText(PuterApiClient.DEFAULT_SMART_MODEL)
            puterManualModelEdit.setText("")
            puterSmartSwitch.isChecked = true
            savePuterFields()
            Toast.makeText(requireContext(), "Выбрана умная модель: ${PuterApiClient.DEFAULT_SMART_MODEL}", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<View>(R.id.cloud_puter_preset_gemini).setOnClickListener {
            puterSmartModelEdit.setText(PuterApiClient.ALT_SMART_MODEL)
            puterManualModelEdit.setText("")
            puterSmartSwitch.isChecked = true
            savePuterFields()
            Toast.makeText(requireContext(), "Выбрана умная модель: ${PuterApiClient.ALT_SMART_MODEL}", Toast.LENGTH_SHORT).show()
        }
        view.findViewById<View>(R.id.cloud_puter_preset_free).setOnClickListener {
            puterManualModelEdit.setText(PuterApiClient.DEFAULT_FREE_MODEL)
            savePuterFields()
            Toast.makeText(requireContext(), "Установлена бесплатная :free модель", Toast.LENGTH_LONG).show()
        }

        puterSaveBtn.setOnClickListener {
            savePuterFields()
            Toast.makeText(requireContext(), "Настройки Puter сохранены (активна: ${prefs.effectivePuterModel()}).", Toast.LENGTH_SHORT).show()
        }

        puterTestBtn.setOnClickListener {
            savePuterFields()
            puterUsageStatus.text = "Запрашиваю квоту Puter (/metering/usage) и проверяю токен…"
            viewLifecycleOwner.lifecycleScope.launch {
                val testRes = app.puterApiClient.testConnection(
                    authToken = prefs.puterAuthToken,
                    selectedModel = prefs.effectivePuterModel()
                )
                if (testRes.ok) {
                    prefs.puterLastUsageLabelRu = testRes.summaryRu
                }
                puterUsageStatus.text = testRes.summaryRu
                testOutput.text = "${if (testRes.ok) "OK" else "Ошибка"} (Puter): ${testRes.summaryRu}"
            }
        }
    }

    private fun savePuterFields() {
        val app = JarvisApplication.instance
        val prefs = app.prefs
        prefs.puterAuthToken = puterTokenEdit.text.toString().trim()
        prefs.puterSmartMode = puterSmartSwitch.isChecked
        prefs.puterModel = puterEconModelEdit.text.toString().trim().ifBlank { PuterApiClient.DEFAULT_ECON_MODEL }
        prefs.puterSmartModel = puterSmartModelEdit.text.toString().trim().ifBlank { PuterApiClient.DEFAULT_SMART_MODEL }
        prefs.puterManualModelId = puterManualModelEdit.text.toString().trim()
        app.inferenceEngine.refreshEffectiveState()
    }

    private fun setupPerchanceSection() {
        val app = JarvisApplication.instance
        val prefs = app.prefs

        perchanceEnableSwitch.isChecked = prefs.perchanceEnabled
        perchanceTextUrlEdit.setText(prefs.perchanceVerifyUrl)
        perchanceImageUrlEdit.setText(prefs.perchanceImageUrl)

        perchanceEnableSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.perchanceEnabled = checked
            if (checked) (activity as? MainActivity)?.reattachPerchanceHost(warmup = true)
            app.inferenceEngine.refreshEffectiveState()
        }

        perchanceSaveUrlsBtn.setOnClickListener {
            val textUrl = perchanceTextUrlEdit.text.toString().trim()
            val imageUrl = perchanceImageUrlEdit.text.toString().trim()
            if (!textUrl.startsWith("http://") && !textUrl.startsWith("https://")) {
                Toast.makeText(requireContext(), "URL текстового генератора должен начинаться с https://", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (!imageUrl.startsWith("http://") && !imageUrl.startsWith("https://")) {
                Toast.makeText(requireContext(), "URL генератора картинок должен начинаться с https://", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            prefs.perchanceEnabled = true
            perchanceEnableSwitch.isChecked = true
            (activity as? MainActivity)?.reattachPerchanceHost(warmup = false)
            app.perchanceBridge.updateUrlsAndReverify(textUrl, imageUrl)
            Toast.makeText(requireContext(), "URL Perchance сохранены. Запущена проверка готовности.", Toast.LENGTH_SHORT).show()
        }

        perchanceVerifyBtn.setOnClickListener {
            prefs.perchanceEnabled = true
            perchanceEnableSwitch.isChecked = true
            (activity as? MainActivity)?.reattachPerchanceHost(warmup = false)
            activity?.let { act -> PerchanceVerifyDialogHelper.show(act, viewLifecycleOwner) }
        }

        perchanceRecheckBtn.setOnClickListener {
            (activity as? MainActivity)?.reattachPerchanceHost(warmup = false)
            app.perchanceBridge.requestVerification(manualTrigger = true)
        }

        perchanceResetBtn.setOnClickListener {
            app.perchanceBridge.clearStorageAndReverify()
            Toast.makeText(requireContext(), "Cookies Perchance сброшены.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupCoreProviders() {
        val app = JarvisApplication.instance
        val prefs = app.prefs

        geminiKeyEdit.setText(prefs.geminiApiKey)
        geminiModelEdit.setText(prefs.geminiModel)
        groqKeyEdit.setText(prefs.groqApiKey)
        groqModelEdit.setText(prefs.groqLlmModel)
        openRouterKeyEdit.setText(prefs.openRouterApiKey)
        openRouterModelEdit.setText(prefs.openRouterModel)

        geminiTestBtn.setOnClickListener {
            prefs.geminiApiKey = geminiKeyEdit.text.toString().trim()
            prefs.geminiModel = geminiModelEdit.text.toString().trim().ifBlank { "gemini-2.5-flash" }
            app.inferenceEngine.refreshEffectiveState()
            runProviderTest(CloudProvider.GEMINI)
        }

        groqTestBtn.setOnClickListener {
            prefs.groqApiKey = groqKeyEdit.text.toString().trim()
            prefs.groqLlmModel = groqModelEdit.text.toString().trim().ifBlank { "llama-3.3-70b-versatile" }
            app.inferenceEngine.refreshEffectiveState()
            runProviderTest(CloudProvider.GROQ)
        }

        openRouterTestBtn.setOnClickListener {
            prefs.openRouterApiKey = openRouterKeyEdit.text.toString().trim()
            prefs.openRouterModel = openRouterModelEdit.text.toString().trim().ifBlank { "openrouter/free" }
            app.inferenceEngine.refreshEffectiveState()
            runProviderTest(CloudProvider.OPENROUTER)
        }
    }

    private fun runProviderTest(provider: CloudProvider, customConfig: CustomProviderConfig? = null) {
        val app = JarvisApplication.instance
        val prefs = app.prefs
        testOutput.text = "Проверяю ${provider.shortLabelRu}…"
        viewLifecycleOwner.lifecycleScope.launch {
            val res = when (provider) {
                CloudProvider.GEMINI -> app.cloudLlmClient.testGeminiKey(
                    apiKey = prefs.geminiApiKey,
                    model = prefs.geminiModel,
                    endpointMode = prefs.geminiEndpointMode
                ).also { if (it.ok) prefs.geminiDetectedVertex = it.detectedVertex }
                CloudProvider.GROQ -> app.cloudLlmClient.testGroqKey(prefs.groqApiKey)
                CloudProvider.OPENROUTER -> app.cloudLlmClient.testOpenRouterKey(prefs.openRouterApiKey)
                CloudProvider.CUSTOM_API -> {
                    val target = customConfig ?: prefs.getActiveCustomProvider()
                    if (target != null) app.cloudLlmClient.testCustomProvider(target)
                    else app.cloudLlmClient.testCustomApi(
                        apiKey = prefs.customApiKey,
                        compatibility = prefs.customApiCompat,
                        optionalBaseUrl = prefs.customApiBaseUrl,
                        optionalModel = prefs.customApiModel
                    )
                }
                CloudProvider.PUTER -> app.puterApiClient.testConnection(prefs.puterAuthToken, prefs.effectivePuterModel())
                else -> return@launch
            }
            testOutput.text = "${if (res.ok) "OK" else "Ошибка"} (${provider.shortLabelRu}): ${res.summaryRu}"
        }
    }

    // -------------------------------------------------------------------------
    // A3: Custom Providers CRUD (1..10) with Ordered URL -> Key -> Дополнительно
    // -------------------------------------------------------------------------

    private fun setupCustomProvidersSection() {
        customAddBtn.setOnClickListener {
            val existing = JarvisApplication.instance.prefs.getCustomProviders()
            if (existing.size >= CustomProviderManager.MAX_PROVIDERS) {
                Toast.makeText(requireContext(), "Достигнут максимум (${CustomProviderManager.MAX_PROVIDERS}) кастомных провайдеров.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            showCustomProviderDialog(existing = null)
        }
        renderCustomProviders()
    }

    private fun renderCustomProviders() {
        val prefs = JarvisApplication.instance.prefs
        val list = prefs.getCustomProviders()
        val activeId = prefs.activeCustomProviderId
        customHeader.text = "4. Пользовательские API (${list.size}/${CustomProviderManager.MAX_PROVIDERS})"
        customAddBtn.isEnabled = list.size < CustomProviderManager.MAX_PROVIDERS
        customListContainer.removeAllViews()
        val d = resources.displayMetrics.density

        if (list.isEmpty()) {
            customListContainer.addView(TextView(requireContext()).apply {
                text = "Нет добавленных кастомных провайдеров. Нажмите «+ Добавить»."
                setTextColor(Color.parseColor("#9CA3AF"))
                textSize = 12.5f
            })
            return
        }

        for (p in list) {
            val isActive = p.id == activeId || (activeId.isBlank() && p == list.first())
            val card = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                background = requireContext().getDrawable(R.drawable.bg_glass_pill)
                setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (8 * d).toInt() }
            }

            val title = TextView(requireContext()).apply {
                val activeMark = if (isActive) "[Активный] " else ""
                val enabledMark = if (p.enabled) "" else " [Выкл]"
                text = "$activeMark${p.displayTitle()}$enabledMark"
                setTextColor(if (isActive) Color.parseColor("#5EF2A5") else Color.WHITE)
                textSize = 13.5f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            card.addView(title)

            val sub = TextView(requireContext()).apply {
                text = "${p.baseUrl}\nМодель: ${p.effectiveModel()} • Формат: ${p.compatibility.labelRu}"
                setTextColor(Color.parseColor("#9CA3AF"))
                textSize = 11.5f
            }
            card.addView(sub)

            val btnRow = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (8 * d).toInt() }
            }

            fun chip(label: String, colorHex: String, onClick: () -> Unit): TextView =
                TextView(requireContext()).apply {
                    text = label
                    setTextColor(Color.parseColor(colorHex))
                    textSize = 11.5f
                    gravity = Gravity.CENTER
                    background = requireContext().getDrawable(R.drawable.bg_glass_card)
                    setPadding((8 * d).toInt(), (5 * d).toInt(), (8 * d).toInt(), (5 * d).toInt())
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginEnd = (5 * d).toInt()
                    }
                    setOnClickListener { onClick() }
                }

            btnRow.addView(chip(if (isActive) "Выбран" else "Выбрать", "#5EF2A5") {
                prefs.activeCustomProviderId = p.id
                prefs.chatPrimaryProvider = CloudProvider.CUSTOM_API
                JarvisApplication.instance.inferenceEngine.refreshEffectiveState()
                renderCustomProviders()
            })
            btnRow.addView(chip("Изменить", "#93C5FD") { showCustomProviderDialog(p) })
            btnRow.addView(chip("Тест", "#FDE68A") {
                prefs.activeCustomProviderId = p.id
                runProviderTest(CloudProvider.CUSTOM_API, customConfig = p)
            })
            btnRow.addView(chip("Удалить", "#FCA5A5") {
                AlertDialog.Builder(requireContext())
                    .setTitle("Удалить провайдер?")
                    .setMessage("Удалить «${p.displayTitle()}»?")
                    .setPositiveButton("Удалить") { _, _ ->
                        prefs.deleteCustomProvider(p.id)
                        JarvisApplication.instance.inferenceEngine.refreshEffectiveState()
                        renderCustomProviders()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            })

            card.addView(btnRow)
            customListContainer.addView(card)
        }
    }

    /** A3: Ordered fields: 1. URL -> 2. API Key -> 3. Collapsible «Дополнительно». */
    private fun showCustomProviderDialog(existing: CustomProviderConfig?) {
        val prefs = JarvisApplication.instance.prefs
        val d = resources.displayMetrics.density
        val scroll = ScrollView(requireContext())
        val box = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
        }
        scroll.addView(box)

        // 1. URL (required)
        val urlEdit = EditText(requireContext()).apply {
            hint = "1. URL эндпоинта (обязательно, например https://api.example.com/v1)"
            setText(existing?.baseUrl.orEmpty())
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        box.addView(urlEdit)

        // 2. API Key
        val keyEdit = EditText(requireContext()).apply {
            hint = "2. API-ключ (хранится зашифрованно)"
            setText(existing?.apiKey.orEmpty())
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        box.addView(keyEdit)

        // 3. Collapsible «Дополнительно»
        val extraToggle = TextView(requireContext()).apply {
            text = "Дополнительно (развернуть)"
            setTextColor(Color.parseColor("#93C5FD"))
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, (12 * d).toInt(), 0, (6 * d).toInt())
        }
        box.addView(extraToggle)

        val extraBox = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        box.addView(extraBox)

        val nameEdit = EditText(requireContext()).apply {
            hint = "Название провайдера (опционально)"
            setText(existing?.name.orEmpty())
        }
        val modelEdit = EditText(requireContext()).apply {
            hint = "Модель (опционально, например gpt-4o-mini)"
            setText(existing?.model.orEmpty())
        }
        val compatSpinner = Spinner(requireContext()).apply {
            adapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                CustomApiCompatibility.entries.map { it.labelRu }
            )
            setSelection(
                CustomApiCompatibility.entries.indexOf(existing?.compatibility ?: CustomApiCompatibility.OPENAI_COMPATIBLE)
                    .coerceAtLeast(0)
            )
        }
        val headersEdit = EditText(requireContext()).apply {
            hint = "Доп. заголовки JSON (опционально, {\"X-Org\":\"...\"})"
            setText(existing?.extraHeadersJson.orEmpty())
        }
        val paramsEdit = EditText(requireContext()).apply {
            hint = "Доп. параметры JSON (опционально)"
            setText(existing?.extraParamsJson.orEmpty())
        }
        val enabledSwitch = SwitchMaterial(requireContext()).apply {
            text = "Провайдер включён"
            isChecked = existing?.enabled ?: true
        }

        extraBox.addView(nameEdit)
        extraBox.addView(modelEdit)
        extraBox.addView(compatSpinner)
        extraBox.addView(headersEdit)
        extraBox.addView(paramsEdit)
        extraBox.addView(enabledSwitch)

        extraToggle.setOnClickListener {
            val show = extraBox.visibility != View.VISIBLE
            extraBox.visibility = if (show) View.VISIBLE else View.GONE
            extraToggle.text = if (show) "Дополнительно (свернуть)" else "Дополнительно (развернуть)"
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle(if (existing == null) "Новый Custom API провайдер" else "Редактировать Custom API")
            .setView(scroll)
            .setPositiveButton("Сохранить", null)
            .setNegativeButton("Отмена", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val cfg = CustomProviderConfig(
                    id = existing?.id ?: UUID.randomUUID().toString().take(12),
                    baseUrl = urlEdit.text.toString().trim(),
                    apiKey = keyEdit.text.toString().trim(),
                    name = nameEdit.text.toString().trim(),
                    model = modelEdit.text.toString().trim(),
                    compatibility = CustomApiCompatibility.entries[compatSpinner.selectedItemPosition],
                    extraHeadersJson = headersEdit.text.toString().trim(),
                    extraParamsJson = paramsEdit.text.toString().trim(),
                    enabled = enabledSwitch.isChecked
                )
                val validation = CustomProviderManager.validate(cfg, prefs.getCustomProviders())
                if (!validation.valid) {
                    Toast.makeText(requireContext(), validation.errorRu ?: "Ошибка валидации", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.upsertCustomProvider(cfg, setAsActive = existing == null || prefs.activeCustomProviderId.isBlank())
                JarvisApplication.instance.inferenceEngine.refreshEffectiveState()
                renderCustomProviders()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun simpleSelectListener(onSelect: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = onSelect(position)
        override fun onNothingSelected(parent: AdapterView<*>?) {}
    }
}
