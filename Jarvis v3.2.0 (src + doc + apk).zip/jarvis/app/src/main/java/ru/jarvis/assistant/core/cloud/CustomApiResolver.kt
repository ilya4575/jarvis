package ru.jarvis.assistant.core.cloud

/**
 * Resolves Base URL & default model automatically from just an API key + chosen compatibility
 * (OpenAI Compatible or Anthropic Compatible), so users do NOT have to type URLs manually.
 */
object CustomApiResolver {

    const val DEFAULT_OPENAI_BASE = "https://api.openai.com/v1"
    const val DEFAULT_ANTHROPIC_BASE = "https://api.anthropic.com/v1"
    const val DEFAULT_OPENAI_MODEL = "gpt-4o-mini"
    const val DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-4-5"

    fun suggestCompatibilityForKey(rawKey: String): CustomApiCompatibility? {
        val key = CloudLlmClient.sanitizeApiKey(rawKey)
        if (key.startsWith("sk-ant-")) return CustomApiCompatibility.ANTHROPIC_COMPATIBLE
        if (
            key.startsWith("sk-proj-") ||
            key.startsWith("github_pat_") ||
            key.startsWith("ghp_") ||
            key.startsWith("nvapi-") ||
            key.startsWith("xai-") ||
            key.startsWith("pza_") ||
            key.startsWith("gsk_") ||
            key.startsWith("csk-") ||
            key.startsWith("sk-or-v1-")
        ) {
            return CustomApiCompatibility.OPENAI_COMPATIBLE
        }
        return null
    }

    fun resolve(
        rawKey: String,
        compatibility: CustomApiCompatibility,
        optionalBaseUrl: String = "",
        optionalModel: String = ""
    ): ResolvedCustomApiConfig {
        val key = CloudLlmClient.sanitizeApiKey(rawKey)
        val userUrl = optionalBaseUrl.trim().trimEnd('/')
        val userModel = optionalModel.trim()

        if (userUrl.isNotBlank()) {
            val fallbackModel = when (compatibility) {
                CustomApiCompatibility.ANTHROPIC_COMPATIBLE -> DEFAULT_ANTHROPIC_MODEL
                CustomApiCompatibility.OPENAI_COMPATIBLE -> DEFAULT_OPENAI_MODEL
            }
            return ResolvedCustomApiConfig(
                baseUrl = userUrl,
                model = userModel.ifBlank { fallbackModel },
                compatibility = compatibility,
                detectedLabelRu = "Свой URL (${compatibility.labelRu})",
                autoDetectedUrl = false
            )
        }

        // Auto-detect endpoint purely from API key prefix + compatibility (no URL needed!)
        return when {
            key.startsWith("sk-ant-") -> ResolvedCustomApiConfig(
                baseUrl = DEFAULT_ANTHROPIC_BASE,
                model = userModel.ifBlank { DEFAULT_ANTHROPIC_MODEL },
                compatibility = CustomApiCompatibility.ANTHROPIC_COMPATIBLE,
                detectedLabelRu = "Anthropic API (авто по ключу)",
                autoDetectedUrl = true
            )
            key.startsWith("github_pat_") || key.startsWith("ghp_") -> ResolvedCustomApiConfig(
                baseUrl = "https://models.github.ai/inference",
                model = userModel.ifBlank { "openai/gpt-4o-mini" },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "GitHub Models (авто по ключу)",
                autoDetectedUrl = true
            )
            key.startsWith("nvapi-") -> ResolvedCustomApiConfig(
                baseUrl = "https://integrate.api.nvidia.com/v1",
                model = userModel.ifBlank { "meta/llama-3.3-70b-instruct" },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "NVIDIA NIM (авто по ключу)",
                autoDetectedUrl = true
            )
            key.startsWith("xai-") -> ResolvedCustomApiConfig(
                baseUrl = "https://api.x.ai/v1",
                model = userModel.ifBlank { "grok-3-mini" },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "xAI Grok (авто по ключу)",
                autoDetectedUrl = true
            )
            key.startsWith("pza_") -> ResolvedCustomApiConfig(
                baseUrl = "https://api.polza.ai/api/v1",
                model = userModel.ifBlank { "openai/gpt-4o-mini" },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "Polza.ai (авто по ключу)",
                autoDetectedUrl = true
            )
            key.startsWith("gsk_") -> ResolvedCustomApiConfig(
                baseUrl = CloudLlmClient.DEFAULT_GROQ_BASE,
                model = userModel.ifBlank { CloudLlmClient.DEFAULT_GROQ_LLM_MODEL },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "Groq (авто по ключу)",
                autoDetectedUrl = true
            )
            key.startsWith("sk-or-v1-") -> ResolvedCustomApiConfig(
                baseUrl = CloudLlmClient.DEFAULT_OPENROUTER_BASE,
                model = userModel.ifBlank { CloudLlmClient.DEFAULT_OPENROUTER_MODEL },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "OpenRouter (авто по ключу)",
                autoDetectedUrl = true
            )
            compatibility == CustomApiCompatibility.ANTHROPIC_COMPATIBLE -> ResolvedCustomApiConfig(
                baseUrl = DEFAULT_ANTHROPIC_BASE,
                model = userModel.ifBlank { DEFAULT_ANTHROPIC_MODEL },
                compatibility = CustomApiCompatibility.ANTHROPIC_COMPATIBLE,
                detectedLabelRu = "Anthropic API (по совместимости)",
                autoDetectedUrl = true
            )
            else -> ResolvedCustomApiConfig(
                baseUrl = DEFAULT_OPENAI_BASE,
                model = userModel.ifBlank { DEFAULT_OPENAI_MODEL },
                compatibility = CustomApiCompatibility.OPENAI_COMPATIBLE,
                detectedLabelRu = "OpenAI API (по совместимости)",
                autoDetectedUrl = true
            )
        }
    }
}
