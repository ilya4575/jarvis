package ru.jarvis.assistant.feature.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import java.io.File
import java.util.Locale

data class TtsPlaybackState(
    val active: Boolean = false,
    val loading: Boolean = false,
    val activeVoiceId: String? = null,
    val statusRu: String = ""
)

/**
 * Neural-First Russian Voice Speaker.
 * Completely bypasses Chinese Android ROM system TTS by defaulting to Microsoft Edge Neural TTS
 * (free, zero-key, 24 kHz human Russian MP3 via MediaPlayer), with optional Gemini Native TTS
 * and OpenAI-compatible /audio/speech fallback. System Android TTS is only used if explicitly chosen.
 */
class LocalTtsSpeaker(
    context: Context,
    private val prefs: JarvisPreferences,
    private val puterClient: ru.jarvis.assistant.core.cloud.PuterApiClient? = null
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val edgeClient = EdgeNeuralTtsClient()
    private val cloudTtsClient = CloudNeuralTtsClient()
    private val grokTtsClient = GrokTtsClient()

    private var mediaPlayer: MediaPlayer? = null
    private var activeJob: Job? = null

    private var systemTts: TextToSpeech? = null
    @Volatile
    private var systemTtsReady = false
    @Volatile
    private var systemTtsInitStarted = false

    private val _playbackState = MutableStateFlow(TtsPlaybackState())
    val playbackState: StateFlow<TtsPlaybackState> = _playbackState.asStateFlow()

    private val audioCacheDir: File by lazy {
        File(appContext.cacheDir, "jarvis_tts").apply { mkdirs() }
    }

    fun isSpeaking(): Boolean {
        val mpPlaying = runCatching { mediaPlayer?.isPlaying == true }.getOrDefault(false)
        val sysPlaying = runCatching { systemTts?.isSpeaking == true }.getOrDefault(false)
        return mpPlaying || sysPlaying || _playbackState.value.loading || _playbackState.value.active
    }

    /**
     * Toggles speech playback for a chat/island reply using the user's selected neural voice.
     */
    fun speak(
        text: String,
        onError: ((String) -> Unit)? = null
    ): Result<Unit> {
        val clean = sanitizeForSpeech(text)
        if (clean.isBlank()) {
            return Result.failure(IllegalArgumentException("Нет текста для озвучки."))
        }
        if (isSpeaking()) {
            stop()
            return Result.success(Unit)
        }
        val mode = prefs.ttsEngineMode
        val preset = prefs.ttsVoicePreset
        if (mode == TtsEngineMode.SYSTEM_ANDROID) {
            return speakViaSystemAndroid(clean)
        }
        startNeuralPlayback(
            cleanText = clean.take(1600),
            mode = mode,
            voice = preset,
            rateOffset = prefs.ttsRateOffsetPct,
            pitchOffset = prefs.ttsPitchOffsetHz,
            onError = onError
        )
        return Result.success(Unit)
    }

    /**
     * Auditions a specific neural voice preset live from the Voice Settings screen.
     */
    fun previewVoice(
        voice: NeuralVoicePreset,
        sampleText: String,
        rateOffset: Int = prefs.ttsRateOffsetPct,
        pitchOffset: Int = prefs.ttsPitchOffsetHz,
        forceMode: TtsEngineMode? = null,
        onError: ((String) -> Unit)? = null
    ) {
        val wasSame = _playbackState.value.activeVoiceId == voice.id && isSpeaking()
        stop()
        if (wasSame) return

        val mode = forceMode ?: when (prefs.ttsEngineMode) {
            TtsEngineMode.SYSTEM_ANDROID -> TtsEngineMode.EDGE_NEURAL
            else -> prefs.ttsEngineMode
        }
        startNeuralPlayback(
            cleanText = sanitizeForSpeech(sampleText).ifBlank {
                "Привет! Я ${prefs.assistantName}. Могу помочь с задачами и открыть любое приложение."
            },
            mode = mode,
            voice = voice,
            rateOffset = rateOffset,
            pitchOffset = pitchOffset,
            onError = onError
        )
    }

    private fun startNeuralPlayback(
        cleanText: String,
        mode: TtsEngineMode,
        voice: NeuralVoicePreset,
        rateOffset: Int,
        pitchOffset: Int,
        onError: ((String) -> Unit)?
    ) {
        stop()
        _playbackState.value = TtsPlaybackState(
            active = true,
            loading = true,
            activeVoiceId = voice.id,
            statusRu = "Синтез голоса (${voice.titleRu})…"
        )

        activeJob = scope.launch {
            val outFile = File(audioCacheDir, "tts_${System.currentTimeMillis()}.audio")
            val synthesized = synthesizeWithFallback(cleanText, mode, voice, rateOffset, pitchOffset, outFile)
            synthesized.onSuccess { audioFile ->
                playAudioFile(audioFile, voice) { err ->
                    _playbackState.value = TtsPlaybackState()
                    onError?.invoke(err)
                }
            }.onFailure { err ->
                _playbackState.value = TtsPlaybackState()
                onError?.invoke(err.message ?: "Не удалось озвучить текст.")
            }
        }
    }

    /**
     * Plays a user-uploaded reference voice sample directly so the user can audition their clip.
     */
    fun playLocalSampleFile(file: File, onError: ((String) -> Unit)? = null) {
        if (!file.exists() || file.length() <= 0L) {
            onError?.invoke("Файл сэмпла не найден.")
            return
        }
        if (isSpeaking() && _playbackState.value.activeVoiceId == "custom_sample") {
            stop()
            return
        }
        stop()
        _playbackState.value = TtsPlaybackState(
            active = true,
            loading = false,
            activeVoiceId = "custom_sample",
            statusRu = "Прослушивание вашего сэмпла голоса…"
        )
        playAudioFile(file, prefs.ttsVoicePreset) { err ->
            _playbackState.value = TtsPlaybackState()
            onError?.invoke(err)
        }
    }

    private suspend fun synthesizeWithFallback(
        text: String,
        mode: TtsEngineMode,
        voice: NeuralVoicePreset,
        rateOffset: Int,
        pitchOffset: Int,
        outFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        cleanupOldCache()
        when (mode) {
            TtsEngineMode.EDGE_NEURAL -> {
                val edge = edgeClient.synthesizeToMp3File(text, voice, rateOffset, pitchOffset, outFile)
                if (edge.isSuccess) return@withContext edge
                // Optional fallback to Gemini Native TTS if user has a Gemini key
                if (prefs.geminiApiKey.isNotBlank()) {
                    val gem = cloudTtsClient.synthesizeGeminiToWavFile(
                        apiKey = prefs.geminiApiKey,
                        endpointMode = prefs.geminiEndpointMode,
                        cachedUseVertex = prefs.geminiDetectedVertex,
                        text = text,
                        voiceName = voice.geminiVoiceName,
                        outputFile = outFile
                    )
                    if (gem.isSuccess) return@withContext gem
                }
                edge
            }
            TtsEngineMode.GROK_TTS -> grokTtsClient.synthesizeToMp3File(
                apiKey = prefs.grokTtsApiKey,
                voiceId = prefs.grokTtsVoiceId,
                text = text,
                speed = (1.0f + rateOffset / 100f).coerceIn(0.7f, 1.5f),
                outputFile = outFile
            )
            TtsEngineMode.FISH_AUDIO_CLONE -> {
                val sampleFile = prefs.customVoiceSamplePath?.let { File(it) }?.takeIf { it.exists() }
                val speed = (1.0f + rateOffset / 100f).coerceIn(0.7f, 1.4f)
                val fish = cloudTtsClient.synthesizeFishAudioToMp3File(
                    apiKey = prefs.fishAudioApiKey,
                    model = prefs.fishAudioModel,
                    referenceId = prefs.fishAudioVoiceId,
                    sampleFile = sampleFile,
                    sampleTranscript = prefs.customVoiceSampleText,
                    text = text,
                    speed = speed,
                    outputFile = outFile
                )
                if (fish.isSuccess) return@withContext fish
                // Return Fish Audio's explicit error if user is previewing/configuring it, otherwise fallback gracefully
                if (prefs.fishAudioApiKey.isBlank()) {
                    edgeClient.synthesizeToMp3File(text, voice, rateOffset, pitchOffset, outFile)
                } else {
                    fish
                }
            }
            TtsEngineMode.ELEVENLABS_CLONE -> {
                val el = cloudTtsClient.synthesizeElevenLabsToMp3File(
                    apiKey = prefs.elevenLabsApiKey,
                    voiceId = prefs.elevenLabsVoiceId,
                    text = text,
                    outputFile = outFile
                )
                if (el.isSuccess) return@withContext el
                if (prefs.elevenLabsApiKey.isBlank()) {
                    edgeClient.synthesizeToMp3File(text, voice, rateOffset, pitchOffset, outFile)
                } else {
                    el
                }
            }
            TtsEngineMode.PUTER_TTS -> {
                val client = puterClient
                if (client == null) {
                    Result.failure(IllegalStateException("Puter TTS клиент недоступен."))
                } else {
                    client.synthesizeSpeechToFile(
                        authToken = prefs.puterAuthToken,
                        text = text,
                        provider = prefs.puterTtsProvider,
                        voice = prefs.puterTtsVoice,
                        model = prefs.puterTtsModel,
                        outputFile = outFile
                    )
                }
            }
            TtsEngineMode.CUSTOM_CLONE_URL -> {
                val sampleFile = prefs.customVoiceSamplePath?.let { File(it) }?.takeIf { it.exists() }
                val bearer = prefs.customTtsApiKey.ifBlank { prefs.customApiKey }
                val custom = cloudTtsClient.synthesizeCustomCloneUrlToFile(
                    endpointUrl = prefs.customCloneTtsUrl,
                    optionalBearerKey = bearer,
                    sampleFile = sampleFile,
                    sampleTranscript = prefs.customVoiceSampleText,
                    text = text,
                    outputFile = outFile,
                    customModel = prefs.customTtsModel,
                    customVoice = prefs.customTtsVoice
                )
                if (custom.isSuccess) return@withContext custom
                if (prefs.customCloneTtsUrl.isBlank()) {
                    edgeClient.synthesizeToMp3File(text, voice, rateOffset, pitchOffset, outFile)
                } else {
                    custom
                }
            }
            TtsEngineMode.GEMINI_NATIVE -> {
                if (prefs.geminiApiKey.isNotBlank()) {
                    val gem = cloudTtsClient.synthesizeGeminiToWavFile(
                        apiKey = prefs.geminiApiKey,
                        endpointMode = prefs.geminiEndpointMode,
                        cachedUseVertex = prefs.geminiDetectedVertex,
                        text = text,
                        voiceName = voice.geminiVoiceName,
                        outputFile = outFile
                    )
                    if (gem.isSuccess) return@withContext gem
                }
                edgeClient.synthesizeToMp3File(text, voice, rateOffset, pitchOffset, outFile)
            }
            TtsEngineMode.CUSTOM_OPENAI -> {
                if (prefs.customApiKey.isNotBlank()) {
                    val resolved = prefs.resolvedCustomApi()
                    if (resolved.compatibility == ru.jarvis.assistant.core.cloud.CustomApiCompatibility.OPENAI_COMPATIBLE) {
                        val oai = cloudTtsClient.synthesizeOpenAiSpeechToMp3File(
                            baseUrl = resolved.baseUrl,
                            apiKey = prefs.customApiKey,
                            voiceName = voice.openAiVoiceName,
                            text = text,
                            outputFile = outFile
                        )
                        if (oai.isSuccess) return@withContext oai
                    }
                }
                edgeClient.synthesizeToMp3File(text, voice, rateOffset, pitchOffset, outFile)
            }
            TtsEngineMode.SYSTEM_ANDROID -> Result.failure(IllegalStateException("Используется системный TTS"))
        }
    }

    private fun playAudioFile(
        file: File,
        voice: NeuralVoicePreset,
        onError: (String) -> Unit
    ) {
        mainHandler.post {
            releaseMediaPlayer()
            try {
                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    setDataSource(file.absolutePath)
                    setOnCompletionListener {
                        releaseMediaPlayer()
                        _playbackState.value = TtsPlaybackState()
                    }
                    setOnErrorListener { _, what, extra ->
                        releaseMediaPlayer()
                        _playbackState.value = TtsPlaybackState()
                        onError("Ошибка воспроизведения аудио ($what/$extra)")
                        true
                    }
                    prepare()
                    start()
                }
                mediaPlayer = mp
                _playbackState.value = TtsPlaybackState(
                    active = true,
                    loading = false,
                    activeVoiceId = voice.id,
                    statusRu = "Озвучиваю (${voice.titleRu})…"
                )
            } catch (t: Throwable) {
                releaseMediaPlayer()
                _playbackState.value = TtsPlaybackState()
                onError("Не удалось воспроизвести аудио: ${t.message}")
            }
        }
    }

    private fun speakViaSystemAndroid(clean: String): Result<Unit> {
        if (!systemTtsInitStarted) {
            systemTtsInitStarted = true
            systemTts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val eng = systemTts
                    val res = runCatching { eng?.setLanguage(Locale("ru", "RU")) }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
                    systemTtsReady = res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED
                    if (systemTtsReady) {
                        eng?.speak(clean.take(1800), TextToSpeech.QUEUE_FLUSH, null, "jarvis_sys_${System.currentTimeMillis()}")
                    }
                }
            }
            return Result.success(Unit)
        }
        val eng = systemTts
        if (!systemTtsReady || eng == null) {
            return Result.failure(
                IllegalStateException("В системном TTS Android нет русского голоса — переключитесь на «Нейро-голос» в меню «Голос и Диктор».")
            )
        }
        eng.speak(clean.take(1800), TextToSpeech.QUEUE_FLUSH, null, "jarvis_sys_${System.currentTimeMillis()}")
        return Result.success(Unit)
    }

    private fun releaseMediaPlayer() {
        val mp = mediaPlayer
        mediaPlayer = null
        if (mp != null) {
            runCatching { if (mp.isPlaying) mp.stop() }
            runCatching { mp.reset() }
            runCatching { mp.release() }
        }
    }

    private fun cleanupOldCache() {
        runCatching {
            val files = audioCacheDir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
            if (files.size > 6) {
                files.drop(6).forEach { it.delete() }
            }
        }
    }

    fun stop() {
        activeJob?.cancel()
        activeJob = null
        edgeClient.cancelActive()
        cloudTtsClient.cancelActive()
        grokTtsClient.cancelActive()
        releaseMediaPlayer()
        runCatching { systemTts?.stop() }
        _playbackState.value = TtsPlaybackState()
    }

    fun shutdown() {
        stop()
        runCatching { systemTts?.shutdown() }
        systemTts = null
        systemTtsReady = false
        systemTtsInitStarted = false
    }

    companion object {
        private val EMOJI_PATTERN = Regex("[\\x{1F300}-\\x{1FAFF}\\x{2600}-\\x{27BF}]")

        fun sanitizeForSpeech(raw: String): String {
            return raw
                .lines()
                .filterNot { line ->
                    val t = line.trim()
                    t.startsWith("[[ACTION]]") || t.startsWith("[[WARN]]")
                }
                .joinToString("\n")
                .replace(Regex("```[\\s\\S]*?```"), " фрагмент кода ")
                .replace(Regex("https?://\\S+"), " ссылка ")
                .replace(Regex("[*_`#~>|]"), " ")
                .replace(EMOJI_PATTERN, " ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        fun openSystemTtsSettings(context: Context) {
            val intent = Intent("com.android.settings.TTS_SETTINGS").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(intent) }
        }
    }
}
