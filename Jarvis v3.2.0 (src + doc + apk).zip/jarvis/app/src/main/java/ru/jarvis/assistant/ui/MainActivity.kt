package ru.jarvis.assistant.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import ru.jarvis.assistant.JarvisApplication
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.inference.EngineState
import ru.jarvis.assistant.data.db.ChatSessionEntity
import ru.jarvis.assistant.feature.overlay.IslandForegroundService
import ru.jarvis.assistant.feature.overlay.IslandPriorityEngine
import ru.jarvis.assistant.feature.overlay.IslandRestoreDecision
import ru.jarvis.assistant.ui.about.AboutFragment
import ru.jarvis.assistant.ui.actions.ActionsFragment
import ru.jarvis.assistant.ui.chat.ChatFragment
import ru.jarvis.assistant.ui.cloud.CloudApiSettingsFragment
import ru.jarvis.assistant.ui.cloud.PerchanceVerifyDialogHelper
import ru.jarvis.assistant.ui.island.IslandAvatarFragment
import ru.jarvis.assistant.ui.models.ModelsFragment
import ru.jarvis.assistant.ui.persona.PersonaSettingsFragment
import ru.jarvis.assistant.ui.voice.VoiceTtsSettingsFragment

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var drawerAvatarImg: ImageView
    private lateinit var drawerTitleText: TextView
    private lateinit var drawerModelSubtitle: TextView
    private lateinit var drawerNewChatBtn: View
    private lateinit var drawerSessionsContainer: LinearLayout
    private lateinit var perchanceHiddenHost: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawer_layout)
        drawerAvatarImg = findViewById(R.id.drawer_avatar_img)
        drawerTitleText = findViewById(R.id.drawer_title_text)
        drawerModelSubtitle = findViewById(R.id.drawer_model_subtitle)
        drawerNewChatBtn = findViewById(R.id.drawer_new_chat_btn)
        drawerSessionsContainer = findViewById(R.id.drawer_sessions_container)
        perchanceHiddenHost = findViewById(R.id.perchance_hidden_host)

        if (JarvisApplication.instance.prefs.perchanceEnabled) {
            reattachPerchanceHost(warmup = true)
        }

        drawerAvatarImg.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        drawerAvatarImg.clipToOutline = true

        drawerNewChatBtn.setOnClickListener {
            JarvisApplication.instance.chatCoordinator.createNewChat()
            drawerLayout.closeDrawer(GravityCompat.START)
            navigateToChat()
        }

        findViewById<View>(R.id.drawer_nav_cloud).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(CloudApiSettingsFragment())
        }
        findViewById<View>(R.id.drawer_nav_voice).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(VoiceTtsSettingsFragment())
        }
        findViewById<View>(R.id.drawer_nav_models).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(ModelsFragment())
        }
        findViewById<View>(R.id.drawer_nav_island).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(IslandAvatarFragment())
        }
        findViewById<View>(R.id.drawer_nav_persona).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(PersonaSettingsFragment())
        }
        findViewById<View>(R.id.drawer_nav_actions).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(ActionsFragment())
        }
        findViewById<View>(R.id.drawer_nav_about).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            openSecondaryScreen(AboutFragment())
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                } else if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                } else {
                    finish()
                }
            }
        })

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, ChatFragment())
                .commit()
        }

        observeDrawerState()
        ensureDynamicIslandAutoStarted()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshDrawerHeader()
        // A1: Automatically show Dynamic Island whenever toggle is ON & overlay permission is granted
        ensureDynamicIslandAutoStarted()
    }

    private fun ensureDynamicIslandAutoStarted() {
        val prefs = JarvisApplication.instance.prefs
        val decision = IslandPriorityEngine.evaluateAutoRestore(
            islandToggleEnabled = prefs.islandEnabled,
            hasOverlayPermission = Settings.canDrawOverlays(this)
        )
        if (decision == IslandRestoreDecision.START_NOW && !IslandForegroundService.isRunning) {
            val started = IslandForegroundService.startSafe(this)
            if (started) prefs.islandPendingRestore = false
        }
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra(EXTRA_RESTORE_ISLAND, false)) {
            intent.removeExtra(EXTRA_RESTORE_ISLAND)
            ensureDynamicIslandAutoStarted()
        }
        if (intent.getBooleanExtra(EXTRA_OPEN_PERCHANCE_VERIFY, false)) {
            intent.removeExtra(EXTRA_OPEN_PERCHANCE_VERIFY)
            PerchanceVerifyDialogHelper.show(this, this)
        }
        val agentMsg = intent.getStringExtra(EXTRA_AGENT_RETURN_MESSAGE)
        if (!agentMsg.isNullOrBlank()) {
            intent.removeExtra(EXTRA_AGENT_RETURN_MESSAGE)
            navigateToChat()
            Toast.makeText(this, agentMsg, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        if (::perchanceHiddenHost.isInitialized) {
            JarvisApplication.instance.perchanceBridge.detachFromContainer(perchanceHiddenHost)
        }
        super.onDestroy()
    }

    fun reattachPerchanceHost(warmup: Boolean = false) {
        if (!::perchanceHiddenHost.isInitialized) return
        val bridge = JarvisApplication.instance.perchanceBridge
        bridge.attachToContainer(perchanceHiddenHost)
        if (warmup) {
            bridge.warmup()
        }
    }

    fun openDrawer() {
        refreshDrawerHeader()
        drawerLayout.openDrawer(GravityCompat.START)
    }

    fun navigateToChat() {
        while (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStackImmediate()
        }
        val current = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (current !is ChatFragment) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, ChatFragment())
                .commit()
        }
    }

    fun navigateToCloudApiScreen() = openSecondaryScreen(CloudApiSettingsFragment())
    fun navigateToModelsTab() = openSecondaryScreen(ModelsFragment())
    fun navigateToPersonaScreen() = openSecondaryScreen(PersonaSettingsFragment())
    fun navigateToVoiceTtsScreen() = openSecondaryScreen(VoiceTtsSettingsFragment())
    fun navigateToIslandScreen() = openSecondaryScreen(IslandAvatarFragment())
    fun navigateToActionsScreen() = openSecondaryScreen(ActionsFragment())

    fun popToChat() {
        if (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
        } else {
            navigateToChat()
        }
    }

    fun updateToolbarTitle() {
        refreshDrawerHeader()
    }

    private fun openSecondaryScreen(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                R.anim.jarvis_slide_in_right,
                R.anim.jarvis_slide_out_left,
                R.anim.jarvis_slide_in_left,
                R.anim.jarvis_slide_out_right
            )
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(fragment.javaClass.simpleName)
            .commit()
    }

    private fun refreshDrawerHeader() {
        val app = JarvisApplication.instance
        drawerTitleText.text = app.prefs.assistantName
        val img = app.avatarManager.getStaticImageFile()
        if (img != null && img.exists()) {
            val bmp = runCatching { BitmapFactory.decodeFile(img.absolutePath) }.getOrNull()
            if (bmp != null) drawerAvatarImg.setImageBitmap(bmp)
            else drawerAvatarImg.setImageResource(
                if (app.prefs.kurumiThemeEnabled) R.drawable.kurumi_avatar_default else R.drawable.ic_jarvis_avatar_default
            )
        } else {
            drawerAvatarImg.setImageResource(
                if (app.prefs.kurumiThemeEnabled) R.drawable.kurumi_avatar_default else R.drawable.ic_jarvis_avatar_default
            )
        }
    }

    private fun observeDrawerState() {
        val app = JarvisApplication.instance
        lifecycleScope.launch {
            app.chatCoordinator.uiState.collectLatest { st ->
                renderDrawerSessions(st.sessions, st.activeSessionId)
            }
        }
        lifecycleScope.launch {
            app.inferenceEngine.state.collectLatest { eng ->
                drawerModelSubtitle.text = when (eng) {
                    is EngineState.Ready -> "Активна: ${eng.profileTitle}"
                    is EngineState.Loading -> "Загрузка ${eng.modelName}…"
                    is EngineState.Error -> "Ошибка движка"
                    is EngineState.Unloaded -> "Нет подключённого провайдера"
                }
            }
        }
    }

    private fun renderDrawerSessions(sessions: List<ChatSessionEntity>, activeId: Long) {
        drawerSessionsContainer.removeAllViews()
        val density = resources.displayMetrics.density
        val padH = (12 * density).toInt()
        val padV = (8 * density).toInt()

        for (session in sessions) {
            val isActive = session.id == activeId
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(padH, padV, (4 * density).toInt(), padV)
                background = if (isActive) getDrawable(R.drawable.bg_glass_pill) else null
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (4 * density).toInt() }
            }

            val titleTv = TextView(this).apply {
                val modeTag = if (session.mode != ru.jarvis.assistant.core.inference.ChatMode.NORMAL) {
                    "[${session.mode.shortLabelRu}] "
                } else ""
                text = "$modeTag${session.title}"
                setTextColor(getColor(if (isActive) R.color.jarvis_text_primary else R.color.jarvis_text_secondary))
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(titleTv)

            if (sessions.size > 1) {
                val delBtn = ImageButton(this).apply {
                    setImageResource(R.drawable.ic_delete)
                    background = null
                    contentDescription = "Удалить чат"
                    val sz = (32 * density).toInt()
                    layoutParams = LinearLayout.LayoutParams(sz, sz)
                    setPadding((6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt(), (6 * density).toInt())
                    setOnClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Удалить чат?")
                            .setMessage("Чат «${session.title}» будет удалён с устройства.")
                            .setPositiveButton("Удалить") { _, _ ->
                                JarvisApplication.instance.chatCoordinator.deleteChat(session.id)
                            }
                            .setNegativeButton("Отмена", null)
                            .show()
                    }
                }
                row.addView(delBtn)
            }

            row.setOnClickListener {
                JarvisApplication.instance.chatCoordinator.selectChat(session.id)
                drawerLayout.closeDrawer(GravityCompat.START)
                navigateToChat()
            }
            drawerSessionsContainer.addView(row)
        }
    }

    companion object {
        const val EXTRA_OPEN_PERCHANCE_VERIFY = "extra_open_perchance_verify"
        const val EXTRA_RESTORE_ISLAND = "extra_restore_island"
        const val EXTRA_AGENT_RETURN_MESSAGE = "extra_agent_return_message"
    }
}
