package ru.jarvis.assistant.feature.voice

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import ru.jarvis.assistant.core.cloud.CloudLlmClient
import ru.jarvis.assistant.core.cloud.GeminiEndpointMode
import ru.jarvis.assistant.core.cloud.GroqWhisperClient
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Cloud Neural TTS & Voice Cloning clients:
 *  1. Fish Audio (`/v1/tts`) — supports BOTH community/custom `reference_id` (e.g. Kurumi Tokisaki)
 *     AND zero-shot cloning straight from a local MP3/WAV reference sample via MessagePack!
 *  2. ElevenLabs (`/v1/text-to-speech/{voice_id}`) — Multilingual v2 voice cloning on Russian.
 *  3. Custom Voice Cloning / TTS Server URL — sends multipart with local sample (XTTS-v2 / F5-TTS /
 *     Chatterbox / custom Flask/FastAPI) OR OpenAI-compatible JSON when no sample is attached.
 *  4. Google Gemini Native TTS (`gemini-2.5-flash-preview-tts` -> 24 kHz WAV).
 *  5. OpenAI-compatible `/audio/speech`.
 */
class CloudNeuralTtsClient(
    private val geminiAiStudioBaseUrl: String = CloudLlmClient.DEFAULT_GEMINI_AI_STUDIO_BASE,
    private val geminiVertexBaseUrl: String = CloudLlmClient.DEFAULT_GEMINI_VERTEX_BASE,
    private val fishAudioBaseUrl: String = DEFAULT_FISH_AUDIO_BASE,
    private val elevenLabsBaseUrl: String = DEFAULT_ELEVENLABS_BASE
) {
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val activeCall = AtomicReference<Call?>(null)

    fun cancelActive() {
        activeCall.getAndSet(null)?.cancel()
    }

    /**
     * Synthesizes speech via Fish Audio (`/v1/tts`).
     * - If `referenceId` is provided: uses JSON request referencing that Fish Audio model ID.
     * - Else if `sampleFile` exists: encodes binary zero-shot `references` via MessagePack!
     */
    suspend fun synthesizeFishAudioToMp3File(
        apiKey: String,
        model: String,
        referenceId: String,
        sampleFile: File?,
        sampleTranscript: String,
        text: String,
        speed: Float = 1.0f,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanKey = CloudLlmClient.sanitizeApiKey(apiKey)
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Укажите API-ключ Fish Audio."))
        }
        val cleanRefId = referenceId.trim()
        val hasSample = sampleFile != null && sampleFile.exists() && sampleFile.length() > 0L
        if (cleanRefId.isBlank() && !hasSample) {
            return@withContext Result.failure(
                IllegalStateException("Для Fish Audio укажите ID голоса (reference_id) или выберите MP3/WAV-сэмпл.")
            )
        }

        val chosenModel = model.trim().ifBlank { DEFAULT_FISH_AUDIO_MODEL }
        val endpoint = "${fishAudioBaseUrl.trimEnd('/')}/v1/tts"
        val clampedSpeed = speed.coerceIn(0.6f, 1.5f).toDouble()

        val request = if (cleanRefId.isNotBlank()) {
            val payload = JSONObject().apply {
                put("text", text.trim())
                put("reference_id", cleanRefId)
                put("format", "mp3")
                put("mp3_bitrate", 128)
                put("normalize", true)
                put("latency", "normal")
                put("prosody", JSONObject().put("speed", clampedSpeed).put("volume", 0))
            }
            Request.Builder()
                .url(endpoint)
                .header("Authorization", "Bearer $cleanKey")
                .header("model", chosenModel)
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()
        } else {
            val audioBytes = sampleFile!!.readBytes()
            val msgMap = linkedMapOf<String, Any>(
                "text" to text.trim(),
                "format" to "mp3",
                "mp3_bitrate" to 128,
                "normalize" to true,
                "latency" to "normal",
                "prosody" to linkedMapOf("speed" to clampedSpeed, "volume" to 0),
                "references" to listOf(
                    linkedMapOf(
                        "audio" to audioBytes,
                        "text" to sampleTranscript.trim()
                    )
                )
            )
            val packed = MiniMsgPackEncoder.encode(msgMap)
            Request.Builder()
                .url(endpoint)
                .header("Authorization", "Bearer $cleanKey")
                .header("model", chosenModel)
                .header("Content-Type", "application/msgpack")
                .post(packed.toRequestBody(MSGPACK_MEDIA))
                .build()
        }

        val call = httpClient.newCall(request)
        activeCall.set(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty()
                    return@withContext Result.failure(
                        IllegalStateException("Fish Audio HTTP ${resp.code}: ${CloudLlmClient.extractErrorMessage(err)}")
                    )
                }
                val bytes = resp.body?.bytes() ?: ByteArray(0)
                if (bytes.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("Fish Audio вернул пустой аудиопоток."))
                }
                outputFile.parentFile?.mkdirs()
                outputFile.writeBytes(bytes)
                Result.success(outputFile)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    /**
     * Synthesizes speech via ElevenLabs Multilingual v2 (`/v1/text-to-speech/{voice_id}`).
     */
    suspend fun synthesizeElevenLabsToMp3File(
        apiKey: String,
        voiceId: String,
        text: String,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanKey = CloudLlmClient.sanitizeApiKey(apiKey)
        val cleanVoice = voiceId.trim()
        if (cleanKey.isBlank() || cleanVoice.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Для ElevenLabs укажите API-ключ и voice_id клонированного голоса.")
            )
        }
        val endpoint = "${elevenLabsBaseUrl.trimEnd('/')}/v1/text-to-speech/$cleanVoice"
        val payload = JSONObject().apply {
            put("text", text.trim())
            put("model_id", DEFAULT_ELEVENLABS_MODEL)
            put(
                "voice_settings",
                JSONObject()
                    .put("stability", 0.45)
                    .put("similarity_boost", 0.82)
                    .put("style", 0.35)
                    .put("use_speaker_boost", true)
            )
        }
        val req = Request.Builder()
            .url(endpoint)
            .header("xi-api-key", cleanKey)
            .header("Accept", "audio/mpeg")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .build()

        val call = httpClient.newCall(req)
        activeCall.set(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty()
                    return@withContext Result.failure(
                        IllegalStateException("ElevenLabs HTTP ${resp.code}: ${CloudLlmClient.extractErrorMessage(err)}")
                    )
                }
                val bytes = resp.body?.bytes() ?: ByteArray(0)
                if (bytes.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("ElevenLabs вернул пустой файл."))
                }
                outputFile.parentFile?.mkdirs()
                outputFile.writeBytes(bytes)
                Result.success(outputFile)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    /**
     * Synthesizes speech via a user-hosted Voice Cloning / TTS URL (XTTS-v2 / F5-TTS / Chatterbox /
     * GPT-SoVITS / local PC bridge). When a local reference sample is attached, sends a clean
     * `multipart/form-data` POST with `text`, `language=ru`, `reference_text`, and `reference_audio`
     * (plus `speaker_wav` alias? standard `reference_audio` field). Without a sample, sends JSON.
     */
    suspend fun synthesizeCustomCloneUrlToFile(
        endpointUrl: String,
        optionalBearerKey: String,
        sampleFile: File?,
        sampleTranscript: String,
        text: String,
        outputFile: File,
        customModel: String = "tts-1",
        customVoice: String = "nova"
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanUrl = endpointUrl.trim()
        if (cleanUrl.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Укажите URL вашего кастомного TTS / cloning сервера."))
        }
        val reqBuilder = Request.Builder().url(cleanUrl)
        val cleanKey = CloudLlmClient.sanitizeApiKey(optionalBearerKey)
        if (cleanKey.isNotBlank()) {
            reqBuilder.header("Authorization", "Bearer $cleanKey")
        }

        val hasSample = sampleFile != null && sampleFile.exists() && sampleFile.length() > 0L
        if (hasSample) {
            val audioMedia = when (sampleFile!!.extension.lowercase()) {
                "wav" -> "audio/wav".toMediaType()
                "ogg", "opus" -> "audio/ogg".toMediaType()
                "m4a" -> "audio/mp4".toMediaType()
                else -> "audio/mpeg".toMediaType()
            }
            val multipart = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("text", text.trim())
                .addFormDataPart("input", text.trim())
                .addFormDataPart("language", "ru")
                .addFormDataPart("model", customModel.trim().ifBlank { "tts-1" })
                .addFormDataPart("voice", customVoice.trim().ifBlank { "nova" })
                .addFormDataPart("reference_text", sampleTranscript.trim())
                .addFormDataPart(
                    "reference_audio",
                    sampleFile.name,
                    sampleFile.asRequestBody(audioMedia)
                )
                .build()
            reqBuilder.post(multipart)
        } else {
            val payload = JSONObject().apply {
                put("text", text.trim())
                put("input", text.trim())
                put("model", customModel.trim().ifBlank { "tts-1" })
                put("voice", customVoice.trim().ifBlank { "nova" })
                put("language", "ru")
                put("response_format", "mp3")
            }
            reqBuilder
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA))
        }

        val call = httpClient.newCall(reqBuilder.build())
        activeCall.set(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty()
                    return@withContext Result.failure(
                        IllegalStateException("TTS сервер HTTP ${resp.code}: ${CloudLlmClient.extractErrorMessage(err)}")
                    )
                }
                val bytes = resp.body?.bytes() ?: ByteArray(0)
                if (bytes.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("TTS сервер вернул пустой ответ."))
                }
                outputFile.parentFile?.mkdirs()
                outputFile.writeBytes(bytes)
                Result.success(outputFile)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    suspend fun synthesizeGeminiToWavFile(
        apiKey: String,
        endpointMode: GeminiEndpointMode,
        cachedUseVertex: Boolean,
        text: String,
        voiceName: String,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim().trim('"', '\'')
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Ключ Gemini не указан."))
        }
        val payload = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", text.trim())))
                    }
                )
            )
            put(
                "generationConfig",
                JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put(
                                "prebuiltVoiceConfig",
                                JSONObject().put("voiceName", voiceName)
                            )
                        )
                    )
                }
            )
        }

        val endpoints = when (endpointMode) {
            GeminiEndpointMode.AI_STUDIO -> listOf(geminiAiStudioBaseUrl)
            GeminiEndpointMode.VERTEX_EXPRESS -> listOf(geminiVertexBaseUrl)
            GeminiEndpointMode.AUTO -> if (cachedUseVertex) {
                listOf(geminiVertexBaseUrl, geminiAiStudioBaseUrl)
            } else {
                listOf(geminiAiStudioBaseUrl, geminiVertexBaseUrl)
            }
        }

        var lastError = "Gemini TTS недоступен"
        for (base in endpoints) {
            val url = "${base.trimEnd('/')}/models/gemini-2.5-flash-preview-tts:generateContent"
            val req = Request.Builder()
                .url(url)
                .header("x-goog-api-key", cleanKey)
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()
            val call = httpClient.newCall(req)
            activeCall.set(call)
            try {
                var shouldStop = false
                var okFile: File? = null
                call.execute().use { resp ->
                    val bodyStr = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        lastError = "Gemini TTS HTTP ${resp.code}: ${CloudLlmClient.extractErrorMessage(bodyStr)}"
                        if (resp.code != 400 && resp.code != 401 && resp.code != 403 && resp.code != 404) {
                            shouldStop = true
                        }
                        return@use
                    }
                    val root = JSONObject(bodyStr)
                    val b64 = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                        ?.optJSONObject(0)
                        ?.optJSONObject("inlineData")
                        ?.optString("data")
                        .orEmpty()
                    if (b64.isBlank()) {
                        lastError = "Gemini TTS не вернул аудиоданные."
                        return@use
                    }
                    val pcm = runCatching { Base64.decode(b64, Base64.DEFAULT) }
                        .getOrElse { java.util.Base64.getDecoder().decode(b64) }
                    val wav = GroqWhisperClient.pcm16ToWav(pcm, sampleRate = 24_000, channels = 1)
                    outputFile.parentFile?.mkdirs()
                    outputFile.writeBytes(wav)
                    okFile = outputFile
                }
                if (okFile != null) return@withContext Result.success(okFile!!)
                if (shouldStop) return@withContext Result.failure(IllegalStateException(lastError))
            } catch (t: Throwable) {
                lastError = t.message ?: t.javaClass.simpleName
            } finally {
                activeCall.compareAndSet(call, null)
            }
        }
        Result.failure(IllegalStateException(lastError))
    }

    suspend fun synthesizeOpenAiSpeechToMp3File(
        baseUrl: String,
        apiKey: String,
        voiceName: String,
        text: String,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanBase = baseUrl.trim().trimEnd('/')
        val cleanKey = apiKey.trim().trim('"', '\'')
        if (cleanBase.isBlank() || cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Кастомный OpenAI API не настроен."))
        }
        val endpoint = if (cleanBase.endsWith("/audio/speech")) cleanBase else "$cleanBase/audio/speech"
        val payload = JSONObject().apply {
            put("model", "tts-1")
            put("voice", voiceName)
            put("input", text.trim())
            put("response_format", "mp3")
        }
        val req = Request.Builder()
            .url(endpoint)
            .header("Authorization", "Bearer $cleanKey")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .build()
        val call = httpClient.newCall(req)
        activeCall.set(call)
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string().orEmpty()
                    return@withContext Result.failure(
                        IllegalStateException("OpenAI TTS HTTP ${resp.code}: ${CloudLlmClient.extractErrorMessage(err)}")
                    )
                }
                val bytes = resp.body?.bytes() ?: ByteArray(0)
                if (bytes.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("OpenAI TTS вернул пустое аудио."))
                }
                outputFile.parentFile?.mkdirs()
                outputFile.writeBytes(bytes)
                Result.success(outputFile)
            }
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            activeCall.compareAndSet(call, null)
        }
    }

    companion object {
        const val DEFAULT_FISH_AUDIO_BASE = "https://api.fish.audio"
        const val DEFAULT_FISH_AUDIO_MODEL = "s2.1-pro-free"
        const val DEFAULT_ELEVENLABS_BASE = "https://api.elevenlabs.io"
        const val DEFAULT_ELEVENLABS_MODEL = "eleven_multilingual_v2"

        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
        private val MSGPACK_MEDIA = "application/msgpack".toMediaType()
    }
}
