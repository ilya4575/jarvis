package ru.jarvis.assistant.feature.voice

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import ru.jarvis.assistant.core.cloud.GroqWhisperClient
import ru.jarvis.assistant.core.cloud.VoiceSttMode
import ru.jarvis.assistant.core.models.ModelCatalog
import ru.jarvis.assistant.core.models.ModelStorage
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

sealed class VoiceState {
    data object Idle : VoiceState()
    data class Recording(val partialText: String = "", val isCloudGroq: Boolean = false) : VoiceState()
    data class Transcribing(val statusRu: String = "Распознаю речь (Groq Whisper)…") : VoiceState()
    data class ResultReady(val recognizedText: String) : VoiceState()
    data class Error(val messageRu: String) : VoiceState()
}

/**
 * Multi-mode Russian Speech-to-Text engine:
 *  1. Native Android SpeechRecognizer (default free mode — spends ZERO Puter/API quota!)
 *  2. Groq Whisper (`whisper-large-v3-turbo`) when Groq API key is configured & selected
 *  3. Strictly Offline Vosk RU (`vosk-model-small-ru-0.22`)
 */
class OfflineVoiceEngine(
    private val storage: ModelStorage,
    private val prefs: JarvisPreferences? = null,
    private val groqWhisperClient: GroqWhisperClient = GroqWhisperClient(),
    private val context: Context? = null
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    @Volatile
    private var voskModel: Model? = null

    @Volatile
    private var loadedModelDirPath: String? = null

    private var nativeRecognizer: SpeechRecognizer? = null
    private var nativeCallback: ((String?, String?) -> Unit)? = null

    private val isRecordingFlag = AtomicBoolean(false)
    private var recordJob: Job? = null

    fun isGroqSttConfigured(): Boolean {
        val p = prefs ?: return false
        return p.voiceSttMode == VoiceSttMode.GROQ_FIRST && p.groqApiKey.isNotBlank()
    }

    fun isNativeAndroidSttAvailable(): Boolean {
        val ctx = context ?: return false
        return runCatching { SpeechRecognizer.isRecognitionAvailable(ctx) }.getOrDefault(false)
    }

    fun isModelAvailable(): Boolean =
        isNativeAndroidSttAvailable() ||
            isGroqSttConfigured() ||
            storage.verifyAndGetExtractedDir(ModelCatalog.VOSK_SMALL_RU).isSuccess

    @SuppressLint("MissingPermission")
    fun startRecording(onFinalResult: ((String?, String?) -> Unit)? = null) {
        if (isRecordingFlag.getAndSet(true)) return

        val mode = prefs?.voiceSttMode ?: VoiceSttMode.ANDROID_NATIVE
        when (mode) {
            VoiceSttMode.ANDROID_NATIVE -> {
                if (isNativeAndroidSttAvailable()) {
                    startNativeAndroidSpeech(onFinalResult)
                    return
                }
                if (prefs?.groqApiKey?.isNotBlank() == true) {
                    startGroqWhisperRecording(onFinalResult)
                    return
                }
                startLocalVoskRecording(onFinalResult)
            }
            VoiceSttMode.GROQ_FIRST -> {
                if (prefs?.groqApiKey?.isNotBlank() == true) {
                    startGroqWhisperRecording(onFinalResult)
                    return
                }
                if (isNativeAndroidSttAvailable()) {
                    startNativeAndroidSpeech(onFinalResult)
                    return
                }
                startLocalVoskRecording(onFinalResult)
            }
            VoiceSttMode.VOSK_ONLY -> startLocalVoskRecording(onFinalResult)
        }
    }

    private fun startNativeAndroidSpeech(onFinalResult: ((String?, String?) -> Unit)?) {
        val ctx = context?.applicationContext
        if (ctx == null) {
            isRecordingFlag.set(false)
            onFinalResult?.invoke(null, "Системный SpeechRecognizer недоступен.")
            return
        }
        nativeCallback = onFinalResult
        _state.value = VoiceState.Recording("Слушаю (Android STT)…", isCloudGroq = false)

        mainHandler.post {
            runCatching {
                nativeRecognizer?.destroy()
                val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _state.value = VoiceState.Recording("Говорите…", isCloudGroq = false)
                    }

                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() {
                        _state.value = VoiceState.Transcribing("Распознаю речь (Android)…")
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (partial.isNotEmpty()) {
                            _state.value = VoiceState.Recording(partial, isCloudGroq = false)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isRecordingFlag.set(false)
                        val text = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        val cb = nativeCallback
                        nativeCallback = null
                        if (text.isNotEmpty()) {
                            _state.value = VoiceState.ResultReady(text)
                            cb?.invoke(text, null)
                        } else {
                            val msg = "Речь не распознана. Попробуйте сказать чуть громче."
                            _state.value = VoiceState.Error(msg)
                            cb?.invoke(null, msg)
                        }
                    }

                    override fun onError(error: Int) {
                        isRecordingFlag.set(false)
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "Речь не распознана — попробуйте ещё раз."
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Время ожидания речи истекло."
                            SpeechRecognizer.ERROR_AUDIO -> "Ошибка микрофона."
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "Android SpeechRecognizer не смог распознать речь. В настройках API выберите Groq Whisper или Vosk (офлайн, после скачивания модели)."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения на микрофон."
                            else -> "Ошибка системного STT (код $error)."
                        }
                        val cb = nativeCallback
                        nativeCallback = null
                        _state.value = VoiceState.Error(msg)
                        cb?.invoke(null, msg)
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                }
                nativeRecognizer = sr
                sr.startListening(intent)
            }.onFailure { err ->
                isRecordingFlag.set(false)
                val msg = "Не удалось запустить Android SpeechRecognizer: ${err.message}"
                _state.value = VoiceState.Error(msg)
                nativeCallback?.invoke(null, msg)
                nativeCallback = null
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGroqWhisperRecording(onFinalResult: ((String?, String?) -> Unit)?) {
        val p = prefs ?: run {
            isRecordingFlag.set(false)
            return
        }
        val apiKey = p.groqApiKey
        val sttModel = p.groqSttModel

        _state.value = VoiceState.Recording("Слушаю (Groq Whisper)…", isCloudGroq = true)

        recordJob = scope.launch {
            var audioRecord: AudioRecord? = null
            val pcmOut = ByteArrayOutputStream(SAMPLE_RATE * 2 * 5)
            val startMs = System.currentTimeMillis()

            try {
                val minBuf = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufBytes = (minBuf * 2).coerceAtLeast(4096)

                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufBytes
                )
                if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("Микрофон недоступен или занят другим приложением.")
                }

                audioRecord.startRecording()
                val shortBuf = ShortArray(bufBytes / 2)
                val byteBuf = ByteArray(bufBytes)
                var lastUiUpdateMs = 0L

                while (isActive && isRecordingFlag.get()) {
                    val elapsedSec = ((System.currentTimeMillis() - startMs) / 1000L).toInt()
                    if (elapsedSec >= MAX_GROQ_RECORD_SECONDS) {
                        isRecordingFlag.set(false)
                        break
                    }
                    val read = audioRecord.read(shortBuf, 0, shortBuf.size)
                    if (read > 0) {
                        var sumSq = 0.0
                        for (i in 0 until read) {
                            val s = shortBuf[i].toInt()
                            sumSq += (s * s).toDouble()
                            byteBuf[i * 2] = (s and 0xFF).toByte()
                            byteBuf[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
                        }
                        pcmOut.write(byteBuf, 0, read * 2)

                        val now = System.currentTimeMillis()
                        if (now - lastUiUpdateMs >= 250L) {
                            lastUiUpdateMs = now
                            val rms = sqrt(sumSq / read).toInt()
                            val levelBars = when {
                                rms > 3500 -> "▮▮▮▮"
                                rms > 1800 -> "▮▮▮"
                                rms > 700 -> "▮▮"
                                else -> "▮"
                            }
                            _state.value = VoiceState.Recording(
                                partialText = "Groq Whisper • ${elapsedSec}с  $levelBars",
                                isCloudGroq = true
                            )
                        }
                    } else if (read < 0) {
                        throw IllegalStateException("Ошибка чтения микрофона (код $read).")
                    }
                }
            } catch (t: Throwable) {
                val msg = "Ошибка записи: ${t.message ?: t.javaClass.simpleName}"
                _state.value = VoiceState.Error(msg)
                onFinalResult?.invoke(null, msg)
                return@launch
            } finally {
                isRecordingFlag.set(false)
                runCatching { audioRecord?.stop() }
                runCatching { audioRecord?.release() }
            }

            val pcmBytes = pcmOut.toByteArray()
            if (pcmBytes.size < 1600) {
                val msg = "Запись слишком короткая — удерживайте и проговорите фразу."
                _state.value = VoiceState.Error(msg)
                onFinalResult?.invoke(null, msg)
                return@launch
            }

            _state.value = VoiceState.Transcribing("Распознаю речь (Groq Whisper)…")
            val res = groqWhisperClient.transcribePcm16(
                apiKey = apiKey,
                pcm16Bytes = pcmBytes,
                sampleRate = SAMPLE_RATE,
                model = sttModel,
                language = "ru"
            )
            res.onSuccess { text ->
                _state.value = VoiceState.ResultReady(text)
                onFinalResult?.invoke(text, null)
            }.onFailure { err ->
                val voskReady = storage.verifyAndGetExtractedDir(ModelCatalog.VOSK_SMALL_RU).isSuccess
                val extra = if (voskReady) "\n(Офлайн Vosk доступен в настройках речи.)" else ""
                val msg = (err.message ?: "Ошибка Groq Whisper") + extra
                _state.value = VoiceState.Error(msg)
                onFinalResult?.invoke(null, msg)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocalVoskRecording(onFinalResult: ((String?, String?) -> Unit)?) {
        val modelDirResult = storage.verifyAndGetExtractedDir(ModelCatalog.VOSK_SMALL_RU)
        val modelDir: File = modelDirResult.getOrElse {
            isRecordingFlag.set(false)
            val err = "Не скачан офлайн Vosk и не включён Android/Groq STT. Выберите системный микрофон Android в настройках или скачайте Vosk."
            _state.value = VoiceState.Error(err)
            onFinalResult?.invoke(null, err)
            return
        }

        _state.value = VoiceState.Recording("", isCloudGroq = false)

        recordJob = scope.launch {
            var audioRecord: AudioRecord? = null
            var recognizer: Recognizer? = null
            val finalParts = StringBuilder()

            try {
                val model = ensureModelLoaded(modelDir)
                recognizer = Recognizer(model, SAMPLE_RATE.toFloat())

                val minBuf = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufBytes = (minBuf * 2).coerceAtLeast(4096)

                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufBytes
                )

                if (audioRecord.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("Микрофон недоступен или занят другим приложением.")
                }

                audioRecord.startRecording()
                val pcmBuffer = ShortArray(bufBytes / 2)

                while (isActive && isRecordingFlag.get()) {
                    val read = audioRecord.read(pcmBuffer, 0, pcmBuffer.size)
                    if (read > 0) {
                        if (recognizer.acceptWaveForm(pcmBuffer, read)) {
                            val txt = parseVoskField(recognizer.result, "text")
                            if (txt.isNotBlank()) {
                                if (finalParts.isNotEmpty()) finalParts.append(' ')
                                finalParts.append(txt)
                            }
                            _state.value = VoiceState.Recording(finalParts.toString(), isCloudGroq = false)
                        } else {
                            val partial = parseVoskField(recognizer.partialResult, "partial")
                            val combined = listOf(finalParts.toString(), partial)
                                .filter { it.isNotBlank() }
                                .joinToString(" ")
                            _state.value = VoiceState.Recording(combined, isCloudGroq = false)
                        }
                    } else if (read < 0) {
                        throw IllegalStateException("Ошибка чтения аудиопотока (код $read).")
                    }
                }

                val tail = parseVoskField(recognizer.finalResult, "text")
                if (tail.isNotBlank()) {
                    if (finalParts.isNotEmpty()) finalParts.append(' ')
                    finalParts.append(tail)
                }

                val recognized = finalParts.toString().trim()
                if (recognized.isNotEmpty()) {
                    _state.value = VoiceState.ResultReady(recognized)
                    onFinalResult?.invoke(recognized, null)
                } else {
                    val msg = "Речь не распознана. Попробуйте сказать фразу чуть громче."
                    _state.value = VoiceState.Error(msg)
                    onFinalResult?.invoke(null, msg)
                }
            } catch (t: Throwable) {
                val msg = "Ошибка распознавания речи: ${t.message ?: t.javaClass.simpleName}"
                _state.value = VoiceState.Error(msg)
                onFinalResult?.invoke(null, msg)
            } finally {
                isRecordingFlag.set(false)
                runCatching { audioRecord?.stop() }
                runCatching { audioRecord?.release() }
                runCatching { recognizer?.close() }
            }
        }
    }

    fun stopRecording() {
        isRecordingFlag.set(false)
        mainHandler.post {
            runCatching { nativeRecognizer?.stopListening() }
        }
    }

    fun resetToIdle() {
        if (!isRecordingFlag.get()) {
            _state.value = VoiceState.Idle
        }
    }

    fun releaseModel() {
        stopRecording()
        recordJob?.cancel()
        mainHandler.post {
            runCatching { nativeRecognizer?.destroy() }
            nativeRecognizer = null
        }
        runCatching { voskModel?.close() }
        voskModel = null
        loadedModelDirPath = null
    }

    @Synchronized
    private fun ensureModelLoaded(dir: File): Model {
        val current = voskModel
        if (current != null && loadedModelDirPath == dir.absolutePath) {
            return current
        }
        runCatching { current?.close() }
        val loaded = Model(dir.absolutePath)
        voskModel = loaded
        loadedModelDirPath = dir.absolutePath
        return loaded
    }

    private fun parseVoskField(jsonStr: String?, field: String): String {
        if (jsonStr.isNullOrBlank()) return ""
        return runCatching {
            JSONObject(jsonStr).optString(field, "").trim()
        }.getOrDefault("")
    }

    companion object {
        const val SAMPLE_RATE = 16000
        private const val MAX_GROQ_RECORD_SECONDS = 60
    }
}
