package ru.jarvis.assistant.core.cloud

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/**
 * Fast speech-to-text client powered by Groq Whisper (`whisper-large-v3-turbo`).
 * Converts raw 16 kHz mono PCM16 audio into a standard WAV container in memory
 * and uploads it directly to Groq's OpenAI-compatible audio transcriptions API.
 */
class GroqWhisperClient(
    private val groqBaseUrl: String = CloudLlmClient.DEFAULT_GROQ_BASE
) {
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun transcribePcm16(
        apiKey: String,
        pcm16Bytes: ByteArray,
        sampleRate: Int = 16000,
        model: String = DEFAULT_STT_MODEL,
        language: String = "ru"
    ): Result<String> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Ключ Groq не указан."))
        }
        if (pcm16Bytes.size < 1600) {
            return@withContext Result.failure(IllegalArgumentException("Слишком короткая запись — скажите фразу чуть дольше."))
        }

        val wavBytes = pcm16ToWav(pcm16Bytes, sampleRate = sampleRate, channels = 1, bitsPerSample = 16)
        val modelId = model.trim().ifEmpty { DEFAULT_STT_MODEL }

        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "file",
                "voice.wav",
                wavBytes.toRequestBody("audio/wav".toMediaType())
            )
            .addFormDataPart("model", modelId)
            .addFormDataPart("language", language)
            .addFormDataPart("response_format", "json")
            .addFormDataPart("temperature", "0")
            .build()

        val req = Request.Builder()
            .url("${groqBaseUrl.trimEnd('/')}/audio/transcriptions")
            .header("Authorization", "Bearer $cleanKey")
            .post(multipart)
            .build()

        runCatching {
            httpClient.newCall(req).execute().use { resp ->
                val bodyStr = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException(
                        "Groq Whisper (HTTP ${resp.code}): ${CloudLlmClient.extractErrorMessage(bodyStr)}"
                    )
                }
                val text = JSONObject(bodyStr).optString("text", "").trim()
                if (text.isBlank()) {
                    throw IllegalStateException("Речь не распознана. Попробуйте сказать чуть громче.")
                }
                text
            }
        }
    }

    companion object {
        const val DEFAULT_STT_MODEL = "whisper-large-v3-turbo"

        /** Wraps raw little-endian PCM16 bytes in a standard 44-byte RIFF/WAVE header. */
        fun pcm16ToWav(
            pcmData: ByteArray,
            sampleRate: Int = 16000,
            channels: Int = 1,
            bitsPerSample: Int = 16
        ): ByteArray {
            val byteRate = sampleRate * channels * (bitsPerSample / 8)
            val blockAlign = channels * (bitsPerSample / 8)
            val dataSize = pcmData.size
            val chunkSize = 36 + dataSize

            val out = ByteArrayOutputStream(44 + dataSize)
            out.write("RIFF".toByteArray(Charsets.US_ASCII))
            writeIntLe(out, chunkSize)
            out.write("WAVE".toByteArray(Charsets.US_ASCII))
            out.write("fmt ".toByteArray(Charsets.US_ASCII))
            writeIntLe(out, 16) // PCM subchunk size
            writeShortLe(out, 1) // PCM audio format
            writeShortLe(out, channels)
            writeIntLe(out, sampleRate)
            writeIntLe(out, byteRate)
            writeShortLe(out, blockAlign)
            writeShortLe(out, bitsPerSample)
            out.write("data".toByteArray(Charsets.US_ASCII))
            writeIntLe(out, dataSize)
            out.write(pcmData)
            return out.toByteArray()
        }

        private fun writeIntLe(out: ByteArrayOutputStream, value: Int) {
            out.write(value and 0xFF)
            out.write((value shr 8) and 0xFF)
            out.write((value shr 16) and 0xFF)
            out.write((value shr 24) and 0xFF)
        }

        private fun writeShortLe(out: ByteArrayOutputStream, value: Int) {
            out.write(value and 0xFF)
            out.write((value shr 8) and 0xFF)
        }
    }
}
