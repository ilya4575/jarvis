package ru.jarvis.assistant.core.cloud

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.http.SslError
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import ru.jarvis.assistant.R
import ru.jarvis.assistant.core.chat.ChatContextManager
import ru.jarvis.assistant.core.inference.ChatTurn
import ru.jarvis.assistant.core.inference.GenerationConfig
import ru.jarvis.assistant.core.inference.GenerationResult
import ru.jarvis.assistant.core.inference.LlamaInferenceEngine
import ru.jarvis.assistant.core.prefs.JarvisPreferences
import ru.jarvis.assistant.ui.MainActivity
import java.io.File
import java.net.URI
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

data class PerchanceBridgeState(
    val embedReady: Boolean = false,
    val verified: Boolean = false,
    val verifying: Boolean = false,
    val verifyStatus: PerchanceVerifyStatus = PerchanceVerifyStatus.IDLE,
    val statusRu: String = "Проверка не выполнена",
    val verifyUrl: String = PerchanceWebViewBridge.DEFAULT_TEXT_EMBED_URL,
    val imageUrl: String = PerchanceWebViewBridge.DEFAULT_IMAGE_API_URL
)

/**
 * Pure Kotlin prompt formatting helpers for Perchance (unit-testable on JVM without Android WebView).
 */
object PerchancePromptBuilder {

    fun buildInstruction(
        history: List<ChatTurn>,
        userPrompt: String,
        config: GenerationConfig
    ): String {
        val sys = LlamaInferenceEngine.buildSystemInstruction(config)
        val assistant = config.assistantName.ifBlank { "Jarvis" }
        val window = ChatContextManager.clampWindowSize(config.contextWindowSize)
        return buildString {
            append(sys)
            append("\n\nВажно: отвечай только от имени [[")
            append(assistant)
            append("]], не пиши реплики за [[Пользователь]].\n\n")
            append("<MESSAGES>\n")
            for (turn in history.takeLast(window)) {
                val content = turn.content.trim()
                if (content.isEmpty()) continue
                val speaker = if (turn.role == "user") "Пользователь" else assistant
                append("[[").append(speaker).append("]]: ").append(content).append("\n\n")
            }
            val cleanPrompt = userPrompt.trim().ifEmpty { "Опиши это изображение подробно на русском языке." }
            append("[[Пользователь]]: ").append(cleanPrompt).append("\n")
            append("</MESSAGES>\n\n")
            append(">>> TASK: Напиши следующий естественный и полезный ответ от имени [[")
            append(assistant)
            append("]] на русском языке.")
        }
    }

    fun buildStartWith(assistantName: String): String =
        "[[${assistantName.ifBlank { "Jarvis" }}]]: "

    fun buildStopSequences(): List<String> = listOf(
        "\n\n[[",
        "\n[[Пользователь]]",
        "\n[[User]]"
    )

    fun cleanResponsePrefix(raw: String, assistantName: String): String {
        val name = assistantName.ifBlank { "Jarvis" }
        return raw
            .removePrefix("[[$name]]:")
            .removePrefix("[[$name]]: ")
            .removePrefix("$name:")
            .trim()
    }
}

/**
 * Background Chromium WebView bridge to Perchance:
 * 1) Text chat streaming via official embed (editable URL, default https://text-generation.perchance.org/embed).
 * 2) Image generation via Perchance Image API v1 (default https://perchance.org/perchance-ai-api)
 *    with iframe+postMessage and automatic fallback to image-generation.perchance.org/embed.
 * 3) Network-aware Cloudflare/Turnstile auto-verification with ConnectivityManager.NetworkCallback,
 *    2.5s debounce, rate-limited system notifications, SSL safety, and URL-change reset.
 */
class PerchanceWebViewBridge(
    context: Context,
    private val prefs: JarvisPreferences
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val stateMachine = PerchanceVerificationStateMachine()
    private val imageHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private var webView: WebView? = null
    private var attachedHost: ViewGroup? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var pendingDebounceRunnable: Runnable? = null
    private var verifyTimeoutRunnable: Runnable? = null

    private val _bridgeState = MutableStateFlow(
        PerchanceBridgeState(
            verifyUrl = prefs.perchanceVerifyUrl,
            imageUrl = prefs.perchanceImageUrl
        )
    )
    val bridgeState: StateFlow<PerchanceBridgeState> = _bridgeState.asStateFlow()

    private val embedReadyDeferred = AtomicReference<CompletableDeferred<Boolean>>(CompletableDeferred())
    private val verifiedDeferred = AtomicReference<CompletableDeferred<Boolean>>(CompletableDeferred())

    private data class ActiveStream(
        val requestId: String,
        val assistantName: String,
        val startMs: Long,
        val onToken: (String) -> Unit,
        val collected: StringBuilder = StringBuilder(),
        val finished: AtomicBoolean = AtomicBoolean(false),
        val onDone: (GenerationResult) -> Unit
    )

    private data class ActiveImageRequest(
        val requestId: String,
        val finished: AtomicBoolean = AtomicBoolean(false),
        val onDone: (ok: Boolean, url: String?, dataUrl: String?, seed: Long?, error: String?) -> Unit
    )

    private val activeStream = AtomicReference<ActiveStream?>(null)
    private val activeImageReq = AtomicReference<ActiveImageRequest?>(null)

    @Volatile
    private var suppressNextSuccessNotification = false

    init {
        createNotificationChannel()
        registerNetworkMonitor()
    }

    fun isVerified(): Boolean = stateMachine.isVerified()

    fun warmup() {
        mainHandler.post { ensureWebViewCreated() }
    }

    fun attachToContainer(container: ViewGroup) {
        mainHandler.post {
            val wv = ensureWebViewCreated() ?: return@post
            val parent = wv.parent as? ViewGroup
            if (parent === container) return@post
            parent?.removeView(wv)
            attachedHost = container
            container.addView(
                wv,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            wv.onResume()
        }
    }

    fun detachFromContainer(container: ViewGroup) {
        mainHandler.post {
            val wv = webView ?: return@post
            if (wv.parent === container) {
                container.removeView(wv)
                if (attachedHost === container) attachedHost = null
            }
        }
    }

    /** Called when the user changes Perchance URL in settings: resets verification & auto-rechecks. */
    fun updateUrlsAndReverify(newVerifyUrl: String, newImageUrl: String) {
        val cleanVerify = newVerifyUrl.trim().ifBlank { DEFAULT_TEXT_EMBED_URL }
        val cleanImage = newImageUrl.trim().ifBlank { DEFAULT_IMAGE_API_URL }
        prefs.perchanceVerifyUrl = cleanVerify
        prefs.perchanceImageUrl = cleanImage
        stateMachine.onUrlChanged(cleanVerify, System.currentTimeMillis())
        syncStateFlow(embedReady = false, verifying = true)
        reloadBridge(autoTriggerVerify = true)
    }

    /** Explicitly starts/repeats verification (e.g. "Проверить" button in dialog or settings). */
    fun requestVerification(manualTrigger: Boolean = true) {
        mainHandler.post {
            stateMachine.onCheckStarted(
                System.currentTimeMillis(),
                if (manualTrigger) "Проверка Perchance (Cloudflare)…" else "Автопроверка Perchance…"
            )
            if (verifiedDeferred.get().isCompleted) {
                verifiedDeferred.set(CompletableDeferred())
            }
            syncStateFlow(verifying = true)
            val wv = ensureWebViewCreated()
            if (wv == null) {
                stateMachine.onError("WebView недоступен на устройстве")
                syncStateFlow(verifying = false)
                return@post
            }
            if (_bridgeState.value.embedReady) {
                wv.evaluateJavascript("window.jarvisRequestVerify && window.jarvisRequestVerify();", null)
            } else {
                wv.loadDataWithBaseURL(PARENT_BASE_URL, buildHostHtml(prefs.perchanceVerifyUrl, prefs.perchanceImageUrl), "text/html", "UTF-8", null)
            }
            scheduleVerifyTimeout(VERIFY_TIMEOUT_MS, notifyIfStillUnverified = !manualTrigger)
        }
    }

    /** Called when user presses the mandatory "×" button in the verification dialog. */
    fun onVerifyDialogDismissedByUser() {
        cancelVerifyTimeout()
        stateMachine.onDialogClosedWithX()
        syncStateFlow(verifying = false)
    }

    /** Clears cookies + WebView storage and triggers a fresh check. */
    fun clearStorageAndReverify() {
        mainHandler.post {
            runCatching {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
                webView?.clearCache(true)
            }
            stateMachine.onSessionInvalidated("Кэш и cookies очищены — запуск новой проверки…")
            syncStateFlow(embedReady = false, verifying = true)
            reloadBridge(autoTriggerVerify = true)
        }
    }

    fun reloadBridge(autoTriggerVerify: Boolean = true) {
        mainHandler.post {
            embedReadyDeferred.set(CompletableDeferred())
            verifiedDeferred.set(CompletableDeferred())
            stateMachine.onCheckStarted(System.currentTimeMillis(), "Загрузка и проверка Perchance…")
            syncStateFlow(embedReady = false, verifying = true)
            val wv = ensureWebViewCreated() ?: return@post
            wv.loadDataWithBaseURL(
                PARENT_BASE_URL,
                buildHostHtml(prefs.perchanceVerifyUrl, prefs.perchanceImageUrl),
                "text/html",
                "UTF-8",
                null
            )
            if (autoTriggerVerify) {
                scheduleVerifyTimeout(VERIFY_TIMEOUT_MS, notifyIfStillUnverified = true)
            }
        }
    }

    private fun registerNetworkMonitor() {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()

        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                scheduleDebouncedNetworkCheck(cm, network)
            }

            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    scheduleDebouncedNetworkCheck(cm, network)
                }
            }

            override fun onLost(network: Network) {
                val active = cm.activeNetwork
                if (active == null) {
                    mainHandler.post {
                        stateMachine.onNetworkLost()
                        syncStateFlow(verifying = false)
                    }
                }
            }
        }
        networkCallback = cb
        runCatching { cm.registerNetworkCallback(req, cb) }
    }

    private fun scheduleDebouncedNetworkCheck(cm: ConnectivityManager, network: Network) {
        if (!prefs.perchanceEnabled) return
        val caps = runCatching { cm.getNetworkCapabilities(network) }.getOrNull() ?: return
        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELL"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "OTHER"
        }
        val sig = "$transport:${network.hashCode()}"
        pendingDebounceRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = Runnable {
            val shouldRecheck = stateMachine.onNetworkChanged(
                networkSignature = sig,
                nowMs = System.currentTimeMillis(),
                enabled = prefs.perchanceEnabled
            )
            if (shouldRecheck) {
                syncStateFlow(verifying = true)
                reloadBridge(autoTriggerVerify = true)
            }
        }
        pendingDebounceRunnable = r
        mainHandler.postDelayed(r, 2_500L)
    }

    private fun scheduleVerifyTimeout(timeoutMs: Long, notifyIfStillUnverified: Boolean) {
        cancelVerifyTimeout()
        val r = Runnable {
            if (!stateMachine.isVerified()) {
                stateMachine.onNeedsManualVerification(
                    "Автопроверка заняла слишком долго (~30 сек) — требуется ручное подтверждение Cloudflare."
                )
                syncStateFlow(verifying = false)
                if (notifyIfStillUnverified && stateMachine.shouldPostManualActionNotification(System.currentTimeMillis())) {
                    postSystemNotification(
                        title = "Нужна проверка Perchance",
                        body = "Сменилась сеть или истекла сессия Cloudflare. Нажмите, чтобы открыть окно проверки.",
                        openVerifyDialog = true
                    )
                }
            }
        }
        verifyTimeoutRunnable = r
        mainHandler.postDelayed(r, timeoutMs)
    }

    private fun cancelVerifyTimeout() {
        verifyTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        verifyTimeoutRunnable = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebViewCreated(): WebView? {
        webView?.let { return it }
        return try {
            val wv = WebView(appContext)
            val settings = wv.settings
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            val rawUa = settings.userAgentString
            settings.userAgentString = rawUa.replace("; wv)", ")").replace("Version/4.0 ", "")

            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)

            wv.webViewClient = object : WebViewClient() {
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        stateMachine.onError("Ошибка сети: ${error?.description ?: "нет соединения"}")
                        syncStateFlow(verifying = false)
                    }
                }

                override fun onReceivedSslError(
                    view: WebView?,
                    handler: SslErrorHandler?,
                    error: SslError?
                ) {
                    // Never bypass SSL errors silently!
                    handler?.cancel()
                    stateMachine.onError("Ошибка SSL-сертификата (${error?.primaryError ?: "SSL"})")
                    syncStateFlow(verifying = false)
                }
            }
            wv.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean = true
            }
            wv.addJavascriptInterface(JsBridgeCallback(), "AndroidPerchanceBridge")

            webView = wv
            stateMachine.onCheckStarted(System.currentTimeMillis(), "Загрузка Perchance embed…")
            syncStateFlow(embedReady = false, verifying = true)
            wv.loadDataWithBaseURL(
                PARENT_BASE_URL,
                buildHostHtml(prefs.perchanceVerifyUrl, prefs.perchanceImageUrl),
                "text/html",
                "UTF-8",
                null
            )
            wv
        } catch (t: Throwable) {
            stateMachine.onError("WebView недоступен на устройстве: ${t.message}")
            syncStateFlow(verifying = false)
            null
        }
    }

    suspend fun testConnection(timeoutMs: Long = 30_000L): CloudTestResult {
        warmup()
        val ready = withTimeoutOrNull(14_000L) { embedReadyDeferred.get().await() } == true
        if (!ready) {
            stateMachine.onNeedsManualVerification("Embed не загрузился — проверьте интернет/URL и нажмите «Проверить»")
            syncStateFlow(verifying = false)
            return CloudTestResult(
                provider = CloudProvider.PERCHANCE,
                ok = false,
                summaryRu = "Embed не загрузился (проверьте интернет/URL и нажмите «Проверить»)"
            )
        }

        if (stateMachine.isVerified()) {
            return CloudTestResult(
                provider = CloudProvider.PERCHANCE,
                ok = true,
                summaryRu = "Проверка пройдена (Perchance активен)"
            )
        }

        requestVerification(manualTrigger = true)
        val ok = withTimeoutOrNull(timeoutMs) { verifiedDeferred.get().await() } == true
        return if (ok) {
            CloudTestResult(
                provider = CloudProvider.PERCHANCE,
                ok = true,
                summaryRu = "Проверка пройдена (Cloudflare верифицирован)"
            )
        } else {
            stateMachine.onNeedsManualVerification("Нужна ручная проверка Cloudflare — откройте окно проверки")
            syncStateFlow(verifying = false)
            CloudTestResult(
                provider = CloudProvider.PERCHANCE,
                ok = false,
                summaryRu = "Нужна проверка Cloudflare — нажмите «Окно проверки»"
            )
        }
    }

    suspend fun stream(
        history: List<ChatTurn>,
        userPrompt: String,
        imagePath: String?,
        config: GenerationConfig,
        onToken: (String) -> Unit
    ): GenerationResult {
        if (!stateMachine.isVerified()) {
            return GenerationResult.Failed("$PERCHANCE_VERIFY_REQUIRED_TOKEN Требуется проверка Perchance (Cloudflare).")
        }
        warmup()
        val ready = withTimeoutOrNull(14_000L) { embedReadyDeferred.get().await() } == true
        if (!ready) {
            stateMachine.onNeedsManualVerification("Perchance WebView-мост не готов")
            syncStateFlow(verifying = false)
            return GenerationResult.Failed("$PERCHANCE_VERIFY_REQUIRED_TOKEN Perchance WebView-мост не загрузился — откройте окно проверки.")
        }

        val requestId = "jarvis_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val instruction = PerchancePromptBuilder.buildInstruction(history, userPrompt, config)
        val startWith = PerchancePromptBuilder.buildStartWith(config.assistantName)
        val stops = PerchancePromptBuilder.buildStopSequences()

        val encodedImage = encodeImageBase64(imagePath)
        val payloadObj = JSONObject().apply {
            put("requestId", requestId)
            put("instruction", instruction)
            put("startWith", startWith)
            put("stopSequences", JSONArray(stops))
            put("generatorName", "ai-character-chat")
            if (encodedImage != null) {
                put("imageMime", encodedImage.first)
                put("imageBase64", encodedImage.second)
            }
        }

        val startMs = System.currentTimeMillis()
        val result = withTimeoutOrNull(110_000L) {
            suspendCancellableCoroutine<GenerationResult> { cont ->
                val streamObj = ActiveStream(
                    requestId = requestId,
                    assistantName = config.assistantName,
                    startMs = startMs,
                    onToken = onToken,
                    onDone = { res ->
                        if (cont.isActive) cont.resume(res)
                    }
                )
                activeStream.getAndSet(streamObj)?.let { old ->
                    if (old.finished.compareAndSet(false, true)) {
                        old.onDone(GenerationResult.Cancelled(old.collected.toString()))
                    }
                }

                val jsArg = JSONObject.quote(payloadObj.toString())
                mainHandler.post {
                    webView?.evaluateJavascript("window.jarvisStartStream && window.jarvisStartStream($jsArg);", null)
                }

                cont.invokeOnCancellation { cancelActive() }
            }
        }

        if (result == null) {
            cancelActive()
            stateMachine.onNeedsManualVerification("Таймаут Perchance — требуется проверка Cloudflare")
            syncStateFlow(verifying = false)
            return GenerationResult.Failed(
                "$PERCHANCE_VERIFY_REQUIRED_TOKEN Perchance: таймаут ожидания — пройдите проверку Cloudflare."
            )
        }
        return result
    }

    /**
     * A4: Generates an image via Perchance inside the Chromium WebView (no keys, iframe+postMessage).
     * Supports both https://perchance.org/perchance-ai-api (official Image API v1) and
     * https://image-generation.perchance.org/embed fallback.
     */
    suspend fun generateImage(
        prompt: String,
        resolution: String = "768x768",
        negativePrompt: String = ""
    ): PerchanceImageResult {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isEmpty()) {
            return PerchanceImageResult(ok = false, errorRu = "Укажите описание изображения.")
        }
        warmup()
        withTimeoutOrNull(8_000L) { embedReadyDeferred.get().await() }

        val reqId = "img_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val resolvedUrl = prefs.perchanceImageUrl.let { raw ->
            if (raw.contains("perchance-ai-api", ignoreCase = true) || raw.isBlank()) {
                DEFAULT_IMAGE_API_URL
            } else raw
        }
        val payload = JSONObject().apply {
            put("id", reqId)
            put("prompt", cleanPrompt)
            put("resolution", resolution)
            put("negativePrompt", negativePrompt)
            put("imageApiUrl", resolvedUrl)
        }

        val rawOutcome = withTimeoutOrNull(38_000L) {
            suspendCancellableCoroutine<PerchanceRawImageOutcome> { cont ->
                val reqObj = ActiveImageRequest(
                    requestId = reqId,
                    onDone = { ok, url, dataUrl, seed, err ->
                        if (cont.isActive) {
                            cont.resume(PerchanceRawImageOutcome(ok, url, dataUrl, seed, err))
                        }
                    }
                )
                activeImageReq.getAndSet(reqObj)?.let { old ->
                    if (old.finished.compareAndSet(false, true)) {
                        old.onDone(false, null, null, null, "Отменено новым запросом")
                    }
                }
                val jsArg = JSONObject.quote(payload.toString())
                mainHandler.post {
                    webView?.evaluateJavascript("window.jarvisGenerateImage && window.jarvisGenerateImage($jsArg);", null)
                }
                cont.invokeOnCancellation {
                    activeImageReq.compareAndSet(reqObj, null)
                }
            }
        } ?: return PerchanceImageResult(
            ok = false,
            errorRu = "Таймаут Perchance Embed (38 сек)."
        )

        if (!rawOutcome.ok) {
            val err = rawOutcome.error.orEmpty()
            val needsVerify = err.contains("verify", ignoreCase = true) ||
                err.contains("cloudflare", ignoreCase = true) ||
                err.contains("invalid_key", ignoreCase = true)
            if (needsVerify) {
                stateMachine.onNeedsManualVerification("Perchance запросил повторную проверку для генерации картинок")
                syncStateFlow(verifying = false)
            }
            return PerchanceImageResult(
                ok = false,
                needsVerification = needsVerify,
                errorRu = err.ifBlank { "Не удалось сгенерировать изображение через Perchance." }
            )
        }

        // Persist image locally so it can be viewed, saved to gallery, and shared
        val localFile = saveGeneratedImageLocally(rawOutcome.dataUrl, rawOutcome.url)
        if (localFile == null) {
            return PerchanceImageResult(
                ok = false,
                remoteUrl = rawOutcome.url,
                errorRu = "Изображение создано, но не удалось скачать или сохранить файл локально."
            )
        }

        return PerchanceImageResult(
            ok = true,
            localFilePath = localFile.absolutePath,
            remoteUrl = rawOutcome.url,
            seed = rawOutcome.seed
        )
    }

    private data class PerchanceRawImageOutcome(
        val ok: Boolean,
        val url: String?,
        val dataUrl: String?,
        val seed: Long?,
        val error: String?
    )

    private suspend fun saveGeneratedImageLocally(dataUrl: String?, remoteUrl: String?): File? =
        withContext(Dispatchers.IO) {
            val outDir = File(appContext.filesDir, "generated_images").apply { mkdirs() }
            if (!dataUrl.isNullOrBlank() && dataUrl.contains("base64,")) {
                val ext = when {
                    dataUrl.contains("image/jpeg") || dataUrl.contains("image/jpg") -> "jpg"
                    dataUrl.contains("image/webp") -> "webp"
                    else -> "png"
                }
                val b64 = dataUrl.substringAfter("base64,")
                val bytes = runCatching { Base64.decode(b64, Base64.DEFAULT) }.getOrNull()
                if (bytes != null && bytes.size > 128) {
                    val f = File(outDir, "perchance_${System.currentTimeMillis()}.$ext")
                    f.writeBytes(bytes)
                    return@withContext f
                }
            }
            if (!remoteUrl.isNullOrBlank() && (remoteUrl.startsWith("https://") || remoteUrl.startsWith("http://"))) {
                val req = Request.Builder().url(remoteUrl).get().build()
                runCatching {
                    imageHttpClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) return@use null
                        val bytes = resp.body?.bytes() ?: return@use null
                        if (bytes.size <= 128) return@use null
                        val ct = resp.header("Content-Type").orEmpty()
                        val ext = when {
                            ct.contains("jpeg") || ct.contains("jpg") -> "jpg"
                            ct.contains("webp") -> "webp"
                            else -> "png"
                        }
                        val f = File(outDir, "perchance_${System.currentTimeMillis()}.$ext")
                        f.writeBytes(bytes)
                        f
                    }
                }.getOrNull()?.let { return@withContext it }
            }
            null
        }

    fun cancelActive() {
        val current = activeStream.getAndSet(null) ?: return
        val reqId = current.requestId
        mainHandler.post {
            val quoted = JSONObject.quote(reqId)
            webView?.evaluateJavascript("window.jarvisStopStream && window.jarvisStopStream($quoted);", null)
        }
        if (current.finished.compareAndSet(false, true)) {
            current.onDone(GenerationResult.Cancelled(current.collected.toString()))
        }
    }

    fun destroy() {
        cancelActive()
        cancelVerifyTimeout()
        pendingDebounceRunnable?.let { mainHandler.removeCallbacks(it) }
        networkCallback?.let { cb ->
            val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            runCatching { cm?.unregisterNetworkCallback(cb) }
        }
        networkCallback = null
        mainHandler.post {
            webView?.let { wv ->
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.destroy()
            }
            webView = null
        }
    }

    private fun syncStateFlow(
        embedReady: Boolean = _bridgeState.value.embedReady,
        verifying: Boolean = stateMachine.state.status == PerchanceVerifyStatus.CHECKING
    ) {
        val snap = stateMachine.state
        _bridgeState.value = PerchanceBridgeState(
            embedReady = embedReady,
            verified = snap.isVerified,
            verifying = verifying,
            verifyStatus = snap.status,
            statusRu = snap.statusMessageRu,
            verifyUrl = prefs.perchanceVerifyUrl,
            imageUrl = prefs.perchanceImageUrl
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                VERIFY_CHANNEL_ID,
                "Проверка Perchance",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Уведомления о статусе проверки Cloudflare для Perchance"
            }
            nm.createNotificationChannel(ch)
        }
    }

    fun postSystemNotification(title: String, body: String, openVerifyDialog: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(appContext, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        val intent = Intent(appContext, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (openVerifyDialog) putExtra(MainActivity.EXTRA_OPEN_PERCHANCE_VERIFY, true)
        }
        val pi = PendingIntent.getActivity(
            appContext,
            if (openVerifyDialog) 4211 else 4212,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(appContext, VERIFY_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_jarvis_status)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(if (openVerifyDialog) VERIFY_NEEDED_NOTIF_ID else VERIFY_OK_NOTIF_ID, notif)
    }

    private suspend fun encodeImageBase64(path: String?): Pair<String, String>? = withContext(Dispatchers.IO) {
        if (path.isNullOrBlank()) return@withContext null
        val file = File(path)
        if (!file.exists() || !file.isFile || file.length() <= 0L) return@withContext null
        runCatching {
            val bytes = file.readBytes()
            val mime = when (file.extension.lowercase()) {
                "png" -> "image/png"
                "webp" -> "image/webp"
                else -> "image/jpeg"
            }
            mime to Base64.encodeToString(bytes, Base64.NO_WRAP)
        }.getOrNull()
    }

    private inner class JsBridgeCallback {
        @JavascriptInterface
        fun onEmbedReady() {
            embedReadyDeferred.get().complete(true)
            if (!stateMachine.isVerified()) {
                stateMachine.onCheckStarted(System.currentTimeMillis(), "Embed загружен — проверка Cloudflare…")
            }
            syncStateFlow(embedReady = true, verifying = !stateMachine.isVerified())
        }

        @JavascriptInterface
        fun onVerifying() {
            stateMachine.onCheckStarted(System.currentTimeMillis(), "Проверка Cloudflare Turnstile…")
            syncStateFlow(verifying = true)
        }

        @JavascriptInterface
        fun onVerified() {
            cancelVerifyTimeout()
            val wasVerifiedBefore = stateMachine.isVerified()
            stateMachine.onVerified(System.currentTimeMillis())
            verifiedDeferred.get().complete(true)
            syncStateFlow(embedReady = true, verifying = false)
            if (!wasVerifiedBefore && !suppressNextSuccessNotification) {
                postSystemNotification(
                    title = "Проверка Perchance пройдена",
                    body = "Чат и генерация изображений Perchance готовы к работе.",
                    openVerifyDialog = false
                )
            }
        }

        @JavascriptInterface
        fun onStreamChunk(requestId: String, chunk: String) {
            val st = activeStream.get() ?: return
            if (st.requestId != requestId || st.finished.get()) return
            if (chunk.isNotEmpty()) {
                st.collected.append(chunk)
                st.onToken(chunk)
            }
        }

        @JavascriptInterface
        fun onStreamEnd(requestId: String) {
            val st = activeStream.get() ?: return
            if (st.requestId != requestId) return
            if (st.finished.compareAndSet(false, true)) {
                activeStream.compareAndSet(st, null)
                val finalText = PerchancePromptBuilder.cleanResponsePrefix(st.collected.toString(), st.assistantName)
                val elapsed = (System.currentTimeMillis() - st.startMs).coerceAtLeast(1L)
                if (finalText.isBlank()) {
                    st.onDone(GenerationResult.Failed("Perchance вернул пустой ответ."))
                } else {
                    st.onDone(GenerationResult.Completed(text = finalText, elapsedMs = elapsed))
                }
            }
        }

        @JavascriptInterface
        fun onStreamError(requestId: String, status: String) {
            val st = activeStream.get() ?: return
            if (st.requestId != requestId) return
            if (st.finished.compareAndSet(false, true)) {
                activeStream.compareAndSet(st, null)
                if (status.contains("abort_due_to_stop_stream")) {
                    st.onDone(GenerationResult.Cancelled(st.collected.toString()))
                    return
                }
                if (status.contains("invalid_key") || status.contains("verify")) {
                    stateMachine.onSessionInvalidated("Сессия Perchance устарела — нужна проверка Cloudflare")
                    syncStateFlow(verifying = false)
                    st.onDone(GenerationResult.Failed("$PERCHANCE_VERIFY_REQUIRED_TOKEN Требуется повторная проверка Cloudflare."))
                    return
                }
                val friendly = when {
                    status.contains("network_busy") -> "Сервер Perchance сейчас перегружен (network_busy)."
                    status.contains("stale") -> "Поток Perchance прервался (stale)."
                    else -> "Perchance ошибка: $status"
                }
                st.onDone(GenerationResult.Failed(friendly))
            }
        }

        @JavascriptInterface
        fun onImageResult(requestId: String, ok: Boolean, url: String, dataUrl: String, seed: String, error: String) {
            val req = activeImageReq.get() ?: return
            if (req.requestId != requestId) return
            if (req.finished.compareAndSet(false, true)) {
                activeImageReq.compareAndSet(req, null)
                req.onDone(
                    ok,
                    url.ifBlank { null },
                    dataUrl.ifBlank { null },
                    seed.toLongOrNull(),
                    error.ifBlank { null }
                )
            }
        }
    }

    companion object {
        const val PARENT_BASE_URL = "https://null.perchance.org/"
        const val DEFAULT_TEXT_EMBED_URL = "https://text-generation.perchance.org/embed"
        const val DEFAULT_IMAGE_API_URL = "https://image-generation.perchance.org/embed"
        const val FALLBACK_IMAGE_EMBED_URL = "https://image-generation.perchance.org/embed"
        const val PERCHANCE_VERIFY_REQUIRED_TOKEN = "[[PERCHANCE_VERIFY_REQUIRED]]"

        private const val VERIFY_TIMEOUT_MS = 32_000L
        private const val VERIFY_CHANNEL_ID = "jarvis_perchance_verify_channel"
        private const val VERIFY_NEEDED_NOTIF_ID = 4211
        private const val VERIFY_OK_NOTIF_ID = 4212

        fun extractOrigin(url: String, fallback: String): String = runCatching {
            val u = URI(url.trim())
            if (u.scheme != null && u.host != null) "${u.scheme}://${u.host}" else fallback
        }.getOrDefault(fallback)

        private fun buildHostHtml(embedUrl: String, defaultImageApiUrl: String): String {
            val safeEmbedUrl = embedUrl.trim().ifBlank { DEFAULT_TEXT_EMBED_URL }
            val safeOrigin = extractOrigin(safeEmbedUrl, "https://text-generation.perchance.org")
            val safeImgUrl = defaultImageApiUrl.trim().ifBlank { DEFAULT_IMAGE_API_URL }
            return """
                <!DOCTYPE html>
                <html>
                <head>
                  <meta charset="utf-8" />
                  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                  <style>
                    html, body { margin: 0; padding: 0; background: #0B0C10; width: 100%; height: 100%; overflow: hidden; }
                    #perchanceFrame { width: 100%; height: 100%; min-width: 300px; min-height: 180px; border: 0; }
                    #imgHost { position: fixed; width: 384px; height: 384px; opacity: 0.01; pointer-events: none; left: 0; top: 0; z-index: -1; }
                  </style>
                </head>
                <body>
                  <iframe id="perchanceFrame" src="${escapeHtmlAttr(safeEmbedUrl)}" allow="cross-origin-isolated"></iframe>
                  <div id="imgHost"></div>
                  <script>
                    (function() {
                      const EMBED_ORIGIN = ${JSONObject.quote(safeOrigin)};
                      const DEFAULT_IMG_URL = ${JSONObject.quote(safeImgUrl)};
                      const frame = document.getElementById("perchanceFrame");
                      const imgHost = document.getElementById("imgHost");
                      const keepAliveTimers = {};
                      const pendingImages = {};

                      function postToEmbed(msg) {
                        if (!frame || !frame.contentWindow) return;
                        frame.contentWindow.postMessage(msg, EMBED_ORIGIN);
                      }

                      window.addEventListener("message", function(e) {
                        const data = e.data || {};
                        // 1) Official Perchance Image API v1 response
                        if (data.api === "perchance-image-api" && data.result) {
                          const r = data.result;
                          const rid = String(r.id || "");
                          if (rid && pendingImages[rid]) {
                            const entry = pendingImages[rid];
                            delete pendingImages[rid];
                            if (entry.frame && entry.frame.parentNode) entry.frame.parentNode.removeChild(entry.frame);
                            AndroidPerchanceBridge.onImageResult(
                              rid,
                              !!r.ok,
                              String(r.url || ""),
                              String(r.dataUrl || ""),
                              String(r.seed || ""),
                              String(r.error || "")
                            );
                          }
                          return;
                        }
                        // 2) image-generation.perchance.org/embed response
                        if (data.type === "finished" && data.dataUrl) {
                          const rid = String(data.id || Object.keys(pendingImages)[0] || "");
                          if (rid && pendingImages[rid]) {
                            const entry = pendingImages[rid];
                            delete pendingImages[rid];
                            if (entry.frame && entry.frame.parentNode) entry.frame.parentNode.removeChild(entry.frame);
                            AndroidPerchanceBridge.onImageResult(rid, true, "", String(data.dataUrl || ""), String(data.seedUsed || ""), "");
                          }
                          return;
                        }
                        // 3) Text embed messages
                        if (e.origin !== EMBED_ORIGIN && !String(e.origin || "").endsWith(".perchance.org")) return;
                        if (data.type === "embedIsReady") {
                          AndroidPerchanceBridge.onEmbedReady();
                          postToEmbed({ type: "preload" });
                        } else if (data.type === "verifying") {
                          AndroidPerchanceBridge.onVerifying();
                        } else if (data.type === "verified") {
                          AndroidPerchanceBridge.onVerified();
                        } else if (data.type === "streamData") {
                          const txt = (data.value && typeof data.value.text === "string") ? data.value.text : "";
                          AndroidPerchanceBridge.onStreamChunk(String(data.requestId || ""), txt);
                        } else if (data.type === "streamEnd") {
                          const rid = String(data.requestId || "");
                          if (keepAliveTimers[rid]) { clearInterval(keepAliveTimers[rid]); delete keepAliveTimers[rid]; }
                          AndroidPerchanceBridge.onStreamEnd(rid);
                        } else if (data.type === "streamError") {
                          const rid = String(data.requestId || "");
                          if (keepAliveTimers[rid]) { clearInterval(keepAliveTimers[rid]); delete keepAliveTimers[rid]; }
                          AndroidPerchanceBridge.onStreamError(rid, String(data.status || "unknown"));
                        }
                      });

                      window.jarvisRequestVerify = function() {
                        postToEmbed({ type: "verifyUser" });
                      };

                      window.jarvisStartStream = async function(payloadJson) {
                        try {
                          const req = JSON.parse(payloadJson);
                          const rid = req.requestId;
                          let instructionVal = req.instruction || "";
                          if (req.imageBase64 && req.imageMime) {
                            const binStr = atob(req.imageBase64);
                            const bytes = new Uint8Array(binStr.length);
                            for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
                            const blob = new Blob([bytes], { type: req.imageMime });
                            instructionVal = [instructionVal, blob];
                          }
                          const postData = {
                            instruction: instructionVal,
                            startWith: req.startWith || "",
                            stopSequences: req.stopSequences || [],
                            generatorName: req.generatorName || "ai-character-chat"
                          };
                          postToEmbed({ type: "startStream", requestId: rid, postData: postData });
                          if (keepAliveTimers[rid]) clearInterval(keepAliveTimers[rid]);
                          keepAliveTimers[rid] = setInterval(function() {
                            postToEmbed({ type: "streamKeepAlive", requestId: rid });
                          }, 2000);
                        } catch (err) {
                          AndroidPerchanceBridge.onStreamError("", "bridge_js_error: " + (err && err.message ? err.message : err));
                        }
                      };

                      window.jarvisStopStream = function(rid) {
                        if (keepAliveTimers[rid]) { clearInterval(keepAliveTimers[rid]); delete keepAliveTimers[rid]; }
                        postToEmbed({ type: "stopStream", requestId: rid });
                      };

                      window.jarvisGenerateImage = function(payloadJson) {
                        try {
                          const req = JSON.parse(payloadJson);
                          const rid = req.id;
                          const apiUrl = (req.imageApiUrl || DEFAULT_IMG_URL).trim();
                          const f = document.createElement("iframe");
                          f.style.width = "384px";
                          f.style.height = "384px";
                          f.style.border = "0";
                          if (apiUrl.indexOf("image-generation.perchance.org/embed") >= 0) {
                            const cfg = {
                              prompt: req.prompt || "",
                              negativePrompt: req.negativePrompt || "",
                              resolution: req.resolution || "768x768",
                              guidanceScale: 7,
                              seed: -1,
                              hideGalleryButtons: true,
                              iframeId: rid,
                              id: rid
                            };
                            f.src = apiUrl.split("#")[0] + "#" + encodeURIComponent(JSON.stringify(cfg));
                          } else {
                            const params = new URLSearchParams();
                            params.set("prompt", req.prompt || "");
                            params.set("format", "json");
                            params.set("id", rid);
                            if (req.resolution) params.set("resolution", req.resolution);
                            if (req.negativePrompt) params.set("negativePrompt", req.negativePrompt);
                            const sep = apiUrl.indexOf("?") >= 0 ? "&" : "?";
                            f.src = apiUrl + sep + params.toString();
                          }
                          pendingImages[rid] = { frame: f };
                          imgHost.appendChild(f);
                        } catch (err) {
                          AndroidPerchanceBridge.onImageResult("", false, "", "", "", "img_js_error: " + (err && err.message ? err.message : err));
                        }
                      };
                    })();
                  </script>
                </body>
                </html>
            """.trimIndent()
        }

        private fun escapeHtmlAttr(raw: String): String =
            raw.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    }
}
