#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_set>
#include <vector>

#include "llama.h"
#include "mtmd.h"
#include "mtmd-helper.h"

#define LOG_TAG "JarvisLlamaJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

std::once_flag g_backend_init_once;
std::mutex g_global_err_mutex;
std::string g_last_global_error;

static void set_global_error(const std::string & msg) {
    std::lock_guard<std::mutex> lock(g_global_err_mutex);
    g_last_global_error = msg;
}

struct JarvisEngineHandle {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    mtmd_context * mctx = nullptr;
    int32_t n_ctx = 2048;
    int32_t n_batch = 256;
    int32_t n_threads = 4;
    std::unordered_set<llama_token> stop_tokens;
    std::string last_error;
    std::atomic<bool> cancelled{false};
    std::mutex mutex;
};

static bool jarvis_abort_callback(void * user_data) {
    auto * flag = static_cast<std::atomic<bool> *>(user_data);
    return flag != nullptr && flag->load(std::memory_order_relaxed);
}

static void jarvis_log_callback(enum ggml_log_level level, const char * text, void * /*user_data*/) {
    if (!text) return;
    if (level == GGML_LOG_LEVEL_ERROR) {
        LOGE("%s", text);
    } else if (level == GGML_LOG_LEVEL_WARN) {
        LOGW("%s", text);
    }
}

static void collect_stop_tokens(const llama_vocab * vocab, std::unordered_set<llama_token> & out) {
    out.clear();
    if (!vocab) return;
    static const char * kStopMarkers[] = {
        "<|im_end|>",
        "<|im_start|>",
        "<|endoftext|>",
        "<end_of_turn>",
        "<start_of_turn>",
        "<|eot_id|>",
        "<eos>",
        "</s>"
    };
    for (const char * marker : kStopMarkers) {
        llama_token buf[4];
        int32_t n = llama_tokenize(
                vocab,
                marker,
                static_cast<int32_t>(std::strlen(marker)),
                buf,
                4,
                false,
                true);
        if (n == 1 && buf[0] >= 0) {
            out.insert(buf[0]);
        }
    }
}

static size_t utf8_complete_prefix_len(const std::string & s) {
    const size_t n = s.size();
    if (n == 0) return 0;

    size_t i = n;
    size_t cont = 0;
    while (i > 0 && cont < 4) {
        unsigned char c = static_cast<unsigned char>(s[i - 1]);
        if ((c & 0xC0) == 0x80) {
            --i;
            ++cont;
        } else {
            size_t expected = 1;
            if ((c & 0x80) == 0x00)      expected = 1;
            else if ((c & 0xE0) == 0xC0) expected = 2;
            else if ((c & 0xF0) == 0xE0) expected = 3;
            else if ((c & 0xF8) == 0xF0) expected = 4;
            else return n;

            size_t actual = 1 + cont;
            if (actual < expected) {
                return i - 1;
            }
            return n;
        }
    }
    return n;
}

static std::string sanitize_utf8(const std::string & input) {
    std::string out;
    out.reserve(input.size());
    const size_t n = input.size();
    size_t i = 0;
    while (i < n) {
        unsigned char c = static_cast<unsigned char>(input[i]);
        if (c < 0x80) {
            if (c != 0) out.push_back(static_cast<char>(c));
            ++i;
        } else if ((c & 0xE0) == 0xC0 && i + 1 < n &&
                   (static_cast<unsigned char>(input[i + 1]) & 0xC0) == 0x80) {
            out.append(input, i, 2);
            i += 2;
        } else if ((c & 0xF0) == 0xE0 && i + 2 < n &&
                   (static_cast<unsigned char>(input[i + 1]) & 0xC0) == 0x80 &&
                   (static_cast<unsigned char>(input[i + 2]) & 0xC0) == 0x80) {
            out.append(input, i, 3);
            i += 3;
        } else if ((c & 0xF8) == 0xF0 && i + 3 < n &&
                   (static_cast<unsigned char>(input[i + 1]) & 0xC0) == 0x80 &&
                   (static_cast<unsigned char>(input[i + 2]) & 0xC0) == 0x80 &&
                   (static_cast<unsigned char>(input[i + 3]) & 0xC0) == 0x80) {
            out.append(input, i, 4);
            i += 4;
        } else {
            out.push_back('?');
            ++i;
        }
    }
    return out;
}

static bool emit_text_to_java(JNIEnv * env, jobject callback, jmethodID on_token_mid, const std::string & text) {
    if (text.empty()) return true;
    std::string safe = sanitize_utf8(text);
    if (safe.empty()) return true;

    jstring jpiece = env->NewStringUTF(safe.c_str());
    if (!jpiece) {
        env->ExceptionClear();
        return false;
    }
    jboolean cont = env->CallBooleanMethod(callback, on_token_mid, jpiece);
    env->DeleteLocalRef(jpiece);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }
    return cont == JNI_TRUE;
}

static size_t find_earliest_stop_sequence(const std::string & buf) {
    static const char * kStopSeqs[] = {
        "<|im_end|>",
        "<|im_start|>",
        "<end_of_turn>",
        "<start_of_turn>",
        "<|endoftext|>",
        "\n<|im_start|>",
        "\n<start_of_turn>"
    };
    size_t best = std::string::npos;
    for (const char * seq : kStopSeqs) {
        size_t pos = buf.find(seq);
        if (pos != std::string::npos && (best == std::string::npos || pos < best)) {
            best = pos;
        }
    }
    return best;
}

static bool has_partial_stop_prefix_at_end(const std::string & buf) {
    static const char * kStopSeqs[] = {
        "<|im_end|>",
        "<|im_start|>",
        "<end_of_turn>",
        "<start_of_turn>",
        "<|endoftext|>"
    };
    for (const char * seq : kStopSeqs) {
        const size_t slen = std::strlen(seq);
        const size_t maxCheck = std::min(slen - 1, buf.size());
        for (size_t k = 1; k <= maxCheck; ++k) {
            if (buf.compare(buf.size() - k, k, seq, 0, k) == 0) {
                return true;
            }
        }
    }
    return false;
}

} // namespace

extern "C" {

JNIEXPORT void JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeInitBackend(JNIEnv *, jobject) {
    std::call_once(g_backend_init_once, []() {
        llama_log_set(jarvis_log_callback, nullptr);
        mtmd_helper_log_set(jarvis_log_callback, nullptr);
        llama_backend_init();
        LOGI("llama.cpp backend initialized");
    });
}

JNIEXPORT jstring JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeGetLastError(
        JNIEnv * env,
        jobject,
        jlong handlePtr) {
    auto * handle = reinterpret_cast<JarvisEngineHandle *>(handlePtr);
    if (handle && !handle->last_error.empty()) {
        return env->NewStringUTF(handle->last_error.c_str());
    }
    std::lock_guard<std::mutex> lock(g_global_err_mutex);
    return env->NewStringUTF(g_last_global_error.c_str());
}

JNIEXPORT jlong JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeLoadModel(
        JNIEnv * env,
        jobject,
        jstring jModelPath,
        jstring jMmprojPath,
        jint nCtx,
        jint nThreads) {
    if (!jModelPath) {
        set_global_error("Путь к модели пуст");
        return 0;
    }

    const char * modelPathC = env->GetStringUTFChars(jModelPath, nullptr);
    std::string modelPath(modelPathC ? modelPathC : "");
    env->ReleaseStringUTFChars(jModelPath, modelPathC);

    std::string mmprojPath;
    if (jMmprojPath != nullptr) {
        const char * mmC = env->GetStringUTFChars(jMmprojPath, nullptr);
        if (mmC) mmprojPath = mmC;
        env->ReleaseStringUTFChars(jMmprojPath, mmC);
    }

    auto * handle = new JarvisEngineHandle();
    handle->n_ctx = nCtx > 256 ? nCtx : 2048;
    handle->n_batch = 256;
    handle->n_threads = nThreads > 0 ? nThreads : 4;

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0;

    handle->model = llama_model_load_from_file(modelPath.c_str(), mparams);
    if (!handle->model) {
        LOGE("Failed to load GGUF model from %s", modelPath.c_str());
        set_global_error("llama_model_load_from_file не смог открыть GGUF-файл");
        delete handle;
        return 0;
    }

    collect_stop_tokens(llama_model_get_vocab(handle->model), handle->stop_tokens);

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(handle->n_ctx);
    cparams.n_batch = static_cast<uint32_t>(handle->n_batch);
    cparams.n_ubatch = static_cast<uint32_t>(handle->n_batch);
    cparams.n_threads = handle->n_threads;
    cparams.n_threads_batch = handle->n_threads;
    cparams.no_perf = true;
    cparams.abort_callback = jarvis_abort_callback;
    cparams.abort_callback_data = &handle->cancelled;

    handle->ctx = llama_init_from_model(handle->model, cparams);
    if (!handle->ctx) {
        LOGE("Failed to create llama_context (n_ctx=%d)", handle->n_ctx);
        set_global_error("Не хватило памяти для создания контекста n_ctx=" + std::to_string(handle->n_ctx));
        llama_model_free(handle->model);
        delete handle;
        return 0;
    }

    if (!mmprojPath.empty()) {
        mtmd_context_params mtmdParams = mtmd_context_params_default();
        mtmdParams.use_gpu = false;
        mtmdParams.print_timings = false;
        mtmdParams.n_threads = handle->n_threads;
        mtmdParams.warmup = false;
        mtmdParams.image_max_tokens = 512;

        handle->mctx = mtmd_init_from_file(mmprojPath.c_str(), handle->model, mtmdParams);
        if (!handle->mctx) {
            LOGW("Vision projector failed to load (%s); continuing in text-only mode", mmprojPath.c_str());
        } else {
            LOGI("Loaded vision projector successfully (vision=%d)", mtmd_support_vision(handle->mctx) ? 1 : 0);
        }
    }

    set_global_error("");
    LOGI("Model loaded: n_ctx=%d n_threads=%d stop_tokens=%zu", handle->n_ctx, handle->n_threads, handle->stop_tokens.size());
    return reinterpret_cast<jlong>(handle);
}

JNIEXPORT jboolean JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeSupportsVision(
        JNIEnv *,
        jobject,
        jlong handlePtr) {
    auto * handle = reinterpret_cast<JarvisEngineHandle *>(handlePtr);
    if (!handle || !handle->mctx) return JNI_FALSE;
    return mtmd_support_vision(handle->mctx) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeDefaultMediaMarker(
        JNIEnv * env,
        jobject) {
    return env->NewStringUTF(mtmd_default_marker());
}

JNIEXPORT void JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeCancel(
        JNIEnv *,
        jobject,
        jlong handlePtr) {
    auto * handle = reinterpret_cast<JarvisEngineHandle *>(handlePtr);
    if (handle) {
        handle->cancelled.store(true, std::memory_order_relaxed);
    }
}

JNIEXPORT void JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeFreeModel(
        JNIEnv *,
        jobject,
        jlong handlePtr) {
    auto * handle = reinterpret_cast<JarvisEngineHandle *>(handlePtr);
    if (!handle) return;
    handle->cancelled.store(true, std::memory_order_relaxed);
    {
        std::lock_guard<std::mutex> lock(handle->mutex);
        if (handle->mctx) {
            mtmd_free(handle->mctx);
            handle->mctx = nullptr;
        }
        if (handle->ctx) {
            llama_free(handle->ctx);
            handle->ctx = nullptr;
        }
        if (handle->model) {
            llama_model_free(handle->model);
            handle->model = nullptr;
        }
    }
    delete handle;
    LOGI("Model resources freed");
}

// Return codes:
//   0  = success
//   1  = cancelled by user
//  -1  = invalid handle / model not loaded
//  -2  = tokenization failed
//  -3  = prompt decode failed
//  -4  = vision projector missing or image load failed
//  -5  = token decode failed
JNIEXPORT jint JNICALL
Java_ru_jarvis_assistant_core_inference_NativeLlamaBridge_nativeGenerate(
        JNIEnv * env,
        jobject,
        jlong handlePtr,
        jstring jPrompt,
        jstring jImagePath,
        jint maxTokens,
        jfloat temperature,
        jobject callback) {
    auto * handle = reinterpret_cast<JarvisEngineHandle *>(handlePtr);
    if (!handle || !handle->model || !handle->ctx || !jPrompt || !callback) {
        return -1;
    }

    std::lock_guard<std::mutex> lock(handle->mutex);
    handle->cancelled.store(false, std::memory_order_relaxed);
    handle->last_error.clear();

    jclass cbClass = env->GetObjectClass(callback);
    jmethodID onTokenMid = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)Z");
    env->DeleteLocalRef(cbClass);
    if (!onTokenMid) return -1;

    const char * promptC = env->GetStringUTFChars(jPrompt, nullptr);
    std::string prompt(promptC ? promptC : "");
    env->ReleaseStringUTFChars(jPrompt, promptC);

    std::string imagePath;
    if (jImagePath != nullptr) {
        const char * imgC = env->GetStringUTFChars(jImagePath, nullptr);
        if (imgC) imagePath = imgC;
        env->ReleaseStringUTFChars(jImagePath, imgC);
    }

    const llama_vocab * vocab = llama_model_get_vocab(handle->model);
    const bool addBos = llama_vocab_get_add_bos(vocab);
    llama_memory_clear(llama_get_memory(handle->ctx), true);

    llama_pos n_past = 0;

    if (!imagePath.empty()) {
        if (!handle->mctx || !mtmd_support_vision(handle->mctx)) {
            handle->last_error = "Модуль зрения (mmproj) не загружен для активной модели.";
            LOGE("Image requested but vision projector is not loaded");
            return -4;
        }
        auto initOpt = mtmd_helper_init_opt_default();
        auto bmpWrapper = mtmd_helper_bitmap_init_from_file(handle->mctx, imagePath.c_str(), false, initOpt);
        if (!bmpWrapper.bitmap) {
            handle->last_error = "libmtmd не смог декодировать подготовленный JPEG-файл.";
            LOGE("Failed to decode image for mtmd: %s", imagePath.c_str());
            return -4;
        }

        const mtmd_bitmap * bitmaps[1] = { bmpWrapper.bitmap };
        mtmd_input_chunks * chunks = mtmd_input_chunks_init();
        mtmd_input_text inpText;
        inpText.text = prompt.c_str();
        inpText.text_len = prompt.size();
        inpText.add_special = addBos;
        inpText.parse_special = true;

        int32_t tokRes = mtmd_tokenize(handle->mctx, chunks, &inpText, bitmaps, 1);
        if (tokRes != 0) {
            handle->last_error = "Ошибка токенизации мультимодального промпта (код " + std::to_string(tokRes) + ").";
            LOGE("mtmd_tokenize failed with code %d", tokRes);
            mtmd_input_chunks_free(chunks);
            mtmd_bitmap_free(bmpWrapper.bitmap);
            return -2;
        }

        llama_pos new_n_past = 0;
        int32_t evalRes = mtmd_helper_eval_chunks(
                handle->mctx,
                handle->ctx,
                chunks,
                0,
                0,
                handle->n_batch,
                true,
                &new_n_past);

        mtmd_input_chunks_free(chunks);
        mtmd_bitmap_free(bmpWrapper.bitmap);

        if (handle->cancelled.load(std::memory_order_relaxed)) {
            return 1;
        }
        if (evalRes != 0) {
            handle->last_error = "Ошибка обработки изображения в mtmd_helper_eval_chunks (код " + std::to_string(evalRes) + ").";
            LOGE("mtmd_helper_eval_chunks failed with code %d", evalRes);
            return -3;
        }
        n_past = new_n_past;
    } else {
        int32_t maxPromptTokens = handle->n_ctx - 128;
        if (maxPromptTokens < 128) maxPromptTokens = 128;

        int32_t nNeeded = -llama_tokenize(
                vocab,
                prompt.c_str(),
                static_cast<int32_t>(prompt.size()),
                nullptr,
                0,
                addBos,
                true);
        if (nNeeded <= 0) {
            handle->last_error = "Не удалось токенизировать запрос.";
            return -2;
        }

        std::vector<llama_token> tokens(static_cast<size_t>(nNeeded));
        int32_t nTok = llama_tokenize(
                vocab,
                prompt.c_str(),
                static_cast<int32_t>(prompt.size()),
                tokens.data(),
                static_cast<int32_t>(tokens.size()),
                addBos,
                true);
        if (nTok <= 0) {
            handle->last_error = "Ошибка токенизации запроса.";
            return -2;
        }
        tokens.resize(static_cast<size_t>(nTok));

        if (static_cast<int32_t>(tokens.size()) > maxPromptTokens) {
            tokens.erase(tokens.begin(), tokens.end() - maxPromptTokens);
        }

        llama_batch batch = llama_batch_init(handle->n_batch, 0, 1);
        for (size_t offset = 0; offset < tokens.size(); offset += static_cast<size_t>(handle->n_batch)) {
            if (handle->cancelled.load(std::memory_order_relaxed)) {
                llama_batch_free(batch);
                return 1;
            }
            size_t chunkCount = std::min(static_cast<size_t>(handle->n_batch), tokens.size() - offset);
            batch.n_tokens = static_cast<int32_t>(chunkCount);
            for (size_t i = 0; i < chunkCount; ++i) {
                batch.token[i] = tokens[offset + i];
                batch.pos[i] = n_past + static_cast<llama_pos>(i);
                batch.n_seq_id[i] = 1;
                batch.seq_id[i][0] = 0;
                batch.logits[i] = (offset + i + 1 == tokens.size()) ? 1 : 0;
            }
            if (llama_decode(handle->ctx, batch) != 0) {
                llama_batch_free(batch);
                handle->last_error = "Ошибка декодирования промпта (llama_decode).";
                return handle->cancelled.load(std::memory_order_relaxed) ? 1 : -3;
            }
            n_past += static_cast<llama_pos>(chunkCount);
        }
        llama_batch_free(batch);
    }

    auto sparams = llama_sampler_chain_default_params();
    llama_sampler * smpl = llama_sampler_chain_init(sparams);
    if (temperature <= 0.01f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.90f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_min_p(0.05f, 1));
        llama_sampler_chain_add(
                smpl,
                llama_sampler_init_penalties(llama_vocab_n_tokens(vocab), 64, 1.05f, 0.0f, 0.0f));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    llama_batch genBatch = llama_batch_init(1, 0, 1);
    std::string pending;
    int32_t limit = maxTokens > 0 ? maxTokens : 450;
    int result = 0;

    for (int32_t step = 0; step < limit; ++step) {
        if (handle->cancelled.load(std::memory_order_relaxed)) {
            result = 1;
            break;
        }
        if (n_past >= handle->n_ctx - 4) {
            break;
        }

        llama_token token = llama_sampler_sample(smpl, handle->ctx, -1);
        llama_sampler_accept(smpl, token);

        if (llama_vocab_is_eog(vocab, token) || handle->stop_tokens.count(token) > 0) {
            break;
        }

        char pieceBuf[256];
        int32_t pieceLen = llama_token_to_piece(vocab, token, pieceBuf, sizeof(pieceBuf), 0, true);
        if (pieceLen < 0) {
            std::vector<char> largeBuf(static_cast<size_t>(-pieceLen) + 1);
            pieceLen = llama_token_to_piece(vocab, token, largeBuf.data(), static_cast<int32_t>(largeBuf.size()), 0, true);
            if (pieceLen > 0) {
                pending.append(largeBuf.data(), static_cast<size_t>(pieceLen));
            }
        } else if (pieceLen > 0) {
            pending.append(pieceBuf, static_cast<size_t>(pieceLen));
        }

        // Check if any turn-delimiter stop sequence appeared inside pending text
        size_t stopPos = find_earliest_stop_sequence(pending);
        if (stopPos != std::string::npos) {
            if (stopPos > 0) {
                size_t validLen = utf8_complete_prefix_len(pending.substr(0, stopPos));
                if (validLen > 0) {
                    emit_text_to_java(env, callback, onTokenMid, pending.substr(0, validLen));
                }
            }
            pending.clear();
            break;
        }

        // Hold back trailing bytes only while they might be the start of a stop tag or split UTF-8 codepoint
        if (!has_partial_stop_prefix_at_end(pending)) {
            size_t emitLen = utf8_complete_prefix_len(pending);
            if (emitLen > 0) {
                std::string chunk = pending.substr(0, emitLen);
                pending.erase(0, emitLen);
                if (!emit_text_to_java(env, callback, onTokenMid, chunk)) {
                    handle->cancelled.store(true, std::memory_order_relaxed);
                    result = 1;
                    break;
                }
            }
        }

        genBatch.n_tokens = 1;
        genBatch.token[0] = token;
        genBatch.pos[0] = n_past++;
        genBatch.n_seq_id[0] = 1;
        genBatch.seq_id[0][0] = 0;
        genBatch.logits[0] = 1;

        if (llama_decode(handle->ctx, genBatch) != 0) {
            handle->last_error = "Ошибка генерации следующего токена (llama_decode).";
            result = handle->cancelled.load(std::memory_order_relaxed) ? 1 : -5;
            break;
        }
    }

    if (result == 0 && !pending.empty()) {
        size_t stopPos = find_earliest_stop_sequence(pending);
        std::string tail = (stopPos == std::string::npos) ? pending : pending.substr(0, stopPos);
        if (!tail.empty()) {
            emit_text_to_java(env, callback, onTokenMid, tail);
        }
    }

    llama_batch_free(genBatch);
    llama_sampler_free(smpl);
    return result;
}

} // extern "C"
