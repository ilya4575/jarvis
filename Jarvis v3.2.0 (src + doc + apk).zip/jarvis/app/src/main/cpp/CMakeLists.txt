cmake_minimum_required(VERSION 3.22.1)
project(jarvis_llama LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

if(NOT DEFINED JARVIS_LLAMA_CPP_DIR OR NOT EXISTS "${JARVIS_LLAMA_CPP_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "JARVIS_LLAMA_CPP_DIR must point to a valid llama.cpp checkout (got: '${JARVIS_LLAMA_CPP_DIR}')")
endif()

# Portable ARM64 CPU configuration for broad Android 10+ compatibility (including older ARMv8.0 CPUs)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(GGML_CPU_KLEIDIAI OFF CACHE BOOL "" FORCE)
set(GGML_BACKEND_DL OFF CACHE BOOL "" FORCE)
set(GGML_VULKAN OFF CACHE BOOL "" FORCE)
set(GGML_CUDA OFF CACHE BOOL "" FORCE)
set(GGML_METAL OFF CACHE BOOL "" FORCE)
set(GGML_RPC OFF CACHE BOOL "" FORCE)

set(LLAMA_OPENSSL OFF CACHE BOOL "" FORCE)
set(LLAMA_SUBPROCESS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_APP OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_MTMD ON CACHE BOOL "" FORCE)
set(MTMD_VIDEO OFF CACHE BOOL "" FORCE)

add_subdirectory("${JARVIS_LLAMA_CPP_DIR}" "${CMAKE_CURRENT_BINARY_DIR}/llama_build" EXCLUDE_FROM_ALL)

# Avoid large unity compilation units so low-RAM environments (AndroidIDE / small CI runners) compile reliably
if(TARGET mtmd)
    set_target_properties(mtmd PROPERTIES UNITY_BUILD OFF)
endif()

add_library(jarvis_llama SHARED
    jarvis_llama_jni.cpp
)

target_include_directories(jarvis_llama PRIVATE
    "${JARVIS_LLAMA_CPP_DIR}/include"
    "${JARVIS_LLAMA_CPP_DIR}/ggml/include"
    "${JARVIS_LLAMA_CPP_DIR}/tools/mtmd"
)

target_link_libraries(jarvis_llama PRIVATE
    llama
    mtmd
    ggml
    android
    log
)

target_compile_options(jarvis_llama PRIVATE
    -O2
    -fvisibility=hidden
    -ffunction-sections
    -fdata-sections
)

target_link_options(jarvis_llama PRIVATE
    -Wl,--gc-sections
    -Wl,--exclude-libs,ALL
)
